(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define([], factory);
	else {
		var a = factory();
		for(var i in a) (typeof exports === 'object' ? exports : root)[i] = a[i];
	}
})(self, () => {
return /******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/@siteimprove/alfa-array/dist/array.js":
/*!************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-array/dist/array.js ***!
  \************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Array: () => (/* binding */ Array)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_clone__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-clone */ "./node_modules/@siteimprove/alfa-clone/dist/index.js");
/* harmony import */ var _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @siteimprove/alfa-comparable */ "./node_modules/@siteimprove/alfa-comparable/dist/index.js");
/* harmony import */ var _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @siteimprove/alfa-equatable */ "./node_modules/@siteimprove/alfa-equatable/dist/index.js");
/* harmony import */ var _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @siteimprove/alfa-iterable */ "./node_modules/@siteimprove/alfa-iterable/dist/index.js");
/* harmony import */ var _siteimprove_alfa_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @siteimprove/alfa-json */ "./node_modules/@siteimprove/alfa-json/dist/index.js");
/* harmony import */ var _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @siteimprove/alfa-option */ "./node_modules/@siteimprove/alfa-option/dist/index.js");
/* harmony import */ var _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @siteimprove/alfa-predicate */ "./node_modules/@siteimprove/alfa-predicate/dist/index.js");
/* harmony import */ var _builtin_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./builtin.js */ "./node_modules/@siteimprove/alfa-array/dist/builtin.js");








const { not } = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_6__.Predicate;
const { compareComparable } = _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_1__.Comparable;
/**
 * @public
 */
var Array;
(function (Array) {
    function isArray(value) {
        return _builtin_js__WEBPACK_IMPORTED_MODULE_7__.Array.isArray(value);
    }
    Array.isArray = isArray;
    function of(...values) {
        return values;
    }
    Array.of = of;
    function empty() {
        return [];
    }
    Array.empty = empty;
    function allocate(capacity) {
        return new _builtin_js__WEBPACK_IMPORTED_MODULE_7__.Array(capacity);
    }
    Array.allocate = allocate;
    /**
     * @remarks
     * Unlike the built-in function of the same name, this function will pass
     * along existing arrays as-is instead of returning a copy.
     */
    function from(iterable) {
        if (isArray(iterable)) {
            return iterable;
        }
        return [...iterable];
    }
    Array.from = from;
    function size(array) {
        return array.length;
    }
    Array.size = size;
    function isEmpty(array) {
        return array.length === 0;
    }
    Array.isEmpty = isEmpty;
    function copy(array) {
        return array.slice(0);
    }
    Array.copy = copy;
    function clone(array) {
        return array.map(_siteimprove_alfa_clone__WEBPACK_IMPORTED_MODULE_0__.Clone.clone);
    }
    Array.clone = clone;
    function forEach(array, callback) {
        for (let i = 0, n = array.length; i < n; i++) {
            callback(array[i], i);
        }
    }
    Array.forEach = forEach;
    function map(array, mapper) {
        const result = new _builtin_js__WEBPACK_IMPORTED_MODULE_7__.Array(array.length);
        for (let i = 0, n = array.length; i < n; i++) {
            result[i] = mapper(array[i], i);
        }
        return result;
    }
    Array.map = map;
    function flatMap(array, mapper) {
        const result = empty();
        for (let i = 0, n = array.length; i < n; i++) {
            result.push(...mapper(array[i], i));
        }
        return result;
    }
    Array.flatMap = flatMap;
    function flatten(array) {
        return flatMap(array, (array) => array);
    }
    Array.flatten = flatten;
    function reduce(array, reducer, accumulator) {
        for (let i = 0, n = array.length; i < n; i++) {
            accumulator = reducer(accumulator, array[i], i);
        }
        return accumulator;
    }
    Array.reduce = reduce;
    function reduceWhile(array, predicate, reducer, accumulator) {
        for (let i = 0, n = array.length; i < n; i++) {
            const value = array[i];
            if (predicate(value, i)) {
                accumulator = reducer(accumulator, value, i);
            }
            else {
                break;
            }
        }
        return accumulator;
    }
    Array.reduceWhile = reduceWhile;
    function reduceUntil(array, predicate, reducer, accumulator) {
        return reduceWhile(array, not(predicate), reducer, accumulator);
    }
    Array.reduceUntil = reduceUntil;
    function apply(array, mapper) {
        return flatMap(mapper, (mapper) => map(array, mapper));
    }
    Array.apply = apply;
    function filter(array, predicate) {
        const result = empty();
        for (let i = 0, n = array.length; i < n; i++) {
            const value = array[i];
            if (predicate(value, i)) {
                result.push(value);
            }
        }
        return result;
    }
    Array.filter = filter;
    function reject(array, predicate) {
        return filter(array, not(predicate));
    }
    Array.reject = reject;
    function find(array, predicate) {
        for (let i = 0, n = array.length; i < n; i++) {
            const value = array[i];
            if (predicate(value, i)) {
                return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__.Option.of(value);
            }
        }
        return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__.None;
    }
    Array.find = find;
    function findLast(array, predicate) {
        for (let i = array.length - 1; i >= 0; i--) {
            const value = array[i];
            if (predicate(value, i)) {
                return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__.Option.of(value);
            }
        }
        return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__.None;
    }
    Array.findLast = findLast;
    function includes(array, value) {
        return some(array, _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_6__.Predicate.equals(value));
    }
    Array.includes = includes;
    function collect(array, mapper) {
        const result = empty();
        for (let i = 0, n = array.length; i < n; i++) {
            for (const value of mapper(array[i], i)) {
                result.push(value);
            }
        }
        return result;
    }
    Array.collect = collect;
    function collectFirst(array, mapper) {
        for (let i = 0, n = array.length; i < n; i++) {
            const value = mapper(array[i], i);
            if (value.isSome()) {
                return value;
            }
        }
        return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__.None;
    }
    Array.collectFirst = collectFirst;
    function some(array, predicate) {
        for (let i = 0, n = array.length; i < n; i++) {
            if (predicate(array[i], i)) {
                return true;
            }
        }
        return false;
    }
    Array.some = some;
    function none(array, predicate) {
        return every(array, not(predicate));
    }
    Array.none = none;
    function every(array, predicate) {
        for (let i = 0, n = array.length; i < n; i++) {
            if (!predicate(array[i], i)) {
                return false;
            }
        }
        return true;
    }
    Array.every = every;
    function count(array, predicate) {
        return reduce(array, (count, value, index) => (predicate(value, index) ? count + 1 : count), 0);
    }
    Array.count = count;
    function distinct(array) {
        const result = empty();
        for (let i = 0, n = array.length; i < n; i++) {
            const value = array[i];
            if (result.some(_siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_6__.Predicate.equals(value))) {
                continue;
            }
            result.push(value);
        }
        return result;
    }
    Array.distinct = distinct;
    function get(array, index) {
        return index < array.length ? _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__.Option.of(array[index]) : _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__.None;
    }
    Array.get = get;
    function has(array, index) {
        return index < array.length;
    }
    Array.has = has;
    function set(array, index, value) {
        if (index < array.length) {
            array[index] = value;
        }
        return array;
    }
    Array.set = set;
    function insert(array, index, value) {
        if (index <= array.length) {
            array.splice(index, 0, value);
        }
        return array;
    }
    Array.insert = insert;
    function append(array, value) {
        array.push(value);
        return array;
    }
    Array.append = append;
    function prepend(array, value) {
        array.unshift(value);
        return array;
    }
    Array.prepend = prepend;
    function concat(array, ...iterables) {
        return [..._siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_3__.Iterable.concat(array, ...iterables)];
    }
    Array.concat = concat;
    function subtract(array, ...iterables) {
        return [..._siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_3__.Iterable.subtract(array, ...iterables)];
    }
    Array.subtract = subtract;
    function intersect(array, ...iterables) {
        return [..._siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_3__.Iterable.intersect(array, ...iterables)];
    }
    Array.intersect = intersect;
    function zip(array, iterable) {
        const result = empty();
        const it = _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_3__.Iterable.iterator(iterable);
        for (let i = 0, n = array.length; i < n; i++) {
            const next = it.next();
            if (next.done === true) {
                break;
            }
            result.push([array[i], next.value]);
        }
        return result;
    }
    Array.zip = zip;
    function first(array) {
        return array.length > 0 ? _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__.Option.of(array[0]) : _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__.None;
    }
    Array.first = first;
    function last(array) {
        return array.length > 0 ? _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__.Option.of(array[array.length - 1]) : _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__.None;
    }
    Array.last = last;
    function sort(array) {
        return sortWith(array, compareComparable);
    }
    Array.sort = sort;
    function sortWith(array, comparer) {
        return array.sort(comparer);
    }
    Array.sortWith = sortWith;
    function compare(a, b) {
        return compareWith(a, b, compareComparable);
    }
    Array.compare = compare;
    function compareWith(a, b, comparer) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_3__.Iterable.compareWith(a, b, comparer);
    }
    Array.compareWith = compareWith;
    function search(array, value, comparer) {
        let lower = 0;
        let upper = array.length - 1;
        while (lower <= upper) {
            const middle = (lower + (upper - lower) / 2) >>> 0;
            switch (comparer(value, array[middle])) {
                case _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_1__.Comparison.Greater:
                    lower = middle + 1;
                    break;
                case _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_1__.Comparison.Less:
                    upper = middle - 1;
                    break;
                case _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_1__.Comparison.Equal:
                    return middle;
            }
        }
        return lower;
    }
    Array.search = search;
    function equals(a, b) {
        if (a.length !== b.length) {
            return false;
        }
        for (let i = 0, n = a.length; i < n; i++) {
            if (!_siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_2__.Equatable.equals(a[i], b[i])) {
                return false;
            }
        }
        return true;
    }
    Array.equals = equals;
    function hash(array, hash) {
        for (let i = 0, n = array.length; i < n; i++) {
            hash.writeUnknown(array[i]);
        }
        hash.writeUint32(array.length);
    }
    Array.hash = hash;
    function iterator(array) {
        return array[Symbol.iterator]();
    }
    Array.iterator = iterator;
    function toJSON(array, options) {
        return array.map((value) => _siteimprove_alfa_json__WEBPACK_IMPORTED_MODULE_4__.Serializable.toJSON(value, options));
    }
    Array.toJSON = toJSON;
})(Array || (Array = {}));
//# sourceMappingURL=array.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-array/dist/builtin.js":
/*!**************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-array/dist/builtin.js ***!
  \**************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Array: () => (/* binding */ Builtin)
/* harmony export */ });
// This file defines exports from the builtin `Array` constructor for internal
// use only.
/**
 * @internal
 */
const Builtin = Array;

//# sourceMappingURL=builtin.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-array/dist/index.js":
/*!************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-array/dist/index.js ***!
  \************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Array: () => (/* reexport safe */ _array_js__WEBPACK_IMPORTED_MODULE_0__.Array)
/* harmony export */ });
/* harmony import */ var _array_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./array.js */ "./node_modules/@siteimprove/alfa-array/dist/array.js");
/**
 * This package provides functionality for working with arrays.
 *
 * @packageDocumentation
 */

//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-bits/dist/bits.js":
/*!**********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-bits/dist/bits.js ***!
  \**********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Bits: () => (/* binding */ Bits)
/* harmony export */ });
/**
 * @public
 */
var Bits;
(function (Bits) {
    function bit(i) {
        return 1 << i;
    }
    Bits.bit = bit;
    function set(bits, i) {
        return bits | bit(i);
    }
    Bits.set = set;
    function clear(bits, i) {
        return bits & ~bit(i);
    }
    Bits.clear = clear;
    function test(bits, i) {
        return (bits & bit(i)) !== 0;
    }
    Bits.test = test;
    function take(bits, n) {
        return bits & ((1 << n) - 1);
    }
    Bits.take = take;
    function skip(bits, n) {
        return bits >>> n;
    }
    Bits.skip = skip;
    /**
     * @remarks
     * This is a 32-bit variant of the 64-bit population count algorithm outlined
     * on Wikipedia. Until ECMAScript natively provides an efficient population
     * count algorithm, this is the best we can do.
     *
     * {@link https://en.wikipedia.org/wiki/Hamming_weight}
     */
    function popCount(bits) {
        bits -= (bits >> 1) & 0x55555555;
        bits = (bits & 0x33333333) + ((bits >> 2) & 0x33333333);
        bits = (bits + (bits >> 4)) & 0x0f0f0f0f;
        bits += bits >> 8;
        bits += bits >> 16;
        return bits & 0x7f;
    }
    Bits.popCount = popCount;
})(Bits || (Bits = {}));
//# sourceMappingURL=bits.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-bits/dist/index.js":
/*!***********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-bits/dist/index.js ***!
  \***********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Bits: () => (/* reexport safe */ _bits_js__WEBPACK_IMPORTED_MODULE_0__.Bits)
/* harmony export */ });
/* harmony import */ var _bits_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./bits.js */ "./node_modules/@siteimprove/alfa-bits/dist/bits.js");

//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-clone/dist/clone.js":
/*!************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-clone/dist/clone.js ***!
  \************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Clone: () => (/* binding */ Clone)
/* harmony export */ });
/**
 * @public
 */
var Clone;
(function (Clone) {
    function clone(value) {
        return value.clone();
    }
    Clone.clone = clone;
})(Clone || (Clone = {}));
//# sourceMappingURL=clone.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-clone/dist/index.js":
/*!************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-clone/dist/index.js ***!
  \************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Clone: () => (/* reexport safe */ _clone_js__WEBPACK_IMPORTED_MODULE_0__.Clone)
/* harmony export */ });
/* harmony import */ var _clone_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./clone.js */ "./node_modules/@siteimprove/alfa-clone/dist/clone.js");

//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-comparable/dist/comparable.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-comparable/dist/comparable.js ***!
  \**********************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Comparable: () => (/* binding */ Comparable)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_refinement__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-refinement */ "./node_modules/@siteimprove/alfa-refinement/dist/index.js");
/* harmony import */ var _comparison_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./comparison.js */ "./node_modules/@siteimprove/alfa-comparable/dist/comparison.js");


const { isString, isNumber, isBigInt, isBoolean, isFunction, isObject } = _siteimprove_alfa_refinement__WEBPACK_IMPORTED_MODULE_0__.Refinement;
/**
 * This namespace provides additional functions for the
 * {@link (Comparable:interface)} interface.
 *
 * @public
 */
var Comparable;
(function (Comparable) {
    /**
     * Check if an unknown value implements the {@link (Comparable:interface)}
     * interface.
     */
    function isComparable(value) {
        return isObject(value) && isFunction(value.compare);
    }
    Comparable.isComparable = isComparable;
    function compare(a, b) {
        if (isString(a)) {
            return compareString(a, b);
        }
        if (isNumber(a)) {
            return compareNumber(a, b);
        }
        if (isBigInt(a)) {
            return compareBigInt(a, b);
        }
        if (isBoolean(a)) {
            return compareBoolean(a, b);
        }
        return compareComparable(a, b);
    }
    Comparable.compare = compare;
    /**
     * @remarks
     * This should only be used in cases where branch mispredictions caused by the
     * more general {@link (Comparable:namespace).(compare:1)} are undesired.
     */
    function compareString(a, b) {
        return comparePrimitive(a, b);
    }
    Comparable.compareString = compareString;
    /**
     * @remarks
     * This should only be used in cases where branch mispredictions caused by the
     * more general {@link (Comparable:namespace).(compare:2)} are undesired.
     */
    function compareNumber(a, b) {
        return comparePrimitive(a, b);
    }
    Comparable.compareNumber = compareNumber;
    /**
     * @remarks
     * This should only be used in cases where branch mispredictions caused by the
     * more general {@link (Comparable:namespace).(compare:3)} are undesired.
     */
    function compareBigInt(a, b) {
        return comparePrimitive(a, b);
    }
    Comparable.compareBigInt = compareBigInt;
    /**
     * @remarks
     * This should only be used in cases where branch mispredictions caused by the
     * more general {@link (Comparable:namespace).(compare:4)} are undesired.
     */
    function compareBoolean(a, b) {
        return comparePrimitive(a, b);
    }
    Comparable.compareBoolean = compareBoolean;
    /**
     * @remarks
     * This should only be used in cases where branch mispredictions caused by the
     * more general {@link (Comparable:namespace).(compare:5)} are undesired.
     */
    function compareComparable(a, b) {
        return a.compare(b);
    }
    Comparable.compareComparable = compareComparable;
    /**
     * Compare two primitive values.
     */
    function comparePrimitive(a, b) {
        if (a < b) {
            return _comparison_js__WEBPACK_IMPORTED_MODULE_1__.Comparison.Less;
        }
        if (a > b) {
            return _comparison_js__WEBPACK_IMPORTED_MODULE_1__.Comparison.Greater;
        }
        return _comparison_js__WEBPACK_IMPORTED_MODULE_1__.Comparison.Equal;
    }
    /**
     * Compare tuples lexicographically
     *
     * {@link https://en.wikipedia.org/wiki/Lexicographic_order}
     */
    function compareLexicographically(a, b, comparer) {
        for (let i = 0; i < a.length; i++) {
            const comparison = comparer[i](a[i], b[i]);
            if (comparison === _comparison_js__WEBPACK_IMPORTED_MODULE_1__.Comparison.Equal) {
                continue;
            }
            return comparison;
        }
        return _comparison_js__WEBPACK_IMPORTED_MODULE_1__.Comparison.Equal;
    }
    Comparable.compareLexicographically = compareLexicographically;
    /**
     * Check if one value is less than another.
     */
    function isLessThan(a, b) {
        return a.compare(b) < 0;
    }
    Comparable.isLessThan = isLessThan;
    /**
     * Check if one value is less than or equal to another.
     */
    function isLessThanOrEqual(a, b) {
        return a.compare(b) <= 0;
    }
    Comparable.isLessThanOrEqual = isLessThanOrEqual;
    /**
     * Check if one value is equal to another
     */
    function isEqual(a, b) {
        return a.compare(b) === 0;
    }
    Comparable.isEqual = isEqual;
    /**
     * Check if one value is greater than another.
     */
    function isGreaterThan(a, b) {
        return a.compare(b) > 0;
    }
    Comparable.isGreaterThan = isGreaterThan;
    /**
     * Check if one value is greater than or equal to another.
     */
    function isGreaterThanOrEqual(a, b) {
        return a.compare(b) >= 0;
    }
    Comparable.isGreaterThanOrEqual = isGreaterThanOrEqual;
})(Comparable || (Comparable = {}));
//# sourceMappingURL=comparable.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-comparable/dist/comparer.js":
/*!********************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-comparable/dist/comparer.js ***!
  \********************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);

//# sourceMappingURL=comparer.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-comparable/dist/comparison.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-comparable/dist/comparison.js ***!
  \**********************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Comparison: () => (/* binding */ Comparison)
/* harmony export */ });
/**
 * @remarks
 * Comparisons are limited to the range [-1, 1] in order to avoid the potential
 * of over-/underflows when comparisons are implemented naively using
 * subtractions, such `a - b`; this would not be allowed.
 *
 * @public
 */
var Comparison;
(function (Comparison) {
    Comparison[Comparison["Less"] = -1] = "Less";
    Comparison[Comparison["Equal"] = 0] = "Equal";
    Comparison[Comparison["Greater"] = 1] = "Greater";
})(Comparison || (Comparison = {}));
//# sourceMappingURL=comparison.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-comparable/dist/index.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-comparable/dist/index.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Comparable: () => (/* reexport safe */ _comparable_js__WEBPACK_IMPORTED_MODULE_0__.Comparable),
/* harmony export */   Comparison: () => (/* reexport safe */ _comparison_js__WEBPACK_IMPORTED_MODULE_2__.Comparison)
/* harmony export */ });
/* harmony import */ var _comparable_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./comparable.js */ "./node_modules/@siteimprove/alfa-comparable/dist/comparable.js");
/* harmony import */ var _comparer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./comparer.js */ "./node_modules/@siteimprove/alfa-comparable/dist/comparer.js");
/* harmony import */ var _comparison_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./comparison.js */ "./node_modules/@siteimprove/alfa-comparable/dist/comparison.js");



//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-encoding/dist/decoder.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-encoding/dist/decoder.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Decoder: () => (/* binding */ Decoder)
/* harmony export */ });
/**
 * {@link https://encoding.spec.whatwg.org/#textdecoder}
 *
 * @public
 */
var Decoder;
(function (Decoder) {
    /**
     * {@link https://encoding.spec.whatwg.org/#dom-textdecoder-decode}
     * {@link https://encoding.spec.whatwg.org/#utf-8-decoder}
     */
    function decode(input) {
        let output = "";
        let i = 0;
        while (i < input.length) {
            let byte = input[i];
            let bytesNeeded = 0;
            let codePoint = 0;
            if (byte <= 0x7f) {
                bytesNeeded = 0;
                codePoint = byte & 0xff;
            }
            else if (byte <= 0xdf) {
                bytesNeeded = 1;
                codePoint = byte & 0x1f;
            }
            else if (byte <= 0xef) {
                bytesNeeded = 2;
                codePoint = byte & 0x0f;
            }
            else if (byte <= 0xf4) {
                bytesNeeded = 3;
                codePoint = byte & 0x07;
            }
            if (input.length - i - bytesNeeded > 0) {
                let k = 0;
                while (k < bytesNeeded) {
                    byte = input[i + k + 1];
                    codePoint = (codePoint << 6) | (byte & 0x3f);
                    k += 1;
                }
            }
            else {
                codePoint = 0xfffd;
                bytesNeeded = input.length - i;
            }
            output += String.fromCodePoint(codePoint);
            i += bytesNeeded + 1;
        }
        return output;
    }
    Decoder.decode = decode;
})(Decoder || (Decoder = {}));
//# sourceMappingURL=decoder.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-encoding/dist/encoder.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-encoding/dist/encoder.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Encoder: () => (/* binding */ Encoder)
/* harmony export */ });
/**
 * {@link https://encoding.spec.whatwg.org/#textencoder}
 *
 * @public
 */
var Encoder;
(function (Encoder) {
    /**
     * {@link https://encoding.spec.whatwg.org/#dom-textencoder-encode}
     * {@link https://encoding.spec.whatwg.org/#utf-8-encoder}
     */
    function encode(input) {
        const output = [];
        const length = input.length;
        let i = 0;
        while (i < length) {
            const codePoint = input.codePointAt(i);
            let count = 0;
            let bits = 0;
            if (codePoint <= 0x7f) {
                count = 0;
                bits = 0x00;
            }
            else if (codePoint <= 0x7ff) {
                count = 6;
                bits = 0xc0;
            }
            else if (codePoint <= 0xffff) {
                count = 12;
                bits = 0xe0;
            }
            else if (codePoint <= 0x1fffff) {
                count = 18;
                bits = 0xf0;
            }
            output.push(bits | (codePoint >> count));
            count -= 6;
            while (count >= 0) {
                output.push(0x80 | ((codePoint >> count) & 0x3f));
                count -= 6;
            }
            i += codePoint >= 0x10000 ? 2 : 1;
        }
        return new Uint8Array(output);
    }
    Encoder.encode = encode;
})(Encoder || (Encoder = {}));
//# sourceMappingURL=encoder.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-encoding/dist/index.js":
/*!***************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-encoding/dist/index.js ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Decoder: () => (/* reexport safe */ _decoder_js__WEBPACK_IMPORTED_MODULE_0__.Decoder),
/* harmony export */   Encoder: () => (/* reexport safe */ _encoder_js__WEBPACK_IMPORTED_MODULE_1__.Encoder)
/* harmony export */ });
/* harmony import */ var _decoder_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./decoder.js */ "./node_modules/@siteimprove/alfa-encoding/dist/decoder.js");
/* harmony import */ var _encoder_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./encoder.js */ "./node_modules/@siteimprove/alfa-encoding/dist/encoder.js");


//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-equatable/dist/equatable.js":
/*!********************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-equatable/dist/equatable.js ***!
  \********************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Equatable: () => (/* binding */ Equatable)
/* harmony export */ });
/**
 * This namespace provides additional types and functions for the
 * {@link (Equatable:interface)} interface.
 *
 * @public
 */
var Equatable;
(function (Equatable) {
    // The following two type guards have been inlined from the
    // @siteimprove/alfa-refinement package to avoid creating a circular
    // dependency.
    function isFunction(value) {
        return typeof value === "function";
    }
    function isObject(value) {
        return typeof value === "object" && value !== null;
    }
    /**
     * Check if an unknown value implements the {@link (Equatable:interface)}
     * interface.
     */
    function isEquatable(value) {
        return isObject(value) && isFunction(value.equals);
    }
    Equatable.isEquatable = isEquatable;
    /**
     * Check if two unknown values are equal.
     *
     * @remarks
     * If either of the given values implement the {@link (Equatable:interface)}
     * interface, the equivalence constraints of the value will be used. If not,
     * strict equality will be used with the additional constraint that `NaN` is
     * equal to itself.
     */
    function equals(a, b) {
        if (a === b ||
            // `NaN` is the only value in JavaScript that is not equal to itself.
            (a !== a && b !== b)) {
            return true;
        }
        if (isEquatable(a)) {
            return a.equals(b);
        }
        if (isEquatable(b)) {
            return b.equals(a);
        }
        return false;
    }
    Equatable.equals = equals;
})(Equatable || (Equatable = {}));
//# sourceMappingURL=equatable.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-equatable/dist/index.js":
/*!****************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-equatable/dist/index.js ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Equatable: () => (/* reexport safe */ _equatable_js__WEBPACK_IMPORTED_MODULE_0__.Equatable)
/* harmony export */ });
/* harmony import */ var _equatable_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./equatable.js */ "./node_modules/@siteimprove/alfa-equatable/dist/equatable.js");

//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-fnv/dist/fnv.js":
/*!********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-fnv/dist/fnv.js ***!
  \********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FNV: () => (/* binding */ FNV)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_hash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-hash */ "./node_modules/@siteimprove/alfa-hash/dist/index.js");

/**
 * @public
 */
class FNV extends _siteimprove_alfa_hash__WEBPACK_IMPORTED_MODULE_0__.Hash {
    static empty() {
        return new FNV();
    }
    _hash = 2166136261;
    constructor() {
        super();
    }
    finish() {
        return this._hash >>> 0; // Convert to unsigned 32-bit integer
    }
    write(data) {
        let hash = this._hash;
        for (const octet of data) {
            hash ^= octet;
            hash +=
                (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
        }
        this._hash = hash;
        return this;
    }
    equals(value) {
        return value instanceof FNV && value._hash === this._hash;
    }
}
//# sourceMappingURL=fnv.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-fnv/dist/index.js":
/*!**********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-fnv/dist/index.js ***!
  \**********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FNV: () => (/* reexport safe */ _fnv_js__WEBPACK_IMPORTED_MODULE_0__.FNV)
/* harmony export */ });
/* harmony import */ var _fnv_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./fnv.js */ "./node_modules/@siteimprove/alfa-fnv/dist/fnv.js");

//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-hash/dist/hash.js":
/*!**********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-hash/dist/hash.js ***!
  \**********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Hash: () => (/* binding */ Hash)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_encoding__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-encoding */ "./node_modules/@siteimprove/alfa-encoding/dist/index.js");
/* harmony import */ var _hashable_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./hashable.js */ "./node_modules/@siteimprove/alfa-hash/dist/hashable.js");


const { keys } = Object;
/**
 * A special offset used for the builtin types `true`, `false`, `undefined`, and
 * `null`. The offset is designed to minimize the chance of collisions for data
 * structures that rely on 5-bit partitioning. We use the first 30 bits for 6 of
 * these partitions, leaving us 2 bits to encode the 4 builtin types.
 */
const builtinOffset = 0b10000_10000_10000_10000_10000_10000_00;
/**
 * @public
 */
class Hash {
    /**
     * A map from objects to their hash values. Objects are weakly referenced as
     * to not prevent them from being garbage collected.
     */
    static _objectHashes = new WeakMap();
    /**
     * A map from symbols to their hash values. As there's not currently a way to
     * weakly reference symbols, we have to instead use strong references.
     *
     * {@link https://github.com/tc39/proposal-symbols-as-weakmap-keys}
     */
    static _symbolHashes = new Map();
    /**
     * The next available hash value. This is used for symbols and objects that
     * don't implement the {@link (Hashable:interface)} interface.
     */
    static _nextHash = 0;
    constructor() { }
    writeString(data) {
        return this.write(_siteimprove_alfa_encoding__WEBPACK_IMPORTED_MODULE_0__.Encoder.encode(data));
    }
    /**
     * @remarks
     * As JavaScript represents numbers in double-precision floating-point format,
     * numbers in general will be written as such.
     *
     * {@link https://en.wikipedia.org/wiki/Double-precision_floating-point_format}
     */
    writeNumber(data) {
        return this.writeFloat64(data);
    }
    writeInt(data, size = 32, signed = true) {
        const buffer = new ArrayBuffer(size / 8);
        const view = new DataView(buffer);
        switch (size) {
            case 8:
                signed ? view.setInt8(0, data) : view.setUint8(0, data);
                break;
            case 16:
                signed ? view.setInt16(0, data) : view.setUint16(0, data);
                break;
            case 32:
                signed ? view.setInt32(0, data) : view.setUint32(0, data);
        }
        return this.write(new Uint8Array(buffer));
    }
    writeInt8(data) {
        return this.writeInt(data, 8, true);
    }
    writeUint8(data) {
        return this.writeInt(data, 8, false);
    }
    writeInt16(data) {
        return this.writeInt(data, 16, true);
    }
    writeUint16(data) {
        return this.writeInt(data, 16, false);
    }
    writeInt32(data) {
        return this.writeInt(data, 32, true);
    }
    writeUint32(data) {
        return this.writeInt(data, 32, false);
    }
    writeBigInt(data, size = 64, signed = true) {
        const buffer = new ArrayBuffer(size / 8);
        const view = new DataView(buffer);
        switch (size) {
            case 64:
                signed ? view.setBigInt64(0, data) : view.setBigUint64(0, data);
        }
        return this.write(new Uint8Array(buffer));
    }
    writeBigInt64(data) {
        return this.writeBigInt(data, 64, true);
    }
    writeBigUint64(data) {
        return this.writeBigInt(data, 64, false);
    }
    writeFloat(data, size = 32) {
        const buffer = new ArrayBuffer(size / 8);
        const view = new DataView(buffer);
        switch (size) {
            case 32:
                view.setFloat32(0, data);
                break;
            case 64:
                view.setFloat64(0, data);
        }
        return this.write(new Uint8Array(buffer));
    }
    writeFloat32(data) {
        return this.writeFloat(data, 32);
    }
    writeFloat64(data) {
        return this.writeFloat(data, 64);
    }
    writeBoolean(data) {
        return this.writeUint8(builtinOffset + (data ? 1 : 0));
    }
    writeUndefined() {
        return this.writeUint32(builtinOffset + 2);
    }
    writeNull() {
        return this.writeUint32(builtinOffset + 3);
    }
    writeObject(data) {
        let hash = Hash._objectHashes.get(data);
        if (hash === undefined) {
            hash = Hash._getNextHash();
            Hash._objectHashes.set(data, hash);
        }
        return this.writeUint32(hash);
    }
    writeSymbol(data) {
        let hash = Hash._symbolHashes.get(data);
        if (hash === undefined) {
            hash = Hash._getNextHash();
            Hash._symbolHashes.set(data, hash);
        }
        return this.writeUint32(hash);
    }
    writeHashable(data) {
        data.hash(this);
        return this;
    }
    writeUnknown(data) {
        switch (typeof data) {
            case "string":
                return this.writeString(data);
            case "number":
                return this.writeNumber(data);
            case "bigint":
                return this.writeBigInt(data);
            case "boolean":
                return this.writeBoolean(data);
            case "symbol":
                return this.writeSymbol(data);
            case "undefined":
                return this.writeUndefined();
            case "object":
                if (data === null) {
                    return this.writeNull();
                }
                if (_hashable_js__WEBPACK_IMPORTED_MODULE_1__.Hashable.isHashable(data)) {
                    return this.writeHashable(data);
                }
                return this.writeObject(data);
            case "function":
                return this.writeObject(data);
        }
    }
    writeJSON(data) {
        switch (typeof data) {
            case "string":
                return this.writeString(data);
            case "number":
                return this.writeNumber(data);
            case "boolean":
                return this.writeBoolean(data);
            case "object":
                if (Array.isArray(data)) {
                    for (let i = 0, n = data.length; i < n; i++) {
                        this.writeJSON(data[i]);
                    }
                    this.writeUint32(data.length);
                }
                else if (data !== null) {
                    for (const key of keys(data).sort()) {
                        const value = data[key];
                        this.writeString(key);
                        if (value !== undefined) {
                            this.writeJSON(value);
                        }
                        // Write a null byte as a separator between key/value pairs.
                        this.writeUint8(0);
                    }
                }
                return this;
        }
    }
    equals(value) {
        return value instanceof Hash && value.finish() === this.finish();
    }
    hash(hash) {
        hash.writeUint32(this.finish());
    }
    static _getNextHash() {
        const nextHash = Hash._nextHash;
        // Increase the hash, wrapping around when it reaches the limit of 32 bits.
        Hash._nextHash = (Hash._nextHash + 1) >>> 0;
        return nextHash;
    }
}
//# sourceMappingURL=hash.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-hash/dist/hashable.js":
/*!**************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-hash/dist/hashable.js ***!
  \**************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Hashable: () => (/* binding */ Hashable)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_refinement__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-refinement */ "./node_modules/@siteimprove/alfa-refinement/dist/index.js");

const { isFunction, isObject } = _siteimprove_alfa_refinement__WEBPACK_IMPORTED_MODULE_0__.Refinement;
/**
 * @public
 */
var Hashable;
(function (Hashable) {
    function isHashable(value) {
        return isObject(value) && isFunction(value.hash);
    }
    Hashable.isHashable = isHashable;
})(Hashable || (Hashable = {}));
//# sourceMappingURL=hashable.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-hash/dist/index.js":
/*!***********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-hash/dist/index.js ***!
  \***********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Hash: () => (/* reexport safe */ _hash_js__WEBPACK_IMPORTED_MODULE_0__.Hash),
/* harmony export */   Hashable: () => (/* reexport safe */ _hashable_js__WEBPACK_IMPORTED_MODULE_1__.Hashable)
/* harmony export */ });
/* harmony import */ var _hash_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./hash.js */ "./node_modules/@siteimprove/alfa-hash/dist/hash.js");
/* harmony import */ var _hashable_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./hashable.js */ "./node_modules/@siteimprove/alfa-hash/dist/hashable.js");


//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-iterable/dist/index.js":
/*!***************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-iterable/dist/index.js ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Iterable: () => (/* reexport safe */ _iterable_js__WEBPACK_IMPORTED_MODULE_0__.Iterable)
/* harmony export */ });
/* harmony import */ var _iterable_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./iterable.js */ "./node_modules/@siteimprove/alfa-iterable/dist/iterable.js");

//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-iterable/dist/iterable.js":
/*!******************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-iterable/dist/iterable.js ***!
  \******************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Iterable: () => (/* binding */ Iterable)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-comparable */ "./node_modules/@siteimprove/alfa-comparable/dist/index.js");
/* harmony import */ var _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @siteimprove/alfa-equatable */ "./node_modules/@siteimprove/alfa-equatable/dist/index.js");
/* harmony import */ var _siteimprove_alfa_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @siteimprove/alfa-json */ "./node_modules/@siteimprove/alfa-json/dist/index.js");
/* harmony import */ var _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @siteimprove/alfa-option */ "./node_modules/@siteimprove/alfa-option/dist/index.js");
/* harmony import */ var _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @siteimprove/alfa-predicate */ "./node_modules/@siteimprove/alfa-predicate/dist/index.js");
/* harmony import */ var _siteimprove_alfa_refinement__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @siteimprove/alfa-refinement */ "./node_modules/@siteimprove/alfa-refinement/dist/index.js");






const { not } = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_4__.Predicate;
const { isObject } = _siteimprove_alfa_refinement__WEBPACK_IMPORTED_MODULE_5__.Refinement;
const { compareComparable } = _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__.Comparable;
/**
 * @public
 */
var Iterable;
(function (Iterable) {
    function isIterable(value) {
        return isObject(value) && Symbol.iterator in value;
    }
    Iterable.isIterable = isIterable;
    function* empty() { }
    Iterable.empty = empty;
    function* from(arrayLike) {
        for (let i = 0, n = arrayLike.length; i < n; i++) {
            yield arrayLike[i];
        }
    }
    Iterable.from = from;
    function size(iterable) {
        return reduce(iterable, (size) => size + 1, 0);
    }
    Iterable.size = size;
    function isEmpty(iterable) {
        for (const _ of iterable) {
            return false;
        }
        return true;
    }
    Iterable.isEmpty = isEmpty;
    function forEach(iterable, callback) {
        let index = 0;
        for (const value of iterable) {
            callback(value, index++);
        }
    }
    Iterable.forEach = forEach;
    function* map(iterable, mapper) {
        let index = 0;
        for (const value of iterable) {
            yield mapper(value, index++);
        }
    }
    Iterable.map = map;
    function* flatMap(iterable, mapper) {
        let index = 0;
        for (const value of iterable) {
            yield* mapper(value, index++);
        }
    }
    Iterable.flatMap = flatMap;
    function* flatten(iterable) {
        for (const value of iterable) {
            yield* value;
        }
    }
    Iterable.flatten = flatten;
    function reduce(iterable, reducer, accumulator) {
        let index = 0;
        for (const value of iterable) {
            accumulator = reducer(accumulator, value, index++);
        }
        return accumulator;
    }
    Iterable.reduce = reduce;
    function reduceWhile(iterable, predicate, reducer, accumulator) {
        let index = 0;
        for (const value of iterable) {
            if (predicate(value, index)) {
                accumulator = reducer(accumulator, value, index++);
            }
            else {
                break;
            }
        }
        return accumulator;
    }
    Iterable.reduceWhile = reduceWhile;
    function reduceUntil(iterable, predicate, reducer, accumulator) {
        return reduceWhile(iterable, not(predicate), reducer, accumulator);
    }
    Iterable.reduceUntil = reduceUntil;
    function apply(iterable, mapper) {
        return flatMap(mapper, (mapper) => map(iterable, mapper));
    }
    Iterable.apply = apply;
    function* filter(iterable, predicate) {
        let index = 0;
        for (const value of iterable) {
            if (predicate(value, index++)) {
                yield value;
            }
        }
    }
    Iterable.filter = filter;
    function reject(iterable, predicate) {
        return filter(iterable, not(predicate));
    }
    Iterable.reject = reject;
    function find(iterable, predicate) {
        let index = 0;
        for (const value of iterable) {
            if (predicate(value, index++)) {
                return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_3__.Option.of(value);
            }
        }
        return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_3__.None;
    }
    Iterable.find = find;
    function findLast(iterable, predicate) {
        let index = 0;
        let result = _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_3__.None;
        for (const value of iterable) {
            if (predicate(value, index++)) {
                result = _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_3__.Option.of(value);
            }
        }
        return result;
    }
    Iterable.findLast = findLast;
    function includes(iterable, value) {
        return some(iterable, _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_4__.Predicate.equals(value));
    }
    Iterable.includes = includes;
    function collect(iterable, mapper) {
        return flatMap(iterable, mapper);
    }
    Iterable.collect = collect;
    function collectFirst(iterable, mapper) {
        return first(collect(iterable, mapper));
    }
    Iterable.collectFirst = collectFirst;
    function some(iterable, predicate) {
        let index = 0;
        for (const value of iterable) {
            if (predicate(value, index++)) {
                return true;
            }
        }
        return false;
    }
    Iterable.some = some;
    function none(iterable, predicate) {
        return every(iterable, not(predicate));
    }
    Iterable.none = none;
    function every(iterable, predicate) {
        let index = 0;
        for (const value of iterable) {
            if (!predicate(value, index++)) {
                return false;
            }
        }
        return true;
    }
    Iterable.every = every;
    function count(iterable, predicate) {
        return reduce(iterable, (count, value, index) => (predicate(value, index) ? count + 1 : count), 0);
    }
    Iterable.count = count;
    function* distinct(iterable) {
        const seen = [];
        for (const value of iterable) {
            if (seen.some(_siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_4__.Predicate.equals(value))) {
                continue;
            }
            seen.push(value);
            yield value;
        }
    }
    Iterable.distinct = distinct;
    function get(iterable, index) {
        return index < 0 ? _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_3__.None : first(skip(iterable, index));
    }
    Iterable.get = get;
    function has(iterable, index) {
        return index < 0 ? false : !isEmpty(skip(iterable, index));
    }
    Iterable.has = has;
    function* set(iterable, index, value) {
        const it = iterator(iterable);
        while (index-- > 0) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            yield next.value;
        }
        const next = it.next();
        if (next.done === true) {
            return;
        }
        yield value;
        while (true) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            yield next.value;
        }
    }
    Iterable.set = set;
    function* insert(iterable, index, value) {
        const it = iterator(iterable);
        while (index-- > 0) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            yield next.value;
        }
        yield value;
        while (true) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            yield next.value;
        }
    }
    Iterable.insert = insert;
    function* append(iterable, value) {
        yield* iterable;
        yield value;
    }
    Iterable.append = append;
    function* prepend(iterable, value) {
        yield value;
        yield* iterable;
    }
    Iterable.prepend = prepend;
    function* concat(iterable, ...iterables) {
        yield* iterable;
        for (const iterable of iterables) {
            yield* iterable;
        }
    }
    Iterable.concat = concat;
    function subtract(iterable, ...iterables) {
        return reject(iterable, (value) => includes(flatten(iterables), value));
    }
    Iterable.subtract = subtract;
    function intersect(iterable, ...iterables) {
        return filter(iterable, (value) => includes(flatten(iterables), value));
    }
    Iterable.intersect = intersect;
    function* zip(a, b) {
        const itA = iterator(a);
        const itB = iterator(b);
        while (true) {
            const a = itA.next();
            const b = itB.next();
            if (a.done === true || b.done === true) {
                return;
            }
            yield [a.value, b.value];
        }
    }
    Iterable.zip = zip;
    function first(iterable) {
        for (const value of iterable) {
            return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_3__.Option.of(value);
        }
        return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_3__.None;
    }
    Iterable.first = first;
    function last(iterable) {
        let last = null;
        for (const value of iterable) {
            last = value;
        }
        return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_3__.Option.from(last);
    }
    Iterable.last = last;
    function* take(iterable, count) {
        const it = iterator(iterable);
        while (count-- > 0) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            yield next.value;
        }
    }
    Iterable.take = take;
    function* takeWhile(iterable, predicate) {
        let index = 0;
        for (const value of iterable) {
            if (predicate(value, index++)) {
                yield value;
            }
            else {
                break;
            }
        }
    }
    Iterable.takeWhile = takeWhile;
    function takeUntil(iterable, predicate) {
        return takeWhile(iterable, not(predicate));
    }
    Iterable.takeUntil = takeUntil;
    function* takeLast(iterable, count = 1) {
        if (count <= 0) {
            return;
        }
        const last = [];
        for (const value of iterable) {
            last.push(value);
            if (last.length > count) {
                last.shift();
            }
        }
        yield* last;
    }
    Iterable.takeLast = takeLast;
    function* takeLastWhile(iterable, predicate) {
        const values = [...iterable];
        let last = values.length - 1;
        while (last >= 0) {
            if (predicate(values[last], last)) {
                last--;
            }
            else {
                break;
            }
        }
        for (let i = last, n = values.length - 1; i < n; i++) {
            yield values[i];
        }
    }
    Iterable.takeLastWhile = takeLastWhile;
    function takeLastUntil(iterable, predicate) {
        return takeLastWhile(iterable, not(predicate));
    }
    Iterable.takeLastUntil = takeLastUntil;
    function* skip(iterable, count) {
        const it = iterator(iterable);
        while (count-- > 0) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
        }
        while (true) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            yield next.value;
        }
    }
    Iterable.skip = skip;
    function* skipWhile(iterable, predicate) {
        let index = 0;
        let skipped = false;
        for (const value of iterable) {
            if (!skipped && predicate(value, index++)) {
                continue;
            }
            else {
                skipped = true;
                yield value;
            }
        }
    }
    Iterable.skipWhile = skipWhile;
    function skipUntil(iterable, predicate) {
        return skipWhile(iterable, not(predicate));
    }
    Iterable.skipUntil = skipUntil;
    function* skipLast(iterable, count = 1) {
        const it = iterator(iterable);
        const first = [];
        while (count-- > 0) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            first.push(next.value);
        }
        while (true) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            first.push(next.value);
            yield first.shift();
        }
    }
    Iterable.skipLast = skipLast;
    function* skipLastWhile(iterable, predicate) {
        const values = [...iterable];
        let last = values.length - 1;
        while (last >= 0) {
            if (predicate(values[last], last)) {
                last--;
            }
            else {
                break;
            }
        }
        for (let i = 0, n = last; i < n; i++) {
            yield values[i];
        }
    }
    Iterable.skipLastWhile = skipLastWhile;
    function skipLastUntil(iterable, predicate) {
        return skipLastWhile(iterable, not(predicate));
    }
    Iterable.skipLastUntil = skipLastUntil;
    function trim(iterable, predicate) {
        return trimTrailing(trimLeading(iterable, predicate), predicate);
    }
    Iterable.trim = trim;
    function trimLeading(iterable, predicate) {
        return skipWhile(iterable, predicate);
    }
    Iterable.trimLeading = trimLeading;
    function trimTrailing(iterable, predicate) {
        return skipLastWhile(iterable, predicate);
    }
    Iterable.trimTrailing = trimTrailing;
    function rest(iterable) {
        return skip(iterable, 1);
    }
    Iterable.rest = rest;
    function slice(iterable, start, end) {
        iterable = skip(iterable, start);
        if (end !== undefined) {
            iterable = take(iterable, end - start);
        }
        return iterable;
    }
    Iterable.slice = slice;
    function* reverse(iterable) {
        const array = Array.from(iterable);
        for (let i = array.length - 1; i >= 0; i--) {
            yield array[i];
        }
    }
    Iterable.reverse = reverse;
    function join(iterable, separator) {
        const it = iterator(iterable);
        let next = it.next();
        if (next.done === true) {
            return "";
        }
        let result = `${next.value}`;
        next = it.next();
        while (next.done !== true) {
            result += `${separator}${next.value}`;
            next = it.next();
        }
        return result;
    }
    Iterable.join = join;
    function sort(iterable) {
        return sortWith(iterable, compareComparable);
    }
    Iterable.sort = sort;
    function* sortWith(iterable, comparer) {
        yield* [...iterable].sort(comparer);
    }
    Iterable.sortWith = sortWith;
    function compare(a, b) {
        return compareWith(a, b, compareComparable);
    }
    Iterable.compare = compare;
    function compareWith(a, b, comparer) {
        const itA = iterator(a);
        const itB = iterator(b);
        let index = 0;
        while (true) {
            const a = itA.next();
            const b = itB.next();
            if (a.done === true) {
                return b.done === true ? _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__.Comparison.Equal : _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__.Comparison.Less;
            }
            if (b.done === true) {
                return _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__.Comparison.Greater;
            }
            const result = comparer(a.value, b.value, index++);
            if (result !== 0) {
                return result;
            }
        }
    }
    Iterable.compareWith = compareWith;
    function equals(a, b) {
        const itA = iterator(a);
        const itB = iterator(b);
        while (true) {
            const a = itA.next();
            const b = itB.next();
            if (a.done === true) {
                return b.done === true;
            }
            if (b.done === true || !_siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(a.value, b.value)) {
                return false;
            }
        }
    }
    Iterable.equals = equals;
    function hash(iterable, hash) {
        let size = 0;
        for (const value of iterable) {
            hash.writeUnknown(value);
            size++;
        }
        hash.writeUint32(size);
    }
    Iterable.hash = hash;
    function iterator(iterable) {
        return iterable[Symbol.iterator]();
    }
    Iterable.iterator = iterator;
    function groupBy(iterable, grouper) {
        const groups = [];
        let index = 0;
        for (const value of iterable) {
            const group = grouper(value, index++);
            const existing = groups.find(([existing]) => _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(group, existing));
            if (existing === undefined) {
                groups.push([group, [value]]);
            }
            else {
                existing[1].push(value);
            }
        }
        return groups;
    }
    Iterable.groupBy = groupBy;
    function toJSON(iterable, options) {
        return [...map(iterable, (value) => _siteimprove_alfa_json__WEBPACK_IMPORTED_MODULE_2__.Serializable.toJSON(value, options))];
    }
    Iterable.toJSON = toJSON;
})(Iterable || (Iterable = {}));
//# sourceMappingURL=iterable.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-json/dist/builtin.js":
/*!*************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-json/dist/builtin.js ***!
  \*************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   JSON: () => (/* binding */ Builtin)
/* harmony export */ });
// This file defines exports from the builtin `JSON` constructor for internal
// use only.
/**
 * @internal
 */
const Builtin = JSON;

//# sourceMappingURL=builtin.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-json/dist/index.js":
/*!***********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-json/dist/index.js ***!
  \***********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   JSON: () => (/* reexport safe */ _json_js__WEBPACK_IMPORTED_MODULE_0__.JSON),
/* harmony export */   Serializable: () => (/* reexport safe */ _serializable_js__WEBPACK_IMPORTED_MODULE_1__.Serializable)
/* harmony export */ });
/* harmony import */ var _json_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./json.js */ "./node_modules/@siteimprove/alfa-json/dist/json.js");
/* harmony import */ var _serializable_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./serializable.js */ "./node_modules/@siteimprove/alfa-json/dist/serializable.js");


//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-json/dist/json.js":
/*!**********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-json/dist/json.js ***!
  \**********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   JSON: () => (/* binding */ JSON)
/* harmony export */ });
/* harmony import */ var _builtin_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./builtin.js */ "./node_modules/@siteimprove/alfa-json/dist/builtin.js");

/**
 * @public
 */
var JSON;
(function (JSON) {
    function parse(value) {
        return _builtin_js__WEBPACK_IMPORTED_MODULE_0__.JSON.parse(value);
    }
    JSON.parse = parse;
    function stringify(value) {
        return _builtin_js__WEBPACK_IMPORTED_MODULE_0__.JSON.stringify(value);
    }
    JSON.stringify = stringify;
})(JSON || (JSON = {}));
//# sourceMappingURL=json.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-json/dist/serializable.js":
/*!******************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-json/dist/serializable.js ***!
  \******************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Serializable: () => (/* binding */ Serializable)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_refinement__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-refinement */ "./node_modules/@siteimprove/alfa-refinement/dist/index.js");

const { keys } = Object;
const { isArray } = Array;
const { isFunction, isObject, isString, isNumber, isBoolean, isNull } = _siteimprove_alfa_refinement__WEBPACK_IMPORTED_MODULE_0__.Refinement;
/**
 * @public
 */
var Serializable;
(function (Serializable) {
    function isSerializable(value) {
        return isObject(value) && isFunction(value.toJSON);
    }
    Serializable.isSerializable = isSerializable;
    function toJSON(value, options) {
        if (isSerializable(value)) {
            return value.toJSON(options);
        }
        if (isString(value) ||
            isNumber(value) ||
            isBoolean(value) ||
            isNull(value)) {
            return value;
        }
        if (isArray(value)) {
            return value.map((item) => toJSON(item, options));
        }
        if (isObject(value)) {
            const json = {};
            for (const key of keys(value)) {
                if (value[key] !== undefined) {
                    json[key] = toJSON(value[key], options);
                }
            }
            return json;
        }
        return null;
    }
    Serializable.toJSON = toJSON;
    let Verbosity;
    (function (Verbosity) {
        Verbosity[Verbosity["Minimal"] = 0] = "Minimal";
        Verbosity[Verbosity["Low"] = 100] = "Low";
        Verbosity[Verbosity["Medium"] = 200] = "Medium";
        Verbosity[Verbosity["High"] = 300] = "High";
    })(Verbosity = Serializable.Verbosity || (Serializable.Verbosity = {}));
})(Serializable || (Serializable = {}));
//# sourceMappingURL=serializable.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-map/dist/index.js":
/*!**********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-map/dist/index.js ***!
  \**********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Collision: () => (/* reexport safe */ _node_js__WEBPACK_IMPORTED_MODULE_1__.Collision),
/* harmony export */   Empty: () => (/* reexport safe */ _node_js__WEBPACK_IMPORTED_MODULE_1__.Empty),
/* harmony export */   Leaf: () => (/* reexport safe */ _node_js__WEBPACK_IMPORTED_MODULE_1__.Leaf),
/* harmony export */   Map: () => (/* reexport safe */ _map_js__WEBPACK_IMPORTED_MODULE_0__.Map),
/* harmony export */   Node: () => (/* reexport safe */ _node_js__WEBPACK_IMPORTED_MODULE_1__.Node),
/* harmony export */   Sparse: () => (/* reexport safe */ _node_js__WEBPACK_IMPORTED_MODULE_1__.Sparse)
/* harmony export */ });
/* harmony import */ var _map_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./map.js */ "./node_modules/@siteimprove/alfa-map/dist/map.js");
/* harmony import */ var _node_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node.js */ "./node_modules/@siteimprove/alfa-map/dist/node.js");


//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-map/dist/map.js":
/*!********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-map/dist/map.js ***!
  \********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Map: () => (/* binding */ Map)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_array__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-array */ "./node_modules/@siteimprove/alfa-array/dist/index.js");
/* harmony import */ var _siteimprove_alfa_fnv__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @siteimprove/alfa-fnv */ "./node_modules/@siteimprove/alfa-fnv/dist/index.js");
/* harmony import */ var _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @siteimprove/alfa-iterable */ "./node_modules/@siteimprove/alfa-iterable/dist/index.js");
/* harmony import */ var _siteimprove_alfa_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @siteimprove/alfa-json */ "./node_modules/@siteimprove/alfa-json/dist/index.js");
/* harmony import */ var _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @siteimprove/alfa-predicate */ "./node_modules/@siteimprove/alfa-predicate/dist/index.js");
/* harmony import */ var _node_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node.js */ "./node_modules/@siteimprove/alfa-map/dist/node.js");






const { not } = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_4__.Predicate;
/**
 * @public
 */
class Map {
    static of(...entries) {
        return entries.reduce((map, [key, value]) => map.set(key, value), Map.empty());
    }
    static _empty = new Map(_node_js__WEBPACK_IMPORTED_MODULE_5__.Empty, 0);
    static empty() {
        return this._empty;
    }
    _root;
    _size;
    constructor(root, size) {
        this._root = root;
        this._size = size;
    }
    get size() {
        return this._size;
    }
    isEmpty() {
        return this._size === 0;
    }
    forEach(callback) {
        _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.forEach(this, ([key, value]) => callback(value, key));
    }
    map(mapper) {
        return new Map(this._root.map(mapper), this._size);
    }
    /**
     * Apply a map of functions to each corresponding value of this map.
     *
     * @remarks
     * Keys without a corresponding function or value are dropped from the
     * resulting map.
     *
     * @example
     * ```ts
     * Map.of(["a", 1], ["b", 2])
     *   .apply(Map.of(["a", (x) => x + 1], ["b", (x) => x * 2]))
     *   .toArray();
     * // => [["a", 2], ["b", 4]]
     * ```
     */
    apply(mapper) {
        return this.collect((value, key) => mapper.get(key).map((mapper) => mapper(value)));
    }
    /**
     * @remarks
     * As the order of maps is undefined, it is also undefined which keys are
     * kept when duplicate keys are encountered.
     */
    flatMap(mapper) {
        return this.reduce((map, value, key) => map.concat(mapper(value, key)), Map.empty());
    }
    /**
     * @remarks
     * As the order of maps is undefined, it is also undefined which keys are
     * kept when duplicate keys are encountered.
     */
    flatten() {
        return this.flatMap((map) => map);
    }
    reduce(reducer, accumulator) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.reduce(this, (accumulator, [key, value]) => reducer(accumulator, value, key), accumulator);
    }
    filter(predicate) {
        return this.reduce((map, value, key) => (predicate(value, key) ? map.set(key, value) : map), Map.empty());
    }
    reject(predicate) {
        return this.filter(not(predicate));
    }
    find(predicate) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.find(this, ([key, value]) => predicate(value, key)).map(([, value]) => value);
    }
    includes(value) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.includes(this.values(), value);
    }
    collect(mapper) {
        return Map.from(_siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.collect(this, ([key, value]) => mapper(value, key).map((value) => [key, value])));
    }
    collectFirst(mapper) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.collectFirst(this, ([key, value]) => mapper(value, key));
    }
    some(predicate) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.some(this, ([key, value]) => predicate(value, key));
    }
    none(predicate) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.none(this, ([key, value]) => predicate(value, key));
    }
    every(predicate) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.every(this, ([key, value]) => predicate(value, key));
    }
    count(predicate) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.count(this, ([key, value]) => predicate(value, key));
    }
    /**
     * @remarks
     * As the order of maps is undefined, it is also undefined which keys are
     * kept when duplicate values are encountered.
     */
    distinct() {
        let seen = Map.empty();
        // We optimize for the case where there are more distinct values than there
        // are duplicate values by starting with the current map and removing
        // duplicates as we find them.
        let map = this;
        for (const [key, value] of map) {
            if (seen.has(value)) {
                map = map.delete(key);
            }
            else {
                seen = seen.set(value, value);
            }
        }
        return map;
    }
    get(key) {
        return this._root.get(key, hash(key), 0);
    }
    has(key) {
        return this.get(key).isSome();
    }
    set(key, value) {
        const { result: root, status } = this._root.set(key, value, hash(key), 0);
        if (status === "unchanged") {
            return this;
        }
        return new Map(root, this._size + (status === "updated" ? 0 : 1));
    }
    delete(key) {
        const { result: root, status } = this._root.delete(key, hash(key), 0);
        if (status === "unchanged") {
            return this;
        }
        return new Map(root, this._size - 1);
    }
    concat(iterable) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.reduce(iterable, (map, [key, value]) => map.set(key, value), this);
    }
    subtract(iterable) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.reduce(iterable, (map, [key]) => map.delete(key), this);
    }
    intersect(iterable) {
        return Map.fromIterable(_siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.filter(iterable, ([key]) => this.has(key)));
    }
    tee(callback, ...args) {
        callback(this, ...args);
        return this;
    }
    equals(value) {
        return (value instanceof Map &&
            value._size === this._size &&
            value._root.equals(this._root));
    }
    hash(hash) {
        for (const [key, value] of this) {
            hash.writeUnknown(key).writeUnknown(value);
        }
        hash.writeUint32(this._size);
    }
    keys() {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.map(this._root, (entry) => entry[0]);
    }
    values() {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.map(this._root, (entry) => entry[1]);
    }
    *iterator() {
        yield* this._root;
    }
    [Symbol.iterator]() {
        return this.iterator();
    }
    toArray() {
        return [...this];
    }
    toJSON(options) {
        return this.toArray().map(([key, value]) => [
            _siteimprove_alfa_json__WEBPACK_IMPORTED_MODULE_3__.Serializable.toJSON(key, options),
            _siteimprove_alfa_json__WEBPACK_IMPORTED_MODULE_3__.Serializable.toJSON(value, options),
        ]);
    }
    toString() {
        const entries = this.toArray()
            .map(([key, value]) => `${key} => ${value}`)
            .join(", ");
        return `Map {${entries === "" ? "" : ` ${entries} `}}`;
    }
}
/**
 * @public
 */
(function (Map) {
    function isMap(value) {
        return value instanceof Map;
    }
    Map.isMap = isMap;
    function from(iterable) {
        if (isMap(iterable)) {
            return iterable;
        }
        if (_siteimprove_alfa_array__WEBPACK_IMPORTED_MODULE_0__.Array.isArray(iterable)) {
            return fromArray(iterable);
        }
        return fromIterable(iterable);
    }
    Map.from = from;
    function fromArray(array) {
        return _siteimprove_alfa_array__WEBPACK_IMPORTED_MODULE_0__.Array.reduce(array, (map, [key, value]) => map.set(key, value), Map.empty());
    }
    Map.fromArray = fromArray;
    function fromIterable(iterable) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.reduce(iterable, (map, [key, value]) => map.set(key, value), Map.empty());
    }
    Map.fromIterable = fromIterable;
})(Map || (Map = {}));
function hash(key) {
    return _siteimprove_alfa_fnv__WEBPACK_IMPORTED_MODULE_1__.FNV.empty().writeUnknown(key).finish();
}
//# sourceMappingURL=map.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-map/dist/node.js":
/*!*********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-map/dist/node.js ***!
  \*********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Collision: () => (/* binding */ Collision),
/* harmony export */   Empty: () => (/* binding */ Empty),
/* harmony export */   Leaf: () => (/* binding */ Leaf),
/* harmony export */   Node: () => (/* binding */ Node),
/* harmony export */   Sparse: () => (/* binding */ Sparse)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_bits__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-bits */ "./node_modules/@siteimprove/alfa-bits/dist/index.js");
/* harmony import */ var _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @siteimprove/alfa-equatable */ "./node_modules/@siteimprove/alfa-equatable/dist/index.js");
/* harmony import */ var _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @siteimprove/alfa-option */ "./node_modules/@siteimprove/alfa-option/dist/index.js");
/* harmony import */ var _status_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./status.js */ "./node_modules/@siteimprove/alfa-map/dist/status.js");




const { bit, take, skip, test, set, clear, popCount } = _siteimprove_alfa_bits__WEBPACK_IMPORTED_MODULE_0__.Bits;
/**
 * @internal
 */
var Node;
(function (Node) {
    Node.Bits = 5;
    function fragment(hash, shift) {
        return take(skip(hash, shift), Node.Bits);
    }
    Node.fragment = fragment;
    function index(fragment, mask) {
        return popCount(take(mask, fragment));
    }
    Node.index = index;
})(Node || (Node = {}));
/**
 * @internal
 */
const Empty = new (class Empty {
    isEmpty() {
        return true;
    }
    isLeaf() {
        return false;
    }
    get() {
        return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_2__.None;
    }
    set(key, value, hash) {
        return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.created(Leaf.of(hash, key, value));
    }
    delete() {
        return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.unchanged(this);
    }
    map() {
        return this;
    }
    equals(value) {
        return value instanceof Empty;
    }
    *[Symbol.iterator]() { }
})();
/**
 * @internal
 */
class Leaf {
    static of(hash, key, value) {
        return new Leaf(hash, key, value);
    }
    _hash;
    _key;
    _value;
    constructor(hash, key, value) {
        this._hash = hash;
        this._key = key;
        this._value = value;
    }
    get key() {
        return this._key;
    }
    get value() {
        return this._value;
    }
    isEmpty() {
        return false;
    }
    isLeaf() {
        return true;
    }
    get(key, hash, shift) {
        return hash === this._hash && _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(key, this._key)
            ? _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_2__.Option.of(this._value)
            : _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_2__.None;
    }
    set(key, value, hash, shift) {
        if (hash === this._hash) {
            if (_siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(key, this._key)) {
                if (_siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(value, this._value)) {
                    return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.unchanged(this);
                }
                return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.updated(Leaf.of(hash, key, value));
            }
            return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.created(Collision.of(hash, [this, Leaf.of(hash, key, value)]));
        }
        const fragment = Node.fragment(this._hash, shift);
        return Sparse.of(bit(fragment), [this]).set(key, value, hash, shift);
    }
    delete(key, hash) {
        return hash === this._hash && _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(key, this._key)
            ? _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.deleted(Empty)
            : _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.unchanged(this);
    }
    map(mapper) {
        return Leaf.of(this._hash, this._key, mapper(this._value, this._key));
    }
    equals(value) {
        return (value instanceof Leaf &&
            value._hash === this._hash &&
            _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(value._key, this._key) &&
            _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(value._value, this._value));
    }
    *[Symbol.iterator]() {
        yield [this._key, this._value];
    }
}
/**
 * @internal
 */
class Collision {
    static of(hash, nodes) {
        return new Collision(hash, nodes);
    }
    _hash;
    _nodes;
    constructor(hash, nodes) {
        this._hash = hash;
        this._nodes = nodes;
    }
    isEmpty() {
        return false;
    }
    isLeaf() {
        return false;
    }
    get(key, hash, shift) {
        if (hash === this._hash) {
            for (const node of this._nodes) {
                const value = node.get(key, hash, shift);
                if (value.isSome()) {
                    return value;
                }
            }
        }
        return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_2__.None;
    }
    set(key, value, hash, shift) {
        if (hash === this._hash) {
            for (let i = 0, n = this._nodes.length; i < n; i++) {
                const node = this._nodes[i];
                if (_siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(key, node.key)) {
                    if (_siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(value, node.value)) {
                        return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.unchanged(this);
                    }
                    return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.updated(Collision.of(this._hash, replace(this._nodes, i, Leaf.of(hash, key, value))));
                }
            }
            return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.created(Collision.of(this._hash, this._nodes.concat(Leaf.of(hash, key, value))));
        }
        const fragment = Node.fragment(this._hash, shift);
        return Sparse.of(bit(fragment), [this]).set(key, value, hash, shift);
    }
    delete(key, hash) {
        if (hash === this._hash) {
            for (let i = 0, n = this._nodes.length; i < n; i++) {
                const node = this._nodes[i];
                if (_siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(key, node.key)) {
                    const nodes = remove(this._nodes, i);
                    if (nodes.length === 1) {
                        // We just deleted the penultimate Leaf of the Collision, so we can
                        // remove the Collision and only keep the remaining Leaf.
                        return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.deleted(nodes[0]);
                    }
                    return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.deleted(Collision.of(this._hash, nodes));
                }
            }
        }
        return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.unchanged(this);
    }
    map(mapper) {
        return Collision.of(this._hash, this._nodes.map((node) => node.map(mapper)));
    }
    equals(value) {
        return (value instanceof Collision &&
            value._hash === this._hash &&
            value._nodes.length === this._nodes.length &&
            value._nodes.every((node, i) => node.equals(this._nodes[i])));
    }
    *[Symbol.iterator]() {
        for (const node of this._nodes) {
            yield* node;
        }
    }
}
/**
 * @internal
 */
class Sparse {
    static of(mask, nodes) {
        return new Sparse(mask, nodes);
    }
    _mask;
    _nodes;
    constructor(mask, nodes) {
        this._mask = mask;
        this._nodes = nodes;
    }
    isEmpty() {
        return false;
    }
    isLeaf() {
        return false;
    }
    get(key, hash, shift) {
        const fragment = Node.fragment(hash, shift);
        if (test(this._mask, fragment)) {
            const index = Node.index(fragment, this._mask);
            return this._nodes[index].get(key, hash, shift + Node.Bits);
        }
        return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_2__.None;
    }
    set(key, value, hash, shift) {
        const fragment = Node.fragment(hash, shift);
        const index = Node.index(fragment, this._mask);
        if (test(this._mask, fragment)) {
            const { result: node, status } = this._nodes[index].set(key, value, hash, shift + Node.Bits);
            if (status === "unchanged") {
                return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.unchanged(this);
            }
            const sparse = Sparse.of(this._mask, replace(this._nodes, index, node));
            switch (status) {
                case "created":
                    return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.created(sparse);
                case "updated":
                default:
                    return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.updated(sparse);
            }
        }
        return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.created(Sparse.of(set(this._mask, fragment), insert(this._nodes, index, Leaf.of(hash, key, value))));
    }
    delete(key, hash, shift) {
        const fragment = Node.fragment(hash, shift);
        if (test(this._mask, fragment)) {
            const index = Node.index(fragment, this._mask);
            const { result: node, status } = this._nodes[index].delete(key, hash, shift + Node.Bits);
            if (status === "unchanged") {
                return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.unchanged(this);
            }
            if (node.isEmpty()) {
                const nodes = remove(this._nodes, index);
                if (nodes.length === 1) {
                    // We deleted the penultimate child of the Sparse, we may be able to
                    // simplify the tree.
                    if (nodes[0].isLeaf() || nodes[0] instanceof Collision) {
                        // The last child is leaf-like, hence hashes will be fully matched
                        // against its key(s) and we can remove the current Sparse
                        return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.deleted(nodes[0]);
                    }
                    // Otherwise, the last child is a Sparse. We can't simply collapse the
                    // tree by removing the current Sparse, since it will cause the child
                    // mask to be tested with the wrong shift (its depth in the tree would
                    // be different).
                    // We could do some further optimisations (e.g., if the child's
                    // children are all leaf-like, we could instead delete the lone child
                    // and connect directly to the grandchildren). This is, however,
                    // getting hairy to make all cases working fine, and we assume this
                    // kind of situation is not too frequent. So we pay the price of
                    // keeping a non-branching Sparse until we need to optimise that.
                }
                return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.deleted(Sparse.of(clear(this._mask, fragment), nodes));
            }
            return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.deleted(Sparse.of(this._mask, replace(this._nodes, index, node)));
        }
        return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.unchanged(this);
    }
    map(mapper) {
        return Sparse.of(this._mask, this._nodes.map((node) => node.map(mapper)));
    }
    equals(value) {
        return (value instanceof Sparse &&
            value._mask === this._mask &&
            value._nodes.length === this._nodes.length &&
            value._nodes.every((node, i) => node.equals(this._nodes[i])));
    }
    *[Symbol.iterator]() {
        for (const node of this._nodes) {
            yield* node;
        }
    }
}
function insert(array, index, value) {
    const result = new Array(array.length + 1);
    result[index] = value;
    for (let i = 0, n = index; i < n; i++) {
        result[i] = array[i];
    }
    for (let i = index, n = array.length; i < n; i++) {
        result[i + 1] = array[i];
    }
    return result;
}
function remove(array, index) {
    const result = new Array(array.length - 1);
    for (let i = 0, n = index; i < n; i++) {
        result[i] = array[i];
    }
    for (let i = index, n = result.length; i < n; i++) {
        result[i] = array[i + 1];
    }
    return result;
}
function replace(array, index, value) {
    const result = array.slice(0);
    result[index] = value;
    return result;
}
//# sourceMappingURL=node.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-map/dist/status.js":
/*!***********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-map/dist/status.js ***!
  \***********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Status: () => (/* binding */ Status)
/* harmony export */ });
/**
 * @internal
 */
var Status;
(function (Status_1) {
    class Status {
        _result;
        constructor(result) {
            this._result = result;
        }
        get result() {
            return this._result;
        }
    }
    class Created extends Status {
        static of(result) {
            return new Created(result);
        }
        constructor(result) {
            super(result);
        }
        get status() {
            return "created";
        }
    }
    Status_1.Created = Created;
    Status_1.created = Created.of;
    class Updated extends Status {
        static of(result) {
            return new Updated(result);
        }
        constructor(result) {
            super(result);
        }
        get status() {
            return "updated";
        }
    }
    Status_1.Updated = Updated;
    Status_1.updated = Updated.of;
    class Deleted extends Status {
        static of(result) {
            return new Deleted(result);
        }
        constructor(result) {
            super(result);
        }
        get status() {
            return "deleted";
        }
    }
    Status_1.Deleted = Deleted;
    Status_1.deleted = Deleted.of;
    class Unchanged extends Status {
        static of(result) {
            return new Unchanged(result);
        }
        constructor(result) {
            super(result);
        }
        get status() {
            return "unchanged";
        }
    }
    Status_1.Unchanged = Unchanged;
    Status_1.unchanged = Unchanged.of;
})(Status || (Status = {}));
//# sourceMappingURL=status.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-option/dist/index.js":
/*!*************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-option/dist/index.js ***!
  \*************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Maybe: () => (/* reexport safe */ _maybe_js__WEBPACK_IMPORTED_MODULE_0__.Maybe),
/* harmony export */   None: () => (/* reexport safe */ _none_js__WEBPACK_IMPORTED_MODULE_1__.None),
/* harmony export */   Option: () => (/* reexport safe */ _option_js__WEBPACK_IMPORTED_MODULE_2__.Option),
/* harmony export */   Some: () => (/* reexport safe */ _some_js__WEBPACK_IMPORTED_MODULE_3__.Some)
/* harmony export */ });
/* harmony import */ var _maybe_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./maybe.js */ "./node_modules/@siteimprove/alfa-option/dist/maybe.js");
/* harmony import */ var _none_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./none.js */ "./node_modules/@siteimprove/alfa-option/dist/none.js");
/* harmony import */ var _option_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./option.js */ "./node_modules/@siteimprove/alfa-option/dist/option.js");
/* harmony import */ var _some_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./some.js */ "./node_modules/@siteimprove/alfa-option/dist/some.js");




//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-option/dist/maybe.js":
/*!*************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-option/dist/maybe.js ***!
  \*************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Maybe: () => (/* binding */ Maybe)
/* harmony export */ });
/* harmony import */ var _option_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./option.js */ "./node_modules/@siteimprove/alfa-option/dist/option.js");

/**
 * @internal
 */
var Maybe;
(function (Maybe) {
    function toOption(maybe) {
        return _option_js__WEBPACK_IMPORTED_MODULE_0__.Option.isOption(maybe) ? maybe : _option_js__WEBPACK_IMPORTED_MODULE_0__.Option.of(maybe);
    }
    Maybe.toOption = toOption;
})(Maybe || (Maybe = {}));
//# sourceMappingURL=maybe.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-option/dist/none.js":
/*!************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-option/dist/none.js ***!
  \************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   None: () => (/* binding */ None)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-comparable */ "./node_modules/@siteimprove/alfa-comparable/dist/index.js");

const { compareComparable } = _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__.Comparable;
/**
 * @public
 */
const None = new (class None {
    isSome() {
        return false;
    }
    isNone() {
        return true;
    }
    map() {
        return this;
    }
    forEach() {
        return;
    }
    apply() {
        return this;
    }
    flatMap() {
        return this;
    }
    flatten() {
        return this;
    }
    reduce(reducer, accumulator) {
        return accumulator;
    }
    filter() {
        return this;
    }
    reject() {
        return this;
    }
    includes() {
        return false;
    }
    some() {
        return false;
    }
    none() {
        return true;
    }
    every() {
        return true;
    }
    and() {
        return this;
    }
    andThen() {
        return this;
    }
    or(option) {
        return option;
    }
    orElse(option) {
        return option();
    }
    /**
     * @internal
     */
    getUnsafe(message = "Attempted to .getUnsafe() from None") {
        throw new Error(message);
    }
    getOr(value) {
        return value;
    }
    getOrElse(value) {
        return value();
    }
    tee() {
        return this;
    }
    compare(option) {
        return this.compareWith(option, compareComparable);
    }
    compareWith(option) {
        return option.isNone() ? _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__.Comparison.Equal : _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__.Comparison.Less;
    }
    equals(value) {
        return value instanceof None;
    }
    hash(hash) {
        hash.writeBoolean(false);
    }
    *[Symbol.iterator]() { }
    toArray() {
        return [];
    }
    toJSON() {
        return {
            type: "none",
        };
    }
    toString() {
        return "None";
    }
})();
//# sourceMappingURL=none.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-option/dist/option.js":
/*!**************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-option/dist/option.js ***!
  \**************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Option: () => (/* binding */ Option)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-comparable */ "./node_modules/@siteimprove/alfa-comparable/dist/index.js");
/* harmony import */ var _none_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./none.js */ "./node_modules/@siteimprove/alfa-option/dist/none.js");
/* harmony import */ var _some_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./some.js */ "./node_modules/@siteimprove/alfa-option/dist/some.js");



/**
 * @public
 */
var Option;
(function (Option) {
    function isOption(value) {
        return isSome(value) || isNone(value);
    }
    Option.isOption = isOption;
    function isSome(value) {
        return _some_js__WEBPACK_IMPORTED_MODULE_2__.Some.isSome(value);
    }
    Option.isSome = isSome;
    function isNone(value) {
        return value === _none_js__WEBPACK_IMPORTED_MODULE_1__.None;
    }
    Option.isNone = isNone;
    function of(value) {
        return _some_js__WEBPACK_IMPORTED_MODULE_2__.Some.of(value);
    }
    Option.of = of;
    function empty() {
        return _none_js__WEBPACK_IMPORTED_MODULE_1__.None;
    }
    Option.empty = empty;
    function from(value) {
        return value === null || value === undefined ? _none_js__WEBPACK_IMPORTED_MODULE_1__.None : _some_js__WEBPACK_IMPORTED_MODULE_2__.Some.of(value);
    }
    Option.from = from;
    function conditional(value, predicate) {
        return predicate(value) ? _some_js__WEBPACK_IMPORTED_MODULE_2__.Some.of(value) : _none_js__WEBPACK_IMPORTED_MODULE_1__.None;
    }
    Option.conditional = conditional;
})(Option || (Option = {}));
//# sourceMappingURL=option.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-option/dist/some.js":
/*!************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-option/dist/some.js ***!
  \************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Some: () => (/* binding */ Some)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-comparable */ "./node_modules/@siteimprove/alfa-comparable/dist/index.js");
/* harmony import */ var _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @siteimprove/alfa-equatable */ "./node_modules/@siteimprove/alfa-equatable/dist/index.js");
/* harmony import */ var _siteimprove_alfa_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @siteimprove/alfa-json */ "./node_modules/@siteimprove/alfa-json/dist/index.js");
/* harmony import */ var _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @siteimprove/alfa-predicate */ "./node_modules/@siteimprove/alfa-predicate/dist/index.js");
/* harmony import */ var _none_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./none.js */ "./node_modules/@siteimprove/alfa-option/dist/none.js");





const { not, test } = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_3__.Predicate;
const { compareComparable } = _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__.Comparable;
/**
 * @public
 */
class Some {
    static of(value) {
        return new Some(value);
    }
    _value;
    constructor(value) {
        this._value = value;
    }
    isSome() {
        return true;
    }
    isNone() {
        return false;
    }
    map(mapper) {
        return new Some(mapper(this._value));
    }
    forEach(mapper) {
        mapper(this._value);
    }
    apply(mapper) {
        return mapper.map((mapper) => mapper(this._value));
    }
    flatMap(mapper) {
        return mapper(this._value);
    }
    flatten() {
        return this._value;
    }
    reduce(reducer, accumulator) {
        return reducer(accumulator, this._value);
    }
    filter(predicate) {
        return test(predicate, this._value) ? this : _none_js__WEBPACK_IMPORTED_MODULE_4__.None;
    }
    reject(predicate) {
        return this.filter(not(predicate));
    }
    includes(value) {
        return _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(value, this._value);
    }
    some(predicate) {
        return test(predicate, this._value);
    }
    none(predicate) {
        return test(not(predicate), this._value);
    }
    every(predicate) {
        return test(predicate, this._value);
    }
    and(option) {
        return option;
    }
    andThen(option) {
        return option(this._value);
    }
    or() {
        return this;
    }
    orElse() {
        return this;
    }
    get() {
        return this._value;
    }
    /**
     * @internal
     */
    getUnsafe() {
        return this._value;
    }
    getOr() {
        return this._value;
    }
    getOrElse() {
        return this._value;
    }
    tee(callback) {
        callback(this._value);
        return this;
    }
    compare(option) {
        return this.compareWith(option, compareComparable);
    }
    compareWith(option, comparer) {
        return option.isSome()
            ? comparer(this._value, option._value)
            : _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__.Comparison.Greater;
    }
    equals(value) {
        return value instanceof Some && _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(value._value, this._value);
    }
    hash(hash) {
        hash.writeBoolean(true).writeUnknown(this._value);
    }
    *[Symbol.iterator]() {
        yield this._value;
    }
    toArray() {
        return [this._value];
    }
    toJSON(options) {
        return {
            type: "some",
            value: _siteimprove_alfa_json__WEBPACK_IMPORTED_MODULE_2__.Serializable.toJSON(this._value, options),
        };
    }
    toString() {
        return `Some { ${this._value} }`;
    }
}
/**
 * @public
 */
(function (Some) {
    function isSome(value) {
        return value instanceof Some;
    }
    Some.isSome = isSome;
})(Some || (Some = {}));
//# sourceMappingURL=some.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-predicate/dist/index.js":
/*!****************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-predicate/dist/index.js ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Predicate: () => (/* reexport safe */ _predicate_js__WEBPACK_IMPORTED_MODULE_0__.Predicate)
/* harmony export */ });
/* harmony import */ var _predicate_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./predicate.js */ "./node_modules/@siteimprove/alfa-predicate/dist/predicate.js");

//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-predicate/dist/predicate.js":
/*!********************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-predicate/dist/predicate.js ***!
  \********************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Predicate: () => (/* binding */ Predicate)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-equatable */ "./node_modules/@siteimprove/alfa-equatable/dist/index.js");

/**
 * @public
 */
var Predicate;
(function (Predicate) {
    function test(predicate, value, ...args) {
        return predicate(value, ...args);
    }
    Predicate.test = test;
    function fold(predicate, ifTrue, ifFalse, value, ...args) {
        return predicate(value, ...args) ? ifTrue(value) : ifFalse(value);
    }
    Predicate.fold = fold;
    function not(predicate) {
        return (value, ...args) => !predicate(value, ...args);
    }
    Predicate.not = not;
    function and(...predicates) {
        return (value, ...args) => {
            for (let i = 0, n = predicates.length; i < n; i++) {
                if (!predicates[i](value, ...args)) {
                    return false;
                }
            }
            return true;
        };
    }
    Predicate.and = and;
    function or(...predicates) {
        return (value, ...args) => {
            for (let i = 0, n = predicates.length; i < n; i++) {
                if (predicates[i](value, ...args)) {
                    return true;
                }
            }
            return false;
        };
    }
    Predicate.or = or;
    function xor(...predicates) {
        return and(or(...predicates), not(and(...predicates)));
    }
    Predicate.xor = xor;
    function nor(...predicates) {
        return not(or(...predicates));
    }
    Predicate.nor = nor;
    function nand(...predicates) {
        return not(and(...predicates));
    }
    Predicate.nand = nand;
    function equals(...values) {
        return (other) => values.some((value) => _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_0__.Equatable.equals(other, value));
    }
    Predicate.equals = equals;
    function property(property, predicate) {
        return (value, ...args) => predicate(value[property], ...args);
    }
    Predicate.property = property;
    function tee(predicate, callback) {
        return (value, ...args) => {
            const result = predicate(value, ...args);
            callback(value, result, ...args);
            return result;
        };
    }
    Predicate.tee = tee;
})(Predicate || (Predicate = {}));
//# sourceMappingURL=predicate.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-refinement/dist/index.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-refinement/dist/index.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Refinement: () => (/* reexport safe */ _refinement_js__WEBPACK_IMPORTED_MODULE_0__.Refinement)
/* harmony export */ });
/* harmony import */ var _refinement_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./refinement.js */ "./node_modules/@siteimprove/alfa-refinement/dist/refinement.js");

//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-refinement/dist/refinement.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-refinement/dist/refinement.js ***!
  \**********************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Refinement: () => (/* binding */ Refinement)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-predicate */ "./node_modules/@siteimprove/alfa-predicate/dist/index.js");

/**
 * @public
 */
var Refinement;
(function (Refinement) {
    Refinement.test = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_0__.Predicate.test;
    Refinement.fold = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_0__.Predicate.fold;
    Refinement.not = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_0__.Predicate.not;
    Refinement.and = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_0__.Predicate.and;
    Refinement.or = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_0__.Predicate.or;
    Refinement.xor = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_0__.Predicate.xor;
    Refinement.nor = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_0__.Predicate.nor;
    Refinement.nand = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_0__.Predicate.nand;
    Refinement.equals = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_0__.Predicate.equals;
    Refinement.tee = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_0__.Predicate.tee;
    function isString(value) {
        return typeof value === "string";
    }
    Refinement.isString = isString;
    function isNumber(value) {
        return typeof value === "number";
    }
    Refinement.isNumber = isNumber;
    function isBigInt(value) {
        return typeof value === "bigint";
    }
    Refinement.isBigInt = isBigInt;
    function isBoolean(value) {
        return typeof value === "boolean";
    }
    Refinement.isBoolean = isBoolean;
    function isNull(value) {
        return value === null;
    }
    Refinement.isNull = isNull;
    function isUndefined(value) {
        return value === undefined;
    }
    Refinement.isUndefined = isUndefined;
    function isSymbol(value) {
        return typeof value === "symbol";
    }
    Refinement.isSymbol = isSymbol;
    function isFunction(value) {
        return typeof value === "function";
    }
    Refinement.isFunction = isFunction;
    function isObject(value) {
        return typeof value === "object" && value !== null;
    }
    Refinement.isObject = isObject;
    Refinement.isPrimitive = Refinement.or(isString, Refinement.or(isNumber, Refinement.or(isBigInt, Refinement.or(isBoolean, Refinement.or(isNull, Refinement.or(isUndefined, isSymbol))))));
})(Refinement || (Refinement = {}));
//# sourceMappingURL=refinement.js.map

/***/ }),

/***/ "./node_modules/webextension-polyfill/dist/browser-polyfill.js":
/*!*********************************************************************!*\
  !*** ./node_modules/webextension-polyfill/dist/browser-polyfill.js ***!
  \*********************************************************************/
/***/ (function(module, exports) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;(function (global, factory) {
  if (true) {
    !(__WEBPACK_AMD_DEFINE_ARRAY__ = [module], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory),
		__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
		(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  } else // removed by dead control flow
{ var mod; }
})(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : this, function (module) {
  /* webextension-polyfill - v0.10.0 - Fri Aug 12 2022 19:42:44 */

  /* -*- Mode: indent-tabs-mode: nil; js-indent-level: 2 -*- */

  /* vim: set sts=2 sw=2 et tw=80: */

  /* This Source Code Form is subject to the terms of the Mozilla Public
   * License, v. 2.0. If a copy of the MPL was not distributed with this
   * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
  "use strict";

  if (!globalThis.chrome?.runtime?.id) {
    throw new Error("This script should only be loaded in a browser extension.");
  }

  if (typeof globalThis.browser === "undefined" || Object.getPrototypeOf(globalThis.browser) !== Object.prototype) {
    const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received."; // Wrapping the bulk of this polyfill in a one-time-use function is a minor
    // optimization for Firefox. Since Spidermonkey does not fully parse the
    // contents of a function until the first time it's called, and since it will
    // never actually need to be called, this allows the polyfill to be included
    // in Firefox nearly for free.

    const wrapAPIs = extensionAPIs => {
      // NOTE: apiMetadata is associated to the content of the api-metadata.json file
      // at build time by replacing the following "include" with the content of the
      // JSON file.
      const apiMetadata = {
        "alarms": {
          "clear": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "clearAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "get": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "bookmarks": {
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getChildren": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getRecent": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getSubTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTree": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "browserAction": {
          "disable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "enable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "getBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getBadgeText": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "openPopup": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setBadgeText": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "browsingData": {
          "remove": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "removeCache": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCookies": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeDownloads": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFormData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeHistory": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeLocalStorage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePasswords": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePluginData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "settings": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "commands": {
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "contextMenus": {
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "cookies": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAllCookieStores": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "set": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "devtools": {
          "inspectedWindow": {
            "eval": {
              "minArgs": 1,
              "maxArgs": 2,
              "singleCallbackArg": false
            }
          },
          "panels": {
            "create": {
              "minArgs": 3,
              "maxArgs": 3,
              "singleCallbackArg": true
            },
            "elements": {
              "createSidebarPane": {
                "minArgs": 1,
                "maxArgs": 1
              }
            }
          }
        },
        "downloads": {
          "cancel": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "download": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "erase": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFileIcon": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "open": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "pause": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFile": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "resume": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "extension": {
          "isAllowedFileSchemeAccess": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "isAllowedIncognitoAccess": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "history": {
          "addUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "deleteRange": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getVisits": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "i18n": {
          "detectLanguage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAcceptLanguages": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "identity": {
          "launchWebAuthFlow": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "idle": {
          "queryState": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "management": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getSelf": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setEnabled": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "uninstallSelf": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "notifications": {
          "clear": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPermissionLevel": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "pageAction": {
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "hide": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "permissions": {
          "contains": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "request": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "runtime": {
          "getBackgroundPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPlatformInfo": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "openOptionsPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "requestUpdateCheck": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "sendMessage": {
            "minArgs": 1,
            "maxArgs": 3
          },
          "sendNativeMessage": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "setUninstallURL": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "sessions": {
          "getDevices": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getRecentlyClosed": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "restore": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "storage": {
          "local": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "managed": {
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            }
          },
          "sync": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          }
        },
        "tabs": {
          "captureVisibleTab": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "detectLanguage": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "discard": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "duplicate": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "executeScript": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getZoom": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getZoomSettings": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goBack": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goForward": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "highlight": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "insertCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "query": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "reload": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "sendMessage": {
            "minArgs": 2,
            "maxArgs": 3
          },
          "setZoom": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "setZoomSettings": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "update": {
            "minArgs": 1,
            "maxArgs": 2
          }
        },
        "topSites": {
          "get": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "webNavigation": {
          "getAllFrames": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFrame": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "webRequest": {
          "handlerBehaviorChanged": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "windows": {
          "create": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getLastFocused": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        }
      };

      if (Object.keys(apiMetadata).length === 0) {
        throw new Error("api-metadata.json has not been included in browser-polyfill");
      }
      /**
       * A WeakMap subclass which creates and stores a value for any key which does
       * not exist when accessed, but behaves exactly as an ordinary WeakMap
       * otherwise.
       *
       * @param {function} createItem
       *        A function which will be called in order to create the value for any
       *        key which does not exist, the first time it is accessed. The
       *        function receives, as its only argument, the key being created.
       */


      class DefaultWeakMap extends WeakMap {
        constructor(createItem, items = undefined) {
          super(items);
          this.createItem = createItem;
        }

        get(key) {
          if (!this.has(key)) {
            this.set(key, this.createItem(key));
          }

          return super.get(key);
        }

      }
      /**
       * Returns true if the given object is an object with a `then` method, and can
       * therefore be assumed to behave as a Promise.
       *
       * @param {*} value The value to test.
       * @returns {boolean} True if the value is thenable.
       */


      const isThenable = value => {
        return value && typeof value === "object" && typeof value.then === "function";
      };
      /**
       * Creates and returns a function which, when called, will resolve or reject
       * the given promise based on how it is called:
       *
       * - If, when called, `chrome.runtime.lastError` contains a non-null object,
       *   the promise is rejected with that value.
       * - If the function is called with exactly one argument, the promise is
       *   resolved to that value.
       * - Otherwise, the promise is resolved to an array containing all of the
       *   function's arguments.
       *
       * @param {object} promise
       *        An object containing the resolution and rejection functions of a
       *        promise.
       * @param {function} promise.resolve
       *        The promise's resolution function.
       * @param {function} promise.reject
       *        The promise's rejection function.
       * @param {object} metadata
       *        Metadata about the wrapped method which has created the callback.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function}
       *        The generated callback function.
       */


      const makeCallback = (promise, metadata) => {
        return (...callbackArgs) => {
          if (extensionAPIs.runtime.lastError) {
            promise.reject(new Error(extensionAPIs.runtime.lastError.message));
          } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
            promise.resolve(callbackArgs[0]);
          } else {
            promise.resolve(callbackArgs);
          }
        };
      };

      const pluralizeArguments = numArgs => numArgs == 1 ? "argument" : "arguments";
      /**
       * Creates a wrapper function for a method with the given name and metadata.
       *
       * @param {string} name
       *        The name of the method which is being wrapped.
       * @param {object} metadata
       *        Metadata about the method being wrapped.
       * @param {integer} metadata.minArgs
       *        The minimum number of arguments which must be passed to the
       *        function. If called with fewer than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {integer} metadata.maxArgs
       *        The maximum number of arguments which may be passed to the
       *        function. If called with more than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function(object, ...*)}
       *       The generated wrapper function.
       */


      const wrapAsyncFunction = (name, metadata) => {
        return function asyncFunctionWrapper(target, ...args) {
          if (args.length < metadata.minArgs) {
            throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
          }

          if (args.length > metadata.maxArgs) {
            throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
          }

          return new Promise((resolve, reject) => {
            if (metadata.fallbackToNoCallback) {
              // This API method has currently no callback on Chrome, but it return a promise on Firefox,
              // and so the polyfill will try to call it with a callback first, and it will fallback
              // to not passing the callback if the first call fails.
              try {
                target[name](...args, makeCallback({
                  resolve,
                  reject
                }, metadata));
              } catch (cbError) {
                console.warn(`${name} API method doesn't seem to support the callback parameter, ` + "falling back to call it without a callback: ", cbError);
                target[name](...args); // Update the API method metadata, so that the next API calls will not try to
                // use the unsupported callback anymore.

                metadata.fallbackToNoCallback = false;
                metadata.noCallback = true;
                resolve();
              }
            } else if (metadata.noCallback) {
              target[name](...args);
              resolve();
            } else {
              target[name](...args, makeCallback({
                resolve,
                reject
              }, metadata));
            }
          });
        };
      };
      /**
       * Wraps an existing method of the target object, so that calls to it are
       * intercepted by the given wrapper function. The wrapper function receives,
       * as its first argument, the original `target` object, followed by each of
       * the arguments passed to the original method.
       *
       * @param {object} target
       *        The original target object that the wrapped method belongs to.
       * @param {function} method
       *        The method being wrapped. This is used as the target of the Proxy
       *        object which is created to wrap the method.
       * @param {function} wrapper
       *        The wrapper function which is called in place of a direct invocation
       *        of the wrapped method.
       *
       * @returns {Proxy<function>}
       *        A Proxy object for the given method, which invokes the given wrapper
       *        method in its place.
       */


      const wrapMethod = (target, method, wrapper) => {
        return new Proxy(method, {
          apply(targetMethod, thisObj, args) {
            return wrapper.call(thisObj, target, ...args);
          }

        });
      };

      let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
      /**
       * Wraps an object in a Proxy which intercepts and wraps certain methods
       * based on the given `wrappers` and `metadata` objects.
       *
       * @param {object} target
       *        The target object to wrap.
       *
       * @param {object} [wrappers = {}]
       *        An object tree containing wrapper functions for special cases. Any
       *        function present in this object tree is called in place of the
       *        method in the same location in the `target` object tree. These
       *        wrapper methods are invoked as described in {@see wrapMethod}.
       *
       * @param {object} [metadata = {}]
       *        An object tree containing metadata used to automatically generate
       *        Promise-based wrapper functions for asynchronous. Any function in
       *        the `target` object tree which has a corresponding metadata object
       *        in the same location in the `metadata` tree is replaced with an
       *        automatically-generated wrapper function, as described in
       *        {@see wrapAsyncFunction}
       *
       * @returns {Proxy<object>}
       */

      const wrapObject = (target, wrappers = {}, metadata = {}) => {
        let cache = Object.create(null);
        let handlers = {
          has(proxyTarget, prop) {
            return prop in target || prop in cache;
          },

          get(proxyTarget, prop, receiver) {
            if (prop in cache) {
              return cache[prop];
            }

            if (!(prop in target)) {
              return undefined;
            }

            let value = target[prop];

            if (typeof value === "function") {
              // This is a method on the underlying object. Check if we need to do
              // any wrapping.
              if (typeof wrappers[prop] === "function") {
                // We have a special-case wrapper for this method.
                value = wrapMethod(target, target[prop], wrappers[prop]);
              } else if (hasOwnProperty(metadata, prop)) {
                // This is an async method that we have metadata for. Create a
                // Promise wrapper for it.
                let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                value = wrapMethod(target, target[prop], wrapper);
              } else {
                // This is a method that we don't know or care about. Return the
                // original method, bound to the underlying object.
                value = value.bind(target);
              }
            } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
              // This is an object that we need to do some wrapping for the children
              // of. Create a sub-object wrapper for it with the appropriate child
              // metadata.
              value = wrapObject(value, wrappers[prop], metadata[prop]);
            } else if (hasOwnProperty(metadata, "*")) {
              // Wrap all properties in * namespace.
              value = wrapObject(value, wrappers[prop], metadata["*"]);
            } else {
              // We don't need to do any wrapping for this property,
              // so just forward all access to the underlying object.
              Object.defineProperty(cache, prop, {
                configurable: true,
                enumerable: true,

                get() {
                  return target[prop];
                },

                set(value) {
                  target[prop] = value;
                }

              });
              return value;
            }

            cache[prop] = value;
            return value;
          },

          set(proxyTarget, prop, value, receiver) {
            if (prop in cache) {
              cache[prop] = value;
            } else {
              target[prop] = value;
            }

            return true;
          },

          defineProperty(proxyTarget, prop, desc) {
            return Reflect.defineProperty(cache, prop, desc);
          },

          deleteProperty(proxyTarget, prop) {
            return Reflect.deleteProperty(cache, prop);
          }

        }; // Per contract of the Proxy API, the "get" proxy handler must return the
        // original value of the target if that value is declared read-only and
        // non-configurable. For this reason, we create an object with the
        // prototype set to `target` instead of using `target` directly.
        // Otherwise we cannot return a custom object for APIs that
        // are declared read-only and non-configurable, such as `chrome.devtools`.
        //
        // The proxy handlers themselves will still use the original `target`
        // instead of the `proxyTarget`, so that the methods and properties are
        // dereferenced via the original targets.

        let proxyTarget = Object.create(target);
        return new Proxy(proxyTarget, handlers);
      };
      /**
       * Creates a set of wrapper functions for an event object, which handles
       * wrapping of listener functions that those messages are passed.
       *
       * A single wrapper is created for each listener function, and stored in a
       * map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
       * retrieve the original wrapper, so that  attempts to remove a
       * previously-added listener work as expected.
       *
       * @param {DefaultWeakMap<function, function>} wrapperMap
       *        A DefaultWeakMap object which will create the appropriate wrapper
       *        for a given listener function when one does not exist, and retrieve
       *        an existing one when it does.
       *
       * @returns {object}
       */


      const wrapEvent = wrapperMap => ({
        addListener(target, listener, ...args) {
          target.addListener(wrapperMap.get(listener), ...args);
        },

        hasListener(target, listener) {
          return target.hasListener(wrapperMap.get(listener));
        },

        removeListener(target, listener) {
          target.removeListener(wrapperMap.get(listener));
        }

      });

      const onRequestFinishedWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }
        /**
         * Wraps an onRequestFinished listener function so that it will return a
         * `getContent()` property which returns a `Promise` rather than using a
         * callback API.
         *
         * @param {object} req
         *        The HAR entry object representing the network request.
         */


        return function onRequestFinished(req) {
          const wrappedReq = wrapObject(req, {}
          /* wrappers */
          , {
            getContent: {
              minArgs: 0,
              maxArgs: 0
            }
          });
          listener(wrappedReq);
        };
      });
      const onMessageWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }
        /**
         * Wraps a message listener function so that it may send responses based on
         * its return value, rather than by returning a sentinel value and calling a
         * callback. If the listener function returns a Promise, the response is
         * sent when the promise either resolves or rejects.
         *
         * @param {*} message
         *        The message sent by the other end of the channel.
         * @param {object} sender
         *        Details about the sender of the message.
         * @param {function(*)} sendResponse
         *        A callback which, when called with an arbitrary argument, sends
         *        that value as a response.
         * @returns {boolean}
         *        True if the wrapped listener returned a Promise, which will later
         *        yield a response. False otherwise.
         */


        return function onMessage(message, sender, sendResponse) {
          let didCallSendResponse = false;
          let wrappedSendResponse;
          let sendResponsePromise = new Promise(resolve => {
            wrappedSendResponse = function (response) {
              didCallSendResponse = true;
              resolve(response);
            };
          });
          let result;

          try {
            result = listener(message, sender, wrappedSendResponse);
          } catch (err) {
            result = Promise.reject(err);
          }

          const isResultThenable = result !== true && isThenable(result); // If the listener didn't returned true or a Promise, or called
          // wrappedSendResponse synchronously, we can exit earlier
          // because there will be no response sent from this listener.

          if (result !== true && !isResultThenable && !didCallSendResponse) {
            return false;
          } // A small helper to send the message if the promise resolves
          // and an error if the promise rejects (a wrapped sendMessage has
          // to translate the message into a resolved promise or a rejected
          // promise).


          const sendPromisedResult = promise => {
            promise.then(msg => {
              // send the message value.
              sendResponse(msg);
            }, error => {
              // Send a JSON representation of the error if the rejected value
              // is an instance of error, or the object itself otherwise.
              let message;

              if (error && (error instanceof Error || typeof error.message === "string")) {
                message = error.message;
              } else {
                message = "An unexpected error occurred";
              }

              sendResponse({
                __mozWebExtensionPolyfillReject__: true,
                message
              });
            }).catch(err => {
              // Print an error on the console if unable to send the response.
              console.error("Failed to send onMessage rejected reply", err);
            });
          }; // If the listener returned a Promise, send the resolved value as a
          // result, otherwise wait the promise related to the wrappedSendResponse
          // callback to resolve and send it as a response.


          if (isResultThenable) {
            sendPromisedResult(result);
          } else {
            sendPromisedResult(sendResponsePromise);
          } // Let Chrome know that the listener is replying.


          return true;
        };
      });

      const wrappedSendMessageCallback = ({
        reject,
        resolve
      }, reply) => {
        if (extensionAPIs.runtime.lastError) {
          // Detect when none of the listeners replied to the sendMessage call and resolve
          // the promise to undefined as in Firefox.
          // See https://github.com/mozilla/webextension-polyfill/issues/130
          if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
            resolve();
          } else {
            reject(new Error(extensionAPIs.runtime.lastError.message));
          }
        } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
          // Convert back the JSON representation of the error into
          // an Error instance.
          reject(new Error(reply.message));
        } else {
          resolve(reply);
        }
      };

      const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
        if (args.length < metadata.minArgs) {
          throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
        }

        if (args.length > metadata.maxArgs) {
          throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
        }

        return new Promise((resolve, reject) => {
          const wrappedCb = wrappedSendMessageCallback.bind(null, {
            resolve,
            reject
          });
          args.push(wrappedCb);
          apiNamespaceObj.sendMessage(...args);
        });
      };

      const staticWrappers = {
        devtools: {
          network: {
            onRequestFinished: wrapEvent(onRequestFinishedWrappers)
          }
        },
        runtime: {
          onMessage: wrapEvent(onMessageWrappers),
          onMessageExternal: wrapEvent(onMessageWrappers),
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 1,
            maxArgs: 3
          })
        },
        tabs: {
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 2,
            maxArgs: 3
          })
        }
      };
      const settingMetadata = {
        clear: {
          minArgs: 1,
          maxArgs: 1
        },
        get: {
          minArgs: 1,
          maxArgs: 1
        },
        set: {
          minArgs: 1,
          maxArgs: 1
        }
      };
      apiMetadata.privacy = {
        network: {
          "*": settingMetadata
        },
        services: {
          "*": settingMetadata
        },
        websites: {
          "*": settingMetadata
        }
      };
      return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
    }; // The build process adds a UMD wrapper around this file, which makes the
    // `module` variable available.


    module.exports = wrapAPIs(chrome);
  } else {
    module.exports = globalThis.browser;
  }
});
//# sourceMappingURL=browser-polyfill.js.map


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry needs to be wrapped in an IIFE because it needs to be in strict mode.
(() => {
"use strict";
/*!************************!*\
  !*** ./src/api/api.ts ***!
  \************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _siteimprove_alfa_map__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-map */ "./node_modules/@siteimprove/alfa-map/dist/index.js");
/* harmony import */ var _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @siteimprove/alfa-option */ "./node_modules/@siteimprove/alfa-option/dist/index.js");
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! webextension-polyfill */ "./node_modules/webextension-polyfill/dist/browser-polyfill.js");
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(webextension_polyfill__WEBPACK_IMPORTED_MODULE_2__);
/**
 * This is the main entry point to what we refer to as the API of the extension.
 * The API handles most interactions with Alfa, the browser, and the page being
 * tested and exposes an interface for the application code to call through
 * messaging.
 *
 * The API is run as a possibly non-persistent background script (or service
 * worker, depending on browsers) in the browser.
 * It must therefore not depend on any global state as such state will be lost
 * when the background script is unloaded.
 *
 * Notably, this forces the popup to connect directly to the devtools instance
 * of the inspected page; and this forces the popup map to be stored in local
 * storage.
 */





/**
 * Storage keys
 */
const POPUP_KEY = "popupsMap";

/**
 * Map from tabId to open popup.
 *
 * @remarks
 * Every listener will reload the popups map, to make sure it is up-to-date.
 * Listeners that update it also save it.
 * When clicking the extension button, we also take time to clean it, in case
 * anything bad happened at some point.
 */

let myPopups = _siteimprove_alfa_map__WEBPACK_IMPORTED_MODULE_0__.Map.empty();
async function loadPopupsMap() {
  const popups = await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().storage.local.get(POPUP_KEY);
  myPopups = _siteimprove_alfa_map__WEBPACK_IMPORTED_MODULE_0__.Map.from(popups?.[POPUP_KEY] ?? []);
}
async function savePopupsMap() {
  await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().storage.local.set({
    [POPUP_KEY]: myPopups.toArray()
  });
}
async function windowExists(windowId) {
  if (windowId === undefined) {
    return false;
  }
  try {
    await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().windows.get(windowId);
    return true;
  } catch (e) {
    // We assume errors mostly occur due to non-existent window.
    return false;
  }
}

/**
 * Remove entries with no corresponding opened window
 *
 * @remarks
 * This should not happen since the service worker should restart and clean
 * the map on window removed. This is however not expensive because we assume
 * the map will be small; and this prevents a possible vector of memory leak
 * since this is persistent storage and we have requested unlimited storage
 * permission.
 */
async function cleanPopupsMap() {
  let existing = _siteimprove_alfa_map__WEBPACK_IMPORTED_MODULE_0__.Map.empty();
  for (const [tabId, popup] of myPopups) {
    if (await windowExists(popup.windowId)) {
      existing = existing.set(tabId, popup);
    }
  }
  myPopups = existing;
}

/**
 * Cleanup popup-map when a popup window is closed.
 *
 * @remarks
 * This is triggered by the other listeners closing popup windows.
 */
webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().windows.onRemoved.addListener(async windowId => {
  await loadPopupsMap();
  let key = _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_1__.None;
  myPopups.find((popup, tabId) => {
    if (popup.windowId === windowId) {
      key = _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_1__.Option.of(tabId);
      return true;
    }
    return false;
  });
  key.forEach(key => myPopups = myPopups.delete(key));
  await savePopupsMap();
});

/**
 * Close popup if user navigate to another page.
 */
webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().tabs.onUpdated.addListener(async tabId => {
  await loadPopupsMap();
  const currentPopup = myPopups.get(tabId).getOr(undefined);
  if (currentPopup?.windowId) {
    // Close the popup if the url changes
    const tab = await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().tabs.get(tabId);
    if (currentPopup?.url !== tab.url && navigator.userAgent.indexOf("Firefox") === -1) {
      await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().windows.remove(currentPopup.windowId);
    }
  }
});

/**
 * Close popup if the audited tab is closed.
 */
webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().tabs.onRemoved.addListener(async tabId => {
  await loadPopupsMap();
  const currentPopup = myPopups.get(tabId).getOr(undefined);
  if (currentPopup?.windowId) {
    // Close the popup if the tab is closed
    await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().windows.remove(currentPopup.windowId);
  }
});

/**
 * Open popup when icon is clicked.
 * If the popup is open, close it.
 */
webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().action.onClicked.addListener(async tab => {
  // Bail out immediately if we cannot get a tabId
  if (!tab.id) {
    return;
  }
  await loadPopupsMap();
  await cleanPopupsMap();

  // If the current tab already has an extension popup, close the popup.
  const currentPopup = myPopups.get(tab.id).getOr(undefined);
  if (currentPopup?.windowId) {
    await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().windows.remove(currentPopup.windowId);
    return;
  }

  // Otherwise, open a new popup.
  const popupUrl = new URL(webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().runtime.getURL("app.html"));

  /**
   * Pass along the tab ID as a query parameter. The application code uses this
   * when making API calls.
   */
  popupUrl.searchParams.set("tabId", tab.id?.toString(10) || "");
  const popup = await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().windows.create({
    url: popupUrl.toString(),
    type: "panel",
    height: 600,
    width: 800
  });
  myPopups = myPopups.set(tab.id, {
    windowId: popup.id,
    url: tab.url
  });
  await savePopupsMap();
});
})();

/******/ 	return __webpack_exports__;
/******/ })()
;
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBpLmpzIiwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNWQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7OztBQ2xWQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDUEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7OztBQ05BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7OztBQy9DQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7QUNEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDVkE7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7O0FDaEpBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7OztBQ0RBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2RBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7QUNIQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7OztBQ3JEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQy9DQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7OztBQ0ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7OztBQ2xEQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDN0JBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7OztBQ2hOQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDWkE7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDRkE7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7O0FDaGlCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNQQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUNGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7OztBQ2ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUM5Q0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNGQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ2xPQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7QUN0VEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ25FQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDSkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDWEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDcEdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDckNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsSUE7QUFDQTs7Ozs7Ozs7Ozs7Ozs7OztBQ0RBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDckVBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7OztBQ3REQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQUFBO0FBU0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7O0FDcHZDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7QUN2QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7QUNQQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7OztBQ1BBOzs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDTkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovLy93ZWJwYWNrL3VuaXZlcnNhbE1vZHVsZURlZmluaXRpb24iLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLWFycmF5L2Rpc3QvYXJyYXkuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLWFycmF5L2Rpc3QvYnVpbHRpbi5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtYXJyYXkvZGlzdC9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtYml0cy9kaXN0L2JpdHMuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLWJpdHMvZGlzdC9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtY2xvbmUvZGlzdC9jbG9uZS5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtY2xvbmUvZGlzdC9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtY29tcGFyYWJsZS9kaXN0L2NvbXBhcmFibGUuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLWNvbXBhcmFibGUvZGlzdC9jb21wYXJlci5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtY29tcGFyYWJsZS9kaXN0L2NvbXBhcmlzb24uanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLWNvbXBhcmFibGUvZGlzdC9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtZW5jb2RpbmcvZGlzdC9kZWNvZGVyLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1lbmNvZGluZy9kaXN0L2VuY29kZXIuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLWVuY29kaW5nL2Rpc3QvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLWVxdWF0YWJsZS9kaXN0L2VxdWF0YWJsZS5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtZXF1YXRhYmxlL2Rpc3QvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLWZudi9kaXN0L2Zudi5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtZm52L2Rpc3QvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLWhhc2gvZGlzdC9oYXNoLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1oYXNoL2Rpc3QvaGFzaGFibGUuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLWhhc2gvZGlzdC9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtaXRlcmFibGUvZGlzdC9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtaXRlcmFibGUvZGlzdC9pdGVyYWJsZS5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtanNvbi9kaXN0L2J1aWx0aW4uanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLWpzb24vZGlzdC9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtanNvbi9kaXN0L2pzb24uanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLWpzb24vZGlzdC9zZXJpYWxpemFibGUuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLW1hcC9kaXN0L2luZGV4LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1tYXAvZGlzdC9tYXAuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLW1hcC9kaXN0L25vZGUuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLW1hcC9kaXN0L3N0YXR1cy5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtb3B0aW9uL2Rpc3QvaW5kZXguanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLW9wdGlvbi9kaXN0L21heWJlLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1vcHRpb24vZGlzdC9ub25lLmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1vcHRpb24vZGlzdC9vcHRpb24uanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLW9wdGlvbi9kaXN0L3NvbWUuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLXByZWRpY2F0ZS9kaXN0L2luZGV4LmpzIiwid2VicGFjazovLy8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1wcmVkaWNhdGUvZGlzdC9wcmVkaWNhdGUuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLXJlZmluZW1lbnQvZGlzdC9pbmRleC5qcyIsIndlYnBhY2s6Ly8vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtcmVmaW5lbWVudC9kaXN0L3JlZmluZW1lbnQuanMiLCJ3ZWJwYWNrOi8vLy4vbm9kZV9tb2R1bGVzL3dlYmV4dGVuc2lvbi1wb2x5ZmlsbC9kaXN0L2Jyb3dzZXItcG9seWZpbGwuanMiLCJ3ZWJwYWNrOi8vL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovLy93ZWJwYWNrL3J1bnRpbWUvY29tcGF0IGdldCBkZWZhdWx0IGV4cG9ydCIsIndlYnBhY2s6Ly8vd2VicGFjay9ydW50aW1lL2RlZmluZSBwcm9wZXJ0eSBnZXR0ZXJzIiwid2VicGFjazovLy93ZWJwYWNrL3J1bnRpbWUvaGFzT3duUHJvcGVydHkgc2hvcnRoYW5kIiwid2VicGFjazovLy93ZWJwYWNrL3J1bnRpbWUvbWFrZSBuYW1lc3BhY2Ugb2JqZWN0Iiwid2VicGFjazovLy8uL3NyYy9hcGkvYXBpLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiB3ZWJwYWNrVW5pdmVyc2FsTW9kdWxlRGVmaW5pdGlvbihyb290LCBmYWN0b3J5KSB7XG5cdGlmKHR5cGVvZiBleHBvcnRzID09PSAnb2JqZWN0JyAmJiB0eXBlb2YgbW9kdWxlID09PSAnb2JqZWN0Jylcblx0XHRtb2R1bGUuZXhwb3J0cyA9IGZhY3RvcnkoKTtcblx0ZWxzZSBpZih0eXBlb2YgZGVmaW5lID09PSAnZnVuY3Rpb24nICYmIGRlZmluZS5hbWQpXG5cdFx0ZGVmaW5lKFtdLCBmYWN0b3J5KTtcblx0ZWxzZSB7XG5cdFx0dmFyIGEgPSBmYWN0b3J5KCk7XG5cdFx0Zm9yKHZhciBpIGluIGEpICh0eXBlb2YgZXhwb3J0cyA9PT0gJ29iamVjdCcgPyBleHBvcnRzIDogcm9vdClbaV0gPSBhW2ldO1xuXHR9XG59KShzZWxmLCAoKSA9PiB7XG5yZXR1cm4gIiwiaW1wb3J0IHsgQ2xvbmUgfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtY2xvbmVcIjtcbmltcG9ydCB7IENvbXBhcmFibGUsIENvbXBhcmlzb24sIH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLWNvbXBhcmFibGVcIjtcbmltcG9ydCB7IEVxdWF0YWJsZSB9IGZyb20gXCJAc2l0ZWltcHJvdmUvYWxmYS1lcXVhdGFibGVcIjtcbmltcG9ydCB7IEl0ZXJhYmxlIH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLWl0ZXJhYmxlXCI7XG5pbXBvcnQgeyBTZXJpYWxpemFibGUgfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtanNvblwiO1xuaW1wb3J0IHsgTm9uZSwgT3B0aW9uIH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLW9wdGlvblwiO1xuaW1wb3J0IHsgUHJlZGljYXRlIH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLXByZWRpY2F0ZVwiO1xuaW1wb3J0ICogYXMgYnVpbHRpbiBmcm9tIFwiLi9idWlsdGluLmpzXCI7XG5jb25zdCB7IG5vdCB9ID0gUHJlZGljYXRlO1xuY29uc3QgeyBjb21wYXJlQ29tcGFyYWJsZSB9ID0gQ29tcGFyYWJsZTtcbi8qKlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgdmFyIEFycmF5O1xuKGZ1bmN0aW9uIChBcnJheSkge1xuICAgIGZ1bmN0aW9uIGlzQXJyYXkodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIGJ1aWx0aW4uQXJyYXkuaXNBcnJheSh2YWx1ZSk7XG4gICAgfVxuICAgIEFycmF5LmlzQXJyYXkgPSBpc0FycmF5O1xuICAgIGZ1bmN0aW9uIG9mKC4uLnZhbHVlcykge1xuICAgICAgICByZXR1cm4gdmFsdWVzO1xuICAgIH1cbiAgICBBcnJheS5vZiA9IG9mO1xuICAgIGZ1bmN0aW9uIGVtcHR5KCkge1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxuICAgIEFycmF5LmVtcHR5ID0gZW1wdHk7XG4gICAgZnVuY3Rpb24gYWxsb2NhdGUoY2FwYWNpdHkpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBidWlsdGluLkFycmF5KGNhcGFjaXR5KTtcbiAgICB9XG4gICAgQXJyYXkuYWxsb2NhdGUgPSBhbGxvY2F0ZTtcbiAgICAvKipcbiAgICAgKiBAcmVtYXJrc1xuICAgICAqIFVubGlrZSB0aGUgYnVpbHQtaW4gZnVuY3Rpb24gb2YgdGhlIHNhbWUgbmFtZSwgdGhpcyBmdW5jdGlvbiB3aWxsIHBhc3NcbiAgICAgKiBhbG9uZyBleGlzdGluZyBhcnJheXMgYXMtaXMgaW5zdGVhZCBvZiByZXR1cm5pbmcgYSBjb3B5LlxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGZyb20oaXRlcmFibGUpIHtcbiAgICAgICAgaWYgKGlzQXJyYXkoaXRlcmFibGUpKSB7XG4gICAgICAgICAgICByZXR1cm4gaXRlcmFibGU7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIFsuLi5pdGVyYWJsZV07XG4gICAgfVxuICAgIEFycmF5LmZyb20gPSBmcm9tO1xuICAgIGZ1bmN0aW9uIHNpemUoYXJyYXkpIHtcbiAgICAgICAgcmV0dXJuIGFycmF5Lmxlbmd0aDtcbiAgICB9XG4gICAgQXJyYXkuc2l6ZSA9IHNpemU7XG4gICAgZnVuY3Rpb24gaXNFbXB0eShhcnJheSkge1xuICAgICAgICByZXR1cm4gYXJyYXkubGVuZ3RoID09PSAwO1xuICAgIH1cbiAgICBBcnJheS5pc0VtcHR5ID0gaXNFbXB0eTtcbiAgICBmdW5jdGlvbiBjb3B5KGFycmF5KSB7XG4gICAgICAgIHJldHVybiBhcnJheS5zbGljZSgwKTtcbiAgICB9XG4gICAgQXJyYXkuY29weSA9IGNvcHk7XG4gICAgZnVuY3Rpb24gY2xvbmUoYXJyYXkpIHtcbiAgICAgICAgcmV0dXJuIGFycmF5Lm1hcChDbG9uZS5jbG9uZSk7XG4gICAgfVxuICAgIEFycmF5LmNsb25lID0gY2xvbmU7XG4gICAgZnVuY3Rpb24gZm9yRWFjaChhcnJheSwgY2FsbGJhY2spIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG4gPSBhcnJheS5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIGNhbGxiYWNrKGFycmF5W2ldLCBpKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBBcnJheS5mb3JFYWNoID0gZm9yRWFjaDtcbiAgICBmdW5jdGlvbiBtYXAoYXJyYXksIG1hcHBlcikge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBuZXcgYnVpbHRpbi5BcnJheShhcnJheS5sZW5ndGgpO1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IGFycmF5Lmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgcmVzdWx0W2ldID0gbWFwcGVyKGFycmF5W2ldLCBpKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBBcnJheS5tYXAgPSBtYXA7XG4gICAgZnVuY3Rpb24gZmxhdE1hcChhcnJheSwgbWFwcGVyKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGVtcHR5KCk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBuID0gYXJyYXkubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICByZXN1bHQucHVzaCguLi5tYXBwZXIoYXJyYXlbaV0sIGkpKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBBcnJheS5mbGF0TWFwID0gZmxhdE1hcDtcbiAgICBmdW5jdGlvbiBmbGF0dGVuKGFycmF5KSB7XG4gICAgICAgIHJldHVybiBmbGF0TWFwKGFycmF5LCAoYXJyYXkpID0+IGFycmF5KTtcbiAgICB9XG4gICAgQXJyYXkuZmxhdHRlbiA9IGZsYXR0ZW47XG4gICAgZnVuY3Rpb24gcmVkdWNlKGFycmF5LCByZWR1Y2VyLCBhY2N1bXVsYXRvcikge1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IGFycmF5Lmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgYWNjdW11bGF0b3IgPSByZWR1Y2VyKGFjY3VtdWxhdG9yLCBhcnJheVtpXSwgaSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGFjY3VtdWxhdG9yO1xuICAgIH1cbiAgICBBcnJheS5yZWR1Y2UgPSByZWR1Y2U7XG4gICAgZnVuY3Rpb24gcmVkdWNlV2hpbGUoYXJyYXksIHByZWRpY2F0ZSwgcmVkdWNlciwgYWNjdW11bGF0b3IpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG4gPSBhcnJheS5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gYXJyYXlbaV07XG4gICAgICAgICAgICBpZiAocHJlZGljYXRlKHZhbHVlLCBpKSkge1xuICAgICAgICAgICAgICAgIGFjY3VtdWxhdG9yID0gcmVkdWNlcihhY2N1bXVsYXRvciwgdmFsdWUsIGkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGFjY3VtdWxhdG9yO1xuICAgIH1cbiAgICBBcnJheS5yZWR1Y2VXaGlsZSA9IHJlZHVjZVdoaWxlO1xuICAgIGZ1bmN0aW9uIHJlZHVjZVVudGlsKGFycmF5LCBwcmVkaWNhdGUsIHJlZHVjZXIsIGFjY3VtdWxhdG9yKSB7XG4gICAgICAgIHJldHVybiByZWR1Y2VXaGlsZShhcnJheSwgbm90KHByZWRpY2F0ZSksIHJlZHVjZXIsIGFjY3VtdWxhdG9yKTtcbiAgICB9XG4gICAgQXJyYXkucmVkdWNlVW50aWwgPSByZWR1Y2VVbnRpbDtcbiAgICBmdW5jdGlvbiBhcHBseShhcnJheSwgbWFwcGVyKSB7XG4gICAgICAgIHJldHVybiBmbGF0TWFwKG1hcHBlciwgKG1hcHBlcikgPT4gbWFwKGFycmF5LCBtYXBwZXIpKTtcbiAgICB9XG4gICAgQXJyYXkuYXBwbHkgPSBhcHBseTtcbiAgICBmdW5jdGlvbiBmaWx0ZXIoYXJyYXksIHByZWRpY2F0ZSkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBlbXB0eSgpO1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IGFycmF5Lmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBhcnJheVtpXTtcbiAgICAgICAgICAgIGlmIChwcmVkaWNhdGUodmFsdWUsIGkpKSB7XG4gICAgICAgICAgICAgICAgcmVzdWx0LnB1c2godmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIEFycmF5LmZpbHRlciA9IGZpbHRlcjtcbiAgICBmdW5jdGlvbiByZWplY3QoYXJyYXksIHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gZmlsdGVyKGFycmF5LCBub3QocHJlZGljYXRlKSk7XG4gICAgfVxuICAgIEFycmF5LnJlamVjdCA9IHJlamVjdDtcbiAgICBmdW5jdGlvbiBmaW5kKGFycmF5LCBwcmVkaWNhdGUpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG4gPSBhcnJheS5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gYXJyYXlbaV07XG4gICAgICAgICAgICBpZiAocHJlZGljYXRlKHZhbHVlLCBpKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBPcHRpb24ub2YodmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBOb25lO1xuICAgIH1cbiAgICBBcnJheS5maW5kID0gZmluZDtcbiAgICBmdW5jdGlvbiBmaW5kTGFzdChhcnJheSwgcHJlZGljYXRlKSB7XG4gICAgICAgIGZvciAobGV0IGkgPSBhcnJheS5sZW5ndGggLSAxOyBpID49IDA7IGktLSkge1xuICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBhcnJheVtpXTtcbiAgICAgICAgICAgIGlmIChwcmVkaWNhdGUodmFsdWUsIGkpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIE9wdGlvbi5vZih2YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIE5vbmU7XG4gICAgfVxuICAgIEFycmF5LmZpbmRMYXN0ID0gZmluZExhc3Q7XG4gICAgZnVuY3Rpb24gaW5jbHVkZXMoYXJyYXksIHZhbHVlKSB7XG4gICAgICAgIHJldHVybiBzb21lKGFycmF5LCBQcmVkaWNhdGUuZXF1YWxzKHZhbHVlKSk7XG4gICAgfVxuICAgIEFycmF5LmluY2x1ZGVzID0gaW5jbHVkZXM7XG4gICAgZnVuY3Rpb24gY29sbGVjdChhcnJheSwgbWFwcGVyKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGVtcHR5KCk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBuID0gYXJyYXkubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIG1hcHBlcihhcnJheVtpXSwgaSkpIHtcbiAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh2YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgQXJyYXkuY29sbGVjdCA9IGNvbGxlY3Q7XG4gICAgZnVuY3Rpb24gY29sbGVjdEZpcnN0KGFycmF5LCBtYXBwZXIpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG4gPSBhcnJheS5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gbWFwcGVyKGFycmF5W2ldLCBpKTtcbiAgICAgICAgICAgIGlmICh2YWx1ZS5pc1NvbWUoKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gTm9uZTtcbiAgICB9XG4gICAgQXJyYXkuY29sbGVjdEZpcnN0ID0gY29sbGVjdEZpcnN0O1xuICAgIGZ1bmN0aW9uIHNvbWUoYXJyYXksIHByZWRpY2F0ZSkge1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IGFycmF5Lmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgaWYgKHByZWRpY2F0ZShhcnJheVtpXSwgaSkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIEFycmF5LnNvbWUgPSBzb21lO1xuICAgIGZ1bmN0aW9uIG5vbmUoYXJyYXksIHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gZXZlcnkoYXJyYXksIG5vdChwcmVkaWNhdGUpKTtcbiAgICB9XG4gICAgQXJyYXkubm9uZSA9IG5vbmU7XG4gICAgZnVuY3Rpb24gZXZlcnkoYXJyYXksIHByZWRpY2F0ZSkge1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IGFycmF5Lmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgaWYgKCFwcmVkaWNhdGUoYXJyYXlbaV0sIGkpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBBcnJheS5ldmVyeSA9IGV2ZXJ5O1xuICAgIGZ1bmN0aW9uIGNvdW50KGFycmF5LCBwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIHJlZHVjZShhcnJheSwgKGNvdW50LCB2YWx1ZSwgaW5kZXgpID0+IChwcmVkaWNhdGUodmFsdWUsIGluZGV4KSA/IGNvdW50ICsgMSA6IGNvdW50KSwgMCk7XG4gICAgfVxuICAgIEFycmF5LmNvdW50ID0gY291bnQ7XG4gICAgZnVuY3Rpb24gZGlzdGluY3QoYXJyYXkpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gZW1wdHkoKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG4gPSBhcnJheS5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gYXJyYXlbaV07XG4gICAgICAgICAgICBpZiAocmVzdWx0LnNvbWUoUHJlZGljYXRlLmVxdWFscyh2YWx1ZSkpKSB7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXN1bHQucHVzaCh2YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgQXJyYXkuZGlzdGluY3QgPSBkaXN0aW5jdDtcbiAgICBmdW5jdGlvbiBnZXQoYXJyYXksIGluZGV4KSB7XG4gICAgICAgIHJldHVybiBpbmRleCA8IGFycmF5Lmxlbmd0aCA/IE9wdGlvbi5vZihhcnJheVtpbmRleF0pIDogTm9uZTtcbiAgICB9XG4gICAgQXJyYXkuZ2V0ID0gZ2V0O1xuICAgIGZ1bmN0aW9uIGhhcyhhcnJheSwgaW5kZXgpIHtcbiAgICAgICAgcmV0dXJuIGluZGV4IDwgYXJyYXkubGVuZ3RoO1xuICAgIH1cbiAgICBBcnJheS5oYXMgPSBoYXM7XG4gICAgZnVuY3Rpb24gc2V0KGFycmF5LCBpbmRleCwgdmFsdWUpIHtcbiAgICAgICAgaWYgKGluZGV4IDwgYXJyYXkubGVuZ3RoKSB7XG4gICAgICAgICAgICBhcnJheVtpbmRleF0gPSB2YWx1ZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYXJyYXk7XG4gICAgfVxuICAgIEFycmF5LnNldCA9IHNldDtcbiAgICBmdW5jdGlvbiBpbnNlcnQoYXJyYXksIGluZGV4LCB2YWx1ZSkge1xuICAgICAgICBpZiAoaW5kZXggPD0gYXJyYXkubGVuZ3RoKSB7XG4gICAgICAgICAgICBhcnJheS5zcGxpY2UoaW5kZXgsIDAsIHZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYXJyYXk7XG4gICAgfVxuICAgIEFycmF5Lmluc2VydCA9IGluc2VydDtcbiAgICBmdW5jdGlvbiBhcHBlbmQoYXJyYXksIHZhbHVlKSB7XG4gICAgICAgIGFycmF5LnB1c2godmFsdWUpO1xuICAgICAgICByZXR1cm4gYXJyYXk7XG4gICAgfVxuICAgIEFycmF5LmFwcGVuZCA9IGFwcGVuZDtcbiAgICBmdW5jdGlvbiBwcmVwZW5kKGFycmF5LCB2YWx1ZSkge1xuICAgICAgICBhcnJheS51bnNoaWZ0KHZhbHVlKTtcbiAgICAgICAgcmV0dXJuIGFycmF5O1xuICAgIH1cbiAgICBBcnJheS5wcmVwZW5kID0gcHJlcGVuZDtcbiAgICBmdW5jdGlvbiBjb25jYXQoYXJyYXksIC4uLml0ZXJhYmxlcykge1xuICAgICAgICByZXR1cm4gWy4uLkl0ZXJhYmxlLmNvbmNhdChhcnJheSwgLi4uaXRlcmFibGVzKV07XG4gICAgfVxuICAgIEFycmF5LmNvbmNhdCA9IGNvbmNhdDtcbiAgICBmdW5jdGlvbiBzdWJ0cmFjdChhcnJheSwgLi4uaXRlcmFibGVzKSB7XG4gICAgICAgIHJldHVybiBbLi4uSXRlcmFibGUuc3VidHJhY3QoYXJyYXksIC4uLml0ZXJhYmxlcyldO1xuICAgIH1cbiAgICBBcnJheS5zdWJ0cmFjdCA9IHN1YnRyYWN0O1xuICAgIGZ1bmN0aW9uIGludGVyc2VjdChhcnJheSwgLi4uaXRlcmFibGVzKSB7XG4gICAgICAgIHJldHVybiBbLi4uSXRlcmFibGUuaW50ZXJzZWN0KGFycmF5LCAuLi5pdGVyYWJsZXMpXTtcbiAgICB9XG4gICAgQXJyYXkuaW50ZXJzZWN0ID0gaW50ZXJzZWN0O1xuICAgIGZ1bmN0aW9uIHppcChhcnJheSwgaXRlcmFibGUpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gZW1wdHkoKTtcbiAgICAgICAgY29uc3QgaXQgPSBJdGVyYWJsZS5pdGVyYXRvcihpdGVyYWJsZSk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBuID0gYXJyYXkubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCBuZXh0ID0gaXQubmV4dCgpO1xuICAgICAgICAgICAgaWYgKG5leHQuZG9uZSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmVzdWx0LnB1c2goW2FycmF5W2ldLCBuZXh0LnZhbHVlXSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgQXJyYXkuemlwID0gemlwO1xuICAgIGZ1bmN0aW9uIGZpcnN0KGFycmF5KSB7XG4gICAgICAgIHJldHVybiBhcnJheS5sZW5ndGggPiAwID8gT3B0aW9uLm9mKGFycmF5WzBdKSA6IE5vbmU7XG4gICAgfVxuICAgIEFycmF5LmZpcnN0ID0gZmlyc3Q7XG4gICAgZnVuY3Rpb24gbGFzdChhcnJheSkge1xuICAgICAgICByZXR1cm4gYXJyYXkubGVuZ3RoID4gMCA/IE9wdGlvbi5vZihhcnJheVthcnJheS5sZW5ndGggLSAxXSkgOiBOb25lO1xuICAgIH1cbiAgICBBcnJheS5sYXN0ID0gbGFzdDtcbiAgICBmdW5jdGlvbiBzb3J0KGFycmF5KSB7XG4gICAgICAgIHJldHVybiBzb3J0V2l0aChhcnJheSwgY29tcGFyZUNvbXBhcmFibGUpO1xuICAgIH1cbiAgICBBcnJheS5zb3J0ID0gc29ydDtcbiAgICBmdW5jdGlvbiBzb3J0V2l0aChhcnJheSwgY29tcGFyZXIpIHtcbiAgICAgICAgcmV0dXJuIGFycmF5LnNvcnQoY29tcGFyZXIpO1xuICAgIH1cbiAgICBBcnJheS5zb3J0V2l0aCA9IHNvcnRXaXRoO1xuICAgIGZ1bmN0aW9uIGNvbXBhcmUoYSwgYikge1xuICAgICAgICByZXR1cm4gY29tcGFyZVdpdGgoYSwgYiwgY29tcGFyZUNvbXBhcmFibGUpO1xuICAgIH1cbiAgICBBcnJheS5jb21wYXJlID0gY29tcGFyZTtcbiAgICBmdW5jdGlvbiBjb21wYXJlV2l0aChhLCBiLCBjb21wYXJlcikge1xuICAgICAgICByZXR1cm4gSXRlcmFibGUuY29tcGFyZVdpdGgoYSwgYiwgY29tcGFyZXIpO1xuICAgIH1cbiAgICBBcnJheS5jb21wYXJlV2l0aCA9IGNvbXBhcmVXaXRoO1xuICAgIGZ1bmN0aW9uIHNlYXJjaChhcnJheSwgdmFsdWUsIGNvbXBhcmVyKSB7XG4gICAgICAgIGxldCBsb3dlciA9IDA7XG4gICAgICAgIGxldCB1cHBlciA9IGFycmF5Lmxlbmd0aCAtIDE7XG4gICAgICAgIHdoaWxlIChsb3dlciA8PSB1cHBlcikge1xuICAgICAgICAgICAgY29uc3QgbWlkZGxlID0gKGxvd2VyICsgKHVwcGVyIC0gbG93ZXIpIC8gMikgPj4+IDA7XG4gICAgICAgICAgICBzd2l0Y2ggKGNvbXBhcmVyKHZhbHVlLCBhcnJheVttaWRkbGVdKSkge1xuICAgICAgICAgICAgICAgIGNhc2UgQ29tcGFyaXNvbi5HcmVhdGVyOlxuICAgICAgICAgICAgICAgICAgICBsb3dlciA9IG1pZGRsZSArIDE7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgQ29tcGFyaXNvbi5MZXNzOlxuICAgICAgICAgICAgICAgICAgICB1cHBlciA9IG1pZGRsZSAtIDE7XG4gICAgICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgICAgIGNhc2UgQ29tcGFyaXNvbi5FcXVhbDpcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIG1pZGRsZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbG93ZXI7XG4gICAgfVxuICAgIEFycmF5LnNlYXJjaCA9IHNlYXJjaDtcbiAgICBmdW5jdGlvbiBlcXVhbHMoYSwgYikge1xuICAgICAgICBpZiAoYS5sZW5ndGggIT09IGIubGVuZ3RoKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG4gPSBhLmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgaWYgKCFFcXVhdGFibGUuZXF1YWxzKGFbaV0sIGJbaV0pKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBBcnJheS5lcXVhbHMgPSBlcXVhbHM7XG4gICAgZnVuY3Rpb24gaGFzaChhcnJheSwgaGFzaCkge1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IGFycmF5Lmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgaGFzaC53cml0ZVVua25vd24oYXJyYXlbaV0pO1xuICAgICAgICB9XG4gICAgICAgIGhhc2gud3JpdGVVaW50MzIoYXJyYXkubGVuZ3RoKTtcbiAgICB9XG4gICAgQXJyYXkuaGFzaCA9IGhhc2g7XG4gICAgZnVuY3Rpb24gaXRlcmF0b3IoYXJyYXkpIHtcbiAgICAgICAgcmV0dXJuIGFycmF5W1N5bWJvbC5pdGVyYXRvcl0oKTtcbiAgICB9XG4gICAgQXJyYXkuaXRlcmF0b3IgPSBpdGVyYXRvcjtcbiAgICBmdW5jdGlvbiB0b0pTT04oYXJyYXksIG9wdGlvbnMpIHtcbiAgICAgICAgcmV0dXJuIGFycmF5Lm1hcCgodmFsdWUpID0+IFNlcmlhbGl6YWJsZS50b0pTT04odmFsdWUsIG9wdGlvbnMpKTtcbiAgICB9XG4gICAgQXJyYXkudG9KU09OID0gdG9KU09OO1xufSkoQXJyYXkgfHwgKEFycmF5ID0ge30pKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWFycmF5LmpzLm1hcCIsIi8vIFRoaXMgZmlsZSBkZWZpbmVzIGV4cG9ydHMgZnJvbSB0aGUgYnVpbHRpbiBgQXJyYXlgIGNvbnN0cnVjdG9yIGZvciBpbnRlcm5hbFxuLy8gdXNlIG9ubHkuXG4vKipcbiAqIEBpbnRlcm5hbFxuICovXG5jb25zdCBCdWlsdGluID0gQXJyYXk7XG5leHBvcnQgeyBCdWlsdGluIGFzIEFycmF5IH07XG4vLyMgc291cmNlTWFwcGluZ1VSTD1idWlsdGluLmpzLm1hcCIsIi8qKlxuICogVGhpcyBwYWNrYWdlIHByb3ZpZGVzIGZ1bmN0aW9uYWxpdHkgZm9yIHdvcmtpbmcgd2l0aCBhcnJheXMuXG4gKlxuICogQHBhY2thZ2VEb2N1bWVudGF0aW9uXG4gKi9cbmV4cG9ydCAqIGZyb20gXCIuL2FycmF5LmpzXCI7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCIvKipcbiAqIEBwdWJsaWNcbiAqL1xuZXhwb3J0IHZhciBCaXRzO1xuKGZ1bmN0aW9uIChCaXRzKSB7XG4gICAgZnVuY3Rpb24gYml0KGkpIHtcbiAgICAgICAgcmV0dXJuIDEgPDwgaTtcbiAgICB9XG4gICAgQml0cy5iaXQgPSBiaXQ7XG4gICAgZnVuY3Rpb24gc2V0KGJpdHMsIGkpIHtcbiAgICAgICAgcmV0dXJuIGJpdHMgfCBiaXQoaSk7XG4gICAgfVxuICAgIEJpdHMuc2V0ID0gc2V0O1xuICAgIGZ1bmN0aW9uIGNsZWFyKGJpdHMsIGkpIHtcbiAgICAgICAgcmV0dXJuIGJpdHMgJiB+Yml0KGkpO1xuICAgIH1cbiAgICBCaXRzLmNsZWFyID0gY2xlYXI7XG4gICAgZnVuY3Rpb24gdGVzdChiaXRzLCBpKSB7XG4gICAgICAgIHJldHVybiAoYml0cyAmIGJpdChpKSkgIT09IDA7XG4gICAgfVxuICAgIEJpdHMudGVzdCA9IHRlc3Q7XG4gICAgZnVuY3Rpb24gdGFrZShiaXRzLCBuKSB7XG4gICAgICAgIHJldHVybiBiaXRzICYgKCgxIDw8IG4pIC0gMSk7XG4gICAgfVxuICAgIEJpdHMudGFrZSA9IHRha2U7XG4gICAgZnVuY3Rpb24gc2tpcChiaXRzLCBuKSB7XG4gICAgICAgIHJldHVybiBiaXRzID4+PiBuO1xuICAgIH1cbiAgICBCaXRzLnNraXAgPSBza2lwO1xuICAgIC8qKlxuICAgICAqIEByZW1hcmtzXG4gICAgICogVGhpcyBpcyBhIDMyLWJpdCB2YXJpYW50IG9mIHRoZSA2NC1iaXQgcG9wdWxhdGlvbiBjb3VudCBhbGdvcml0aG0gb3V0bGluZWRcbiAgICAgKiBvbiBXaWtpcGVkaWEuIFVudGlsIEVDTUFTY3JpcHQgbmF0aXZlbHkgcHJvdmlkZXMgYW4gZWZmaWNpZW50IHBvcHVsYXRpb25cbiAgICAgKiBjb3VudCBhbGdvcml0aG0sIHRoaXMgaXMgdGhlIGJlc3Qgd2UgY2FuIGRvLlxuICAgICAqXG4gICAgICoge0BsaW5rIGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL0hhbW1pbmdfd2VpZ2h0fVxuICAgICAqL1xuICAgIGZ1bmN0aW9uIHBvcENvdW50KGJpdHMpIHtcbiAgICAgICAgYml0cyAtPSAoYml0cyA+PiAxKSAmIDB4NTU1NTU1NTU7XG4gICAgICAgIGJpdHMgPSAoYml0cyAmIDB4MzMzMzMzMzMpICsgKChiaXRzID4+IDIpICYgMHgzMzMzMzMzMyk7XG4gICAgICAgIGJpdHMgPSAoYml0cyArIChiaXRzID4+IDQpKSAmIDB4MGYwZjBmMGY7XG4gICAgICAgIGJpdHMgKz0gYml0cyA+PiA4O1xuICAgICAgICBiaXRzICs9IGJpdHMgPj4gMTY7XG4gICAgICAgIHJldHVybiBiaXRzICYgMHg3ZjtcbiAgICB9XG4gICAgQml0cy5wb3BDb3VudCA9IHBvcENvdW50O1xufSkoQml0cyB8fCAoQml0cyA9IHt9KSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1iaXRzLmpzLm1hcCIsImV4cG9ydCAqIGZyb20gXCIuL2JpdHMuanNcIjtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsIi8qKlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgdmFyIENsb25lO1xuKGZ1bmN0aW9uIChDbG9uZSkge1xuICAgIGZ1bmN0aW9uIGNsb25lKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZS5jbG9uZSgpO1xuICAgIH1cbiAgICBDbG9uZS5jbG9uZSA9IGNsb25lO1xufSkoQ2xvbmUgfHwgKENsb25lID0ge30pKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNsb25lLmpzLm1hcCIsImV4cG9ydCAqIGZyb20gXCIuL2Nsb25lLmpzXCI7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCJpbXBvcnQgeyBSZWZpbmVtZW50IH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLXJlZmluZW1lbnRcIjtcbmltcG9ydCB7IENvbXBhcmlzb24gfSBmcm9tIFwiLi9jb21wYXJpc29uLmpzXCI7XG5jb25zdCB7IGlzU3RyaW5nLCBpc051bWJlciwgaXNCaWdJbnQsIGlzQm9vbGVhbiwgaXNGdW5jdGlvbiwgaXNPYmplY3QgfSA9IFJlZmluZW1lbnQ7XG4vKipcbiAqIFRoaXMgbmFtZXNwYWNlIHByb3ZpZGVzIGFkZGl0aW9uYWwgZnVuY3Rpb25zIGZvciB0aGVcbiAqIHtAbGluayAoQ29tcGFyYWJsZTppbnRlcmZhY2UpfSBpbnRlcmZhY2UuXG4gKlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgdmFyIENvbXBhcmFibGU7XG4oZnVuY3Rpb24gKENvbXBhcmFibGUpIHtcbiAgICAvKipcbiAgICAgKiBDaGVjayBpZiBhbiB1bmtub3duIHZhbHVlIGltcGxlbWVudHMgdGhlIHtAbGluayAoQ29tcGFyYWJsZTppbnRlcmZhY2UpfVxuICAgICAqIGludGVyZmFjZS5cbiAgICAgKi9cbiAgICBmdW5jdGlvbiBpc0NvbXBhcmFibGUodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIGlzT2JqZWN0KHZhbHVlKSAmJiBpc0Z1bmN0aW9uKHZhbHVlLmNvbXBhcmUpO1xuICAgIH1cbiAgICBDb21wYXJhYmxlLmlzQ29tcGFyYWJsZSA9IGlzQ29tcGFyYWJsZTtcbiAgICBmdW5jdGlvbiBjb21wYXJlKGEsIGIpIHtcbiAgICAgICAgaWYgKGlzU3RyaW5nKGEpKSB7XG4gICAgICAgICAgICByZXR1cm4gY29tcGFyZVN0cmluZyhhLCBiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNOdW1iZXIoYSkpIHtcbiAgICAgICAgICAgIHJldHVybiBjb21wYXJlTnVtYmVyKGEsIGIpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0JpZ0ludChhKSkge1xuICAgICAgICAgICAgcmV0dXJuIGNvbXBhcmVCaWdJbnQoYSwgYik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzQm9vbGVhbihhKSkge1xuICAgICAgICAgICAgcmV0dXJuIGNvbXBhcmVCb29sZWFuKGEsIGIpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBjb21wYXJlQ29tcGFyYWJsZShhLCBiKTtcbiAgICB9XG4gICAgQ29tcGFyYWJsZS5jb21wYXJlID0gY29tcGFyZTtcbiAgICAvKipcbiAgICAgKiBAcmVtYXJrc1xuICAgICAqIFRoaXMgc2hvdWxkIG9ubHkgYmUgdXNlZCBpbiBjYXNlcyB3aGVyZSBicmFuY2ggbWlzcHJlZGljdGlvbnMgY2F1c2VkIGJ5IHRoZVxuICAgICAqIG1vcmUgZ2VuZXJhbCB7QGxpbmsgKENvbXBhcmFibGU6bmFtZXNwYWNlKS4oY29tcGFyZToxKX0gYXJlIHVuZGVzaXJlZC5cbiAgICAgKi9cbiAgICBmdW5jdGlvbiBjb21wYXJlU3RyaW5nKGEsIGIpIHtcbiAgICAgICAgcmV0dXJuIGNvbXBhcmVQcmltaXRpdmUoYSwgYik7XG4gICAgfVxuICAgIENvbXBhcmFibGUuY29tcGFyZVN0cmluZyA9IGNvbXBhcmVTdHJpbmc7XG4gICAgLyoqXG4gICAgICogQHJlbWFya3NcbiAgICAgKiBUaGlzIHNob3VsZCBvbmx5IGJlIHVzZWQgaW4gY2FzZXMgd2hlcmUgYnJhbmNoIG1pc3ByZWRpY3Rpb25zIGNhdXNlZCBieSB0aGVcbiAgICAgKiBtb3JlIGdlbmVyYWwge0BsaW5rIChDb21wYXJhYmxlOm5hbWVzcGFjZSkuKGNvbXBhcmU6Mil9IGFyZSB1bmRlc2lyZWQuXG4gICAgICovXG4gICAgZnVuY3Rpb24gY29tcGFyZU51bWJlcihhLCBiKSB7XG4gICAgICAgIHJldHVybiBjb21wYXJlUHJpbWl0aXZlKGEsIGIpO1xuICAgIH1cbiAgICBDb21wYXJhYmxlLmNvbXBhcmVOdW1iZXIgPSBjb21wYXJlTnVtYmVyO1xuICAgIC8qKlxuICAgICAqIEByZW1hcmtzXG4gICAgICogVGhpcyBzaG91bGQgb25seSBiZSB1c2VkIGluIGNhc2VzIHdoZXJlIGJyYW5jaCBtaXNwcmVkaWN0aW9ucyBjYXVzZWQgYnkgdGhlXG4gICAgICogbW9yZSBnZW5lcmFsIHtAbGluayAoQ29tcGFyYWJsZTpuYW1lc3BhY2UpLihjb21wYXJlOjMpfSBhcmUgdW5kZXNpcmVkLlxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGNvbXBhcmVCaWdJbnQoYSwgYikge1xuICAgICAgICByZXR1cm4gY29tcGFyZVByaW1pdGl2ZShhLCBiKTtcbiAgICB9XG4gICAgQ29tcGFyYWJsZS5jb21wYXJlQmlnSW50ID0gY29tcGFyZUJpZ0ludDtcbiAgICAvKipcbiAgICAgKiBAcmVtYXJrc1xuICAgICAqIFRoaXMgc2hvdWxkIG9ubHkgYmUgdXNlZCBpbiBjYXNlcyB3aGVyZSBicmFuY2ggbWlzcHJlZGljdGlvbnMgY2F1c2VkIGJ5IHRoZVxuICAgICAqIG1vcmUgZ2VuZXJhbCB7QGxpbmsgKENvbXBhcmFibGU6bmFtZXNwYWNlKS4oY29tcGFyZTo0KX0gYXJlIHVuZGVzaXJlZC5cbiAgICAgKi9cbiAgICBmdW5jdGlvbiBjb21wYXJlQm9vbGVhbihhLCBiKSB7XG4gICAgICAgIHJldHVybiBjb21wYXJlUHJpbWl0aXZlKGEsIGIpO1xuICAgIH1cbiAgICBDb21wYXJhYmxlLmNvbXBhcmVCb29sZWFuID0gY29tcGFyZUJvb2xlYW47XG4gICAgLyoqXG4gICAgICogQHJlbWFya3NcbiAgICAgKiBUaGlzIHNob3VsZCBvbmx5IGJlIHVzZWQgaW4gY2FzZXMgd2hlcmUgYnJhbmNoIG1pc3ByZWRpY3Rpb25zIGNhdXNlZCBieSB0aGVcbiAgICAgKiBtb3JlIGdlbmVyYWwge0BsaW5rIChDb21wYXJhYmxlOm5hbWVzcGFjZSkuKGNvbXBhcmU6NSl9IGFyZSB1bmRlc2lyZWQuXG4gICAgICovXG4gICAgZnVuY3Rpb24gY29tcGFyZUNvbXBhcmFibGUoYSwgYikge1xuICAgICAgICByZXR1cm4gYS5jb21wYXJlKGIpO1xuICAgIH1cbiAgICBDb21wYXJhYmxlLmNvbXBhcmVDb21wYXJhYmxlID0gY29tcGFyZUNvbXBhcmFibGU7XG4gICAgLyoqXG4gICAgICogQ29tcGFyZSB0d28gcHJpbWl0aXZlIHZhbHVlcy5cbiAgICAgKi9cbiAgICBmdW5jdGlvbiBjb21wYXJlUHJpbWl0aXZlKGEsIGIpIHtcbiAgICAgICAgaWYgKGEgPCBiKSB7XG4gICAgICAgICAgICByZXR1cm4gQ29tcGFyaXNvbi5MZXNzO1xuICAgICAgICB9XG4gICAgICAgIGlmIChhID4gYikge1xuICAgICAgICAgICAgcmV0dXJuIENvbXBhcmlzb24uR3JlYXRlcjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gQ29tcGFyaXNvbi5FcXVhbDtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQ29tcGFyZSB0dXBsZXMgbGV4aWNvZ3JhcGhpY2FsbHlcbiAgICAgKlxuICAgICAqIHtAbGluayBodHRwczovL2VuLndpa2lwZWRpYS5vcmcvd2lraS9MZXhpY29ncmFwaGljX29yZGVyfVxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGNvbXBhcmVMZXhpY29ncmFwaGljYWxseShhLCBiLCBjb21wYXJlcikge1xuICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IGEubGVuZ3RoOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IGNvbXBhcmlzb24gPSBjb21wYXJlcltpXShhW2ldLCBiW2ldKTtcbiAgICAgICAgICAgIGlmIChjb21wYXJpc29uID09PSBDb21wYXJpc29uLkVxdWFsKSB7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gY29tcGFyaXNvbjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gQ29tcGFyaXNvbi5FcXVhbDtcbiAgICB9XG4gICAgQ29tcGFyYWJsZS5jb21wYXJlTGV4aWNvZ3JhcGhpY2FsbHkgPSBjb21wYXJlTGV4aWNvZ3JhcGhpY2FsbHk7XG4gICAgLyoqXG4gICAgICogQ2hlY2sgaWYgb25lIHZhbHVlIGlzIGxlc3MgdGhhbiBhbm90aGVyLlxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGlzTGVzc1RoYW4oYSwgYikge1xuICAgICAgICByZXR1cm4gYS5jb21wYXJlKGIpIDwgMDtcbiAgICB9XG4gICAgQ29tcGFyYWJsZS5pc0xlc3NUaGFuID0gaXNMZXNzVGhhbjtcbiAgICAvKipcbiAgICAgKiBDaGVjayBpZiBvbmUgdmFsdWUgaXMgbGVzcyB0aGFuIG9yIGVxdWFsIHRvIGFub3RoZXIuXG4gICAgICovXG4gICAgZnVuY3Rpb24gaXNMZXNzVGhhbk9yRXF1YWwoYSwgYikge1xuICAgICAgICByZXR1cm4gYS5jb21wYXJlKGIpIDw9IDA7XG4gICAgfVxuICAgIENvbXBhcmFibGUuaXNMZXNzVGhhbk9yRXF1YWwgPSBpc0xlc3NUaGFuT3JFcXVhbDtcbiAgICAvKipcbiAgICAgKiBDaGVjayBpZiBvbmUgdmFsdWUgaXMgZXF1YWwgdG8gYW5vdGhlclxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGlzRXF1YWwoYSwgYikge1xuICAgICAgICByZXR1cm4gYS5jb21wYXJlKGIpID09PSAwO1xuICAgIH1cbiAgICBDb21wYXJhYmxlLmlzRXF1YWwgPSBpc0VxdWFsO1xuICAgIC8qKlxuICAgICAqIENoZWNrIGlmIG9uZSB2YWx1ZSBpcyBncmVhdGVyIHRoYW4gYW5vdGhlci5cbiAgICAgKi9cbiAgICBmdW5jdGlvbiBpc0dyZWF0ZXJUaGFuKGEsIGIpIHtcbiAgICAgICAgcmV0dXJuIGEuY29tcGFyZShiKSA+IDA7XG4gICAgfVxuICAgIENvbXBhcmFibGUuaXNHcmVhdGVyVGhhbiA9IGlzR3JlYXRlclRoYW47XG4gICAgLyoqXG4gICAgICogQ2hlY2sgaWYgb25lIHZhbHVlIGlzIGdyZWF0ZXIgdGhhbiBvciBlcXVhbCB0byBhbm90aGVyLlxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGlzR3JlYXRlclRoYW5PckVxdWFsKGEsIGIpIHtcbiAgICAgICAgcmV0dXJuIGEuY29tcGFyZShiKSA+PSAwO1xuICAgIH1cbiAgICBDb21wYXJhYmxlLmlzR3JlYXRlclRoYW5PckVxdWFsID0gaXNHcmVhdGVyVGhhbk9yRXF1YWw7XG59KShDb21wYXJhYmxlIHx8IChDb21wYXJhYmxlID0ge30pKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNvbXBhcmFibGUuanMubWFwIiwiZXhwb3J0IHt9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y29tcGFyZXIuanMubWFwIiwiLyoqXG4gKiBAcmVtYXJrc1xuICogQ29tcGFyaXNvbnMgYXJlIGxpbWl0ZWQgdG8gdGhlIHJhbmdlIFstMSwgMV0gaW4gb3JkZXIgdG8gYXZvaWQgdGhlIHBvdGVudGlhbFxuICogb2Ygb3Zlci0vdW5kZXJmbG93cyB3aGVuIGNvbXBhcmlzb25zIGFyZSBpbXBsZW1lbnRlZCBuYWl2ZWx5IHVzaW5nXG4gKiBzdWJ0cmFjdGlvbnMsIHN1Y2ggYGEgLSBiYDsgdGhpcyB3b3VsZCBub3QgYmUgYWxsb3dlZC5cbiAqXG4gKiBAcHVibGljXG4gKi9cbmV4cG9ydCB2YXIgQ29tcGFyaXNvbjtcbihmdW5jdGlvbiAoQ29tcGFyaXNvbikge1xuICAgIENvbXBhcmlzb25bQ29tcGFyaXNvbltcIkxlc3NcIl0gPSAtMV0gPSBcIkxlc3NcIjtcbiAgICBDb21wYXJpc29uW0NvbXBhcmlzb25bXCJFcXVhbFwiXSA9IDBdID0gXCJFcXVhbFwiO1xuICAgIENvbXBhcmlzb25bQ29tcGFyaXNvbltcIkdyZWF0ZXJcIl0gPSAxXSA9IFwiR3JlYXRlclwiO1xufSkoQ29tcGFyaXNvbiB8fCAoQ29tcGFyaXNvbiA9IHt9KSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jb21wYXJpc29uLmpzLm1hcCIsImV4cG9ydCAqIGZyb20gXCIuL2NvbXBhcmFibGUuanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL2NvbXBhcmVyLmpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9jb21wYXJpc29uLmpzXCI7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCIvKipcbiAqIHtAbGluayBodHRwczovL2VuY29kaW5nLnNwZWMud2hhdHdnLm9yZy8jdGV4dGRlY29kZXJ9XG4gKlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgdmFyIERlY29kZXI7XG4oZnVuY3Rpb24gKERlY29kZXIpIHtcbiAgICAvKipcbiAgICAgKiB7QGxpbmsgaHR0cHM6Ly9lbmNvZGluZy5zcGVjLndoYXR3Zy5vcmcvI2RvbS10ZXh0ZGVjb2Rlci1kZWNvZGV9XG4gICAgICoge0BsaW5rIGh0dHBzOi8vZW5jb2Rpbmcuc3BlYy53aGF0d2cub3JnLyN1dGYtOC1kZWNvZGVyfVxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGRlY29kZShpbnB1dCkge1xuICAgICAgICBsZXQgb3V0cHV0ID0gXCJcIjtcbiAgICAgICAgbGV0IGkgPSAwO1xuICAgICAgICB3aGlsZSAoaSA8IGlucHV0Lmxlbmd0aCkge1xuICAgICAgICAgICAgbGV0IGJ5dGUgPSBpbnB1dFtpXTtcbiAgICAgICAgICAgIGxldCBieXRlc05lZWRlZCA9IDA7XG4gICAgICAgICAgICBsZXQgY29kZVBvaW50ID0gMDtcbiAgICAgICAgICAgIGlmIChieXRlIDw9IDB4N2YpIHtcbiAgICAgICAgICAgICAgICBieXRlc05lZWRlZCA9IDA7XG4gICAgICAgICAgICAgICAgY29kZVBvaW50ID0gYnl0ZSAmIDB4ZmY7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChieXRlIDw9IDB4ZGYpIHtcbiAgICAgICAgICAgICAgICBieXRlc05lZWRlZCA9IDE7XG4gICAgICAgICAgICAgICAgY29kZVBvaW50ID0gYnl0ZSAmIDB4MWY7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChieXRlIDw9IDB4ZWYpIHtcbiAgICAgICAgICAgICAgICBieXRlc05lZWRlZCA9IDI7XG4gICAgICAgICAgICAgICAgY29kZVBvaW50ID0gYnl0ZSAmIDB4MGY7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChieXRlIDw9IDB4ZjQpIHtcbiAgICAgICAgICAgICAgICBieXRlc05lZWRlZCA9IDM7XG4gICAgICAgICAgICAgICAgY29kZVBvaW50ID0gYnl0ZSAmIDB4MDc7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaW5wdXQubGVuZ3RoIC0gaSAtIGJ5dGVzTmVlZGVkID4gMCkge1xuICAgICAgICAgICAgICAgIGxldCBrID0gMDtcbiAgICAgICAgICAgICAgICB3aGlsZSAoayA8IGJ5dGVzTmVlZGVkKSB7XG4gICAgICAgICAgICAgICAgICAgIGJ5dGUgPSBpbnB1dFtpICsgayArIDFdO1xuICAgICAgICAgICAgICAgICAgICBjb2RlUG9pbnQgPSAoY29kZVBvaW50IDw8IDYpIHwgKGJ5dGUgJiAweDNmKTtcbiAgICAgICAgICAgICAgICAgICAgayArPSAxO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGNvZGVQb2ludCA9IDB4ZmZmZDtcbiAgICAgICAgICAgICAgICBieXRlc05lZWRlZCA9IGlucHV0Lmxlbmd0aCAtIGk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBvdXRwdXQgKz0gU3RyaW5nLmZyb21Db2RlUG9pbnQoY29kZVBvaW50KTtcbiAgICAgICAgICAgIGkgKz0gYnl0ZXNOZWVkZWQgKyAxO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBvdXRwdXQ7XG4gICAgfVxuICAgIERlY29kZXIuZGVjb2RlID0gZGVjb2RlO1xufSkoRGVjb2RlciB8fCAoRGVjb2RlciA9IHt9KSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1kZWNvZGVyLmpzLm1hcCIsIi8qKlxuICoge0BsaW5rIGh0dHBzOi8vZW5jb2Rpbmcuc3BlYy53aGF0d2cub3JnLyN0ZXh0ZW5jb2Rlcn1cbiAqXG4gKiBAcHVibGljXG4gKi9cbmV4cG9ydCB2YXIgRW5jb2RlcjtcbihmdW5jdGlvbiAoRW5jb2Rlcikge1xuICAgIC8qKlxuICAgICAqIHtAbGluayBodHRwczovL2VuY29kaW5nLnNwZWMud2hhdHdnLm9yZy8jZG9tLXRleHRlbmNvZGVyLWVuY29kZX1cbiAgICAgKiB7QGxpbmsgaHR0cHM6Ly9lbmNvZGluZy5zcGVjLndoYXR3Zy5vcmcvI3V0Zi04LWVuY29kZXJ9XG4gICAgICovXG4gICAgZnVuY3Rpb24gZW5jb2RlKGlucHV0KSB7XG4gICAgICAgIGNvbnN0IG91dHB1dCA9IFtdO1xuICAgICAgICBjb25zdCBsZW5ndGggPSBpbnB1dC5sZW5ndGg7XG4gICAgICAgIGxldCBpID0gMDtcbiAgICAgICAgd2hpbGUgKGkgPCBsZW5ndGgpIHtcbiAgICAgICAgICAgIGNvbnN0IGNvZGVQb2ludCA9IGlucHV0LmNvZGVQb2ludEF0KGkpO1xuICAgICAgICAgICAgbGV0IGNvdW50ID0gMDtcbiAgICAgICAgICAgIGxldCBiaXRzID0gMDtcbiAgICAgICAgICAgIGlmIChjb2RlUG9pbnQgPD0gMHg3Zikge1xuICAgICAgICAgICAgICAgIGNvdW50ID0gMDtcbiAgICAgICAgICAgICAgICBiaXRzID0gMHgwMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGNvZGVQb2ludCA8PSAweDdmZikge1xuICAgICAgICAgICAgICAgIGNvdW50ID0gNjtcbiAgICAgICAgICAgICAgICBiaXRzID0gMHhjMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGNvZGVQb2ludCA8PSAweGZmZmYpIHtcbiAgICAgICAgICAgICAgICBjb3VudCA9IDEyO1xuICAgICAgICAgICAgICAgIGJpdHMgPSAweGUwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoY29kZVBvaW50IDw9IDB4MWZmZmZmKSB7XG4gICAgICAgICAgICAgICAgY291bnQgPSAxODtcbiAgICAgICAgICAgICAgICBiaXRzID0gMHhmMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG91dHB1dC5wdXNoKGJpdHMgfCAoY29kZVBvaW50ID4+IGNvdW50KSk7XG4gICAgICAgICAgICBjb3VudCAtPSA2O1xuICAgICAgICAgICAgd2hpbGUgKGNvdW50ID49IDApIHtcbiAgICAgICAgICAgICAgICBvdXRwdXQucHVzaCgweDgwIHwgKChjb2RlUG9pbnQgPj4gY291bnQpICYgMHgzZikpO1xuICAgICAgICAgICAgICAgIGNvdW50IC09IDY7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpICs9IGNvZGVQb2ludCA+PSAweDEwMDAwID8gMiA6IDE7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG5ldyBVaW50OEFycmF5KG91dHB1dCk7XG4gICAgfVxuICAgIEVuY29kZXIuZW5jb2RlID0gZW5jb2RlO1xufSkoRW5jb2RlciB8fCAoRW5jb2RlciA9IHt9KSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1lbmNvZGVyLmpzLm1hcCIsImV4cG9ydCAqIGZyb20gXCIuL2RlY29kZXIuanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL2VuY29kZXIuanNcIjtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsIi8qKlxuICogVGhpcyBuYW1lc3BhY2UgcHJvdmlkZXMgYWRkaXRpb25hbCB0eXBlcyBhbmQgZnVuY3Rpb25zIGZvciB0aGVcbiAqIHtAbGluayAoRXF1YXRhYmxlOmludGVyZmFjZSl9IGludGVyZmFjZS5cbiAqXG4gKiBAcHVibGljXG4gKi9cbmV4cG9ydCB2YXIgRXF1YXRhYmxlO1xuKGZ1bmN0aW9uIChFcXVhdGFibGUpIHtcbiAgICAvLyBUaGUgZm9sbG93aW5nIHR3byB0eXBlIGd1YXJkcyBoYXZlIGJlZW4gaW5saW5lZCBmcm9tIHRoZVxuICAgIC8vIEBzaXRlaW1wcm92ZS9hbGZhLXJlZmluZW1lbnQgcGFja2FnZSB0byBhdm9pZCBjcmVhdGluZyBhIGNpcmN1bGFyXG4gICAgLy8gZGVwZW5kZW5jeS5cbiAgICBmdW5jdGlvbiBpc0Z1bmN0aW9uKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwiZnVuY3Rpb25cIjtcbiAgICB9XG4gICAgZnVuY3Rpb24gaXNPYmplY3QodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJvYmplY3RcIiAmJiB2YWx1ZSAhPT0gbnVsbDtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQ2hlY2sgaWYgYW4gdW5rbm93biB2YWx1ZSBpbXBsZW1lbnRzIHRoZSB7QGxpbmsgKEVxdWF0YWJsZTppbnRlcmZhY2UpfVxuICAgICAqIGludGVyZmFjZS5cbiAgICAgKi9cbiAgICBmdW5jdGlvbiBpc0VxdWF0YWJsZSh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gaXNPYmplY3QodmFsdWUpICYmIGlzRnVuY3Rpb24odmFsdWUuZXF1YWxzKTtcbiAgICB9XG4gICAgRXF1YXRhYmxlLmlzRXF1YXRhYmxlID0gaXNFcXVhdGFibGU7XG4gICAgLyoqXG4gICAgICogQ2hlY2sgaWYgdHdvIHVua25vd24gdmFsdWVzIGFyZSBlcXVhbC5cbiAgICAgKlxuICAgICAqIEByZW1hcmtzXG4gICAgICogSWYgZWl0aGVyIG9mIHRoZSBnaXZlbiB2YWx1ZXMgaW1wbGVtZW50IHRoZSB7QGxpbmsgKEVxdWF0YWJsZTppbnRlcmZhY2UpfVxuICAgICAqIGludGVyZmFjZSwgdGhlIGVxdWl2YWxlbmNlIGNvbnN0cmFpbnRzIG9mIHRoZSB2YWx1ZSB3aWxsIGJlIHVzZWQuIElmIG5vdCxcbiAgICAgKiBzdHJpY3QgZXF1YWxpdHkgd2lsbCBiZSB1c2VkIHdpdGggdGhlIGFkZGl0aW9uYWwgY29uc3RyYWludCB0aGF0IGBOYU5gIGlzXG4gICAgICogZXF1YWwgdG8gaXRzZWxmLlxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGVxdWFscyhhLCBiKSB7XG4gICAgICAgIGlmIChhID09PSBiIHx8XG4gICAgICAgICAgICAvLyBgTmFOYCBpcyB0aGUgb25seSB2YWx1ZSBpbiBKYXZhU2NyaXB0IHRoYXQgaXMgbm90IGVxdWFsIHRvIGl0c2VsZi5cbiAgICAgICAgICAgIChhICE9PSBhICYmIGIgIT09IGIpKSB7XG4gICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNFcXVhdGFibGUoYSkpIHtcbiAgICAgICAgICAgIHJldHVybiBhLmVxdWFscyhiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNFcXVhdGFibGUoYikpIHtcbiAgICAgICAgICAgIHJldHVybiBiLmVxdWFscyhhKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIEVxdWF0YWJsZS5lcXVhbHMgPSBlcXVhbHM7XG59KShFcXVhdGFibGUgfHwgKEVxdWF0YWJsZSA9IHt9KSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1lcXVhdGFibGUuanMubWFwIiwiZXhwb3J0ICogZnJvbSBcIi4vZXF1YXRhYmxlLmpzXCI7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCJpbXBvcnQgeyBIYXNoIH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLWhhc2hcIjtcbi8qKlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgY2xhc3MgRk5WIGV4dGVuZHMgSGFzaCB7XG4gICAgc3RhdGljIGVtcHR5KCkge1xuICAgICAgICByZXR1cm4gbmV3IEZOVigpO1xuICAgIH1cbiAgICBfaGFzaCA9IDIxNjYxMzYyNjE7XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgfVxuICAgIGZpbmlzaCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2hhc2ggPj4+IDA7IC8vIENvbnZlcnQgdG8gdW5zaWduZWQgMzItYml0IGludGVnZXJcbiAgICB9XG4gICAgd3JpdGUoZGF0YSkge1xuICAgICAgICBsZXQgaGFzaCA9IHRoaXMuX2hhc2g7XG4gICAgICAgIGZvciAoY29uc3Qgb2N0ZXQgb2YgZGF0YSkge1xuICAgICAgICAgICAgaGFzaCBePSBvY3RldDtcbiAgICAgICAgICAgIGhhc2ggKz1cbiAgICAgICAgICAgICAgICAoaGFzaCA8PCAxKSArIChoYXNoIDw8IDQpICsgKGhhc2ggPDwgNykgKyAoaGFzaCA8PCA4KSArIChoYXNoIDw8IDI0KTtcbiAgICAgICAgfVxuICAgICAgICB0aGlzLl9oYXNoID0gaGFzaDtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGVxdWFscyh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBGTlYgJiYgdmFsdWUuX2hhc2ggPT09IHRoaXMuX2hhc2g7XG4gICAgfVxufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Zm52LmpzLm1hcCIsImV4cG9ydCAqIGZyb20gXCIuL2Zudi5qc1wiO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXguanMubWFwIiwiaW1wb3J0IHsgRW5jb2RlciB9IGZyb20gXCJAc2l0ZWltcHJvdmUvYWxmYS1lbmNvZGluZ1wiO1xuaW1wb3J0IHsgSGFzaGFibGUgfSBmcm9tIFwiLi9oYXNoYWJsZS5qc1wiO1xuY29uc3QgeyBrZXlzIH0gPSBPYmplY3Q7XG4vKipcbiAqIEEgc3BlY2lhbCBvZmZzZXQgdXNlZCBmb3IgdGhlIGJ1aWx0aW4gdHlwZXMgYHRydWVgLCBgZmFsc2VgLCBgdW5kZWZpbmVkYCwgYW5kXG4gKiBgbnVsbGAuIFRoZSBvZmZzZXQgaXMgZGVzaWduZWQgdG8gbWluaW1pemUgdGhlIGNoYW5jZSBvZiBjb2xsaXNpb25zIGZvciBkYXRhXG4gKiBzdHJ1Y3R1cmVzIHRoYXQgcmVseSBvbiA1LWJpdCBwYXJ0aXRpb25pbmcuIFdlIHVzZSB0aGUgZmlyc3QgMzAgYml0cyBmb3IgNiBvZlxuICogdGhlc2UgcGFydGl0aW9ucywgbGVhdmluZyB1cyAyIGJpdHMgdG8gZW5jb2RlIHRoZSA0IGJ1aWx0aW4gdHlwZXMuXG4gKi9cbmNvbnN0IGJ1aWx0aW5PZmZzZXQgPSAwYjEwMDAwXzEwMDAwXzEwMDAwXzEwMDAwXzEwMDAwXzEwMDAwXzAwO1xuLyoqXG4gKiBAcHVibGljXG4gKi9cbmV4cG9ydCBjbGFzcyBIYXNoIHtcbiAgICAvKipcbiAgICAgKiBBIG1hcCBmcm9tIG9iamVjdHMgdG8gdGhlaXIgaGFzaCB2YWx1ZXMuIE9iamVjdHMgYXJlIHdlYWtseSByZWZlcmVuY2VkIGFzXG4gICAgICogdG8gbm90IHByZXZlbnQgdGhlbSBmcm9tIGJlaW5nIGdhcmJhZ2UgY29sbGVjdGVkLlxuICAgICAqL1xuICAgIHN0YXRpYyBfb2JqZWN0SGFzaGVzID0gbmV3IFdlYWtNYXAoKTtcbiAgICAvKipcbiAgICAgKiBBIG1hcCBmcm9tIHN5bWJvbHMgdG8gdGhlaXIgaGFzaCB2YWx1ZXMuIEFzIHRoZXJlJ3Mgbm90IGN1cnJlbnRseSBhIHdheSB0b1xuICAgICAqIHdlYWtseSByZWZlcmVuY2Ugc3ltYm9scywgd2UgaGF2ZSB0byBpbnN0ZWFkIHVzZSBzdHJvbmcgcmVmZXJlbmNlcy5cbiAgICAgKlxuICAgICAqIHtAbGluayBodHRwczovL2dpdGh1Yi5jb20vdGMzOS9wcm9wb3NhbC1zeW1ib2xzLWFzLXdlYWttYXAta2V5c31cbiAgICAgKi9cbiAgICBzdGF0aWMgX3N5bWJvbEhhc2hlcyA9IG5ldyBNYXAoKTtcbiAgICAvKipcbiAgICAgKiBUaGUgbmV4dCBhdmFpbGFibGUgaGFzaCB2YWx1ZS4gVGhpcyBpcyB1c2VkIGZvciBzeW1ib2xzIGFuZCBvYmplY3RzIHRoYXRcbiAgICAgKiBkb24ndCBpbXBsZW1lbnQgdGhlIHtAbGluayAoSGFzaGFibGU6aW50ZXJmYWNlKX0gaW50ZXJmYWNlLlxuICAgICAqL1xuICAgIHN0YXRpYyBfbmV4dEhhc2ggPSAwO1xuICAgIGNvbnN0cnVjdG9yKCkgeyB9XG4gICAgd3JpdGVTdHJpbmcoZGF0YSkge1xuICAgICAgICByZXR1cm4gdGhpcy53cml0ZShFbmNvZGVyLmVuY29kZShkYXRhKSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEByZW1hcmtzXG4gICAgICogQXMgSmF2YVNjcmlwdCByZXByZXNlbnRzIG51bWJlcnMgaW4gZG91YmxlLXByZWNpc2lvbiBmbG9hdGluZy1wb2ludCBmb3JtYXQsXG4gICAgICogbnVtYmVycyBpbiBnZW5lcmFsIHdpbGwgYmUgd3JpdHRlbiBhcyBzdWNoLlxuICAgICAqXG4gICAgICoge0BsaW5rIGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL0RvdWJsZS1wcmVjaXNpb25fZmxvYXRpbmctcG9pbnRfZm9ybWF0fVxuICAgICAqL1xuICAgIHdyaXRlTnVtYmVyKGRhdGEpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVGbG9hdDY0KGRhdGEpO1xuICAgIH1cbiAgICB3cml0ZUludChkYXRhLCBzaXplID0gMzIsIHNpZ25lZCA9IHRydWUpIHtcbiAgICAgICAgY29uc3QgYnVmZmVyID0gbmV3IEFycmF5QnVmZmVyKHNpemUgLyA4KTtcbiAgICAgICAgY29uc3QgdmlldyA9IG5ldyBEYXRhVmlldyhidWZmZXIpO1xuICAgICAgICBzd2l0Y2ggKHNpemUpIHtcbiAgICAgICAgICAgIGNhc2UgODpcbiAgICAgICAgICAgICAgICBzaWduZWQgPyB2aWV3LnNldEludDgoMCwgZGF0YSkgOiB2aWV3LnNldFVpbnQ4KDAsIGRhdGEpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAxNjpcbiAgICAgICAgICAgICAgICBzaWduZWQgPyB2aWV3LnNldEludDE2KDAsIGRhdGEpIDogdmlldy5zZXRVaW50MTYoMCwgZGF0YSk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIDMyOlxuICAgICAgICAgICAgICAgIHNpZ25lZCA/IHZpZXcuc2V0SW50MzIoMCwgZGF0YSkgOiB2aWV3LnNldFVpbnQzMigwLCBkYXRhKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy53cml0ZShuZXcgVWludDhBcnJheShidWZmZXIpKTtcbiAgICB9XG4gICAgd3JpdGVJbnQ4KGRhdGEpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVJbnQoZGF0YSwgOCwgdHJ1ZSk7XG4gICAgfVxuICAgIHdyaXRlVWludDgoZGF0YSkge1xuICAgICAgICByZXR1cm4gdGhpcy53cml0ZUludChkYXRhLCA4LCBmYWxzZSk7XG4gICAgfVxuICAgIHdyaXRlSW50MTYoZGF0YSkge1xuICAgICAgICByZXR1cm4gdGhpcy53cml0ZUludChkYXRhLCAxNiwgdHJ1ZSk7XG4gICAgfVxuICAgIHdyaXRlVWludDE2KGRhdGEpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVJbnQoZGF0YSwgMTYsIGZhbHNlKTtcbiAgICB9XG4gICAgd3JpdGVJbnQzMihkYXRhKSB7XG4gICAgICAgIHJldHVybiB0aGlzLndyaXRlSW50KGRhdGEsIDMyLCB0cnVlKTtcbiAgICB9XG4gICAgd3JpdGVVaW50MzIoZGF0YSkge1xuICAgICAgICByZXR1cm4gdGhpcy53cml0ZUludChkYXRhLCAzMiwgZmFsc2UpO1xuICAgIH1cbiAgICB3cml0ZUJpZ0ludChkYXRhLCBzaXplID0gNjQsIHNpZ25lZCA9IHRydWUpIHtcbiAgICAgICAgY29uc3QgYnVmZmVyID0gbmV3IEFycmF5QnVmZmVyKHNpemUgLyA4KTtcbiAgICAgICAgY29uc3QgdmlldyA9IG5ldyBEYXRhVmlldyhidWZmZXIpO1xuICAgICAgICBzd2l0Y2ggKHNpemUpIHtcbiAgICAgICAgICAgIGNhc2UgNjQ6XG4gICAgICAgICAgICAgICAgc2lnbmVkID8gdmlldy5zZXRCaWdJbnQ2NCgwLCBkYXRhKSA6IHZpZXcuc2V0QmlnVWludDY0KDAsIGRhdGEpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLndyaXRlKG5ldyBVaW50OEFycmF5KGJ1ZmZlcikpO1xuICAgIH1cbiAgICB3cml0ZUJpZ0ludDY0KGRhdGEpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVCaWdJbnQoZGF0YSwgNjQsIHRydWUpO1xuICAgIH1cbiAgICB3cml0ZUJpZ1VpbnQ2NChkYXRhKSB7XG4gICAgICAgIHJldHVybiB0aGlzLndyaXRlQmlnSW50KGRhdGEsIDY0LCBmYWxzZSk7XG4gICAgfVxuICAgIHdyaXRlRmxvYXQoZGF0YSwgc2l6ZSA9IDMyKSB7XG4gICAgICAgIGNvbnN0IGJ1ZmZlciA9IG5ldyBBcnJheUJ1ZmZlcihzaXplIC8gOCk7XG4gICAgICAgIGNvbnN0IHZpZXcgPSBuZXcgRGF0YVZpZXcoYnVmZmVyKTtcbiAgICAgICAgc3dpdGNoIChzaXplKSB7XG4gICAgICAgICAgICBjYXNlIDMyOlxuICAgICAgICAgICAgICAgIHZpZXcuc2V0RmxvYXQzMigwLCBkYXRhKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgNjQ6XG4gICAgICAgICAgICAgICAgdmlldy5zZXRGbG9hdDY0KDAsIGRhdGEpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLndyaXRlKG5ldyBVaW50OEFycmF5KGJ1ZmZlcikpO1xuICAgIH1cbiAgICB3cml0ZUZsb2F0MzIoZGF0YSkge1xuICAgICAgICByZXR1cm4gdGhpcy53cml0ZUZsb2F0KGRhdGEsIDMyKTtcbiAgICB9XG4gICAgd3JpdGVGbG9hdDY0KGRhdGEpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVGbG9hdChkYXRhLCA2NCk7XG4gICAgfVxuICAgIHdyaXRlQm9vbGVhbihkYXRhKSB7XG4gICAgICAgIHJldHVybiB0aGlzLndyaXRlVWludDgoYnVpbHRpbk9mZnNldCArIChkYXRhID8gMSA6IDApKTtcbiAgICB9XG4gICAgd3JpdGVVbmRlZmluZWQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLndyaXRlVWludDMyKGJ1aWx0aW5PZmZzZXQgKyAyKTtcbiAgICB9XG4gICAgd3JpdGVOdWxsKCkge1xuICAgICAgICByZXR1cm4gdGhpcy53cml0ZVVpbnQzMihidWlsdGluT2Zmc2V0ICsgMyk7XG4gICAgfVxuICAgIHdyaXRlT2JqZWN0KGRhdGEpIHtcbiAgICAgICAgbGV0IGhhc2ggPSBIYXNoLl9vYmplY3RIYXNoZXMuZ2V0KGRhdGEpO1xuICAgICAgICBpZiAoaGFzaCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBoYXNoID0gSGFzaC5fZ2V0TmV4dEhhc2goKTtcbiAgICAgICAgICAgIEhhc2guX29iamVjdEhhc2hlcy5zZXQoZGF0YSwgaGFzaCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVVaW50MzIoaGFzaCk7XG4gICAgfVxuICAgIHdyaXRlU3ltYm9sKGRhdGEpIHtcbiAgICAgICAgbGV0IGhhc2ggPSBIYXNoLl9zeW1ib2xIYXNoZXMuZ2V0KGRhdGEpO1xuICAgICAgICBpZiAoaGFzaCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBoYXNoID0gSGFzaC5fZ2V0TmV4dEhhc2goKTtcbiAgICAgICAgICAgIEhhc2guX3N5bWJvbEhhc2hlcy5zZXQoZGF0YSwgaGFzaCk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVVaW50MzIoaGFzaCk7XG4gICAgfVxuICAgIHdyaXRlSGFzaGFibGUoZGF0YSkge1xuICAgICAgICBkYXRhLmhhc2godGhpcyk7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICB3cml0ZVVua25vd24oZGF0YSkge1xuICAgICAgICBzd2l0Y2ggKHR5cGVvZiBkYXRhKSB7XG4gICAgICAgICAgICBjYXNlIFwic3RyaW5nXCI6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVTdHJpbmcoZGF0YSk7XG4gICAgICAgICAgICBjYXNlIFwibnVtYmVyXCI6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVOdW1iZXIoZGF0YSk7XG4gICAgICAgICAgICBjYXNlIFwiYmlnaW50XCI6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVCaWdJbnQoZGF0YSk7XG4gICAgICAgICAgICBjYXNlIFwiYm9vbGVhblwiOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLndyaXRlQm9vbGVhbihkYXRhKTtcbiAgICAgICAgICAgIGNhc2UgXCJzeW1ib2xcIjpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy53cml0ZVN5bWJvbChkYXRhKTtcbiAgICAgICAgICAgIGNhc2UgXCJ1bmRlZmluZWRcIjpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy53cml0ZVVuZGVmaW5lZCgpO1xuICAgICAgICAgICAgY2FzZSBcIm9iamVjdFwiOlxuICAgICAgICAgICAgICAgIGlmIChkYXRhID09PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLndyaXRlTnVsbCgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBpZiAoSGFzaGFibGUuaXNIYXNoYWJsZShkYXRhKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy53cml0ZUhhc2hhYmxlKGRhdGEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy53cml0ZU9iamVjdChkYXRhKTtcbiAgICAgICAgICAgIGNhc2UgXCJmdW5jdGlvblwiOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLndyaXRlT2JqZWN0KGRhdGEpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHdyaXRlSlNPTihkYXRhKSB7XG4gICAgICAgIHN3aXRjaCAodHlwZW9mIGRhdGEpIHtcbiAgICAgICAgICAgIGNhc2UgXCJzdHJpbmdcIjpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy53cml0ZVN0cmluZyhkYXRhKTtcbiAgICAgICAgICAgIGNhc2UgXCJudW1iZXJcIjpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy53cml0ZU51bWJlcihkYXRhKTtcbiAgICAgICAgICAgIGNhc2UgXCJib29sZWFuXCI6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVCb29sZWFuKGRhdGEpO1xuICAgICAgICAgICAgY2FzZSBcIm9iamVjdFwiOlxuICAgICAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KGRhdGEpKSB7XG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwLCBuID0gZGF0YS5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMud3JpdGVKU09OKGRhdGFbaV0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHRoaXMud3JpdGVVaW50MzIoZGF0YS5sZW5ndGgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChkYXRhICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgIGZvciAoY29uc3Qga2V5IG9mIGtleXMoZGF0YSkuc29ydCgpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB2YWx1ZSA9IGRhdGFba2V5XTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMud3JpdGVTdHJpbmcoa2V5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy53cml0ZUpTT04odmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gV3JpdGUgYSBudWxsIGJ5dGUgYXMgYSBzZXBhcmF0b3IgYmV0d2VlbiBrZXkvdmFsdWUgcGFpcnMuXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLndyaXRlVWludDgoMCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH1cbiAgICB9XG4gICAgZXF1YWxzKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIEhhc2ggJiYgdmFsdWUuZmluaXNoKCkgPT09IHRoaXMuZmluaXNoKCk7XG4gICAgfVxuICAgIGhhc2goaGFzaCkge1xuICAgICAgICBoYXNoLndyaXRlVWludDMyKHRoaXMuZmluaXNoKCkpO1xuICAgIH1cbiAgICBzdGF0aWMgX2dldE5leHRIYXNoKCkge1xuICAgICAgICBjb25zdCBuZXh0SGFzaCA9IEhhc2guX25leHRIYXNoO1xuICAgICAgICAvLyBJbmNyZWFzZSB0aGUgaGFzaCwgd3JhcHBpbmcgYXJvdW5kIHdoZW4gaXQgcmVhY2hlcyB0aGUgbGltaXQgb2YgMzIgYml0cy5cbiAgICAgICAgSGFzaC5fbmV4dEhhc2ggPSAoSGFzaC5fbmV4dEhhc2ggKyAxKSA+Pj4gMDtcbiAgICAgICAgcmV0dXJuIG5leHRIYXNoO1xuICAgIH1cbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWhhc2guanMubWFwIiwiaW1wb3J0IHsgUmVmaW5lbWVudCB9IGZyb20gXCJAc2l0ZWltcHJvdmUvYWxmYS1yZWZpbmVtZW50XCI7XG5jb25zdCB7IGlzRnVuY3Rpb24sIGlzT2JqZWN0IH0gPSBSZWZpbmVtZW50O1xuLyoqXG4gKiBAcHVibGljXG4gKi9cbmV4cG9ydCB2YXIgSGFzaGFibGU7XG4oZnVuY3Rpb24gKEhhc2hhYmxlKSB7XG4gICAgZnVuY3Rpb24gaXNIYXNoYWJsZSh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gaXNPYmplY3QodmFsdWUpICYmIGlzRnVuY3Rpb24odmFsdWUuaGFzaCk7XG4gICAgfVxuICAgIEhhc2hhYmxlLmlzSGFzaGFibGUgPSBpc0hhc2hhYmxlO1xufSkoSGFzaGFibGUgfHwgKEhhc2hhYmxlID0ge30pKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWhhc2hhYmxlLmpzLm1hcCIsImV4cG9ydCAqIGZyb20gXCIuL2hhc2guanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL2hhc2hhYmxlLmpzXCI7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCJleHBvcnQgKiBmcm9tIFwiLi9pdGVyYWJsZS5qc1wiO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXguanMubWFwIiwiaW1wb3J0IHsgQ29tcGFyYWJsZSwgQ29tcGFyaXNvbiwgfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtY29tcGFyYWJsZVwiO1xuaW1wb3J0IHsgRXF1YXRhYmxlIH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLWVxdWF0YWJsZVwiO1xuaW1wb3J0IHsgU2VyaWFsaXphYmxlIH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLWpzb25cIjtcbmltcG9ydCB7IE9wdGlvbiwgTm9uZSB9IGZyb20gXCJAc2l0ZWltcHJvdmUvYWxmYS1vcHRpb25cIjtcbmltcG9ydCB7IFByZWRpY2F0ZSB9IGZyb20gXCJAc2l0ZWltcHJvdmUvYWxmYS1wcmVkaWNhdGVcIjtcbmltcG9ydCB7IFJlZmluZW1lbnQgfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtcmVmaW5lbWVudFwiO1xuY29uc3QgeyBub3QgfSA9IFByZWRpY2F0ZTtcbmNvbnN0IHsgaXNPYmplY3QgfSA9IFJlZmluZW1lbnQ7XG5jb25zdCB7IGNvbXBhcmVDb21wYXJhYmxlIH0gPSBDb21wYXJhYmxlO1xuLyoqXG4gKiBAcHVibGljXG4gKi9cbmV4cG9ydCB2YXIgSXRlcmFibGU7XG4oZnVuY3Rpb24gKEl0ZXJhYmxlKSB7XG4gICAgZnVuY3Rpb24gaXNJdGVyYWJsZSh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gaXNPYmplY3QodmFsdWUpICYmIFN5bWJvbC5pdGVyYXRvciBpbiB2YWx1ZTtcbiAgICB9XG4gICAgSXRlcmFibGUuaXNJdGVyYWJsZSA9IGlzSXRlcmFibGU7XG4gICAgZnVuY3Rpb24qIGVtcHR5KCkgeyB9XG4gICAgSXRlcmFibGUuZW1wdHkgPSBlbXB0eTtcbiAgICBmdW5jdGlvbiogZnJvbShhcnJheUxpa2UpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG4gPSBhcnJheUxpa2UubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICB5aWVsZCBhcnJheUxpa2VbaV07XG4gICAgICAgIH1cbiAgICB9XG4gICAgSXRlcmFibGUuZnJvbSA9IGZyb207XG4gICAgZnVuY3Rpb24gc2l6ZShpdGVyYWJsZSkge1xuICAgICAgICByZXR1cm4gcmVkdWNlKGl0ZXJhYmxlLCAoc2l6ZSkgPT4gc2l6ZSArIDEsIDApO1xuICAgIH1cbiAgICBJdGVyYWJsZS5zaXplID0gc2l6ZTtcbiAgICBmdW5jdGlvbiBpc0VtcHR5KGl0ZXJhYmxlKSB7XG4gICAgICAgIGZvciAoY29uc3QgXyBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBJdGVyYWJsZS5pc0VtcHR5ID0gaXNFbXB0eTtcbiAgICBmdW5jdGlvbiBmb3JFYWNoKGl0ZXJhYmxlLCBjYWxsYmFjaykge1xuICAgICAgICBsZXQgaW5kZXggPSAwO1xuICAgICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIGl0ZXJhYmxlKSB7XG4gICAgICAgICAgICBjYWxsYmFjayh2YWx1ZSwgaW5kZXgrKyk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgSXRlcmFibGUuZm9yRWFjaCA9IGZvckVhY2g7XG4gICAgZnVuY3Rpb24qIG1hcChpdGVyYWJsZSwgbWFwcGVyKSB7XG4gICAgICAgIGxldCBpbmRleCA9IDA7XG4gICAgICAgIGZvciAoY29uc3QgdmFsdWUgb2YgaXRlcmFibGUpIHtcbiAgICAgICAgICAgIHlpZWxkIG1hcHBlcih2YWx1ZSwgaW5kZXgrKyk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgSXRlcmFibGUubWFwID0gbWFwO1xuICAgIGZ1bmN0aW9uKiBmbGF0TWFwKGl0ZXJhYmxlLCBtYXBwZXIpIHtcbiAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgeWllbGQqIG1hcHBlcih2YWx1ZSwgaW5kZXgrKyk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgSXRlcmFibGUuZmxhdE1hcCA9IGZsYXRNYXA7XG4gICAgZnVuY3Rpb24qIGZsYXR0ZW4oaXRlcmFibGUpIHtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgeWllbGQqIHZhbHVlO1xuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLmZsYXR0ZW4gPSBmbGF0dGVuO1xuICAgIGZ1bmN0aW9uIHJlZHVjZShpdGVyYWJsZSwgcmVkdWNlciwgYWNjdW11bGF0b3IpIHtcbiAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgYWNjdW11bGF0b3IgPSByZWR1Y2VyKGFjY3VtdWxhdG9yLCB2YWx1ZSwgaW5kZXgrKyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGFjY3VtdWxhdG9yO1xuICAgIH1cbiAgICBJdGVyYWJsZS5yZWR1Y2UgPSByZWR1Y2U7XG4gICAgZnVuY3Rpb24gcmVkdWNlV2hpbGUoaXRlcmFibGUsIHByZWRpY2F0ZSwgcmVkdWNlciwgYWNjdW11bGF0b3IpIHtcbiAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgaWYgKHByZWRpY2F0ZSh2YWx1ZSwgaW5kZXgpKSB7XG4gICAgICAgICAgICAgICAgYWNjdW11bGF0b3IgPSByZWR1Y2VyKGFjY3VtdWxhdG9yLCB2YWx1ZSwgaW5kZXgrKyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYWNjdW11bGF0b3I7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnJlZHVjZVdoaWxlID0gcmVkdWNlV2hpbGU7XG4gICAgZnVuY3Rpb24gcmVkdWNlVW50aWwoaXRlcmFibGUsIHByZWRpY2F0ZSwgcmVkdWNlciwgYWNjdW11bGF0b3IpIHtcbiAgICAgICAgcmV0dXJuIHJlZHVjZVdoaWxlKGl0ZXJhYmxlLCBub3QocHJlZGljYXRlKSwgcmVkdWNlciwgYWNjdW11bGF0b3IpO1xuICAgIH1cbiAgICBJdGVyYWJsZS5yZWR1Y2VVbnRpbCA9IHJlZHVjZVVudGlsO1xuICAgIGZ1bmN0aW9uIGFwcGx5KGl0ZXJhYmxlLCBtYXBwZXIpIHtcbiAgICAgICAgcmV0dXJuIGZsYXRNYXAobWFwcGVyLCAobWFwcGVyKSA9PiBtYXAoaXRlcmFibGUsIG1hcHBlcikpO1xuICAgIH1cbiAgICBJdGVyYWJsZS5hcHBseSA9IGFwcGx5O1xuICAgIGZ1bmN0aW9uKiBmaWx0ZXIoaXRlcmFibGUsIHByZWRpY2F0ZSkge1xuICAgICAgICBsZXQgaW5kZXggPSAwO1xuICAgICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIGl0ZXJhYmxlKSB7XG4gICAgICAgICAgICBpZiAocHJlZGljYXRlKHZhbHVlLCBpbmRleCsrKSkge1xuICAgICAgICAgICAgICAgIHlpZWxkIHZhbHVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLmZpbHRlciA9IGZpbHRlcjtcbiAgICBmdW5jdGlvbiByZWplY3QoaXRlcmFibGUsIHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gZmlsdGVyKGl0ZXJhYmxlLCBub3QocHJlZGljYXRlKSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnJlamVjdCA9IHJlamVjdDtcbiAgICBmdW5jdGlvbiBmaW5kKGl0ZXJhYmxlLCBwcmVkaWNhdGUpIHtcbiAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgaWYgKHByZWRpY2F0ZSh2YWx1ZSwgaW5kZXgrKykpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gT3B0aW9uLm9mKHZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gTm9uZTtcbiAgICB9XG4gICAgSXRlcmFibGUuZmluZCA9IGZpbmQ7XG4gICAgZnVuY3Rpb24gZmluZExhc3QoaXRlcmFibGUsIHByZWRpY2F0ZSkge1xuICAgICAgICBsZXQgaW5kZXggPSAwO1xuICAgICAgICBsZXQgcmVzdWx0ID0gTm9uZTtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgaWYgKHByZWRpY2F0ZSh2YWx1ZSwgaW5kZXgrKykpIHtcbiAgICAgICAgICAgICAgICByZXN1bHQgPSBPcHRpb24ub2YodmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIEl0ZXJhYmxlLmZpbmRMYXN0ID0gZmluZExhc3Q7XG4gICAgZnVuY3Rpb24gaW5jbHVkZXMoaXRlcmFibGUsIHZhbHVlKSB7XG4gICAgICAgIHJldHVybiBzb21lKGl0ZXJhYmxlLCBQcmVkaWNhdGUuZXF1YWxzKHZhbHVlKSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLmluY2x1ZGVzID0gaW5jbHVkZXM7XG4gICAgZnVuY3Rpb24gY29sbGVjdChpdGVyYWJsZSwgbWFwcGVyKSB7XG4gICAgICAgIHJldHVybiBmbGF0TWFwKGl0ZXJhYmxlLCBtYXBwZXIpO1xuICAgIH1cbiAgICBJdGVyYWJsZS5jb2xsZWN0ID0gY29sbGVjdDtcbiAgICBmdW5jdGlvbiBjb2xsZWN0Rmlyc3QoaXRlcmFibGUsIG1hcHBlcikge1xuICAgICAgICByZXR1cm4gZmlyc3QoY29sbGVjdChpdGVyYWJsZSwgbWFwcGVyKSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLmNvbGxlY3RGaXJzdCA9IGNvbGxlY3RGaXJzdDtcbiAgICBmdW5jdGlvbiBzb21lKGl0ZXJhYmxlLCBwcmVkaWNhdGUpIHtcbiAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgaWYgKHByZWRpY2F0ZSh2YWx1ZSwgaW5kZXgrKykpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnNvbWUgPSBzb21lO1xuICAgIGZ1bmN0aW9uIG5vbmUoaXRlcmFibGUsIHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gZXZlcnkoaXRlcmFibGUsIG5vdChwcmVkaWNhdGUpKTtcbiAgICB9XG4gICAgSXRlcmFibGUubm9uZSA9IG5vbmU7XG4gICAgZnVuY3Rpb24gZXZlcnkoaXRlcmFibGUsIHByZWRpY2F0ZSkge1xuICAgICAgICBsZXQgaW5kZXggPSAwO1xuICAgICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIGl0ZXJhYmxlKSB7XG4gICAgICAgICAgICBpZiAoIXByZWRpY2F0ZSh2YWx1ZSwgaW5kZXgrKykpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIEl0ZXJhYmxlLmV2ZXJ5ID0gZXZlcnk7XG4gICAgZnVuY3Rpb24gY291bnQoaXRlcmFibGUsIHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gcmVkdWNlKGl0ZXJhYmxlLCAoY291bnQsIHZhbHVlLCBpbmRleCkgPT4gKHByZWRpY2F0ZSh2YWx1ZSwgaW5kZXgpID8gY291bnQgKyAxIDogY291bnQpLCAwKTtcbiAgICB9XG4gICAgSXRlcmFibGUuY291bnQgPSBjb3VudDtcbiAgICBmdW5jdGlvbiogZGlzdGluY3QoaXRlcmFibGUpIHtcbiAgICAgICAgY29uc3Qgc2VlbiA9IFtdO1xuICAgICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIGl0ZXJhYmxlKSB7XG4gICAgICAgICAgICBpZiAoc2Vlbi5zb21lKFByZWRpY2F0ZS5lcXVhbHModmFsdWUpKSkge1xuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2Vlbi5wdXNoKHZhbHVlKTtcbiAgICAgICAgICAgIHlpZWxkIHZhbHVlO1xuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLmRpc3RpbmN0ID0gZGlzdGluY3Q7XG4gICAgZnVuY3Rpb24gZ2V0KGl0ZXJhYmxlLCBpbmRleCkge1xuICAgICAgICByZXR1cm4gaW5kZXggPCAwID8gTm9uZSA6IGZpcnN0KHNraXAoaXRlcmFibGUsIGluZGV4KSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLmdldCA9IGdldDtcbiAgICBmdW5jdGlvbiBoYXMoaXRlcmFibGUsIGluZGV4KSB7XG4gICAgICAgIHJldHVybiBpbmRleCA8IDAgPyBmYWxzZSA6ICFpc0VtcHR5KHNraXAoaXRlcmFibGUsIGluZGV4KSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLmhhcyA9IGhhcztcbiAgICBmdW5jdGlvbiogc2V0KGl0ZXJhYmxlLCBpbmRleCwgdmFsdWUpIHtcbiAgICAgICAgY29uc3QgaXQgPSBpdGVyYXRvcihpdGVyYWJsZSk7XG4gICAgICAgIHdoaWxlIChpbmRleC0tID4gMCkge1xuICAgICAgICAgICAgY29uc3QgbmV4dCA9IGl0Lm5leHQoKTtcbiAgICAgICAgICAgIGlmIChuZXh0LmRvbmUgPT09IHRydWUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB5aWVsZCBuZXh0LnZhbHVlO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IG5leHQgPSBpdC5uZXh0KCk7XG4gICAgICAgIGlmIChuZXh0LmRvbmUgPT09IHRydWUpIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICB5aWVsZCB2YWx1ZTtcbiAgICAgICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgICAgIGNvbnN0IG5leHQgPSBpdC5uZXh0KCk7XG4gICAgICAgICAgICBpZiAobmV4dC5kb25lID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgeWllbGQgbmV4dC52YWx1ZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBJdGVyYWJsZS5zZXQgPSBzZXQ7XG4gICAgZnVuY3Rpb24qIGluc2VydChpdGVyYWJsZSwgaW5kZXgsIHZhbHVlKSB7XG4gICAgICAgIGNvbnN0IGl0ID0gaXRlcmF0b3IoaXRlcmFibGUpO1xuICAgICAgICB3aGlsZSAoaW5kZXgtLSA+IDApIHtcbiAgICAgICAgICAgIGNvbnN0IG5leHQgPSBpdC5uZXh0KCk7XG4gICAgICAgICAgICBpZiAobmV4dC5kb25lID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgeWllbGQgbmV4dC52YWx1ZTtcbiAgICAgICAgfVxuICAgICAgICB5aWVsZCB2YWx1ZTtcbiAgICAgICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgICAgIGNvbnN0IG5leHQgPSBpdC5uZXh0KCk7XG4gICAgICAgICAgICBpZiAobmV4dC5kb25lID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgeWllbGQgbmV4dC52YWx1ZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBJdGVyYWJsZS5pbnNlcnQgPSBpbnNlcnQ7XG4gICAgZnVuY3Rpb24qIGFwcGVuZChpdGVyYWJsZSwgdmFsdWUpIHtcbiAgICAgICAgeWllbGQqIGl0ZXJhYmxlO1xuICAgICAgICB5aWVsZCB2YWx1ZTtcbiAgICB9XG4gICAgSXRlcmFibGUuYXBwZW5kID0gYXBwZW5kO1xuICAgIGZ1bmN0aW9uKiBwcmVwZW5kKGl0ZXJhYmxlLCB2YWx1ZSkge1xuICAgICAgICB5aWVsZCB2YWx1ZTtcbiAgICAgICAgeWllbGQqIGl0ZXJhYmxlO1xuICAgIH1cbiAgICBJdGVyYWJsZS5wcmVwZW5kID0gcHJlcGVuZDtcbiAgICBmdW5jdGlvbiogY29uY2F0KGl0ZXJhYmxlLCAuLi5pdGVyYWJsZXMpIHtcbiAgICAgICAgeWllbGQqIGl0ZXJhYmxlO1xuICAgICAgICBmb3IgKGNvbnN0IGl0ZXJhYmxlIG9mIGl0ZXJhYmxlcykge1xuICAgICAgICAgICAgeWllbGQqIGl0ZXJhYmxlO1xuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLmNvbmNhdCA9IGNvbmNhdDtcbiAgICBmdW5jdGlvbiBzdWJ0cmFjdChpdGVyYWJsZSwgLi4uaXRlcmFibGVzKSB7XG4gICAgICAgIHJldHVybiByZWplY3QoaXRlcmFibGUsICh2YWx1ZSkgPT4gaW5jbHVkZXMoZmxhdHRlbihpdGVyYWJsZXMpLCB2YWx1ZSkpO1xuICAgIH1cbiAgICBJdGVyYWJsZS5zdWJ0cmFjdCA9IHN1YnRyYWN0O1xuICAgIGZ1bmN0aW9uIGludGVyc2VjdChpdGVyYWJsZSwgLi4uaXRlcmFibGVzKSB7XG4gICAgICAgIHJldHVybiBmaWx0ZXIoaXRlcmFibGUsICh2YWx1ZSkgPT4gaW5jbHVkZXMoZmxhdHRlbihpdGVyYWJsZXMpLCB2YWx1ZSkpO1xuICAgIH1cbiAgICBJdGVyYWJsZS5pbnRlcnNlY3QgPSBpbnRlcnNlY3Q7XG4gICAgZnVuY3Rpb24qIHppcChhLCBiKSB7XG4gICAgICAgIGNvbnN0IGl0QSA9IGl0ZXJhdG9yKGEpO1xuICAgICAgICBjb25zdCBpdEIgPSBpdGVyYXRvcihiKTtcbiAgICAgICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgICAgIGNvbnN0IGEgPSBpdEEubmV4dCgpO1xuICAgICAgICAgICAgY29uc3QgYiA9IGl0Qi5uZXh0KCk7XG4gICAgICAgICAgICBpZiAoYS5kb25lID09PSB0cnVlIHx8IGIuZG9uZSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHlpZWxkIFthLnZhbHVlLCBiLnZhbHVlXTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBJdGVyYWJsZS56aXAgPSB6aXA7XG4gICAgZnVuY3Rpb24gZmlyc3QoaXRlcmFibGUpIHtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgcmV0dXJuIE9wdGlvbi5vZih2YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIE5vbmU7XG4gICAgfVxuICAgIEl0ZXJhYmxlLmZpcnN0ID0gZmlyc3Q7XG4gICAgZnVuY3Rpb24gbGFzdChpdGVyYWJsZSkge1xuICAgICAgICBsZXQgbGFzdCA9IG51bGw7XG4gICAgICAgIGZvciAoY29uc3QgdmFsdWUgb2YgaXRlcmFibGUpIHtcbiAgICAgICAgICAgIGxhc3QgPSB2YWx1ZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gT3B0aW9uLmZyb20obGFzdCk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLmxhc3QgPSBsYXN0O1xuICAgIGZ1bmN0aW9uKiB0YWtlKGl0ZXJhYmxlLCBjb3VudCkge1xuICAgICAgICBjb25zdCBpdCA9IGl0ZXJhdG9yKGl0ZXJhYmxlKTtcbiAgICAgICAgd2hpbGUgKGNvdW50LS0gPiAwKSB7XG4gICAgICAgICAgICBjb25zdCBuZXh0ID0gaXQubmV4dCgpO1xuICAgICAgICAgICAgaWYgKG5leHQuZG9uZSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHlpZWxkIG5leHQudmFsdWU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgSXRlcmFibGUudGFrZSA9IHRha2U7XG4gICAgZnVuY3Rpb24qIHRha2VXaGlsZShpdGVyYWJsZSwgcHJlZGljYXRlKSB7XG4gICAgICAgIGxldCBpbmRleCA9IDA7XG4gICAgICAgIGZvciAoY29uc3QgdmFsdWUgb2YgaXRlcmFibGUpIHtcbiAgICAgICAgICAgIGlmIChwcmVkaWNhdGUodmFsdWUsIGluZGV4KyspKSB7XG4gICAgICAgICAgICAgICAgeWllbGQgdmFsdWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBJdGVyYWJsZS50YWtlV2hpbGUgPSB0YWtlV2hpbGU7XG4gICAgZnVuY3Rpb24gdGFrZVVudGlsKGl0ZXJhYmxlLCBwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIHRha2VXaGlsZShpdGVyYWJsZSwgbm90KHByZWRpY2F0ZSkpO1xuICAgIH1cbiAgICBJdGVyYWJsZS50YWtlVW50aWwgPSB0YWtlVW50aWw7XG4gICAgZnVuY3Rpb24qIHRha2VMYXN0KGl0ZXJhYmxlLCBjb3VudCA9IDEpIHtcbiAgICAgICAgaWYgKGNvdW50IDw9IDApIHtcbiAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuICAgICAgICBjb25zdCBsYXN0ID0gW107XG4gICAgICAgIGZvciAoY29uc3QgdmFsdWUgb2YgaXRlcmFibGUpIHtcbiAgICAgICAgICAgIGxhc3QucHVzaCh2YWx1ZSk7XG4gICAgICAgICAgICBpZiAobGFzdC5sZW5ndGggPiBjb3VudCkge1xuICAgICAgICAgICAgICAgIGxhc3Quc2hpZnQoKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICB5aWVsZCogbGFzdDtcbiAgICB9XG4gICAgSXRlcmFibGUudGFrZUxhc3QgPSB0YWtlTGFzdDtcbiAgICBmdW5jdGlvbiogdGFrZUxhc3RXaGlsZShpdGVyYWJsZSwgcHJlZGljYXRlKSB7XG4gICAgICAgIGNvbnN0IHZhbHVlcyA9IFsuLi5pdGVyYWJsZV07XG4gICAgICAgIGxldCBsYXN0ID0gdmFsdWVzLmxlbmd0aCAtIDE7XG4gICAgICAgIHdoaWxlIChsYXN0ID49IDApIHtcbiAgICAgICAgICAgIGlmIChwcmVkaWNhdGUodmFsdWVzW2xhc3RdLCBsYXN0KSkge1xuICAgICAgICAgICAgICAgIGxhc3QtLTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGZvciAobGV0IGkgPSBsYXN0LCBuID0gdmFsdWVzLmxlbmd0aCAtIDE7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIHlpZWxkIHZhbHVlc1tpXTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBJdGVyYWJsZS50YWtlTGFzdFdoaWxlID0gdGFrZUxhc3RXaGlsZTtcbiAgICBmdW5jdGlvbiB0YWtlTGFzdFVudGlsKGl0ZXJhYmxlLCBwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIHRha2VMYXN0V2hpbGUoaXRlcmFibGUsIG5vdChwcmVkaWNhdGUpKTtcbiAgICB9XG4gICAgSXRlcmFibGUudGFrZUxhc3RVbnRpbCA9IHRha2VMYXN0VW50aWw7XG4gICAgZnVuY3Rpb24qIHNraXAoaXRlcmFibGUsIGNvdW50KSB7XG4gICAgICAgIGNvbnN0IGl0ID0gaXRlcmF0b3IoaXRlcmFibGUpO1xuICAgICAgICB3aGlsZSAoY291bnQtLSA+IDApIHtcbiAgICAgICAgICAgIGNvbnN0IG5leHQgPSBpdC5uZXh0KCk7XG4gICAgICAgICAgICBpZiAobmV4dC5kb25lID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHdoaWxlICh0cnVlKSB7XG4gICAgICAgICAgICBjb25zdCBuZXh0ID0gaXQubmV4dCgpO1xuICAgICAgICAgICAgaWYgKG5leHQuZG9uZSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHlpZWxkIG5leHQudmFsdWU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgSXRlcmFibGUuc2tpcCA9IHNraXA7XG4gICAgZnVuY3Rpb24qIHNraXBXaGlsZShpdGVyYWJsZSwgcHJlZGljYXRlKSB7XG4gICAgICAgIGxldCBpbmRleCA9IDA7XG4gICAgICAgIGxldCBza2lwcGVkID0gZmFsc2U7XG4gICAgICAgIGZvciAoY29uc3QgdmFsdWUgb2YgaXRlcmFibGUpIHtcbiAgICAgICAgICAgIGlmICghc2tpcHBlZCAmJiBwcmVkaWNhdGUodmFsdWUsIGluZGV4KyspKSB7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBza2lwcGVkID0gdHJ1ZTtcbiAgICAgICAgICAgICAgICB5aWVsZCB2YWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBJdGVyYWJsZS5za2lwV2hpbGUgPSBza2lwV2hpbGU7XG4gICAgZnVuY3Rpb24gc2tpcFVudGlsKGl0ZXJhYmxlLCBwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIHNraXBXaGlsZShpdGVyYWJsZSwgbm90KHByZWRpY2F0ZSkpO1xuICAgIH1cbiAgICBJdGVyYWJsZS5za2lwVW50aWwgPSBza2lwVW50aWw7XG4gICAgZnVuY3Rpb24qIHNraXBMYXN0KGl0ZXJhYmxlLCBjb3VudCA9IDEpIHtcbiAgICAgICAgY29uc3QgaXQgPSBpdGVyYXRvcihpdGVyYWJsZSk7XG4gICAgICAgIGNvbnN0IGZpcnN0ID0gW107XG4gICAgICAgIHdoaWxlIChjb3VudC0tID4gMCkge1xuICAgICAgICAgICAgY29uc3QgbmV4dCA9IGl0Lm5leHQoKTtcbiAgICAgICAgICAgIGlmIChuZXh0LmRvbmUgPT09IHRydWUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBmaXJzdC5wdXNoKG5leHQudmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIHdoaWxlICh0cnVlKSB7XG4gICAgICAgICAgICBjb25zdCBuZXh0ID0gaXQubmV4dCgpO1xuICAgICAgICAgICAgaWYgKG5leHQuZG9uZSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZpcnN0LnB1c2gobmV4dC52YWx1ZSk7XG4gICAgICAgICAgICB5aWVsZCBmaXJzdC5zaGlmdCgpO1xuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLnNraXBMYXN0ID0gc2tpcExhc3Q7XG4gICAgZnVuY3Rpb24qIHNraXBMYXN0V2hpbGUoaXRlcmFibGUsIHByZWRpY2F0ZSkge1xuICAgICAgICBjb25zdCB2YWx1ZXMgPSBbLi4uaXRlcmFibGVdO1xuICAgICAgICBsZXQgbGFzdCA9IHZhbHVlcy5sZW5ndGggLSAxO1xuICAgICAgICB3aGlsZSAobGFzdCA+PSAwKSB7XG4gICAgICAgICAgICBpZiAocHJlZGljYXRlKHZhbHVlc1tsYXN0XSwgbGFzdCkpIHtcbiAgICAgICAgICAgICAgICBsYXN0LS07XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IGxhc3Q7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIHlpZWxkIHZhbHVlc1tpXTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBJdGVyYWJsZS5za2lwTGFzdFdoaWxlID0gc2tpcExhc3RXaGlsZTtcbiAgICBmdW5jdGlvbiBza2lwTGFzdFVudGlsKGl0ZXJhYmxlLCBwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIHNraXBMYXN0V2hpbGUoaXRlcmFibGUsIG5vdChwcmVkaWNhdGUpKTtcbiAgICB9XG4gICAgSXRlcmFibGUuc2tpcExhc3RVbnRpbCA9IHNraXBMYXN0VW50aWw7XG4gICAgZnVuY3Rpb24gdHJpbShpdGVyYWJsZSwgcHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiB0cmltVHJhaWxpbmcodHJpbUxlYWRpbmcoaXRlcmFibGUsIHByZWRpY2F0ZSksIHByZWRpY2F0ZSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnRyaW0gPSB0cmltO1xuICAgIGZ1bmN0aW9uIHRyaW1MZWFkaW5nKGl0ZXJhYmxlLCBwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIHNraXBXaGlsZShpdGVyYWJsZSwgcHJlZGljYXRlKTtcbiAgICB9XG4gICAgSXRlcmFibGUudHJpbUxlYWRpbmcgPSB0cmltTGVhZGluZztcbiAgICBmdW5jdGlvbiB0cmltVHJhaWxpbmcoaXRlcmFibGUsIHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gc2tpcExhc3RXaGlsZShpdGVyYWJsZSwgcHJlZGljYXRlKTtcbiAgICB9XG4gICAgSXRlcmFibGUudHJpbVRyYWlsaW5nID0gdHJpbVRyYWlsaW5nO1xuICAgIGZ1bmN0aW9uIHJlc3QoaXRlcmFibGUpIHtcbiAgICAgICAgcmV0dXJuIHNraXAoaXRlcmFibGUsIDEpO1xuICAgIH1cbiAgICBJdGVyYWJsZS5yZXN0ID0gcmVzdDtcbiAgICBmdW5jdGlvbiBzbGljZShpdGVyYWJsZSwgc3RhcnQsIGVuZCkge1xuICAgICAgICBpdGVyYWJsZSA9IHNraXAoaXRlcmFibGUsIHN0YXJ0KTtcbiAgICAgICAgaWYgKGVuZCAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICBpdGVyYWJsZSA9IHRha2UoaXRlcmFibGUsIGVuZCAtIHN0YXJ0KTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gaXRlcmFibGU7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnNsaWNlID0gc2xpY2U7XG4gICAgZnVuY3Rpb24qIHJldmVyc2UoaXRlcmFibGUpIHtcbiAgICAgICAgY29uc3QgYXJyYXkgPSBBcnJheS5mcm9tKGl0ZXJhYmxlKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IGFycmF5Lmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgICAgICAgICB5aWVsZCBhcnJheVtpXTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBJdGVyYWJsZS5yZXZlcnNlID0gcmV2ZXJzZTtcbiAgICBmdW5jdGlvbiBqb2luKGl0ZXJhYmxlLCBzZXBhcmF0b3IpIHtcbiAgICAgICAgY29uc3QgaXQgPSBpdGVyYXRvcihpdGVyYWJsZSk7XG4gICAgICAgIGxldCBuZXh0ID0gaXQubmV4dCgpO1xuICAgICAgICBpZiAobmV4dC5kb25lID09PSB0cnVlKSB7XG4gICAgICAgICAgICByZXR1cm4gXCJcIjtcbiAgICAgICAgfVxuICAgICAgICBsZXQgcmVzdWx0ID0gYCR7bmV4dC52YWx1ZX1gO1xuICAgICAgICBuZXh0ID0gaXQubmV4dCgpO1xuICAgICAgICB3aGlsZSAobmV4dC5kb25lICE9PSB0cnVlKSB7XG4gICAgICAgICAgICByZXN1bHQgKz0gYCR7c2VwYXJhdG9yfSR7bmV4dC52YWx1ZX1gO1xuICAgICAgICAgICAgbmV4dCA9IGl0Lm5leHQoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBJdGVyYWJsZS5qb2luID0gam9pbjtcbiAgICBmdW5jdGlvbiBzb3J0KGl0ZXJhYmxlKSB7XG4gICAgICAgIHJldHVybiBzb3J0V2l0aChpdGVyYWJsZSwgY29tcGFyZUNvbXBhcmFibGUpO1xuICAgIH1cbiAgICBJdGVyYWJsZS5zb3J0ID0gc29ydDtcbiAgICBmdW5jdGlvbiogc29ydFdpdGgoaXRlcmFibGUsIGNvbXBhcmVyKSB7XG4gICAgICAgIHlpZWxkKiBbLi4uaXRlcmFibGVdLnNvcnQoY29tcGFyZXIpO1xuICAgIH1cbiAgICBJdGVyYWJsZS5zb3J0V2l0aCA9IHNvcnRXaXRoO1xuICAgIGZ1bmN0aW9uIGNvbXBhcmUoYSwgYikge1xuICAgICAgICByZXR1cm4gY29tcGFyZVdpdGgoYSwgYiwgY29tcGFyZUNvbXBhcmFibGUpO1xuICAgIH1cbiAgICBJdGVyYWJsZS5jb21wYXJlID0gY29tcGFyZTtcbiAgICBmdW5jdGlvbiBjb21wYXJlV2l0aChhLCBiLCBjb21wYXJlcikge1xuICAgICAgICBjb25zdCBpdEEgPSBpdGVyYXRvcihhKTtcbiAgICAgICAgY29uc3QgaXRCID0gaXRlcmF0b3IoYik7XG4gICAgICAgIGxldCBpbmRleCA9IDA7XG4gICAgICAgIHdoaWxlICh0cnVlKSB7XG4gICAgICAgICAgICBjb25zdCBhID0gaXRBLm5leHQoKTtcbiAgICAgICAgICAgIGNvbnN0IGIgPSBpdEIubmV4dCgpO1xuICAgICAgICAgICAgaWYgKGEuZG9uZSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBiLmRvbmUgPT09IHRydWUgPyBDb21wYXJpc29uLkVxdWFsIDogQ29tcGFyaXNvbi5MZXNzO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGIuZG9uZSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBDb21wYXJpc29uLkdyZWF0ZXI7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBjb21wYXJlcihhLnZhbHVlLCBiLnZhbHVlLCBpbmRleCsrKTtcbiAgICAgICAgICAgIGlmIChyZXN1bHQgIT09IDApIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLmNvbXBhcmVXaXRoID0gY29tcGFyZVdpdGg7XG4gICAgZnVuY3Rpb24gZXF1YWxzKGEsIGIpIHtcbiAgICAgICAgY29uc3QgaXRBID0gaXRlcmF0b3IoYSk7XG4gICAgICAgIGNvbnN0IGl0QiA9IGl0ZXJhdG9yKGIpO1xuICAgICAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgICAgICAgY29uc3QgYSA9IGl0QS5uZXh0KCk7XG4gICAgICAgICAgICBjb25zdCBiID0gaXRCLm5leHQoKTtcbiAgICAgICAgICAgIGlmIChhLmRvbmUgPT09IHRydWUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gYi5kb25lID09PSB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKGIuZG9uZSA9PT0gdHJ1ZSB8fCAhRXF1YXRhYmxlLmVxdWFscyhhLnZhbHVlLCBiLnZhbHVlKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgIH1cbiAgICBJdGVyYWJsZS5lcXVhbHMgPSBlcXVhbHM7XG4gICAgZnVuY3Rpb24gaGFzaChpdGVyYWJsZSwgaGFzaCkge1xuICAgICAgICBsZXQgc2l6ZSA9IDA7XG4gICAgICAgIGZvciAoY29uc3QgdmFsdWUgb2YgaXRlcmFibGUpIHtcbiAgICAgICAgICAgIGhhc2gud3JpdGVVbmtub3duKHZhbHVlKTtcbiAgICAgICAgICAgIHNpemUrKztcbiAgICAgICAgfVxuICAgICAgICBoYXNoLndyaXRlVWludDMyKHNpemUpO1xuICAgIH1cbiAgICBJdGVyYWJsZS5oYXNoID0gaGFzaDtcbiAgICBmdW5jdGlvbiBpdGVyYXRvcihpdGVyYWJsZSkge1xuICAgICAgICByZXR1cm4gaXRlcmFibGVbU3ltYm9sLml0ZXJhdG9yXSgpO1xuICAgIH1cbiAgICBJdGVyYWJsZS5pdGVyYXRvciA9IGl0ZXJhdG9yO1xuICAgIGZ1bmN0aW9uIGdyb3VwQnkoaXRlcmFibGUsIGdyb3VwZXIpIHtcbiAgICAgICAgY29uc3QgZ3JvdXBzID0gW107XG4gICAgICAgIGxldCBpbmRleCA9IDA7XG4gICAgICAgIGZvciAoY29uc3QgdmFsdWUgb2YgaXRlcmFibGUpIHtcbiAgICAgICAgICAgIGNvbnN0IGdyb3VwID0gZ3JvdXBlcih2YWx1ZSwgaW5kZXgrKyk7XG4gICAgICAgICAgICBjb25zdCBleGlzdGluZyA9IGdyb3Vwcy5maW5kKChbZXhpc3RpbmddKSA9PiBFcXVhdGFibGUuZXF1YWxzKGdyb3VwLCBleGlzdGluZykpO1xuICAgICAgICAgICAgaWYgKGV4aXN0aW5nID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICBncm91cHMucHVzaChbZ3JvdXAsIFt2YWx1ZV1dKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGV4aXN0aW5nWzFdLnB1c2godmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBncm91cHM7XG4gICAgfVxuICAgIEl0ZXJhYmxlLmdyb3VwQnkgPSBncm91cEJ5O1xuICAgIGZ1bmN0aW9uIHRvSlNPTihpdGVyYWJsZSwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gWy4uLm1hcChpdGVyYWJsZSwgKHZhbHVlKSA9PiBTZXJpYWxpemFibGUudG9KU09OKHZhbHVlLCBvcHRpb25zKSldO1xuICAgIH1cbiAgICBJdGVyYWJsZS50b0pTT04gPSB0b0pTT047XG59KShJdGVyYWJsZSB8fCAoSXRlcmFibGUgPSB7fSkpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aXRlcmFibGUuanMubWFwIiwiLy8gVGhpcyBmaWxlIGRlZmluZXMgZXhwb3J0cyBmcm9tIHRoZSBidWlsdGluIGBKU09OYCBjb25zdHJ1Y3RvciBmb3IgaW50ZXJuYWxcbi8vIHVzZSBvbmx5LlxuLyoqXG4gKiBAaW50ZXJuYWxcbiAqL1xuY29uc3QgQnVpbHRpbiA9IEpTT047XG5leHBvcnQgeyBCdWlsdGluIGFzIEpTT04gfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWJ1aWx0aW4uanMubWFwIiwiZXhwb3J0ICogZnJvbSBcIi4vanNvbi5qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vc2VyaWFsaXphYmxlLmpzXCI7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCJpbXBvcnQgKiBhcyBidWlsdGluIGZyb20gXCIuL2J1aWx0aW4uanNcIjtcbi8qKlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgdmFyIEpTT047XG4oZnVuY3Rpb24gKEpTT04pIHtcbiAgICBmdW5jdGlvbiBwYXJzZSh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gYnVpbHRpbi5KU09OLnBhcnNlKHZhbHVlKTtcbiAgICB9XG4gICAgSlNPTi5wYXJzZSA9IHBhcnNlO1xuICAgIGZ1bmN0aW9uIHN0cmluZ2lmeSh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gYnVpbHRpbi5KU09OLnN0cmluZ2lmeSh2YWx1ZSk7XG4gICAgfVxuICAgIEpTT04uc3RyaW5naWZ5ID0gc3RyaW5naWZ5O1xufSkoSlNPTiB8fCAoSlNPTiA9IHt9KSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1qc29uLmpzLm1hcCIsImltcG9ydCB7IFJlZmluZW1lbnQgfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtcmVmaW5lbWVudFwiO1xuY29uc3QgeyBrZXlzIH0gPSBPYmplY3Q7XG5jb25zdCB7IGlzQXJyYXkgfSA9IEFycmF5O1xuY29uc3QgeyBpc0Z1bmN0aW9uLCBpc09iamVjdCwgaXNTdHJpbmcsIGlzTnVtYmVyLCBpc0Jvb2xlYW4sIGlzTnVsbCB9ID0gUmVmaW5lbWVudDtcbi8qKlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgdmFyIFNlcmlhbGl6YWJsZTtcbihmdW5jdGlvbiAoU2VyaWFsaXphYmxlKSB7XG4gICAgZnVuY3Rpb24gaXNTZXJpYWxpemFibGUodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIGlzT2JqZWN0KHZhbHVlKSAmJiBpc0Z1bmN0aW9uKHZhbHVlLnRvSlNPTik7XG4gICAgfVxuICAgIFNlcmlhbGl6YWJsZS5pc1NlcmlhbGl6YWJsZSA9IGlzU2VyaWFsaXphYmxlO1xuICAgIGZ1bmN0aW9uIHRvSlNPTih2YWx1ZSwgb3B0aW9ucykge1xuICAgICAgICBpZiAoaXNTZXJpYWxpemFibGUodmFsdWUpKSB7XG4gICAgICAgICAgICByZXR1cm4gdmFsdWUudG9KU09OKG9wdGlvbnMpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc1N0cmluZyh2YWx1ZSkgfHxcbiAgICAgICAgICAgIGlzTnVtYmVyKHZhbHVlKSB8fFxuICAgICAgICAgICAgaXNCb29sZWFuKHZhbHVlKSB8fFxuICAgICAgICAgICAgaXNOdWxsKHZhbHVlKSkge1xuICAgICAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0FycmF5KHZhbHVlKSkge1xuICAgICAgICAgICAgcmV0dXJuIHZhbHVlLm1hcCgoaXRlbSkgPT4gdG9KU09OKGl0ZW0sIG9wdGlvbnMpKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNPYmplY3QodmFsdWUpKSB7XG4gICAgICAgICAgICBjb25zdCBqc29uID0ge307XG4gICAgICAgICAgICBmb3IgKGNvbnN0IGtleSBvZiBrZXlzKHZhbHVlKSkge1xuICAgICAgICAgICAgICAgIGlmICh2YWx1ZVtrZXldICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAganNvbltrZXldID0gdG9KU09OKHZhbHVlW2tleV0sIG9wdGlvbnMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBqc29uO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBudWxsO1xuICAgIH1cbiAgICBTZXJpYWxpemFibGUudG9KU09OID0gdG9KU09OO1xuICAgIGxldCBWZXJib3NpdHk7XG4gICAgKGZ1bmN0aW9uIChWZXJib3NpdHkpIHtcbiAgICAgICAgVmVyYm9zaXR5W1ZlcmJvc2l0eVtcIk1pbmltYWxcIl0gPSAwXSA9IFwiTWluaW1hbFwiO1xuICAgICAgICBWZXJib3NpdHlbVmVyYm9zaXR5W1wiTG93XCJdID0gMTAwXSA9IFwiTG93XCI7XG4gICAgICAgIFZlcmJvc2l0eVtWZXJib3NpdHlbXCJNZWRpdW1cIl0gPSAyMDBdID0gXCJNZWRpdW1cIjtcbiAgICAgICAgVmVyYm9zaXR5W1ZlcmJvc2l0eVtcIkhpZ2hcIl0gPSAzMDBdID0gXCJIaWdoXCI7XG4gICAgfSkoVmVyYm9zaXR5ID0gU2VyaWFsaXphYmxlLlZlcmJvc2l0eSB8fCAoU2VyaWFsaXphYmxlLlZlcmJvc2l0eSA9IHt9KSk7XG59KShTZXJpYWxpemFibGUgfHwgKFNlcmlhbGl6YWJsZSA9IHt9KSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1zZXJpYWxpemFibGUuanMubWFwIiwiZXhwb3J0ICogZnJvbSBcIi4vbWFwLmpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9ub2RlLmpzXCI7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCJpbXBvcnQgeyBBcnJheSB9IGZyb20gXCJAc2l0ZWltcHJvdmUvYWxmYS1hcnJheVwiO1xuaW1wb3J0IHsgRk5WIH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLWZudlwiO1xuaW1wb3J0IHsgSXRlcmFibGUgfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtaXRlcmFibGVcIjtcbmltcG9ydCB7IFNlcmlhbGl6YWJsZSB9IGZyb20gXCJAc2l0ZWltcHJvdmUvYWxmYS1qc29uXCI7XG5pbXBvcnQgeyBQcmVkaWNhdGUgfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtcHJlZGljYXRlXCI7XG5pbXBvcnQgeyBFbXB0eSB9IGZyb20gXCIuL25vZGUuanNcIjtcbmNvbnN0IHsgbm90IH0gPSBQcmVkaWNhdGU7XG4vKipcbiAqIEBwdWJsaWNcbiAqL1xuZXhwb3J0IGNsYXNzIE1hcCB7XG4gICAgc3RhdGljIG9mKC4uLmVudHJpZXMpIHtcbiAgICAgICAgcmV0dXJuIGVudHJpZXMucmVkdWNlKChtYXAsIFtrZXksIHZhbHVlXSkgPT4gbWFwLnNldChrZXksIHZhbHVlKSwgTWFwLmVtcHR5KCkpO1xuICAgIH1cbiAgICBzdGF0aWMgX2VtcHR5ID0gbmV3IE1hcChFbXB0eSwgMCk7XG4gICAgc3RhdGljIGVtcHR5KCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fZW1wdHk7XG4gICAgfVxuICAgIF9yb290O1xuICAgIF9zaXplO1xuICAgIGNvbnN0cnVjdG9yKHJvb3QsIHNpemUpIHtcbiAgICAgICAgdGhpcy5fcm9vdCA9IHJvb3Q7XG4gICAgICAgIHRoaXMuX3NpemUgPSBzaXplO1xuICAgIH1cbiAgICBnZXQgc2l6ZSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3NpemU7XG4gICAgfVxuICAgIGlzRW1wdHkoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9zaXplID09PSAwO1xuICAgIH1cbiAgICBmb3JFYWNoKGNhbGxiYWNrKSB7XG4gICAgICAgIEl0ZXJhYmxlLmZvckVhY2godGhpcywgKFtrZXksIHZhbHVlXSkgPT4gY2FsbGJhY2sodmFsdWUsIGtleSkpO1xuICAgIH1cbiAgICBtYXAobWFwcGVyKSB7XG4gICAgICAgIHJldHVybiBuZXcgTWFwKHRoaXMuX3Jvb3QubWFwKG1hcHBlciksIHRoaXMuX3NpemUpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBBcHBseSBhIG1hcCBvZiBmdW5jdGlvbnMgdG8gZWFjaCBjb3JyZXNwb25kaW5nIHZhbHVlIG9mIHRoaXMgbWFwLlxuICAgICAqXG4gICAgICogQHJlbWFya3NcbiAgICAgKiBLZXlzIHdpdGhvdXQgYSBjb3JyZXNwb25kaW5nIGZ1bmN0aW9uIG9yIHZhbHVlIGFyZSBkcm9wcGVkIGZyb20gdGhlXG4gICAgICogcmVzdWx0aW5nIG1hcC5cbiAgICAgKlxuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiBNYXAub2YoW1wiYVwiLCAxXSwgW1wiYlwiLCAyXSlcbiAgICAgKiAgIC5hcHBseShNYXAub2YoW1wiYVwiLCAoeCkgPT4geCArIDFdLCBbXCJiXCIsICh4KSA9PiB4ICogMl0pKVxuICAgICAqICAgLnRvQXJyYXkoKTtcbiAgICAgKiAvLyA9PiBbW1wiYVwiLCAyXSwgW1wiYlwiLCA0XV1cbiAgICAgKiBgYGBcbiAgICAgKi9cbiAgICBhcHBseShtYXBwZXIpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuY29sbGVjdCgodmFsdWUsIGtleSkgPT4gbWFwcGVyLmdldChrZXkpLm1hcCgobWFwcGVyKSA9PiBtYXBwZXIodmFsdWUpKSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEByZW1hcmtzXG4gICAgICogQXMgdGhlIG9yZGVyIG9mIG1hcHMgaXMgdW5kZWZpbmVkLCBpdCBpcyBhbHNvIHVuZGVmaW5lZCB3aGljaCBrZXlzIGFyZVxuICAgICAqIGtlcHQgd2hlbiBkdXBsaWNhdGUga2V5cyBhcmUgZW5jb3VudGVyZWQuXG4gICAgICovXG4gICAgZmxhdE1hcChtYXBwZXIpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucmVkdWNlKChtYXAsIHZhbHVlLCBrZXkpID0+IG1hcC5jb25jYXQobWFwcGVyKHZhbHVlLCBrZXkpKSwgTWFwLmVtcHR5KCkpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBAcmVtYXJrc1xuICAgICAqIEFzIHRoZSBvcmRlciBvZiBtYXBzIGlzIHVuZGVmaW5lZCwgaXQgaXMgYWxzbyB1bmRlZmluZWQgd2hpY2gga2V5cyBhcmVcbiAgICAgKiBrZXB0IHdoZW4gZHVwbGljYXRlIGtleXMgYXJlIGVuY291bnRlcmVkLlxuICAgICAqL1xuICAgIGZsYXR0ZW4oKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmZsYXRNYXAoKG1hcCkgPT4gbWFwKTtcbiAgICB9XG4gICAgcmVkdWNlKHJlZHVjZXIsIGFjY3VtdWxhdG9yKSB7XG4gICAgICAgIHJldHVybiBJdGVyYWJsZS5yZWR1Y2UodGhpcywgKGFjY3VtdWxhdG9yLCBba2V5LCB2YWx1ZV0pID0+IHJlZHVjZXIoYWNjdW11bGF0b3IsIHZhbHVlLCBrZXkpLCBhY2N1bXVsYXRvcik7XG4gICAgfVxuICAgIGZpbHRlcihwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucmVkdWNlKChtYXAsIHZhbHVlLCBrZXkpID0+IChwcmVkaWNhdGUodmFsdWUsIGtleSkgPyBtYXAuc2V0KGtleSwgdmFsdWUpIDogbWFwKSwgTWFwLmVtcHR5KCkpO1xuICAgIH1cbiAgICByZWplY3QocHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmZpbHRlcihub3QocHJlZGljYXRlKSk7XG4gICAgfVxuICAgIGZpbmQocHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiBJdGVyYWJsZS5maW5kKHRoaXMsIChba2V5LCB2YWx1ZV0pID0+IHByZWRpY2F0ZSh2YWx1ZSwga2V5KSkubWFwKChbLCB2YWx1ZV0pID0+IHZhbHVlKTtcbiAgICB9XG4gICAgaW5jbHVkZXModmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIEl0ZXJhYmxlLmluY2x1ZGVzKHRoaXMudmFsdWVzKCksIHZhbHVlKTtcbiAgICB9XG4gICAgY29sbGVjdChtYXBwZXIpIHtcbiAgICAgICAgcmV0dXJuIE1hcC5mcm9tKEl0ZXJhYmxlLmNvbGxlY3QodGhpcywgKFtrZXksIHZhbHVlXSkgPT4gbWFwcGVyKHZhbHVlLCBrZXkpLm1hcCgodmFsdWUpID0+IFtrZXksIHZhbHVlXSkpKTtcbiAgICB9XG4gICAgY29sbGVjdEZpcnN0KG1hcHBlcikge1xuICAgICAgICByZXR1cm4gSXRlcmFibGUuY29sbGVjdEZpcnN0KHRoaXMsIChba2V5LCB2YWx1ZV0pID0+IG1hcHBlcih2YWx1ZSwga2V5KSk7XG4gICAgfVxuICAgIHNvbWUocHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiBJdGVyYWJsZS5zb21lKHRoaXMsIChba2V5LCB2YWx1ZV0pID0+IHByZWRpY2F0ZSh2YWx1ZSwga2V5KSk7XG4gICAgfVxuICAgIG5vbmUocHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiBJdGVyYWJsZS5ub25lKHRoaXMsIChba2V5LCB2YWx1ZV0pID0+IHByZWRpY2F0ZSh2YWx1ZSwga2V5KSk7XG4gICAgfVxuICAgIGV2ZXJ5KHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gSXRlcmFibGUuZXZlcnkodGhpcywgKFtrZXksIHZhbHVlXSkgPT4gcHJlZGljYXRlKHZhbHVlLCBrZXkpKTtcbiAgICB9XG4gICAgY291bnQocHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiBJdGVyYWJsZS5jb3VudCh0aGlzLCAoW2tleSwgdmFsdWVdKSA9PiBwcmVkaWNhdGUodmFsdWUsIGtleSkpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBAcmVtYXJrc1xuICAgICAqIEFzIHRoZSBvcmRlciBvZiBtYXBzIGlzIHVuZGVmaW5lZCwgaXQgaXMgYWxzbyB1bmRlZmluZWQgd2hpY2gga2V5cyBhcmVcbiAgICAgKiBrZXB0IHdoZW4gZHVwbGljYXRlIHZhbHVlcyBhcmUgZW5jb3VudGVyZWQuXG4gICAgICovXG4gICAgZGlzdGluY3QoKSB7XG4gICAgICAgIGxldCBzZWVuID0gTWFwLmVtcHR5KCk7XG4gICAgICAgIC8vIFdlIG9wdGltaXplIGZvciB0aGUgY2FzZSB3aGVyZSB0aGVyZSBhcmUgbW9yZSBkaXN0aW5jdCB2YWx1ZXMgdGhhbiB0aGVyZVxuICAgICAgICAvLyBhcmUgZHVwbGljYXRlIHZhbHVlcyBieSBzdGFydGluZyB3aXRoIHRoZSBjdXJyZW50IG1hcCBhbmQgcmVtb3ZpbmdcbiAgICAgICAgLy8gZHVwbGljYXRlcyBhcyB3ZSBmaW5kIHRoZW0uXG4gICAgICAgIGxldCBtYXAgPSB0aGlzO1xuICAgICAgICBmb3IgKGNvbnN0IFtrZXksIHZhbHVlXSBvZiBtYXApIHtcbiAgICAgICAgICAgIGlmIChzZWVuLmhhcyh2YWx1ZSkpIHtcbiAgICAgICAgICAgICAgICBtYXAgPSBtYXAuZGVsZXRlKGtleSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBzZWVuID0gc2Vlbi5zZXQodmFsdWUsIHZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbWFwO1xuICAgIH1cbiAgICBnZXQoa2V5KSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9yb290LmdldChrZXksIGhhc2goa2V5KSwgMCk7XG4gICAgfVxuICAgIGhhcyhrZXkpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0KGtleSkuaXNTb21lKCk7XG4gICAgfVxuICAgIHNldChrZXksIHZhbHVlKSB7XG4gICAgICAgIGNvbnN0IHsgcmVzdWx0OiByb290LCBzdGF0dXMgfSA9IHRoaXMuX3Jvb3Quc2V0KGtleSwgdmFsdWUsIGhhc2goa2V5KSwgMCk7XG4gICAgICAgIGlmIChzdGF0dXMgPT09IFwidW5jaGFuZ2VkXCIpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBuZXcgTWFwKHJvb3QsIHRoaXMuX3NpemUgKyAoc3RhdHVzID09PSBcInVwZGF0ZWRcIiA/IDAgOiAxKSk7XG4gICAgfVxuICAgIGRlbGV0ZShrZXkpIHtcbiAgICAgICAgY29uc3QgeyByZXN1bHQ6IHJvb3QsIHN0YXR1cyB9ID0gdGhpcy5fcm9vdC5kZWxldGUoa2V5LCBoYXNoKGtleSksIDApO1xuICAgICAgICBpZiAoc3RhdHVzID09PSBcInVuY2hhbmdlZFwiKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbmV3IE1hcChyb290LCB0aGlzLl9zaXplIC0gMSk7XG4gICAgfVxuICAgIGNvbmNhdChpdGVyYWJsZSkge1xuICAgICAgICByZXR1cm4gSXRlcmFibGUucmVkdWNlKGl0ZXJhYmxlLCAobWFwLCBba2V5LCB2YWx1ZV0pID0+IG1hcC5zZXQoa2V5LCB2YWx1ZSksIHRoaXMpO1xuICAgIH1cbiAgICBzdWJ0cmFjdChpdGVyYWJsZSkge1xuICAgICAgICByZXR1cm4gSXRlcmFibGUucmVkdWNlKGl0ZXJhYmxlLCAobWFwLCBba2V5XSkgPT4gbWFwLmRlbGV0ZShrZXkpLCB0aGlzKTtcbiAgICB9XG4gICAgaW50ZXJzZWN0KGl0ZXJhYmxlKSB7XG4gICAgICAgIHJldHVybiBNYXAuZnJvbUl0ZXJhYmxlKEl0ZXJhYmxlLmZpbHRlcihpdGVyYWJsZSwgKFtrZXldKSA9PiB0aGlzLmhhcyhrZXkpKSk7XG4gICAgfVxuICAgIHRlZShjYWxsYmFjaywgLi4uYXJncykge1xuICAgICAgICBjYWxsYmFjayh0aGlzLCAuLi5hcmdzKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGVxdWFscyh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gKHZhbHVlIGluc3RhbmNlb2YgTWFwICYmXG4gICAgICAgICAgICB2YWx1ZS5fc2l6ZSA9PT0gdGhpcy5fc2l6ZSAmJlxuICAgICAgICAgICAgdmFsdWUuX3Jvb3QuZXF1YWxzKHRoaXMuX3Jvb3QpKTtcbiAgICB9XG4gICAgaGFzaChoYXNoKSB7XG4gICAgICAgIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIHRoaXMpIHtcbiAgICAgICAgICAgIGhhc2gud3JpdGVVbmtub3duKGtleSkud3JpdGVVbmtub3duKHZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgICBoYXNoLndyaXRlVWludDMyKHRoaXMuX3NpemUpO1xuICAgIH1cbiAgICBrZXlzKCkge1xuICAgICAgICByZXR1cm4gSXRlcmFibGUubWFwKHRoaXMuX3Jvb3QsIChlbnRyeSkgPT4gZW50cnlbMF0pO1xuICAgIH1cbiAgICB2YWx1ZXMoKSB7XG4gICAgICAgIHJldHVybiBJdGVyYWJsZS5tYXAodGhpcy5fcm9vdCwgKGVudHJ5KSA9PiBlbnRyeVsxXSk7XG4gICAgfVxuICAgICppdGVyYXRvcigpIHtcbiAgICAgICAgeWllbGQqIHRoaXMuX3Jvb3Q7XG4gICAgfVxuICAgIFtTeW1ib2wuaXRlcmF0b3JdKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5pdGVyYXRvcigpO1xuICAgIH1cbiAgICB0b0FycmF5KCkge1xuICAgICAgICByZXR1cm4gWy4uLnRoaXNdO1xuICAgIH1cbiAgICB0b0pTT04ob3B0aW9ucykge1xuICAgICAgICByZXR1cm4gdGhpcy50b0FycmF5KCkubWFwKChba2V5LCB2YWx1ZV0pID0+IFtcbiAgICAgICAgICAgIFNlcmlhbGl6YWJsZS50b0pTT04oa2V5LCBvcHRpb25zKSxcbiAgICAgICAgICAgIFNlcmlhbGl6YWJsZS50b0pTT04odmFsdWUsIG9wdGlvbnMpLFxuICAgICAgICBdKTtcbiAgICB9XG4gICAgdG9TdHJpbmcoKSB7XG4gICAgICAgIGNvbnN0IGVudHJpZXMgPSB0aGlzLnRvQXJyYXkoKVxuICAgICAgICAgICAgLm1hcCgoW2tleSwgdmFsdWVdKSA9PiBgJHtrZXl9ID0+ICR7dmFsdWV9YClcbiAgICAgICAgICAgIC5qb2luKFwiLCBcIik7XG4gICAgICAgIHJldHVybiBgTWFwIHske2VudHJpZXMgPT09IFwiXCIgPyBcIlwiIDogYCAke2VudHJpZXN9IGB9fWA7XG4gICAgfVxufVxuLyoqXG4gKiBAcHVibGljXG4gKi9cbihmdW5jdGlvbiAoTWFwKSB7XG4gICAgZnVuY3Rpb24gaXNNYXAodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgTWFwO1xuICAgIH1cbiAgICBNYXAuaXNNYXAgPSBpc01hcDtcbiAgICBmdW5jdGlvbiBmcm9tKGl0ZXJhYmxlKSB7XG4gICAgICAgIGlmIChpc01hcChpdGVyYWJsZSkpIHtcbiAgICAgICAgICAgIHJldHVybiBpdGVyYWJsZTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoQXJyYXkuaXNBcnJheShpdGVyYWJsZSkpIHtcbiAgICAgICAgICAgIHJldHVybiBmcm9tQXJyYXkoaXRlcmFibGUpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmcm9tSXRlcmFibGUoaXRlcmFibGUpO1xuICAgIH1cbiAgICBNYXAuZnJvbSA9IGZyb207XG4gICAgZnVuY3Rpb24gZnJvbUFycmF5KGFycmF5KSB7XG4gICAgICAgIHJldHVybiBBcnJheS5yZWR1Y2UoYXJyYXksIChtYXAsIFtrZXksIHZhbHVlXSkgPT4gbWFwLnNldChrZXksIHZhbHVlKSwgTWFwLmVtcHR5KCkpO1xuICAgIH1cbiAgICBNYXAuZnJvbUFycmF5ID0gZnJvbUFycmF5O1xuICAgIGZ1bmN0aW9uIGZyb21JdGVyYWJsZShpdGVyYWJsZSkge1xuICAgICAgICByZXR1cm4gSXRlcmFibGUucmVkdWNlKGl0ZXJhYmxlLCAobWFwLCBba2V5LCB2YWx1ZV0pID0+IG1hcC5zZXQoa2V5LCB2YWx1ZSksIE1hcC5lbXB0eSgpKTtcbiAgICB9XG4gICAgTWFwLmZyb21JdGVyYWJsZSA9IGZyb21JdGVyYWJsZTtcbn0pKE1hcCB8fCAoTWFwID0ge30pKTtcbmZ1bmN0aW9uIGhhc2goa2V5KSB7XG4gICAgcmV0dXJuIEZOVi5lbXB0eSgpLndyaXRlVW5rbm93bihrZXkpLmZpbmlzaCgpO1xufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9bWFwLmpzLm1hcCIsImltcG9ydCB7IEJpdHMgfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtYml0c1wiO1xuaW1wb3J0IHsgRXF1YXRhYmxlIH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLWVxdWF0YWJsZVwiO1xuaW1wb3J0IHsgTm9uZSwgT3B0aW9uIH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLW9wdGlvblwiO1xuaW1wb3J0IHsgU3RhdHVzIH0gZnJvbSBcIi4vc3RhdHVzLmpzXCI7XG5jb25zdCB7IGJpdCwgdGFrZSwgc2tpcCwgdGVzdCwgc2V0LCBjbGVhciwgcG9wQ291bnQgfSA9IEJpdHM7XG4vKipcbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgdmFyIE5vZGU7XG4oZnVuY3Rpb24gKE5vZGUpIHtcbiAgICBOb2RlLkJpdHMgPSA1O1xuICAgIGZ1bmN0aW9uIGZyYWdtZW50KGhhc2gsIHNoaWZ0KSB7XG4gICAgICAgIHJldHVybiB0YWtlKHNraXAoaGFzaCwgc2hpZnQpLCBOb2RlLkJpdHMpO1xuICAgIH1cbiAgICBOb2RlLmZyYWdtZW50ID0gZnJhZ21lbnQ7XG4gICAgZnVuY3Rpb24gaW5kZXgoZnJhZ21lbnQsIG1hc2spIHtcbiAgICAgICAgcmV0dXJuIHBvcENvdW50KHRha2UobWFzaywgZnJhZ21lbnQpKTtcbiAgICB9XG4gICAgTm9kZS5pbmRleCA9IGluZGV4O1xufSkoTm9kZSB8fCAoTm9kZSA9IHt9KSk7XG4vKipcbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgY29uc3QgRW1wdHkgPSBuZXcgKGNsYXNzIEVtcHR5IHtcbiAgICBpc0VtcHR5KCkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaXNMZWFmKCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGdldCgpIHtcbiAgICAgICAgcmV0dXJuIE5vbmU7XG4gICAgfVxuICAgIHNldChrZXksIHZhbHVlLCBoYXNoKSB7XG4gICAgICAgIHJldHVybiBTdGF0dXMuY3JlYXRlZChMZWFmLm9mKGhhc2gsIGtleSwgdmFsdWUpKTtcbiAgICB9XG4gICAgZGVsZXRlKCkge1xuICAgICAgICByZXR1cm4gU3RhdHVzLnVuY2hhbmdlZCh0aGlzKTtcbiAgICB9XG4gICAgbWFwKCkge1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgZXF1YWxzKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIEVtcHR5O1xuICAgIH1cbiAgICAqW1N5bWJvbC5pdGVyYXRvcl0oKSB7IH1cbn0pKCk7XG4vKipcbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgY2xhc3MgTGVhZiB7XG4gICAgc3RhdGljIG9mKGhhc2gsIGtleSwgdmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBMZWFmKGhhc2gsIGtleSwgdmFsdWUpO1xuICAgIH1cbiAgICBfaGFzaDtcbiAgICBfa2V5O1xuICAgIF92YWx1ZTtcbiAgICBjb25zdHJ1Y3RvcihoYXNoLCBrZXksIHZhbHVlKSB7XG4gICAgICAgIHRoaXMuX2hhc2ggPSBoYXNoO1xuICAgICAgICB0aGlzLl9rZXkgPSBrZXk7XG4gICAgICAgIHRoaXMuX3ZhbHVlID0gdmFsdWU7XG4gICAgfVxuICAgIGdldCBrZXkoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9rZXk7XG4gICAgfVxuICAgIGdldCB2YWx1ZSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3ZhbHVlO1xuICAgIH1cbiAgICBpc0VtcHR5KCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlzTGVhZigpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGdldChrZXksIGhhc2gsIHNoaWZ0KSB7XG4gICAgICAgIHJldHVybiBoYXNoID09PSB0aGlzLl9oYXNoICYmIEVxdWF0YWJsZS5lcXVhbHMoa2V5LCB0aGlzLl9rZXkpXG4gICAgICAgICAgICA/IE9wdGlvbi5vZih0aGlzLl92YWx1ZSlcbiAgICAgICAgICAgIDogTm9uZTtcbiAgICB9XG4gICAgc2V0KGtleSwgdmFsdWUsIGhhc2gsIHNoaWZ0KSB7XG4gICAgICAgIGlmIChoYXNoID09PSB0aGlzLl9oYXNoKSB7XG4gICAgICAgICAgICBpZiAoRXF1YXRhYmxlLmVxdWFscyhrZXksIHRoaXMuX2tleSkpIHtcbiAgICAgICAgICAgICAgICBpZiAoRXF1YXRhYmxlLmVxdWFscyh2YWx1ZSwgdGhpcy5fdmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBTdGF0dXMudW5jaGFuZ2VkKHRoaXMpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gU3RhdHVzLnVwZGF0ZWQoTGVhZi5vZihoYXNoLCBrZXksIHZhbHVlKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gU3RhdHVzLmNyZWF0ZWQoQ29sbGlzaW9uLm9mKGhhc2gsIFt0aGlzLCBMZWFmLm9mKGhhc2gsIGtleSwgdmFsdWUpXSkpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGZyYWdtZW50ID0gTm9kZS5mcmFnbWVudCh0aGlzLl9oYXNoLCBzaGlmdCk7XG4gICAgICAgIHJldHVybiBTcGFyc2Uub2YoYml0KGZyYWdtZW50KSwgW3RoaXNdKS5zZXQoa2V5LCB2YWx1ZSwgaGFzaCwgc2hpZnQpO1xuICAgIH1cbiAgICBkZWxldGUoa2V5LCBoYXNoKSB7XG4gICAgICAgIHJldHVybiBoYXNoID09PSB0aGlzLl9oYXNoICYmIEVxdWF0YWJsZS5lcXVhbHMoa2V5LCB0aGlzLl9rZXkpXG4gICAgICAgICAgICA/IFN0YXR1cy5kZWxldGVkKEVtcHR5KVxuICAgICAgICAgICAgOiBTdGF0dXMudW5jaGFuZ2VkKHRoaXMpO1xuICAgIH1cbiAgICBtYXAobWFwcGVyKSB7XG4gICAgICAgIHJldHVybiBMZWFmLm9mKHRoaXMuX2hhc2gsIHRoaXMuX2tleSwgbWFwcGVyKHRoaXMuX3ZhbHVlLCB0aGlzLl9rZXkpKTtcbiAgICB9XG4gICAgZXF1YWxzKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiAodmFsdWUgaW5zdGFuY2VvZiBMZWFmICYmXG4gICAgICAgICAgICB2YWx1ZS5faGFzaCA9PT0gdGhpcy5faGFzaCAmJlxuICAgICAgICAgICAgRXF1YXRhYmxlLmVxdWFscyh2YWx1ZS5fa2V5LCB0aGlzLl9rZXkpICYmXG4gICAgICAgICAgICBFcXVhdGFibGUuZXF1YWxzKHZhbHVlLl92YWx1ZSwgdGhpcy5fdmFsdWUpKTtcbiAgICB9XG4gICAgKltTeW1ib2wuaXRlcmF0b3JdKCkge1xuICAgICAgICB5aWVsZCBbdGhpcy5fa2V5LCB0aGlzLl92YWx1ZV07XG4gICAgfVxufVxuLyoqXG4gKiBAaW50ZXJuYWxcbiAqL1xuZXhwb3J0IGNsYXNzIENvbGxpc2lvbiB7XG4gICAgc3RhdGljIG9mKGhhc2gsIG5vZGVzKSB7XG4gICAgICAgIHJldHVybiBuZXcgQ29sbGlzaW9uKGhhc2gsIG5vZGVzKTtcbiAgICB9XG4gICAgX2hhc2g7XG4gICAgX25vZGVzO1xuICAgIGNvbnN0cnVjdG9yKGhhc2gsIG5vZGVzKSB7XG4gICAgICAgIHRoaXMuX2hhc2ggPSBoYXNoO1xuICAgICAgICB0aGlzLl9ub2RlcyA9IG5vZGVzO1xuICAgIH1cbiAgICBpc0VtcHR5KCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlzTGVhZigpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBnZXQoa2V5LCBoYXNoLCBzaGlmdCkge1xuICAgICAgICBpZiAoaGFzaCA9PT0gdGhpcy5faGFzaCkge1xuICAgICAgICAgICAgZm9yIChjb25zdCBub2RlIG9mIHRoaXMuX25vZGVzKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBub2RlLmdldChrZXksIGhhc2gsIHNoaWZ0KTtcbiAgICAgICAgICAgICAgICBpZiAodmFsdWUuaXNTb21lKCkpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gTm9uZTtcbiAgICB9XG4gICAgc2V0KGtleSwgdmFsdWUsIGhhc2gsIHNoaWZ0KSB7XG4gICAgICAgIGlmIChoYXNoID09PSB0aGlzLl9oYXNoKSB7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IHRoaXMuX25vZGVzLmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IG5vZGUgPSB0aGlzLl9ub2Rlc1tpXTtcbiAgICAgICAgICAgICAgICBpZiAoRXF1YXRhYmxlLmVxdWFscyhrZXksIG5vZGUua2V5KSkge1xuICAgICAgICAgICAgICAgICAgICBpZiAoRXF1YXRhYmxlLmVxdWFscyh2YWx1ZSwgbm9kZS52YWx1ZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBTdGF0dXMudW5jaGFuZ2VkKHRoaXMpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBTdGF0dXMudXBkYXRlZChDb2xsaXNpb24ub2YodGhpcy5faGFzaCwgcmVwbGFjZSh0aGlzLl9ub2RlcywgaSwgTGVhZi5vZihoYXNoLCBrZXksIHZhbHVlKSkpKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gU3RhdHVzLmNyZWF0ZWQoQ29sbGlzaW9uLm9mKHRoaXMuX2hhc2gsIHRoaXMuX25vZGVzLmNvbmNhdChMZWFmLm9mKGhhc2gsIGtleSwgdmFsdWUpKSkpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGZyYWdtZW50ID0gTm9kZS5mcmFnbWVudCh0aGlzLl9oYXNoLCBzaGlmdCk7XG4gICAgICAgIHJldHVybiBTcGFyc2Uub2YoYml0KGZyYWdtZW50KSwgW3RoaXNdKS5zZXQoa2V5LCB2YWx1ZSwgaGFzaCwgc2hpZnQpO1xuICAgIH1cbiAgICBkZWxldGUoa2V5LCBoYXNoKSB7XG4gICAgICAgIGlmIChoYXNoID09PSB0aGlzLl9oYXNoKSB7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IHRoaXMuX25vZGVzLmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IG5vZGUgPSB0aGlzLl9ub2Rlc1tpXTtcbiAgICAgICAgICAgICAgICBpZiAoRXF1YXRhYmxlLmVxdWFscyhrZXksIG5vZGUua2V5KSkge1xuICAgICAgICAgICAgICAgICAgICBjb25zdCBub2RlcyA9IHJlbW92ZSh0aGlzLl9ub2RlcywgaSk7XG4gICAgICAgICAgICAgICAgICAgIGlmIChub2Rlcy5sZW5ndGggPT09IDEpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFdlIGp1c3QgZGVsZXRlZCB0aGUgcGVudWx0aW1hdGUgTGVhZiBvZiB0aGUgQ29sbGlzaW9uLCBzbyB3ZSBjYW5cbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIHJlbW92ZSB0aGUgQ29sbGlzaW9uIGFuZCBvbmx5IGtlZXAgdGhlIHJlbWFpbmluZyBMZWFmLlxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFN0YXR1cy5kZWxldGVkKG5vZGVzWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gU3RhdHVzLmRlbGV0ZWQoQ29sbGlzaW9uLm9mKHRoaXMuX2hhc2gsIG5vZGVzKSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBTdGF0dXMudW5jaGFuZ2VkKHRoaXMpO1xuICAgIH1cbiAgICBtYXAobWFwcGVyKSB7XG4gICAgICAgIHJldHVybiBDb2xsaXNpb24ub2YodGhpcy5faGFzaCwgdGhpcy5fbm9kZXMubWFwKChub2RlKSA9PiBub2RlLm1hcChtYXBwZXIpKSk7XG4gICAgfVxuICAgIGVxdWFscyh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gKHZhbHVlIGluc3RhbmNlb2YgQ29sbGlzaW9uICYmXG4gICAgICAgICAgICB2YWx1ZS5faGFzaCA9PT0gdGhpcy5faGFzaCAmJlxuICAgICAgICAgICAgdmFsdWUuX25vZGVzLmxlbmd0aCA9PT0gdGhpcy5fbm9kZXMubGVuZ3RoICYmXG4gICAgICAgICAgICB2YWx1ZS5fbm9kZXMuZXZlcnkoKG5vZGUsIGkpID0+IG5vZGUuZXF1YWxzKHRoaXMuX25vZGVzW2ldKSkpO1xuICAgIH1cbiAgICAqW1N5bWJvbC5pdGVyYXRvcl0oKSB7XG4gICAgICAgIGZvciAoY29uc3Qgbm9kZSBvZiB0aGlzLl9ub2Rlcykge1xuICAgICAgICAgICAgeWllbGQqIG5vZGU7XG4gICAgICAgIH1cbiAgICB9XG59XG4vKipcbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgY2xhc3MgU3BhcnNlIHtcbiAgICBzdGF0aWMgb2YobWFzaywgbm9kZXMpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBTcGFyc2UobWFzaywgbm9kZXMpO1xuICAgIH1cbiAgICBfbWFzaztcbiAgICBfbm9kZXM7XG4gICAgY29uc3RydWN0b3IobWFzaywgbm9kZXMpIHtcbiAgICAgICAgdGhpcy5fbWFzayA9IG1hc2s7XG4gICAgICAgIHRoaXMuX25vZGVzID0gbm9kZXM7XG4gICAgfVxuICAgIGlzRW1wdHkoKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgaXNMZWFmKCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGdldChrZXksIGhhc2gsIHNoaWZ0KSB7XG4gICAgICAgIGNvbnN0IGZyYWdtZW50ID0gTm9kZS5mcmFnbWVudChoYXNoLCBzaGlmdCk7XG4gICAgICAgIGlmICh0ZXN0KHRoaXMuX21hc2ssIGZyYWdtZW50KSkge1xuICAgICAgICAgICAgY29uc3QgaW5kZXggPSBOb2RlLmluZGV4KGZyYWdtZW50LCB0aGlzLl9tYXNrKTtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9ub2Rlc1tpbmRleF0uZ2V0KGtleSwgaGFzaCwgc2hpZnQgKyBOb2RlLkJpdHMpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBOb25lO1xuICAgIH1cbiAgICBzZXQoa2V5LCB2YWx1ZSwgaGFzaCwgc2hpZnQpIHtcbiAgICAgICAgY29uc3QgZnJhZ21lbnQgPSBOb2RlLmZyYWdtZW50KGhhc2gsIHNoaWZ0KTtcbiAgICAgICAgY29uc3QgaW5kZXggPSBOb2RlLmluZGV4KGZyYWdtZW50LCB0aGlzLl9tYXNrKTtcbiAgICAgICAgaWYgKHRlc3QodGhpcy5fbWFzaywgZnJhZ21lbnQpKSB7XG4gICAgICAgICAgICBjb25zdCB7IHJlc3VsdDogbm9kZSwgc3RhdHVzIH0gPSB0aGlzLl9ub2Rlc1tpbmRleF0uc2V0KGtleSwgdmFsdWUsIGhhc2gsIHNoaWZ0ICsgTm9kZS5CaXRzKTtcbiAgICAgICAgICAgIGlmIChzdGF0dXMgPT09IFwidW5jaGFuZ2VkXCIpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gU3RhdHVzLnVuY2hhbmdlZCh0aGlzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IHNwYXJzZSA9IFNwYXJzZS5vZih0aGlzLl9tYXNrLCByZXBsYWNlKHRoaXMuX25vZGVzLCBpbmRleCwgbm9kZSkpO1xuICAgICAgICAgICAgc3dpdGNoIChzdGF0dXMpIHtcbiAgICAgICAgICAgICAgICBjYXNlIFwiY3JlYXRlZFwiOlxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gU3RhdHVzLmNyZWF0ZWQoc3BhcnNlKTtcbiAgICAgICAgICAgICAgICBjYXNlIFwidXBkYXRlZFwiOlxuICAgICAgICAgICAgICAgIGRlZmF1bHQ6XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBTdGF0dXMudXBkYXRlZChzcGFyc2UpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBTdGF0dXMuY3JlYXRlZChTcGFyc2Uub2Yoc2V0KHRoaXMuX21hc2ssIGZyYWdtZW50KSwgaW5zZXJ0KHRoaXMuX25vZGVzLCBpbmRleCwgTGVhZi5vZihoYXNoLCBrZXksIHZhbHVlKSkpKTtcbiAgICB9XG4gICAgZGVsZXRlKGtleSwgaGFzaCwgc2hpZnQpIHtcbiAgICAgICAgY29uc3QgZnJhZ21lbnQgPSBOb2RlLmZyYWdtZW50KGhhc2gsIHNoaWZ0KTtcbiAgICAgICAgaWYgKHRlc3QodGhpcy5fbWFzaywgZnJhZ21lbnQpKSB7XG4gICAgICAgICAgICBjb25zdCBpbmRleCA9IE5vZGUuaW5kZXgoZnJhZ21lbnQsIHRoaXMuX21hc2spO1xuICAgICAgICAgICAgY29uc3QgeyByZXN1bHQ6IG5vZGUsIHN0YXR1cyB9ID0gdGhpcy5fbm9kZXNbaW5kZXhdLmRlbGV0ZShrZXksIGhhc2gsIHNoaWZ0ICsgTm9kZS5CaXRzKTtcbiAgICAgICAgICAgIGlmIChzdGF0dXMgPT09IFwidW5jaGFuZ2VkXCIpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gU3RhdHVzLnVuY2hhbmdlZCh0aGlzKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChub2RlLmlzRW1wdHkoKSkge1xuICAgICAgICAgICAgICAgIGNvbnN0IG5vZGVzID0gcmVtb3ZlKHRoaXMuX25vZGVzLCBpbmRleCk7XG4gICAgICAgICAgICAgICAgaWYgKG5vZGVzLmxlbmd0aCA9PT0gMSkge1xuICAgICAgICAgICAgICAgICAgICAvLyBXZSBkZWxldGVkIHRoZSBwZW51bHRpbWF0ZSBjaGlsZCBvZiB0aGUgU3BhcnNlLCB3ZSBtYXkgYmUgYWJsZSB0b1xuICAgICAgICAgICAgICAgICAgICAvLyBzaW1wbGlmeSB0aGUgdHJlZS5cbiAgICAgICAgICAgICAgICAgICAgaWYgKG5vZGVzWzBdLmlzTGVhZigpIHx8IG5vZGVzWzBdIGluc3RhbmNlb2YgQ29sbGlzaW9uKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBUaGUgbGFzdCBjaGlsZCBpcyBsZWFmLWxpa2UsIGhlbmNlIGhhc2hlcyB3aWxsIGJlIGZ1bGx5IG1hdGNoZWRcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIGFnYWluc3QgaXRzIGtleShzKSBhbmQgd2UgY2FuIHJlbW92ZSB0aGUgY3VycmVudCBTcGFyc2VcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBTdGF0dXMuZGVsZXRlZChub2Rlc1swXSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgLy8gT3RoZXJ3aXNlLCB0aGUgbGFzdCBjaGlsZCBpcyBhIFNwYXJzZS4gV2UgY2FuJ3Qgc2ltcGx5IGNvbGxhcHNlIHRoZVxuICAgICAgICAgICAgICAgICAgICAvLyB0cmVlIGJ5IHJlbW92aW5nIHRoZSBjdXJyZW50IFNwYXJzZSwgc2luY2UgaXQgd2lsbCBjYXVzZSB0aGUgY2hpbGRcbiAgICAgICAgICAgICAgICAgICAgLy8gbWFzayB0byBiZSB0ZXN0ZWQgd2l0aCB0aGUgd3Jvbmcgc2hpZnQgKGl0cyBkZXB0aCBpbiB0aGUgdHJlZSB3b3VsZFxuICAgICAgICAgICAgICAgICAgICAvLyBiZSBkaWZmZXJlbnQpLlxuICAgICAgICAgICAgICAgICAgICAvLyBXZSBjb3VsZCBkbyBzb21lIGZ1cnRoZXIgb3B0aW1pc2F0aW9ucyAoZS5nLiwgaWYgdGhlIGNoaWxkJ3NcbiAgICAgICAgICAgICAgICAgICAgLy8gY2hpbGRyZW4gYXJlIGFsbCBsZWFmLWxpa2UsIHdlIGNvdWxkIGluc3RlYWQgZGVsZXRlIHRoZSBsb25lIGNoaWxkXG4gICAgICAgICAgICAgICAgICAgIC8vIGFuZCBjb25uZWN0IGRpcmVjdGx5IHRvIHRoZSBncmFuZGNoaWxkcmVuKS4gVGhpcyBpcywgaG93ZXZlcixcbiAgICAgICAgICAgICAgICAgICAgLy8gZ2V0dGluZyBoYWlyeSB0byBtYWtlIGFsbCBjYXNlcyB3b3JraW5nIGZpbmUsIGFuZCB3ZSBhc3N1bWUgdGhpc1xuICAgICAgICAgICAgICAgICAgICAvLyBraW5kIG9mIHNpdHVhdGlvbiBpcyBub3QgdG9vIGZyZXF1ZW50LiBTbyB3ZSBwYXkgdGhlIHByaWNlIG9mXG4gICAgICAgICAgICAgICAgICAgIC8vIGtlZXBpbmcgYSBub24tYnJhbmNoaW5nIFNwYXJzZSB1bnRpbCB3ZSBuZWVkIHRvIG9wdGltaXNlIHRoYXQuXG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBTdGF0dXMuZGVsZXRlZChTcGFyc2Uub2YoY2xlYXIodGhpcy5fbWFzaywgZnJhZ21lbnQpLCBub2RlcykpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIFN0YXR1cy5kZWxldGVkKFNwYXJzZS5vZih0aGlzLl9tYXNrLCByZXBsYWNlKHRoaXMuX25vZGVzLCBpbmRleCwgbm9kZSkpKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gU3RhdHVzLnVuY2hhbmdlZCh0aGlzKTtcbiAgICB9XG4gICAgbWFwKG1hcHBlcikge1xuICAgICAgICByZXR1cm4gU3BhcnNlLm9mKHRoaXMuX21hc2ssIHRoaXMuX25vZGVzLm1hcCgobm9kZSkgPT4gbm9kZS5tYXAobWFwcGVyKSkpO1xuICAgIH1cbiAgICBlcXVhbHModmFsdWUpIHtcbiAgICAgICAgcmV0dXJuICh2YWx1ZSBpbnN0YW5jZW9mIFNwYXJzZSAmJlxuICAgICAgICAgICAgdmFsdWUuX21hc2sgPT09IHRoaXMuX21hc2sgJiZcbiAgICAgICAgICAgIHZhbHVlLl9ub2Rlcy5sZW5ndGggPT09IHRoaXMuX25vZGVzLmxlbmd0aCAmJlxuICAgICAgICAgICAgdmFsdWUuX25vZGVzLmV2ZXJ5KChub2RlLCBpKSA9PiBub2RlLmVxdWFscyh0aGlzLl9ub2Rlc1tpXSkpKTtcbiAgICB9XG4gICAgKltTeW1ib2wuaXRlcmF0b3JdKCkge1xuICAgICAgICBmb3IgKGNvbnN0IG5vZGUgb2YgdGhpcy5fbm9kZXMpIHtcbiAgICAgICAgICAgIHlpZWxkKiBub2RlO1xuICAgICAgICB9XG4gICAgfVxufVxuZnVuY3Rpb24gaW5zZXJ0KGFycmF5LCBpbmRleCwgdmFsdWUpIHtcbiAgICBjb25zdCByZXN1bHQgPSBuZXcgQXJyYXkoYXJyYXkubGVuZ3RoICsgMSk7XG4gICAgcmVzdWx0W2luZGV4XSA9IHZhbHVlO1xuICAgIGZvciAobGV0IGkgPSAwLCBuID0gaW5kZXg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgcmVzdWx0W2ldID0gYXJyYXlbaV07XG4gICAgfVxuICAgIGZvciAobGV0IGkgPSBpbmRleCwgbiA9IGFycmF5Lmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICByZXN1bHRbaSArIDFdID0gYXJyYXlbaV07XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG59XG5mdW5jdGlvbiByZW1vdmUoYXJyYXksIGluZGV4KSB7XG4gICAgY29uc3QgcmVzdWx0ID0gbmV3IEFycmF5KGFycmF5Lmxlbmd0aCAtIDEpO1xuICAgIGZvciAobGV0IGkgPSAwLCBuID0gaW5kZXg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgcmVzdWx0W2ldID0gYXJyYXlbaV07XG4gICAgfVxuICAgIGZvciAobGV0IGkgPSBpbmRleCwgbiA9IHJlc3VsdC5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgcmVzdWx0W2ldID0gYXJyYXlbaSArIDFdO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gcmVwbGFjZShhcnJheSwgaW5kZXgsIHZhbHVlKSB7XG4gICAgY29uc3QgcmVzdWx0ID0gYXJyYXkuc2xpY2UoMCk7XG4gICAgcmVzdWx0W2luZGV4XSA9IHZhbHVlO1xuICAgIHJldHVybiByZXN1bHQ7XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1ub2RlLmpzLm1hcCIsIi8qKlxuICogQGludGVybmFsXG4gKi9cbmV4cG9ydCB2YXIgU3RhdHVzO1xuKGZ1bmN0aW9uIChTdGF0dXNfMSkge1xuICAgIGNsYXNzIFN0YXR1cyB7XG4gICAgICAgIF9yZXN1bHQ7XG4gICAgICAgIGNvbnN0cnVjdG9yKHJlc3VsdCkge1xuICAgICAgICAgICAgdGhpcy5fcmVzdWx0ID0gcmVzdWx0O1xuICAgICAgICB9XG4gICAgICAgIGdldCByZXN1bHQoKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fcmVzdWx0O1xuICAgICAgICB9XG4gICAgfVxuICAgIGNsYXNzIENyZWF0ZWQgZXh0ZW5kcyBTdGF0dXMge1xuICAgICAgICBzdGF0aWMgb2YocmVzdWx0KSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IENyZWF0ZWQocmVzdWx0KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdHJ1Y3RvcihyZXN1bHQpIHtcbiAgICAgICAgICAgIHN1cGVyKHJlc3VsdCk7XG4gICAgICAgIH1cbiAgICAgICAgZ2V0IHN0YXR1cygpIHtcbiAgICAgICAgICAgIHJldHVybiBcImNyZWF0ZWRcIjtcbiAgICAgICAgfVxuICAgIH1cbiAgICBTdGF0dXNfMS5DcmVhdGVkID0gQ3JlYXRlZDtcbiAgICBTdGF0dXNfMS5jcmVhdGVkID0gQ3JlYXRlZC5vZjtcbiAgICBjbGFzcyBVcGRhdGVkIGV4dGVuZHMgU3RhdHVzIHtcbiAgICAgICAgc3RhdGljIG9mKHJlc3VsdCkge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBVcGRhdGVkKHJlc3VsdCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3RydWN0b3IocmVzdWx0KSB7XG4gICAgICAgICAgICBzdXBlcihyZXN1bHQpO1xuICAgICAgICB9XG4gICAgICAgIGdldCBzdGF0dXMoKSB7XG4gICAgICAgICAgICByZXR1cm4gXCJ1cGRhdGVkXCI7XG4gICAgICAgIH1cbiAgICB9XG4gICAgU3RhdHVzXzEuVXBkYXRlZCA9IFVwZGF0ZWQ7XG4gICAgU3RhdHVzXzEudXBkYXRlZCA9IFVwZGF0ZWQub2Y7XG4gICAgY2xhc3MgRGVsZXRlZCBleHRlbmRzIFN0YXR1cyB7XG4gICAgICAgIHN0YXRpYyBvZihyZXN1bHQpIHtcbiAgICAgICAgICAgIHJldHVybiBuZXcgRGVsZXRlZChyZXN1bHQpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0cnVjdG9yKHJlc3VsdCkge1xuICAgICAgICAgICAgc3VwZXIocmVzdWx0KTtcbiAgICAgICAgfVxuICAgICAgICBnZXQgc3RhdHVzKCkge1xuICAgICAgICAgICAgcmV0dXJuIFwiZGVsZXRlZFwiO1xuICAgICAgICB9XG4gICAgfVxuICAgIFN0YXR1c18xLkRlbGV0ZWQgPSBEZWxldGVkO1xuICAgIFN0YXR1c18xLmRlbGV0ZWQgPSBEZWxldGVkLm9mO1xuICAgIGNsYXNzIFVuY2hhbmdlZCBleHRlbmRzIFN0YXR1cyB7XG4gICAgICAgIHN0YXRpYyBvZihyZXN1bHQpIHtcbiAgICAgICAgICAgIHJldHVybiBuZXcgVW5jaGFuZ2VkKHJlc3VsdCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3RydWN0b3IocmVzdWx0KSB7XG4gICAgICAgICAgICBzdXBlcihyZXN1bHQpO1xuICAgICAgICB9XG4gICAgICAgIGdldCBzdGF0dXMoKSB7XG4gICAgICAgICAgICByZXR1cm4gXCJ1bmNoYW5nZWRcIjtcbiAgICAgICAgfVxuICAgIH1cbiAgICBTdGF0dXNfMS5VbmNoYW5nZWQgPSBVbmNoYW5nZWQ7XG4gICAgU3RhdHVzXzEudW5jaGFuZ2VkID0gVW5jaGFuZ2VkLm9mO1xufSkoU3RhdHVzIHx8IChTdGF0dXMgPSB7fSkpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9c3RhdHVzLmpzLm1hcCIsImV4cG9ydCAqIGZyb20gXCIuL21heWJlLmpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9ub25lLmpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9vcHRpb24uanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL3NvbWUuanNcIjtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsImltcG9ydCB7IE9wdGlvbiB9IGZyb20gXCIuL29wdGlvbi5qc1wiO1xuLyoqXG4gKiBAaW50ZXJuYWxcbiAqL1xuZXhwb3J0IHZhciBNYXliZTtcbihmdW5jdGlvbiAoTWF5YmUpIHtcbiAgICBmdW5jdGlvbiB0b09wdGlvbihtYXliZSkge1xuICAgICAgICByZXR1cm4gT3B0aW9uLmlzT3B0aW9uKG1heWJlKSA/IG1heWJlIDogT3B0aW9uLm9mKG1heWJlKTtcbiAgICB9XG4gICAgTWF5YmUudG9PcHRpb24gPSB0b09wdGlvbjtcbn0pKE1heWJlIHx8IChNYXliZSA9IHt9KSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1tYXliZS5qcy5tYXAiLCJpbXBvcnQgeyBDb21wYXJhYmxlLCBDb21wYXJpc29uIH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLWNvbXBhcmFibGVcIjtcbmNvbnN0IHsgY29tcGFyZUNvbXBhcmFibGUgfSA9IENvbXBhcmFibGU7XG4vKipcbiAqIEBwdWJsaWNcbiAqL1xuZXhwb3J0IGNvbnN0IE5vbmUgPSBuZXcgKGNsYXNzIE5vbmUge1xuICAgIGlzU29tZSgpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBpc05vbmUoKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBtYXAoKSB7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBmb3JFYWNoKCkge1xuICAgICAgICByZXR1cm47XG4gICAgfVxuICAgIGFwcGx5KCkge1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgZmxhdE1hcCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGZsYXR0ZW4oKSB7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICByZWR1Y2UocmVkdWNlciwgYWNjdW11bGF0b3IpIHtcbiAgICAgICAgcmV0dXJuIGFjY3VtdWxhdG9yO1xuICAgIH1cbiAgICBmaWx0ZXIoKSB7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICByZWplY3QoKSB7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBpbmNsdWRlcygpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBzb21lKCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIG5vbmUoKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBldmVyeSgpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGFuZCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGFuZFRoZW4oKSB7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBvcihvcHRpb24pIHtcbiAgICAgICAgcmV0dXJuIG9wdGlvbjtcbiAgICB9XG4gICAgb3JFbHNlKG9wdGlvbikge1xuICAgICAgICByZXR1cm4gb3B0aW9uKCk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIGdldFVuc2FmZShtZXNzYWdlID0gXCJBdHRlbXB0ZWQgdG8gLmdldFVuc2FmZSgpIGZyb20gTm9uZVwiKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihtZXNzYWdlKTtcbiAgICB9XG4gICAgZ2V0T3IodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgIH1cbiAgICBnZXRPckVsc2UodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlKCk7XG4gICAgfVxuICAgIHRlZSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGNvbXBhcmUob3B0aW9uKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmNvbXBhcmVXaXRoKG9wdGlvbiwgY29tcGFyZUNvbXBhcmFibGUpO1xuICAgIH1cbiAgICBjb21wYXJlV2l0aChvcHRpb24pIHtcbiAgICAgICAgcmV0dXJuIG9wdGlvbi5pc05vbmUoKSA/IENvbXBhcmlzb24uRXF1YWwgOiBDb21wYXJpc29uLkxlc3M7XG4gICAgfVxuICAgIGVxdWFscyh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBOb25lO1xuICAgIH1cbiAgICBoYXNoKGhhc2gpIHtcbiAgICAgICAgaGFzaC53cml0ZUJvb2xlYW4oZmFsc2UpO1xuICAgIH1cbiAgICAqW1N5bWJvbC5pdGVyYXRvcl0oKSB7IH1cbiAgICB0b0FycmF5KCkge1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxuICAgIHRvSlNPTigpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHR5cGU6IFwibm9uZVwiLFxuICAgICAgICB9O1xuICAgIH1cbiAgICB0b1N0cmluZygpIHtcbiAgICAgICAgcmV0dXJuIFwiTm9uZVwiO1xuICAgIH1cbn0pKCk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1ub25lLmpzLm1hcCIsImltcG9ydCB7fSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtY29tcGFyYWJsZVwiO1xuaW1wb3J0IHsgTm9uZSB9IGZyb20gXCIuL25vbmUuanNcIjtcbmltcG9ydCB7IFNvbWUgfSBmcm9tIFwiLi9zb21lLmpzXCI7XG4vKipcbiAqIEBwdWJsaWNcbiAqL1xuZXhwb3J0IHZhciBPcHRpb247XG4oZnVuY3Rpb24gKE9wdGlvbikge1xuICAgIGZ1bmN0aW9uIGlzT3B0aW9uKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiBpc1NvbWUodmFsdWUpIHx8IGlzTm9uZSh2YWx1ZSk7XG4gICAgfVxuICAgIE9wdGlvbi5pc09wdGlvbiA9IGlzT3B0aW9uO1xuICAgIGZ1bmN0aW9uIGlzU29tZSh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gU29tZS5pc1NvbWUodmFsdWUpO1xuICAgIH1cbiAgICBPcHRpb24uaXNTb21lID0gaXNTb21lO1xuICAgIGZ1bmN0aW9uIGlzTm9uZSh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdmFsdWUgPT09IE5vbmU7XG4gICAgfVxuICAgIE9wdGlvbi5pc05vbmUgPSBpc05vbmU7XG4gICAgZnVuY3Rpb24gb2YodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIFNvbWUub2YodmFsdWUpO1xuICAgIH1cbiAgICBPcHRpb24ub2YgPSBvZjtcbiAgICBmdW5jdGlvbiBlbXB0eSgpIHtcbiAgICAgICAgcmV0dXJuIE5vbmU7XG4gICAgfVxuICAgIE9wdGlvbi5lbXB0eSA9IGVtcHR5O1xuICAgIGZ1bmN0aW9uIGZyb20odmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlID09PSBudWxsIHx8IHZhbHVlID09PSB1bmRlZmluZWQgPyBOb25lIDogU29tZS5vZih2YWx1ZSk7XG4gICAgfVxuICAgIE9wdGlvbi5mcm9tID0gZnJvbTtcbiAgICBmdW5jdGlvbiBjb25kaXRpb25hbCh2YWx1ZSwgcHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiBwcmVkaWNhdGUodmFsdWUpID8gU29tZS5vZih2YWx1ZSkgOiBOb25lO1xuICAgIH1cbiAgICBPcHRpb24uY29uZGl0aW9uYWwgPSBjb25kaXRpb25hbDtcbn0pKE9wdGlvbiB8fCAoT3B0aW9uID0ge30pKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW9wdGlvbi5qcy5tYXAiLCJpbXBvcnQgeyBDb21wYXJhYmxlLCBDb21wYXJpc29uLCB9IGZyb20gXCJAc2l0ZWltcHJvdmUvYWxmYS1jb21wYXJhYmxlXCI7XG5pbXBvcnQgeyBFcXVhdGFibGUgfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtZXF1YXRhYmxlXCI7XG5pbXBvcnQgeyBTZXJpYWxpemFibGUgfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtanNvblwiO1xuaW1wb3J0IHsgUHJlZGljYXRlIH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLXByZWRpY2F0ZVwiO1xuaW1wb3J0IHsgTm9uZSB9IGZyb20gXCIuL25vbmUuanNcIjtcbmNvbnN0IHsgbm90LCB0ZXN0IH0gPSBQcmVkaWNhdGU7XG5jb25zdCB7IGNvbXBhcmVDb21wYXJhYmxlIH0gPSBDb21wYXJhYmxlO1xuLyoqXG4gKiBAcHVibGljXG4gKi9cbmV4cG9ydCBjbGFzcyBTb21lIHtcbiAgICBzdGF0aWMgb2YodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBTb21lKHZhbHVlKTtcbiAgICB9XG4gICAgX3ZhbHVlO1xuICAgIGNvbnN0cnVjdG9yKHZhbHVlKSB7XG4gICAgICAgIHRoaXMuX3ZhbHVlID0gdmFsdWU7XG4gICAgfVxuICAgIGlzU29tZSgpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGlzTm9uZSgpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBtYXAobWFwcGVyKSB7XG4gICAgICAgIHJldHVybiBuZXcgU29tZShtYXBwZXIodGhpcy5fdmFsdWUpKTtcbiAgICB9XG4gICAgZm9yRWFjaChtYXBwZXIpIHtcbiAgICAgICAgbWFwcGVyKHRoaXMuX3ZhbHVlKTtcbiAgICB9XG4gICAgYXBwbHkobWFwcGVyKSB7XG4gICAgICAgIHJldHVybiBtYXBwZXIubWFwKChtYXBwZXIpID0+IG1hcHBlcih0aGlzLl92YWx1ZSkpO1xuICAgIH1cbiAgICBmbGF0TWFwKG1hcHBlcikge1xuICAgICAgICByZXR1cm4gbWFwcGVyKHRoaXMuX3ZhbHVlKTtcbiAgICB9XG4gICAgZmxhdHRlbigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3ZhbHVlO1xuICAgIH1cbiAgICByZWR1Y2UocmVkdWNlciwgYWNjdW11bGF0b3IpIHtcbiAgICAgICAgcmV0dXJuIHJlZHVjZXIoYWNjdW11bGF0b3IsIHRoaXMuX3ZhbHVlKTtcbiAgICB9XG4gICAgZmlsdGVyKHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gdGVzdChwcmVkaWNhdGUsIHRoaXMuX3ZhbHVlKSA/IHRoaXMgOiBOb25lO1xuICAgIH1cbiAgICByZWplY3QocHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmZpbHRlcihub3QocHJlZGljYXRlKSk7XG4gICAgfVxuICAgIGluY2x1ZGVzKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiBFcXVhdGFibGUuZXF1YWxzKHZhbHVlLCB0aGlzLl92YWx1ZSk7XG4gICAgfVxuICAgIHNvbWUocHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiB0ZXN0KHByZWRpY2F0ZSwgdGhpcy5fdmFsdWUpO1xuICAgIH1cbiAgICBub25lKHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gdGVzdChub3QocHJlZGljYXRlKSwgdGhpcy5fdmFsdWUpO1xuICAgIH1cbiAgICBldmVyeShwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIHRlc3QocHJlZGljYXRlLCB0aGlzLl92YWx1ZSk7XG4gICAgfVxuICAgIGFuZChvcHRpb24pIHtcbiAgICAgICAgcmV0dXJuIG9wdGlvbjtcbiAgICB9XG4gICAgYW5kVGhlbihvcHRpb24pIHtcbiAgICAgICAgcmV0dXJuIG9wdGlvbih0aGlzLl92YWx1ZSk7XG4gICAgfVxuICAgIG9yKCkge1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgb3JFbHNlKCkge1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgZ2V0KCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fdmFsdWU7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIGdldFVuc2FmZSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3ZhbHVlO1xuICAgIH1cbiAgICBnZXRPcigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3ZhbHVlO1xuICAgIH1cbiAgICBnZXRPckVsc2UoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl92YWx1ZTtcbiAgICB9XG4gICAgdGVlKGNhbGxiYWNrKSB7XG4gICAgICAgIGNhbGxiYWNrKHRoaXMuX3ZhbHVlKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGNvbXBhcmUob3B0aW9uKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmNvbXBhcmVXaXRoKG9wdGlvbiwgY29tcGFyZUNvbXBhcmFibGUpO1xuICAgIH1cbiAgICBjb21wYXJlV2l0aChvcHRpb24sIGNvbXBhcmVyKSB7XG4gICAgICAgIHJldHVybiBvcHRpb24uaXNTb21lKClcbiAgICAgICAgICAgID8gY29tcGFyZXIodGhpcy5fdmFsdWUsIG9wdGlvbi5fdmFsdWUpXG4gICAgICAgICAgICA6IENvbXBhcmlzb24uR3JlYXRlcjtcbiAgICB9XG4gICAgZXF1YWxzKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIFNvbWUgJiYgRXF1YXRhYmxlLmVxdWFscyh2YWx1ZS5fdmFsdWUsIHRoaXMuX3ZhbHVlKTtcbiAgICB9XG4gICAgaGFzaChoYXNoKSB7XG4gICAgICAgIGhhc2gud3JpdGVCb29sZWFuKHRydWUpLndyaXRlVW5rbm93bih0aGlzLl92YWx1ZSk7XG4gICAgfVxuICAgICpbU3ltYm9sLml0ZXJhdG9yXSgpIHtcbiAgICAgICAgeWllbGQgdGhpcy5fdmFsdWU7XG4gICAgfVxuICAgIHRvQXJyYXkoKSB7XG4gICAgICAgIHJldHVybiBbdGhpcy5fdmFsdWVdO1xuICAgIH1cbiAgICB0b0pTT04ob3B0aW9ucykge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgdHlwZTogXCJzb21lXCIsXG4gICAgICAgICAgICB2YWx1ZTogU2VyaWFsaXphYmxlLnRvSlNPTih0aGlzLl92YWx1ZSwgb3B0aW9ucyksXG4gICAgICAgIH07XG4gICAgfVxuICAgIHRvU3RyaW5nKCkge1xuICAgICAgICByZXR1cm4gYFNvbWUgeyAke3RoaXMuX3ZhbHVlfSB9YDtcbiAgICB9XG59XG4vKipcbiAqIEBwdWJsaWNcbiAqL1xuKGZ1bmN0aW9uIChTb21lKSB7XG4gICAgZnVuY3Rpb24gaXNTb21lKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIFNvbWU7XG4gICAgfVxuICAgIFNvbWUuaXNTb21lID0gaXNTb21lO1xufSkoU29tZSB8fCAoU29tZSA9IHt9KSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1zb21lLmpzLm1hcCIsImV4cG9ydCAqIGZyb20gXCIuL3ByZWRpY2F0ZS5qc1wiO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXguanMubWFwIiwiaW1wb3J0IHsgRXF1YXRhYmxlIH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLWVxdWF0YWJsZVwiO1xuLyoqXG4gKiBAcHVibGljXG4gKi9cbmV4cG9ydCB2YXIgUHJlZGljYXRlO1xuKGZ1bmN0aW9uIChQcmVkaWNhdGUpIHtcbiAgICBmdW5jdGlvbiB0ZXN0KHByZWRpY2F0ZSwgdmFsdWUsIC4uLmFyZ3MpIHtcbiAgICAgICAgcmV0dXJuIHByZWRpY2F0ZSh2YWx1ZSwgLi4uYXJncyk7XG4gICAgfVxuICAgIFByZWRpY2F0ZS50ZXN0ID0gdGVzdDtcbiAgICBmdW5jdGlvbiBmb2xkKHByZWRpY2F0ZSwgaWZUcnVlLCBpZkZhbHNlLCB2YWx1ZSwgLi4uYXJncykge1xuICAgICAgICByZXR1cm4gcHJlZGljYXRlKHZhbHVlLCAuLi5hcmdzKSA/IGlmVHJ1ZSh2YWx1ZSkgOiBpZkZhbHNlKHZhbHVlKTtcbiAgICB9XG4gICAgUHJlZGljYXRlLmZvbGQgPSBmb2xkO1xuICAgIGZ1bmN0aW9uIG5vdChwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuICh2YWx1ZSwgLi4uYXJncykgPT4gIXByZWRpY2F0ZSh2YWx1ZSwgLi4uYXJncyk7XG4gICAgfVxuICAgIFByZWRpY2F0ZS5ub3QgPSBub3Q7XG4gICAgZnVuY3Rpb24gYW5kKC4uLnByZWRpY2F0ZXMpIHtcbiAgICAgICAgcmV0dXJuICh2YWx1ZSwgLi4uYXJncykgPT4ge1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDAsIG4gPSBwcmVkaWNhdGVzLmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgICAgIGlmICghcHJlZGljYXRlc1tpXSh2YWx1ZSwgLi4uYXJncykpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9O1xuICAgIH1cbiAgICBQcmVkaWNhdGUuYW5kID0gYW5kO1xuICAgIGZ1bmN0aW9uIG9yKC4uLnByZWRpY2F0ZXMpIHtcbiAgICAgICAgcmV0dXJuICh2YWx1ZSwgLi4uYXJncykgPT4ge1xuICAgICAgICAgICAgZm9yIChsZXQgaSA9IDAsIG4gPSBwcmVkaWNhdGVzLmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgICAgIGlmIChwcmVkaWNhdGVzW2ldKHZhbHVlLCAuLi5hcmdzKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH07XG4gICAgfVxuICAgIFByZWRpY2F0ZS5vciA9IG9yO1xuICAgIGZ1bmN0aW9uIHhvciguLi5wcmVkaWNhdGVzKSB7XG4gICAgICAgIHJldHVybiBhbmQob3IoLi4ucHJlZGljYXRlcyksIG5vdChhbmQoLi4ucHJlZGljYXRlcykpKTtcbiAgICB9XG4gICAgUHJlZGljYXRlLnhvciA9IHhvcjtcbiAgICBmdW5jdGlvbiBub3IoLi4ucHJlZGljYXRlcykge1xuICAgICAgICByZXR1cm4gbm90KG9yKC4uLnByZWRpY2F0ZXMpKTtcbiAgICB9XG4gICAgUHJlZGljYXRlLm5vciA9IG5vcjtcbiAgICBmdW5jdGlvbiBuYW5kKC4uLnByZWRpY2F0ZXMpIHtcbiAgICAgICAgcmV0dXJuIG5vdChhbmQoLi4ucHJlZGljYXRlcykpO1xuICAgIH1cbiAgICBQcmVkaWNhdGUubmFuZCA9IG5hbmQ7XG4gICAgZnVuY3Rpb24gZXF1YWxzKC4uLnZhbHVlcykge1xuICAgICAgICByZXR1cm4gKG90aGVyKSA9PiB2YWx1ZXMuc29tZSgodmFsdWUpID0+IEVxdWF0YWJsZS5lcXVhbHMob3RoZXIsIHZhbHVlKSk7XG4gICAgfVxuICAgIFByZWRpY2F0ZS5lcXVhbHMgPSBlcXVhbHM7XG4gICAgZnVuY3Rpb24gcHJvcGVydHkocHJvcGVydHksIHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gKHZhbHVlLCAuLi5hcmdzKSA9PiBwcmVkaWNhdGUodmFsdWVbcHJvcGVydHldLCAuLi5hcmdzKTtcbiAgICB9XG4gICAgUHJlZGljYXRlLnByb3BlcnR5ID0gcHJvcGVydHk7XG4gICAgZnVuY3Rpb24gdGVlKHByZWRpY2F0ZSwgY2FsbGJhY2spIHtcbiAgICAgICAgcmV0dXJuICh2YWx1ZSwgLi4uYXJncykgPT4ge1xuICAgICAgICAgICAgY29uc3QgcmVzdWx0ID0gcHJlZGljYXRlKHZhbHVlLCAuLi5hcmdzKTtcbiAgICAgICAgICAgIGNhbGxiYWNrKHZhbHVlLCByZXN1bHQsIC4uLmFyZ3MpO1xuICAgICAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICAgICAgfTtcbiAgICB9XG4gICAgUHJlZGljYXRlLnRlZSA9IHRlZTtcbn0pKFByZWRpY2F0ZSB8fCAoUHJlZGljYXRlID0ge30pKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXByZWRpY2F0ZS5qcy5tYXAiLCJleHBvcnQgKiBmcm9tIFwiLi9yZWZpbmVtZW50LmpzXCI7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCJpbXBvcnQgeyBQcmVkaWNhdGUgfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtcHJlZGljYXRlXCI7XG4vKipcbiAqIEBwdWJsaWNcbiAqL1xuZXhwb3J0IHZhciBSZWZpbmVtZW50O1xuKGZ1bmN0aW9uIChSZWZpbmVtZW50KSB7XG4gICAgUmVmaW5lbWVudC50ZXN0ID0gUHJlZGljYXRlLnRlc3Q7XG4gICAgUmVmaW5lbWVudC5mb2xkID0gUHJlZGljYXRlLmZvbGQ7XG4gICAgUmVmaW5lbWVudC5ub3QgPSBQcmVkaWNhdGUubm90O1xuICAgIFJlZmluZW1lbnQuYW5kID0gUHJlZGljYXRlLmFuZDtcbiAgICBSZWZpbmVtZW50Lm9yID0gUHJlZGljYXRlLm9yO1xuICAgIFJlZmluZW1lbnQueG9yID0gUHJlZGljYXRlLnhvcjtcbiAgICBSZWZpbmVtZW50Lm5vciA9IFByZWRpY2F0ZS5ub3I7XG4gICAgUmVmaW5lbWVudC5uYW5kID0gUHJlZGljYXRlLm5hbmQ7XG4gICAgUmVmaW5lbWVudC5lcXVhbHMgPSBQcmVkaWNhdGUuZXF1YWxzO1xuICAgIFJlZmluZW1lbnQudGVlID0gUHJlZGljYXRlLnRlZTtcbiAgICBmdW5jdGlvbiBpc1N0cmluZyh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSBcInN0cmluZ1wiO1xuICAgIH1cbiAgICBSZWZpbmVtZW50LmlzU3RyaW5nID0gaXNTdHJpbmc7XG4gICAgZnVuY3Rpb24gaXNOdW1iZXIodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJudW1iZXJcIjtcbiAgICB9XG4gICAgUmVmaW5lbWVudC5pc051bWJlciA9IGlzTnVtYmVyO1xuICAgIGZ1bmN0aW9uIGlzQmlnSW50KHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwiYmlnaW50XCI7XG4gICAgfVxuICAgIFJlZmluZW1lbnQuaXNCaWdJbnQgPSBpc0JpZ0ludDtcbiAgICBmdW5jdGlvbiBpc0Jvb2xlYW4odmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJib29sZWFuXCI7XG4gICAgfVxuICAgIFJlZmluZW1lbnQuaXNCb29sZWFuID0gaXNCb29sZWFuO1xuICAgIGZ1bmN0aW9uIGlzTnVsbCh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdmFsdWUgPT09IG51bGw7XG4gICAgfVxuICAgIFJlZmluZW1lbnQuaXNOdWxsID0gaXNOdWxsO1xuICAgIGZ1bmN0aW9uIGlzVW5kZWZpbmVkKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZSA9PT0gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBSZWZpbmVtZW50LmlzVW5kZWZpbmVkID0gaXNVbmRlZmluZWQ7XG4gICAgZnVuY3Rpb24gaXNTeW1ib2wodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJzeW1ib2xcIjtcbiAgICB9XG4gICAgUmVmaW5lbWVudC5pc1N5bWJvbCA9IGlzU3ltYm9sO1xuICAgIGZ1bmN0aW9uIGlzRnVuY3Rpb24odmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJmdW5jdGlvblwiO1xuICAgIH1cbiAgICBSZWZpbmVtZW50LmlzRnVuY3Rpb24gPSBpc0Z1bmN0aW9uO1xuICAgIGZ1bmN0aW9uIGlzT2JqZWN0KHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwib2JqZWN0XCIgJiYgdmFsdWUgIT09IG51bGw7XG4gICAgfVxuICAgIFJlZmluZW1lbnQuaXNPYmplY3QgPSBpc09iamVjdDtcbiAgICBSZWZpbmVtZW50LmlzUHJpbWl0aXZlID0gUmVmaW5lbWVudC5vcihpc1N0cmluZywgUmVmaW5lbWVudC5vcihpc051bWJlciwgUmVmaW5lbWVudC5vcihpc0JpZ0ludCwgUmVmaW5lbWVudC5vcihpc0Jvb2xlYW4sIFJlZmluZW1lbnQub3IoaXNOdWxsLCBSZWZpbmVtZW50Lm9yKGlzVW5kZWZpbmVkLCBpc1N5bWJvbCkpKSkpKTtcbn0pKFJlZmluZW1lbnQgfHwgKFJlZmluZW1lbnQgPSB7fSkpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmVmaW5lbWVudC5qcy5tYXAiLCIoZnVuY3Rpb24gKGdsb2JhbCwgZmFjdG9yeSkge1xuICBpZiAodHlwZW9mIGRlZmluZSA9PT0gXCJmdW5jdGlvblwiICYmIGRlZmluZS5hbWQpIHtcbiAgICBkZWZpbmUoXCJ3ZWJleHRlbnNpb24tcG9seWZpbGxcIiwgW1wibW9kdWxlXCJdLCBmYWN0b3J5KTtcbiAgfSBlbHNlIGlmICh0eXBlb2YgZXhwb3J0cyAhPT0gXCJ1bmRlZmluZWRcIikge1xuICAgIGZhY3RvcnkobW9kdWxlKTtcbiAgfSBlbHNlIHtcbiAgICB2YXIgbW9kID0ge1xuICAgICAgZXhwb3J0czoge31cbiAgICB9O1xuICAgIGZhY3RvcnkobW9kKTtcbiAgICBnbG9iYWwuYnJvd3NlciA9IG1vZC5leHBvcnRzO1xuICB9XG59KSh0eXBlb2YgZ2xvYmFsVGhpcyAhPT0gXCJ1bmRlZmluZWRcIiA/IGdsb2JhbFRoaXMgOiB0eXBlb2Ygc2VsZiAhPT0gXCJ1bmRlZmluZWRcIiA/IHNlbGYgOiB0aGlzLCBmdW5jdGlvbiAobW9kdWxlKSB7XG4gIC8qIHdlYmV4dGVuc2lvbi1wb2x5ZmlsbCAtIHYwLjEwLjAgLSBGcmkgQXVnIDEyIDIwMjIgMTk6NDI6NDQgKi9cblxuICAvKiAtKi0gTW9kZTogaW5kZW50LXRhYnMtbW9kZTogbmlsOyBqcy1pbmRlbnQtbGV2ZWw6IDIgLSotICovXG5cbiAgLyogdmltOiBzZXQgc3RzPTIgc3c9MiBldCB0dz04MDogKi9cblxuICAvKiBUaGlzIFNvdXJjZSBDb2RlIEZvcm0gaXMgc3ViamVjdCB0byB0aGUgdGVybXMgb2YgdGhlIE1vemlsbGEgUHVibGljXG4gICAqIExpY2Vuc2UsIHYuIDIuMC4gSWYgYSBjb3B5IG9mIHRoZSBNUEwgd2FzIG5vdCBkaXN0cmlidXRlZCB3aXRoIHRoaXNcbiAgICogZmlsZSwgWW91IGNhbiBvYnRhaW4gb25lIGF0IGh0dHA6Ly9tb3ppbGxhLm9yZy9NUEwvMi4wLy4gKi9cbiAgXCJ1c2Ugc3RyaWN0XCI7XG5cbiAgaWYgKCFnbG9iYWxUaGlzLmNocm9tZT8ucnVudGltZT8uaWQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJUaGlzIHNjcmlwdCBzaG91bGQgb25seSBiZSBsb2FkZWQgaW4gYSBicm93c2VyIGV4dGVuc2lvbi5cIik7XG4gIH1cblxuICBpZiAodHlwZW9mIGdsb2JhbFRoaXMuYnJvd3NlciA9PT0gXCJ1bmRlZmluZWRcIiB8fCBPYmplY3QuZ2V0UHJvdG90eXBlT2YoZ2xvYmFsVGhpcy5icm93c2VyKSAhPT0gT2JqZWN0LnByb3RvdHlwZSkge1xuICAgIGNvbnN0IENIUk9NRV9TRU5EX01FU1NBR0VfQ0FMTEJBQ0tfTk9fUkVTUE9OU0VfTUVTU0FHRSA9IFwiVGhlIG1lc3NhZ2UgcG9ydCBjbG9zZWQgYmVmb3JlIGEgcmVzcG9uc2Ugd2FzIHJlY2VpdmVkLlwiOyAvLyBXcmFwcGluZyB0aGUgYnVsayBvZiB0aGlzIHBvbHlmaWxsIGluIGEgb25lLXRpbWUtdXNlIGZ1bmN0aW9uIGlzIGEgbWlub3JcbiAgICAvLyBvcHRpbWl6YXRpb24gZm9yIEZpcmVmb3guIFNpbmNlIFNwaWRlcm1vbmtleSBkb2VzIG5vdCBmdWxseSBwYXJzZSB0aGVcbiAgICAvLyBjb250ZW50cyBvZiBhIGZ1bmN0aW9uIHVudGlsIHRoZSBmaXJzdCB0aW1lIGl0J3MgY2FsbGVkLCBhbmQgc2luY2UgaXQgd2lsbFxuICAgIC8vIG5ldmVyIGFjdHVhbGx5IG5lZWQgdG8gYmUgY2FsbGVkLCB0aGlzIGFsbG93cyB0aGUgcG9seWZpbGwgdG8gYmUgaW5jbHVkZWRcbiAgICAvLyBpbiBGaXJlZm94IG5lYXJseSBmb3IgZnJlZS5cblxuICAgIGNvbnN0IHdyYXBBUElzID0gZXh0ZW5zaW9uQVBJcyA9PiB7XG4gICAgICAvLyBOT1RFOiBhcGlNZXRhZGF0YSBpcyBhc3NvY2lhdGVkIHRvIHRoZSBjb250ZW50IG9mIHRoZSBhcGktbWV0YWRhdGEuanNvbiBmaWxlXG4gICAgICAvLyBhdCBidWlsZCB0aW1lIGJ5IHJlcGxhY2luZyB0aGUgZm9sbG93aW5nIFwiaW5jbHVkZVwiIHdpdGggdGhlIGNvbnRlbnQgb2YgdGhlXG4gICAgICAvLyBKU09OIGZpbGUuXG4gICAgICBjb25zdCBhcGlNZXRhZGF0YSA9IHtcbiAgICAgICAgXCJhbGFybXNcIjoge1xuICAgICAgICAgIFwiY2xlYXJcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJjbGVhckFsbFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEFsbFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImJvb2ttYXJrc1wiOiB7XG4gICAgICAgICAgXCJjcmVhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRDaGlsZHJlblwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFJlY2VudFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFN1YlRyZWVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRUcmVlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwibW92ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZVRyZWVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZWFyY2hcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJ1cGRhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJicm93c2VyQWN0aW9uXCI6IHtcbiAgICAgICAgICBcImRpc2FibGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJlbmFibGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRCYWRnZUJhY2tncm91bmRDb2xvclwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEJhZGdlVGV4dFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFBvcHVwXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0VGl0bGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJvcGVuUG9wdXBcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRCYWRnZUJhY2tncm91bmRDb2xvclwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldEJhZGdlVGV4dFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldEljb25cIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRQb3B1cFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldFRpdGxlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiYnJvd3NpbmdEYXRhXCI6IHtcbiAgICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZUNhY2hlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlQ29va2llc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZURvd25sb2Fkc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZUZvcm1EYXRhXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlSGlzdG9yeVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZUxvY2FsU3RvcmFnZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZVBhc3N3b3Jkc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZVBsdWdpbkRhdGFcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXR0aW5nc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImNvbW1hbmRzXCI6IHtcbiAgICAgICAgICBcImdldEFsbFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImNvbnRleHRNZW51c1wiOiB7XG4gICAgICAgICAgXCJyZW1vdmVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVBbGxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJ1cGRhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJjb29raWVzXCI6IHtcbiAgICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEFsbFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEFsbENvb2tpZVN0b3Jlc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImRldnRvb2xzXCI6IHtcbiAgICAgICAgICBcImluc3BlY3RlZFdpbmRvd1wiOiB7XG4gICAgICAgICAgICBcImV2YWxcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDIsXG4gICAgICAgICAgICAgIFwic2luZ2xlQ2FsbGJhY2tBcmdcIjogZmFsc2VcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicGFuZWxzXCI6IHtcbiAgICAgICAgICAgIFwiY3JlYXRlXCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDMsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAzLFxuICAgICAgICAgICAgICBcInNpbmdsZUNhbGxiYWNrQXJnXCI6IHRydWVcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBcImVsZW1lbnRzXCI6IHtcbiAgICAgICAgICAgICAgXCJjcmVhdGVTaWRlYmFyUGFuZVwiOiB7XG4gICAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJkb3dubG9hZHNcIjoge1xuICAgICAgICAgIFwiY2FuY2VsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZG93bmxvYWRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJlcmFzZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEZpbGVJY29uXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwib3BlblwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInBhdXNlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlRmlsZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlc3VtZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNlYXJjaFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNob3dcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJleHRlbnNpb25cIjoge1xuICAgICAgICAgIFwiaXNBbGxvd2VkRmlsZVNjaGVtZUFjY2Vzc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImlzQWxsb3dlZEluY29nbml0b0FjY2Vzc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImhpc3RvcnlcIjoge1xuICAgICAgICAgIFwiYWRkVXJsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZGVsZXRlQWxsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZGVsZXRlUmFuZ2VcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJkZWxldGVVcmxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRWaXNpdHNcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZWFyY2hcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJpMThuXCI6IHtcbiAgICAgICAgICBcImRldGVjdExhbmd1YWdlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0QWNjZXB0TGFuZ3VhZ2VzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiaWRlbnRpdHlcIjoge1xuICAgICAgICAgIFwibGF1bmNoV2ViQXV0aEZsb3dcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJpZGxlXCI6IHtcbiAgICAgICAgICBcInF1ZXJ5U3RhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJtYW5hZ2VtZW50XCI6IHtcbiAgICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEFsbFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFNlbGZcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRFbmFibGVkXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwidW5pbnN0YWxsU2VsZlwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcIm5vdGlmaWNhdGlvbnNcIjoge1xuICAgICAgICAgIFwiY2xlYXJcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJjcmVhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRBbGxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRQZXJtaXNzaW9uTGV2ZWxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJ1cGRhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJwYWdlQWN0aW9uXCI6IHtcbiAgICAgICAgICBcImdldFBvcHVwXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0VGl0bGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJoaWRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0SWNvblwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldFBvcHVwXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0VGl0bGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzaG93XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwicGVybWlzc2lvbnNcIjoge1xuICAgICAgICAgIFwiY29udGFpbnNcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRBbGxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZXF1ZXN0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwicnVudGltZVwiOiB7XG4gICAgICAgICAgXCJnZXRCYWNrZ3JvdW5kUGFnZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFBsYXRmb3JtSW5mb1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcIm9wZW5PcHRpb25zUGFnZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlcXVlc3RVcGRhdGVDaGVja1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNlbmRNZXNzYWdlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDNcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2VuZE5hdGl2ZU1lc3NhZ2VcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRVbmluc3RhbGxVUkxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJzZXNzaW9uc1wiOiB7XG4gICAgICAgICAgXCJnZXREZXZpY2VzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0UmVjZW50bHlDbG9zZWRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZXN0b3JlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwic3RvcmFnZVwiOiB7XG4gICAgICAgICAgXCJsb2NhbFwiOiB7XG4gICAgICAgICAgICBcImNsZWFyXCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBcImdldEJ5dGVzSW5Vc2VcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwic2V0XCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSxcbiAgICAgICAgICBcIm1hbmFnZWRcIjoge1xuICAgICAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBcImdldEJ5dGVzSW5Vc2VcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic3luY1wiOiB7XG4gICAgICAgICAgICBcImNsZWFyXCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBcImdldEJ5dGVzSW5Vc2VcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwic2V0XCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcInRhYnNcIjoge1xuICAgICAgICAgIFwiY2FwdHVyZVZpc2libGVUYWJcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJjcmVhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJkZXRlY3RMYW5ndWFnZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImRpc2NhcmRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJkdXBsaWNhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJleGVjdXRlU2NyaXB0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0Q3VycmVudFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFpvb21cIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRab29tU2V0dGluZ3NcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnb0JhY2tcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnb0ZvcndhcmRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJoaWdobGlnaHRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJpbnNlcnRDU1NcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJtb3ZlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicXVlcnlcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZWxvYWRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVDU1NcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZW5kTWVzc2FnZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAzXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldFpvb21cIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRab29tU2V0dGluZ3NcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJ1cGRhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJ0b3BTaXRlc1wiOiB7XG4gICAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJ3ZWJOYXZpZ2F0aW9uXCI6IHtcbiAgICAgICAgICBcImdldEFsbEZyYW1lc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEZyYW1lXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwid2ViUmVxdWVzdFwiOiB7XG4gICAgICAgICAgXCJoYW5kbGVyQmVoYXZpb3JDaGFuZ2VkXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwid2luZG93c1wiOiB7XG4gICAgICAgICAgXCJjcmVhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRBbGxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRDdXJyZW50XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0TGFzdEZvY3VzZWRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJ1cGRhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfTtcblxuICAgICAgaWYgKE9iamVjdC5rZXlzKGFwaU1ldGFkYXRhKS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiYXBpLW1ldGFkYXRhLmpzb24gaGFzIG5vdCBiZWVuIGluY2x1ZGVkIGluIGJyb3dzZXItcG9seWZpbGxcIik7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIEEgV2Vha01hcCBzdWJjbGFzcyB3aGljaCBjcmVhdGVzIGFuZCBzdG9yZXMgYSB2YWx1ZSBmb3IgYW55IGtleSB3aGljaCBkb2VzXG4gICAgICAgKiBub3QgZXhpc3Qgd2hlbiBhY2Nlc3NlZCwgYnV0IGJlaGF2ZXMgZXhhY3RseSBhcyBhbiBvcmRpbmFyeSBXZWFrTWFwXG4gICAgICAgKiBvdGhlcndpc2UuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtmdW5jdGlvbn0gY3JlYXRlSXRlbVxuICAgICAgICogICAgICAgIEEgZnVuY3Rpb24gd2hpY2ggd2lsbCBiZSBjYWxsZWQgaW4gb3JkZXIgdG8gY3JlYXRlIHRoZSB2YWx1ZSBmb3IgYW55XG4gICAgICAgKiAgICAgICAga2V5IHdoaWNoIGRvZXMgbm90IGV4aXN0LCB0aGUgZmlyc3QgdGltZSBpdCBpcyBhY2Nlc3NlZC4gVGhlXG4gICAgICAgKiAgICAgICAgZnVuY3Rpb24gcmVjZWl2ZXMsIGFzIGl0cyBvbmx5IGFyZ3VtZW50LCB0aGUga2V5IGJlaW5nIGNyZWF0ZWQuXG4gICAgICAgKi9cblxuXG4gICAgICBjbGFzcyBEZWZhdWx0V2Vha01hcCBleHRlbmRzIFdlYWtNYXAge1xuICAgICAgICBjb25zdHJ1Y3RvcihjcmVhdGVJdGVtLCBpdGVtcyA9IHVuZGVmaW5lZCkge1xuICAgICAgICAgIHN1cGVyKGl0ZW1zKTtcbiAgICAgICAgICB0aGlzLmNyZWF0ZUl0ZW0gPSBjcmVhdGVJdGVtO1xuICAgICAgICB9XG5cbiAgICAgICAgZ2V0KGtleSkge1xuICAgICAgICAgIGlmICghdGhpcy5oYXMoa2V5KSkge1xuICAgICAgICAgICAgdGhpcy5zZXQoa2V5LCB0aGlzLmNyZWF0ZUl0ZW0oa2V5KSk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgcmV0dXJuIHN1cGVyLmdldChrZXkpO1xuICAgICAgICB9XG5cbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSBnaXZlbiBvYmplY3QgaXMgYW4gb2JqZWN0IHdpdGggYSBgdGhlbmAgbWV0aG9kLCBhbmQgY2FuXG4gICAgICAgKiB0aGVyZWZvcmUgYmUgYXNzdW1lZCB0byBiZWhhdmUgYXMgYSBQcm9taXNlLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7Kn0gdmFsdWUgVGhlIHZhbHVlIHRvIHRlc3QuXG4gICAgICAgKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB0aGUgdmFsdWUgaXMgdGhlbmFibGUuXG4gICAgICAgKi9cblxuXG4gICAgICBjb25zdCBpc1RoZW5hYmxlID0gdmFsdWUgPT4ge1xuICAgICAgICByZXR1cm4gdmFsdWUgJiYgdHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiB2YWx1ZS50aGVuID09PSBcImZ1bmN0aW9uXCI7XG4gICAgICB9O1xuICAgICAgLyoqXG4gICAgICAgKiBDcmVhdGVzIGFuZCByZXR1cm5zIGEgZnVuY3Rpb24gd2hpY2gsIHdoZW4gY2FsbGVkLCB3aWxsIHJlc29sdmUgb3IgcmVqZWN0XG4gICAgICAgKiB0aGUgZ2l2ZW4gcHJvbWlzZSBiYXNlZCBvbiBob3cgaXQgaXMgY2FsbGVkOlxuICAgICAgICpcbiAgICAgICAqIC0gSWYsIHdoZW4gY2FsbGVkLCBgY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yYCBjb250YWlucyBhIG5vbi1udWxsIG9iamVjdCxcbiAgICAgICAqICAgdGhlIHByb21pc2UgaXMgcmVqZWN0ZWQgd2l0aCB0aGF0IHZhbHVlLlxuICAgICAgICogLSBJZiB0aGUgZnVuY3Rpb24gaXMgY2FsbGVkIHdpdGggZXhhY3RseSBvbmUgYXJndW1lbnQsIHRoZSBwcm9taXNlIGlzXG4gICAgICAgKiAgIHJlc29sdmVkIHRvIHRoYXQgdmFsdWUuXG4gICAgICAgKiAtIE90aGVyd2lzZSwgdGhlIHByb21pc2UgaXMgcmVzb2x2ZWQgdG8gYW4gYXJyYXkgY29udGFpbmluZyBhbGwgb2YgdGhlXG4gICAgICAgKiAgIGZ1bmN0aW9uJ3MgYXJndW1lbnRzLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSBwcm9taXNlXG4gICAgICAgKiAgICAgICAgQW4gb2JqZWN0IGNvbnRhaW5pbmcgdGhlIHJlc29sdXRpb24gYW5kIHJlamVjdGlvbiBmdW5jdGlvbnMgb2YgYVxuICAgICAgICogICAgICAgIHByb21pc2UuXG4gICAgICAgKiBAcGFyYW0ge2Z1bmN0aW9ufSBwcm9taXNlLnJlc29sdmVcbiAgICAgICAqICAgICAgICBUaGUgcHJvbWlzZSdzIHJlc29sdXRpb24gZnVuY3Rpb24uXG4gICAgICAgKiBAcGFyYW0ge2Z1bmN0aW9ufSBwcm9taXNlLnJlamVjdFxuICAgICAgICogICAgICAgIFRoZSBwcm9taXNlJ3MgcmVqZWN0aW9uIGZ1bmN0aW9uLlxuICAgICAgICogQHBhcmFtIHtvYmplY3R9IG1ldGFkYXRhXG4gICAgICAgKiAgICAgICAgTWV0YWRhdGEgYWJvdXQgdGhlIHdyYXBwZWQgbWV0aG9kIHdoaWNoIGhhcyBjcmVhdGVkIHRoZSBjYWxsYmFjay5cbiAgICAgICAqIEBwYXJhbSB7Ym9vbGVhbn0gbWV0YWRhdGEuc2luZ2xlQ2FsbGJhY2tBcmdcbiAgICAgICAqICAgICAgICBXaGV0aGVyIG9yIG5vdCB0aGUgcHJvbWlzZSBpcyByZXNvbHZlZCB3aXRoIG9ubHkgdGhlIGZpcnN0XG4gICAgICAgKiAgICAgICAgYXJndW1lbnQgb2YgdGhlIGNhbGxiYWNrLCBhbHRlcm5hdGl2ZWx5IGFuIGFycmF5IG9mIGFsbCB0aGVcbiAgICAgICAqICAgICAgICBjYWxsYmFjayBhcmd1bWVudHMgaXMgcmVzb2x2ZWQuIEJ5IGRlZmF1bHQsIGlmIHRoZSBjYWxsYmFja1xuICAgICAgICogICAgICAgIGZ1bmN0aW9uIGlzIGludm9rZWQgd2l0aCBvbmx5IGEgc2luZ2xlIGFyZ3VtZW50LCB0aGF0IHdpbGwgYmVcbiAgICAgICAqICAgICAgICByZXNvbHZlZCB0byB0aGUgcHJvbWlzZSwgd2hpbGUgYWxsIGFyZ3VtZW50cyB3aWxsIGJlIHJlc29sdmVkIGFzXG4gICAgICAgKiAgICAgICAgYW4gYXJyYXkgaWYgbXVsdGlwbGUgYXJlIGdpdmVuLlxuICAgICAgICpcbiAgICAgICAqIEByZXR1cm5zIHtmdW5jdGlvbn1cbiAgICAgICAqICAgICAgICBUaGUgZ2VuZXJhdGVkIGNhbGxiYWNrIGZ1bmN0aW9uLlxuICAgICAgICovXG5cblxuICAgICAgY29uc3QgbWFrZUNhbGxiYWNrID0gKHByb21pc2UsIG1ldGFkYXRhKSA9PiB7XG4gICAgICAgIHJldHVybiAoLi4uY2FsbGJhY2tBcmdzKSA9PiB7XG4gICAgICAgICAgaWYgKGV4dGVuc2lvbkFQSXMucnVudGltZS5sYXN0RXJyb3IpIHtcbiAgICAgICAgICAgIHByb21pc2UucmVqZWN0KG5ldyBFcnJvcihleHRlbnNpb25BUElzLnJ1bnRpbWUubGFzdEVycm9yLm1lc3NhZ2UpKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKG1ldGFkYXRhLnNpbmdsZUNhbGxiYWNrQXJnIHx8IGNhbGxiYWNrQXJncy5sZW5ndGggPD0gMSAmJiBtZXRhZGF0YS5zaW5nbGVDYWxsYmFja0FyZyAhPT0gZmFsc2UpIHtcbiAgICAgICAgICAgIHByb21pc2UucmVzb2x2ZShjYWxsYmFja0FyZ3NbMF0pO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBwcm9taXNlLnJlc29sdmUoY2FsbGJhY2tBcmdzKTtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICB9O1xuXG4gICAgICBjb25zdCBwbHVyYWxpemVBcmd1bWVudHMgPSBudW1BcmdzID0+IG51bUFyZ3MgPT0gMSA/IFwiYXJndW1lbnRcIiA6IFwiYXJndW1lbnRzXCI7XG4gICAgICAvKipcbiAgICAgICAqIENyZWF0ZXMgYSB3cmFwcGVyIGZ1bmN0aW9uIGZvciBhIG1ldGhvZCB3aXRoIHRoZSBnaXZlbiBuYW1lIGFuZCBtZXRhZGF0YS5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge3N0cmluZ30gbmFtZVxuICAgICAgICogICAgICAgIFRoZSBuYW1lIG9mIHRoZSBtZXRob2Qgd2hpY2ggaXMgYmVpbmcgd3JhcHBlZC5cbiAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSBtZXRhZGF0YVxuICAgICAgICogICAgICAgIE1ldGFkYXRhIGFib3V0IHRoZSBtZXRob2QgYmVpbmcgd3JhcHBlZC5cbiAgICAgICAqIEBwYXJhbSB7aW50ZWdlcn0gbWV0YWRhdGEubWluQXJnc1xuICAgICAgICogICAgICAgIFRoZSBtaW5pbXVtIG51bWJlciBvZiBhcmd1bWVudHMgd2hpY2ggbXVzdCBiZSBwYXNzZWQgdG8gdGhlXG4gICAgICAgKiAgICAgICAgZnVuY3Rpb24uIElmIGNhbGxlZCB3aXRoIGZld2VyIHRoYW4gdGhpcyBudW1iZXIgb2YgYXJndW1lbnRzLCB0aGVcbiAgICAgICAqICAgICAgICB3cmFwcGVyIHdpbGwgcmFpc2UgYW4gZXhjZXB0aW9uLlxuICAgICAgICogQHBhcmFtIHtpbnRlZ2VyfSBtZXRhZGF0YS5tYXhBcmdzXG4gICAgICAgKiAgICAgICAgVGhlIG1heGltdW0gbnVtYmVyIG9mIGFyZ3VtZW50cyB3aGljaCBtYXkgYmUgcGFzc2VkIHRvIHRoZVxuICAgICAgICogICAgICAgIGZ1bmN0aW9uLiBJZiBjYWxsZWQgd2l0aCBtb3JlIHRoYW4gdGhpcyBudW1iZXIgb2YgYXJndW1lbnRzLCB0aGVcbiAgICAgICAqICAgICAgICB3cmFwcGVyIHdpbGwgcmFpc2UgYW4gZXhjZXB0aW9uLlxuICAgICAgICogQHBhcmFtIHtib29sZWFufSBtZXRhZGF0YS5zaW5nbGVDYWxsYmFja0FyZ1xuICAgICAgICogICAgICAgIFdoZXRoZXIgb3Igbm90IHRoZSBwcm9taXNlIGlzIHJlc29sdmVkIHdpdGggb25seSB0aGUgZmlyc3RcbiAgICAgICAqICAgICAgICBhcmd1bWVudCBvZiB0aGUgY2FsbGJhY2ssIGFsdGVybmF0aXZlbHkgYW4gYXJyYXkgb2YgYWxsIHRoZVxuICAgICAgICogICAgICAgIGNhbGxiYWNrIGFyZ3VtZW50cyBpcyByZXNvbHZlZC4gQnkgZGVmYXVsdCwgaWYgdGhlIGNhbGxiYWNrXG4gICAgICAgKiAgICAgICAgZnVuY3Rpb24gaXMgaW52b2tlZCB3aXRoIG9ubHkgYSBzaW5nbGUgYXJndW1lbnQsIHRoYXQgd2lsbCBiZVxuICAgICAgICogICAgICAgIHJlc29sdmVkIHRvIHRoZSBwcm9taXNlLCB3aGlsZSBhbGwgYXJndW1lbnRzIHdpbGwgYmUgcmVzb2x2ZWQgYXNcbiAgICAgICAqICAgICAgICBhbiBhcnJheSBpZiBtdWx0aXBsZSBhcmUgZ2l2ZW4uXG4gICAgICAgKlxuICAgICAgICogQHJldHVybnMge2Z1bmN0aW9uKG9iamVjdCwgLi4uKil9XG4gICAgICAgKiAgICAgICBUaGUgZ2VuZXJhdGVkIHdyYXBwZXIgZnVuY3Rpb24uXG4gICAgICAgKi9cblxuXG4gICAgICBjb25zdCB3cmFwQXN5bmNGdW5jdGlvbiA9IChuYW1lLCBtZXRhZGF0YSkgPT4ge1xuICAgICAgICByZXR1cm4gZnVuY3Rpb24gYXN5bmNGdW5jdGlvbldyYXBwZXIodGFyZ2V0LCAuLi5hcmdzKSB7XG4gICAgICAgICAgaWYgKGFyZ3MubGVuZ3RoIDwgbWV0YWRhdGEubWluQXJncykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBFeHBlY3RlZCBhdCBsZWFzdCAke21ldGFkYXRhLm1pbkFyZ3N9ICR7cGx1cmFsaXplQXJndW1lbnRzKG1ldGFkYXRhLm1pbkFyZ3MpfSBmb3IgJHtuYW1lfSgpLCBnb3QgJHthcmdzLmxlbmd0aH1gKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAoYXJncy5sZW5ndGggPiBtZXRhZGF0YS5tYXhBcmdzKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEV4cGVjdGVkIGF0IG1vc3QgJHttZXRhZGF0YS5tYXhBcmdzfSAke3BsdXJhbGl6ZUFyZ3VtZW50cyhtZXRhZGF0YS5tYXhBcmdzKX0gZm9yICR7bmFtZX0oKSwgZ290ICR7YXJncy5sZW5ndGh9YCk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICAgIGlmIChtZXRhZGF0YS5mYWxsYmFja1RvTm9DYWxsYmFjaykge1xuICAgICAgICAgICAgICAvLyBUaGlzIEFQSSBtZXRob2QgaGFzIGN1cnJlbnRseSBubyBjYWxsYmFjayBvbiBDaHJvbWUsIGJ1dCBpdCByZXR1cm4gYSBwcm9taXNlIG9uIEZpcmVmb3gsXG4gICAgICAgICAgICAgIC8vIGFuZCBzbyB0aGUgcG9seWZpbGwgd2lsbCB0cnkgdG8gY2FsbCBpdCB3aXRoIGEgY2FsbGJhY2sgZmlyc3QsIGFuZCBpdCB3aWxsIGZhbGxiYWNrXG4gICAgICAgICAgICAgIC8vIHRvIG5vdCBwYXNzaW5nIHRoZSBjYWxsYmFjayBpZiB0aGUgZmlyc3QgY2FsbCBmYWlscy5cbiAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICB0YXJnZXRbbmFtZV0oLi4uYXJncywgbWFrZUNhbGxiYWNrKHtcbiAgICAgICAgICAgICAgICAgIHJlc29sdmUsXG4gICAgICAgICAgICAgICAgICByZWplY3RcbiAgICAgICAgICAgICAgICB9LCBtZXRhZGF0YSkpO1xuICAgICAgICAgICAgICB9IGNhdGNoIChjYkVycm9yKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS53YXJuKGAke25hbWV9IEFQSSBtZXRob2QgZG9lc24ndCBzZWVtIHRvIHN1cHBvcnQgdGhlIGNhbGxiYWNrIHBhcmFtZXRlciwgYCArIFwiZmFsbGluZyBiYWNrIHRvIGNhbGwgaXQgd2l0aG91dCBhIGNhbGxiYWNrOiBcIiwgY2JFcnJvcik7XG4gICAgICAgICAgICAgICAgdGFyZ2V0W25hbWVdKC4uLmFyZ3MpOyAvLyBVcGRhdGUgdGhlIEFQSSBtZXRob2QgbWV0YWRhdGEsIHNvIHRoYXQgdGhlIG5leHQgQVBJIGNhbGxzIHdpbGwgbm90IHRyeSB0b1xuICAgICAgICAgICAgICAgIC8vIHVzZSB0aGUgdW5zdXBwb3J0ZWQgY2FsbGJhY2sgYW55bW9yZS5cblxuICAgICAgICAgICAgICAgIG1ldGFkYXRhLmZhbGxiYWNrVG9Ob0NhbGxiYWNrID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgbWV0YWRhdGEubm9DYWxsYmFjayA9IHRydWU7XG4gICAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2UgaWYgKG1ldGFkYXRhLm5vQ2FsbGJhY2spIHtcbiAgICAgICAgICAgICAgdGFyZ2V0W25hbWVdKC4uLmFyZ3MpO1xuICAgICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICB0YXJnZXRbbmFtZV0oLi4uYXJncywgbWFrZUNhbGxiYWNrKHtcbiAgICAgICAgICAgICAgICByZXNvbHZlLFxuICAgICAgICAgICAgICAgIHJlamVjdFxuICAgICAgICAgICAgICB9LCBtZXRhZGF0YSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgICB9O1xuICAgICAgfTtcbiAgICAgIC8qKlxuICAgICAgICogV3JhcHMgYW4gZXhpc3RpbmcgbWV0aG9kIG9mIHRoZSB0YXJnZXQgb2JqZWN0LCBzbyB0aGF0IGNhbGxzIHRvIGl0IGFyZVxuICAgICAgICogaW50ZXJjZXB0ZWQgYnkgdGhlIGdpdmVuIHdyYXBwZXIgZnVuY3Rpb24uIFRoZSB3cmFwcGVyIGZ1bmN0aW9uIHJlY2VpdmVzLFxuICAgICAgICogYXMgaXRzIGZpcnN0IGFyZ3VtZW50LCB0aGUgb3JpZ2luYWwgYHRhcmdldGAgb2JqZWN0LCBmb2xsb3dlZCBieSBlYWNoIG9mXG4gICAgICAgKiB0aGUgYXJndW1lbnRzIHBhc3NlZCB0byB0aGUgb3JpZ2luYWwgbWV0aG9kLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSB0YXJnZXRcbiAgICAgICAqICAgICAgICBUaGUgb3JpZ2luYWwgdGFyZ2V0IG9iamVjdCB0aGF0IHRoZSB3cmFwcGVkIG1ldGhvZCBiZWxvbmdzIHRvLlxuICAgICAgICogQHBhcmFtIHtmdW5jdGlvbn0gbWV0aG9kXG4gICAgICAgKiAgICAgICAgVGhlIG1ldGhvZCBiZWluZyB3cmFwcGVkLiBUaGlzIGlzIHVzZWQgYXMgdGhlIHRhcmdldCBvZiB0aGUgUHJveHlcbiAgICAgICAqICAgICAgICBvYmplY3Qgd2hpY2ggaXMgY3JlYXRlZCB0byB3cmFwIHRoZSBtZXRob2QuXG4gICAgICAgKiBAcGFyYW0ge2Z1bmN0aW9ufSB3cmFwcGVyXG4gICAgICAgKiAgICAgICAgVGhlIHdyYXBwZXIgZnVuY3Rpb24gd2hpY2ggaXMgY2FsbGVkIGluIHBsYWNlIG9mIGEgZGlyZWN0IGludm9jYXRpb25cbiAgICAgICAqICAgICAgICBvZiB0aGUgd3JhcHBlZCBtZXRob2QuXG4gICAgICAgKlxuICAgICAgICogQHJldHVybnMge1Byb3h5PGZ1bmN0aW9uPn1cbiAgICAgICAqICAgICAgICBBIFByb3h5IG9iamVjdCBmb3IgdGhlIGdpdmVuIG1ldGhvZCwgd2hpY2ggaW52b2tlcyB0aGUgZ2l2ZW4gd3JhcHBlclxuICAgICAgICogICAgICAgIG1ldGhvZCBpbiBpdHMgcGxhY2UuXG4gICAgICAgKi9cblxuXG4gICAgICBjb25zdCB3cmFwTWV0aG9kID0gKHRhcmdldCwgbWV0aG9kLCB3cmFwcGVyKSA9PiB7XG4gICAgICAgIHJldHVybiBuZXcgUHJveHkobWV0aG9kLCB7XG4gICAgICAgICAgYXBwbHkodGFyZ2V0TWV0aG9kLCB0aGlzT2JqLCBhcmdzKSB7XG4gICAgICAgICAgICByZXR1cm4gd3JhcHBlci5jYWxsKHRoaXNPYmosIHRhcmdldCwgLi4uYXJncyk7XG4gICAgICAgICAgfVxuXG4gICAgICAgIH0pO1xuICAgICAgfTtcblxuICAgICAgbGV0IGhhc093blByb3BlcnR5ID0gRnVuY3Rpb24uY2FsbC5iaW5kKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkpO1xuICAgICAgLyoqXG4gICAgICAgKiBXcmFwcyBhbiBvYmplY3QgaW4gYSBQcm94eSB3aGljaCBpbnRlcmNlcHRzIGFuZCB3cmFwcyBjZXJ0YWluIG1ldGhvZHNcbiAgICAgICAqIGJhc2VkIG9uIHRoZSBnaXZlbiBgd3JhcHBlcnNgIGFuZCBgbWV0YWRhdGFgIG9iamVjdHMuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtvYmplY3R9IHRhcmdldFxuICAgICAgICogICAgICAgIFRoZSB0YXJnZXQgb2JqZWN0IHRvIHdyYXAuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtvYmplY3R9IFt3cmFwcGVycyA9IHt9XVxuICAgICAgICogICAgICAgIEFuIG9iamVjdCB0cmVlIGNvbnRhaW5pbmcgd3JhcHBlciBmdW5jdGlvbnMgZm9yIHNwZWNpYWwgY2FzZXMuIEFueVxuICAgICAgICogICAgICAgIGZ1bmN0aW9uIHByZXNlbnQgaW4gdGhpcyBvYmplY3QgdHJlZSBpcyBjYWxsZWQgaW4gcGxhY2Ugb2YgdGhlXG4gICAgICAgKiAgICAgICAgbWV0aG9kIGluIHRoZSBzYW1lIGxvY2F0aW9uIGluIHRoZSBgdGFyZ2V0YCBvYmplY3QgdHJlZS4gVGhlc2VcbiAgICAgICAqICAgICAgICB3cmFwcGVyIG1ldGhvZHMgYXJlIGludm9rZWQgYXMgZGVzY3JpYmVkIGluIHtAc2VlIHdyYXBNZXRob2R9LlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSBbbWV0YWRhdGEgPSB7fV1cbiAgICAgICAqICAgICAgICBBbiBvYmplY3QgdHJlZSBjb250YWluaW5nIG1ldGFkYXRhIHVzZWQgdG8gYXV0b21hdGljYWxseSBnZW5lcmF0ZVxuICAgICAgICogICAgICAgIFByb21pc2UtYmFzZWQgd3JhcHBlciBmdW5jdGlvbnMgZm9yIGFzeW5jaHJvbm91cy4gQW55IGZ1bmN0aW9uIGluXG4gICAgICAgKiAgICAgICAgdGhlIGB0YXJnZXRgIG9iamVjdCB0cmVlIHdoaWNoIGhhcyBhIGNvcnJlc3BvbmRpbmcgbWV0YWRhdGEgb2JqZWN0XG4gICAgICAgKiAgICAgICAgaW4gdGhlIHNhbWUgbG9jYXRpb24gaW4gdGhlIGBtZXRhZGF0YWAgdHJlZSBpcyByZXBsYWNlZCB3aXRoIGFuXG4gICAgICAgKiAgICAgICAgYXV0b21hdGljYWxseS1nZW5lcmF0ZWQgd3JhcHBlciBmdW5jdGlvbiwgYXMgZGVzY3JpYmVkIGluXG4gICAgICAgKiAgICAgICAge0BzZWUgd3JhcEFzeW5jRnVuY3Rpb259XG4gICAgICAgKlxuICAgICAgICogQHJldHVybnMge1Byb3h5PG9iamVjdD59XG4gICAgICAgKi9cblxuICAgICAgY29uc3Qgd3JhcE9iamVjdCA9ICh0YXJnZXQsIHdyYXBwZXJzID0ge30sIG1ldGFkYXRhID0ge30pID0+IHtcbiAgICAgICAgbGV0IGNhY2hlID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAgICAgbGV0IGhhbmRsZXJzID0ge1xuICAgICAgICAgIGhhcyhwcm94eVRhcmdldCwgcHJvcCkge1xuICAgICAgICAgICAgcmV0dXJuIHByb3AgaW4gdGFyZ2V0IHx8IHByb3AgaW4gY2FjaGU7XG4gICAgICAgICAgfSxcblxuICAgICAgICAgIGdldChwcm94eVRhcmdldCwgcHJvcCwgcmVjZWl2ZXIpIHtcbiAgICAgICAgICAgIGlmIChwcm9wIGluIGNhY2hlKSB7XG4gICAgICAgICAgICAgIHJldHVybiBjYWNoZVtwcm9wXTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKCEocHJvcCBpbiB0YXJnZXQpKSB7XG4gICAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGxldCB2YWx1ZSA9IHRhcmdldFtwcm9wXTtcblxuICAgICAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgICAgICAgIC8vIFRoaXMgaXMgYSBtZXRob2Qgb24gdGhlIHVuZGVybHlpbmcgb2JqZWN0LiBDaGVjayBpZiB3ZSBuZWVkIHRvIGRvXG4gICAgICAgICAgICAgIC8vIGFueSB3cmFwcGluZy5cbiAgICAgICAgICAgICAgaWYgKHR5cGVvZiB3cmFwcGVyc1twcm9wXSA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgICAgICAgICAgLy8gV2UgaGF2ZSBhIHNwZWNpYWwtY2FzZSB3cmFwcGVyIGZvciB0aGlzIG1ldGhvZC5cbiAgICAgICAgICAgICAgICB2YWx1ZSA9IHdyYXBNZXRob2QodGFyZ2V0LCB0YXJnZXRbcHJvcF0sIHdyYXBwZXJzW3Byb3BdKTtcbiAgICAgICAgICAgICAgfSBlbHNlIGlmIChoYXNPd25Qcm9wZXJ0eShtZXRhZGF0YSwgcHJvcCkpIHtcbiAgICAgICAgICAgICAgICAvLyBUaGlzIGlzIGFuIGFzeW5jIG1ldGhvZCB0aGF0IHdlIGhhdmUgbWV0YWRhdGEgZm9yLiBDcmVhdGUgYVxuICAgICAgICAgICAgICAgIC8vIFByb21pc2Ugd3JhcHBlciBmb3IgaXQuXG4gICAgICAgICAgICAgICAgbGV0IHdyYXBwZXIgPSB3cmFwQXN5bmNGdW5jdGlvbihwcm9wLCBtZXRhZGF0YVtwcm9wXSk7XG4gICAgICAgICAgICAgICAgdmFsdWUgPSB3cmFwTWV0aG9kKHRhcmdldCwgdGFyZ2V0W3Byb3BdLCB3cmFwcGVyKTtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyBUaGlzIGlzIGEgbWV0aG9kIHRoYXQgd2UgZG9uJ3Qga25vdyBvciBjYXJlIGFib3V0LiBSZXR1cm4gdGhlXG4gICAgICAgICAgICAgICAgLy8gb3JpZ2luYWwgbWV0aG9kLCBib3VuZCB0byB0aGUgdW5kZXJseWluZyBvYmplY3QuXG4gICAgICAgICAgICAgICAgdmFsdWUgPSB2YWx1ZS5iaW5kKHRhcmdldCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIHZhbHVlICE9PSBudWxsICYmIChoYXNPd25Qcm9wZXJ0eSh3cmFwcGVycywgcHJvcCkgfHwgaGFzT3duUHJvcGVydHkobWV0YWRhdGEsIHByb3ApKSkge1xuICAgICAgICAgICAgICAvLyBUaGlzIGlzIGFuIG9iamVjdCB0aGF0IHdlIG5lZWQgdG8gZG8gc29tZSB3cmFwcGluZyBmb3IgdGhlIGNoaWxkcmVuXG4gICAgICAgICAgICAgIC8vIG9mLiBDcmVhdGUgYSBzdWItb2JqZWN0IHdyYXBwZXIgZm9yIGl0IHdpdGggdGhlIGFwcHJvcHJpYXRlIGNoaWxkXG4gICAgICAgICAgICAgIC8vIG1ldGFkYXRhLlxuICAgICAgICAgICAgICB2YWx1ZSA9IHdyYXBPYmplY3QodmFsdWUsIHdyYXBwZXJzW3Byb3BdLCBtZXRhZGF0YVtwcm9wXSk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKGhhc093blByb3BlcnR5KG1ldGFkYXRhLCBcIipcIikpIHtcbiAgICAgICAgICAgICAgLy8gV3JhcCBhbGwgcHJvcGVydGllcyBpbiAqIG5hbWVzcGFjZS5cbiAgICAgICAgICAgICAgdmFsdWUgPSB3cmFwT2JqZWN0KHZhbHVlLCB3cmFwcGVyc1twcm9wXSwgbWV0YWRhdGFbXCIqXCJdKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIC8vIFdlIGRvbid0IG5lZWQgdG8gZG8gYW55IHdyYXBwaW5nIGZvciB0aGlzIHByb3BlcnR5LFxuICAgICAgICAgICAgICAvLyBzbyBqdXN0IGZvcndhcmQgYWxsIGFjY2VzcyB0byB0aGUgdW5kZXJseWluZyBvYmplY3QuXG4gICAgICAgICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShjYWNoZSwgcHJvcCwge1xuICAgICAgICAgICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuXG4gICAgICAgICAgICAgICAgZ2V0KCkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIHRhcmdldFtwcm9wXTtcbiAgICAgICAgICAgICAgICB9LFxuXG4gICAgICAgICAgICAgICAgc2V0KHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICB0YXJnZXRbcHJvcF0gPSB2YWx1ZTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY2FjaGVbcHJvcF0gPSB2YWx1ZTtcbiAgICAgICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgICAgICB9LFxuXG4gICAgICAgICAgc2V0KHByb3h5VGFyZ2V0LCBwcm9wLCB2YWx1ZSwgcmVjZWl2ZXIpIHtcbiAgICAgICAgICAgIGlmIChwcm9wIGluIGNhY2hlKSB7XG4gICAgICAgICAgICAgIGNhY2hlW3Byb3BdID0gdmFsdWU7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICB0YXJnZXRbcHJvcF0gPSB2YWx1ZTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgfSxcblxuICAgICAgICAgIGRlZmluZVByb3BlcnR5KHByb3h5VGFyZ2V0LCBwcm9wLCBkZXNjKSB7XG4gICAgICAgICAgICByZXR1cm4gUmVmbGVjdC5kZWZpbmVQcm9wZXJ0eShjYWNoZSwgcHJvcCwgZGVzYyk7XG4gICAgICAgICAgfSxcblxuICAgICAgICAgIGRlbGV0ZVByb3BlcnR5KHByb3h5VGFyZ2V0LCBwcm9wKSB7XG4gICAgICAgICAgICByZXR1cm4gUmVmbGVjdC5kZWxldGVQcm9wZXJ0eShjYWNoZSwgcHJvcCk7XG4gICAgICAgICAgfVxuXG4gICAgICAgIH07IC8vIFBlciBjb250cmFjdCBvZiB0aGUgUHJveHkgQVBJLCB0aGUgXCJnZXRcIiBwcm94eSBoYW5kbGVyIG11c3QgcmV0dXJuIHRoZVxuICAgICAgICAvLyBvcmlnaW5hbCB2YWx1ZSBvZiB0aGUgdGFyZ2V0IGlmIHRoYXQgdmFsdWUgaXMgZGVjbGFyZWQgcmVhZC1vbmx5IGFuZFxuICAgICAgICAvLyBub24tY29uZmlndXJhYmxlLiBGb3IgdGhpcyByZWFzb24sIHdlIGNyZWF0ZSBhbiBvYmplY3Qgd2l0aCB0aGVcbiAgICAgICAgLy8gcHJvdG90eXBlIHNldCB0byBgdGFyZ2V0YCBpbnN0ZWFkIG9mIHVzaW5nIGB0YXJnZXRgIGRpcmVjdGx5LlxuICAgICAgICAvLyBPdGhlcndpc2Ugd2UgY2Fubm90IHJldHVybiBhIGN1c3RvbSBvYmplY3QgZm9yIEFQSXMgdGhhdFxuICAgICAgICAvLyBhcmUgZGVjbGFyZWQgcmVhZC1vbmx5IGFuZCBub24tY29uZmlndXJhYmxlLCBzdWNoIGFzIGBjaHJvbWUuZGV2dG9vbHNgLlxuICAgICAgICAvL1xuICAgICAgICAvLyBUaGUgcHJveHkgaGFuZGxlcnMgdGhlbXNlbHZlcyB3aWxsIHN0aWxsIHVzZSB0aGUgb3JpZ2luYWwgYHRhcmdldGBcbiAgICAgICAgLy8gaW5zdGVhZCBvZiB0aGUgYHByb3h5VGFyZ2V0YCwgc28gdGhhdCB0aGUgbWV0aG9kcyBhbmQgcHJvcGVydGllcyBhcmVcbiAgICAgICAgLy8gZGVyZWZlcmVuY2VkIHZpYSB0aGUgb3JpZ2luYWwgdGFyZ2V0cy5cblxuICAgICAgICBsZXQgcHJveHlUYXJnZXQgPSBPYmplY3QuY3JlYXRlKHRhcmdldCk7XG4gICAgICAgIHJldHVybiBuZXcgUHJveHkocHJveHlUYXJnZXQsIGhhbmRsZXJzKTtcbiAgICAgIH07XG4gICAgICAvKipcbiAgICAgICAqIENyZWF0ZXMgYSBzZXQgb2Ygd3JhcHBlciBmdW5jdGlvbnMgZm9yIGFuIGV2ZW50IG9iamVjdCwgd2hpY2ggaGFuZGxlc1xuICAgICAgICogd3JhcHBpbmcgb2YgbGlzdGVuZXIgZnVuY3Rpb25zIHRoYXQgdGhvc2UgbWVzc2FnZXMgYXJlIHBhc3NlZC5cbiAgICAgICAqXG4gICAgICAgKiBBIHNpbmdsZSB3cmFwcGVyIGlzIGNyZWF0ZWQgZm9yIGVhY2ggbGlzdGVuZXIgZnVuY3Rpb24sIGFuZCBzdG9yZWQgaW4gYVxuICAgICAgICogbWFwLiBTdWJzZXF1ZW50IGNhbGxzIHRvIGBhZGRMaXN0ZW5lcmAsIGBoYXNMaXN0ZW5lcmAsIG9yIGByZW1vdmVMaXN0ZW5lcmBcbiAgICAgICAqIHJldHJpZXZlIHRoZSBvcmlnaW5hbCB3cmFwcGVyLCBzbyB0aGF0ICBhdHRlbXB0cyB0byByZW1vdmUgYVxuICAgICAgICogcHJldmlvdXNseS1hZGRlZCBsaXN0ZW5lciB3b3JrIGFzIGV4cGVjdGVkLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7RGVmYXVsdFdlYWtNYXA8ZnVuY3Rpb24sIGZ1bmN0aW9uPn0gd3JhcHBlck1hcFxuICAgICAgICogICAgICAgIEEgRGVmYXVsdFdlYWtNYXAgb2JqZWN0IHdoaWNoIHdpbGwgY3JlYXRlIHRoZSBhcHByb3ByaWF0ZSB3cmFwcGVyXG4gICAgICAgKiAgICAgICAgZm9yIGEgZ2l2ZW4gbGlzdGVuZXIgZnVuY3Rpb24gd2hlbiBvbmUgZG9lcyBub3QgZXhpc3QsIGFuZCByZXRyaWV2ZVxuICAgICAgICogICAgICAgIGFuIGV4aXN0aW5nIG9uZSB3aGVuIGl0IGRvZXMuXG4gICAgICAgKlxuICAgICAgICogQHJldHVybnMge29iamVjdH1cbiAgICAgICAqL1xuXG5cbiAgICAgIGNvbnN0IHdyYXBFdmVudCA9IHdyYXBwZXJNYXAgPT4gKHtcbiAgICAgICAgYWRkTGlzdGVuZXIodGFyZ2V0LCBsaXN0ZW5lciwgLi4uYXJncykge1xuICAgICAgICAgIHRhcmdldC5hZGRMaXN0ZW5lcih3cmFwcGVyTWFwLmdldChsaXN0ZW5lciksIC4uLmFyZ3MpO1xuICAgICAgICB9LFxuXG4gICAgICAgIGhhc0xpc3RlbmVyKHRhcmdldCwgbGlzdGVuZXIpIHtcbiAgICAgICAgICByZXR1cm4gdGFyZ2V0Lmhhc0xpc3RlbmVyKHdyYXBwZXJNYXAuZ2V0KGxpc3RlbmVyKSk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgcmVtb3ZlTGlzdGVuZXIodGFyZ2V0LCBsaXN0ZW5lcikge1xuICAgICAgICAgIHRhcmdldC5yZW1vdmVMaXN0ZW5lcih3cmFwcGVyTWFwLmdldChsaXN0ZW5lcikpO1xuICAgICAgICB9XG5cbiAgICAgIH0pO1xuXG4gICAgICBjb25zdCBvblJlcXVlc3RGaW5pc2hlZFdyYXBwZXJzID0gbmV3IERlZmF1bHRXZWFrTWFwKGxpc3RlbmVyID0+IHtcbiAgICAgICAgaWYgKHR5cGVvZiBsaXN0ZW5lciAhPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgICAgcmV0dXJuIGxpc3RlbmVyO1xuICAgICAgICB9XG4gICAgICAgIC8qKlxuICAgICAgICAgKiBXcmFwcyBhbiBvblJlcXVlc3RGaW5pc2hlZCBsaXN0ZW5lciBmdW5jdGlvbiBzbyB0aGF0IGl0IHdpbGwgcmV0dXJuIGFcbiAgICAgICAgICogYGdldENvbnRlbnQoKWAgcHJvcGVydHkgd2hpY2ggcmV0dXJucyBhIGBQcm9taXNlYCByYXRoZXIgdGhhbiB1c2luZyBhXG4gICAgICAgICAqIGNhbGxiYWNrIEFQSS5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtvYmplY3R9IHJlcVxuICAgICAgICAgKiAgICAgICAgVGhlIEhBUiBlbnRyeSBvYmplY3QgcmVwcmVzZW50aW5nIHRoZSBuZXR3b3JrIHJlcXVlc3QuXG4gICAgICAgICAqL1xuXG5cbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIG9uUmVxdWVzdEZpbmlzaGVkKHJlcSkge1xuICAgICAgICAgIGNvbnN0IHdyYXBwZWRSZXEgPSB3cmFwT2JqZWN0KHJlcSwge31cbiAgICAgICAgICAvKiB3cmFwcGVycyAqL1xuICAgICAgICAgICwge1xuICAgICAgICAgICAgZ2V0Q29udGVudDoge1xuICAgICAgICAgICAgICBtaW5BcmdzOiAwLFxuICAgICAgICAgICAgICBtYXhBcmdzOiAwXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgbGlzdGVuZXIod3JhcHBlZFJlcSk7XG4gICAgICAgIH07XG4gICAgICB9KTtcbiAgICAgIGNvbnN0IG9uTWVzc2FnZVdyYXBwZXJzID0gbmV3IERlZmF1bHRXZWFrTWFwKGxpc3RlbmVyID0+IHtcbiAgICAgICAgaWYgKHR5cGVvZiBsaXN0ZW5lciAhPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgICAgcmV0dXJuIGxpc3RlbmVyO1xuICAgICAgICB9XG4gICAgICAgIC8qKlxuICAgICAgICAgKiBXcmFwcyBhIG1lc3NhZ2UgbGlzdGVuZXIgZnVuY3Rpb24gc28gdGhhdCBpdCBtYXkgc2VuZCByZXNwb25zZXMgYmFzZWQgb25cbiAgICAgICAgICogaXRzIHJldHVybiB2YWx1ZSwgcmF0aGVyIHRoYW4gYnkgcmV0dXJuaW5nIGEgc2VudGluZWwgdmFsdWUgYW5kIGNhbGxpbmcgYVxuICAgICAgICAgKiBjYWxsYmFjay4gSWYgdGhlIGxpc3RlbmVyIGZ1bmN0aW9uIHJldHVybnMgYSBQcm9taXNlLCB0aGUgcmVzcG9uc2UgaXNcbiAgICAgICAgICogc2VudCB3aGVuIHRoZSBwcm9taXNlIGVpdGhlciByZXNvbHZlcyBvciByZWplY3RzLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0geyp9IG1lc3NhZ2VcbiAgICAgICAgICogICAgICAgIFRoZSBtZXNzYWdlIHNlbnQgYnkgdGhlIG90aGVyIGVuZCBvZiB0aGUgY2hhbm5lbC5cbiAgICAgICAgICogQHBhcmFtIHtvYmplY3R9IHNlbmRlclxuICAgICAgICAgKiAgICAgICAgRGV0YWlscyBhYm91dCB0aGUgc2VuZGVyIG9mIHRoZSBtZXNzYWdlLlxuICAgICAgICAgKiBAcGFyYW0ge2Z1bmN0aW9uKCopfSBzZW5kUmVzcG9uc2VcbiAgICAgICAgICogICAgICAgIEEgY2FsbGJhY2sgd2hpY2gsIHdoZW4gY2FsbGVkIHdpdGggYW4gYXJiaXRyYXJ5IGFyZ3VtZW50LCBzZW5kc1xuICAgICAgICAgKiAgICAgICAgdGhhdCB2YWx1ZSBhcyBhIHJlc3BvbnNlLlxuICAgICAgICAgKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAgICAgICAgICogICAgICAgIFRydWUgaWYgdGhlIHdyYXBwZWQgbGlzdGVuZXIgcmV0dXJuZWQgYSBQcm9taXNlLCB3aGljaCB3aWxsIGxhdGVyXG4gICAgICAgICAqICAgICAgICB5aWVsZCBhIHJlc3BvbnNlLiBGYWxzZSBvdGhlcndpc2UuXG4gICAgICAgICAqL1xuXG5cbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIG9uTWVzc2FnZShtZXNzYWdlLCBzZW5kZXIsIHNlbmRSZXNwb25zZSkge1xuICAgICAgICAgIGxldCBkaWRDYWxsU2VuZFJlc3BvbnNlID0gZmFsc2U7XG4gICAgICAgICAgbGV0IHdyYXBwZWRTZW5kUmVzcG9uc2U7XG4gICAgICAgICAgbGV0IHNlbmRSZXNwb25zZVByb21pc2UgPSBuZXcgUHJvbWlzZShyZXNvbHZlID0+IHtcbiAgICAgICAgICAgIHdyYXBwZWRTZW5kUmVzcG9uc2UgPSBmdW5jdGlvbiAocmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgZGlkQ2FsbFNlbmRSZXNwb25zZSA9IHRydWU7XG4gICAgICAgICAgICAgIHJlc29sdmUocmVzcG9uc2UpO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBsZXQgcmVzdWx0O1xuXG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHJlc3VsdCA9IGxpc3RlbmVyKG1lc3NhZ2UsIHNlbmRlciwgd3JhcHBlZFNlbmRSZXNwb25zZSk7XG4gICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICByZXN1bHQgPSBQcm9taXNlLnJlamVjdChlcnIpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGNvbnN0IGlzUmVzdWx0VGhlbmFibGUgPSByZXN1bHQgIT09IHRydWUgJiYgaXNUaGVuYWJsZShyZXN1bHQpOyAvLyBJZiB0aGUgbGlzdGVuZXIgZGlkbid0IHJldHVybmVkIHRydWUgb3IgYSBQcm9taXNlLCBvciBjYWxsZWRcbiAgICAgICAgICAvLyB3cmFwcGVkU2VuZFJlc3BvbnNlIHN5bmNocm9ub3VzbHksIHdlIGNhbiBleGl0IGVhcmxpZXJcbiAgICAgICAgICAvLyBiZWNhdXNlIHRoZXJlIHdpbGwgYmUgbm8gcmVzcG9uc2Ugc2VudCBmcm9tIHRoaXMgbGlzdGVuZXIuXG5cbiAgICAgICAgICBpZiAocmVzdWx0ICE9PSB0cnVlICYmICFpc1Jlc3VsdFRoZW5hYmxlICYmICFkaWRDYWxsU2VuZFJlc3BvbnNlKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgfSAvLyBBIHNtYWxsIGhlbHBlciB0byBzZW5kIHRoZSBtZXNzYWdlIGlmIHRoZSBwcm9taXNlIHJlc29sdmVzXG4gICAgICAgICAgLy8gYW5kIGFuIGVycm9yIGlmIHRoZSBwcm9taXNlIHJlamVjdHMgKGEgd3JhcHBlZCBzZW5kTWVzc2FnZSBoYXNcbiAgICAgICAgICAvLyB0byB0cmFuc2xhdGUgdGhlIG1lc3NhZ2UgaW50byBhIHJlc29sdmVkIHByb21pc2Ugb3IgYSByZWplY3RlZFxuICAgICAgICAgIC8vIHByb21pc2UpLlxuXG5cbiAgICAgICAgICBjb25zdCBzZW5kUHJvbWlzZWRSZXN1bHQgPSBwcm9taXNlID0+IHtcbiAgICAgICAgICAgIHByb21pc2UudGhlbihtc2cgPT4ge1xuICAgICAgICAgICAgICAvLyBzZW5kIHRoZSBtZXNzYWdlIHZhbHVlLlxuICAgICAgICAgICAgICBzZW5kUmVzcG9uc2UobXNnKTtcbiAgICAgICAgICAgIH0sIGVycm9yID0+IHtcbiAgICAgICAgICAgICAgLy8gU2VuZCBhIEpTT04gcmVwcmVzZW50YXRpb24gb2YgdGhlIGVycm9yIGlmIHRoZSByZWplY3RlZCB2YWx1ZVxuICAgICAgICAgICAgICAvLyBpcyBhbiBpbnN0YW5jZSBvZiBlcnJvciwgb3IgdGhlIG9iamVjdCBpdHNlbGYgb3RoZXJ3aXNlLlxuICAgICAgICAgICAgICBsZXQgbWVzc2FnZTtcblxuICAgICAgICAgICAgICBpZiAoZXJyb3IgJiYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IgfHwgdHlwZW9mIGVycm9yLm1lc3NhZ2UgPT09IFwic3RyaW5nXCIpKSB7XG4gICAgICAgICAgICAgICAgbWVzc2FnZSA9IGVycm9yLm1lc3NhZ2U7XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgbWVzc2FnZSA9IFwiQW4gdW5leHBlY3RlZCBlcnJvciBvY2N1cnJlZFwiO1xuICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgc2VuZFJlc3BvbnNlKHtcbiAgICAgICAgICAgICAgICBfX21veldlYkV4dGVuc2lvblBvbHlmaWxsUmVqZWN0X186IHRydWUsXG4gICAgICAgICAgICAgICAgbWVzc2FnZVxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pLmNhdGNoKGVyciA9PiB7XG4gICAgICAgICAgICAgIC8vIFByaW50IGFuIGVycm9yIG9uIHRoZSBjb25zb2xlIGlmIHVuYWJsZSB0byBzZW5kIHRoZSByZXNwb25zZS5cbiAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBzZW5kIG9uTWVzc2FnZSByZWplY3RlZCByZXBseVwiLCBlcnIpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfTsgLy8gSWYgdGhlIGxpc3RlbmVyIHJldHVybmVkIGEgUHJvbWlzZSwgc2VuZCB0aGUgcmVzb2x2ZWQgdmFsdWUgYXMgYVxuICAgICAgICAgIC8vIHJlc3VsdCwgb3RoZXJ3aXNlIHdhaXQgdGhlIHByb21pc2UgcmVsYXRlZCB0byB0aGUgd3JhcHBlZFNlbmRSZXNwb25zZVxuICAgICAgICAgIC8vIGNhbGxiYWNrIHRvIHJlc29sdmUgYW5kIHNlbmQgaXQgYXMgYSByZXNwb25zZS5cblxuXG4gICAgICAgICAgaWYgKGlzUmVzdWx0VGhlbmFibGUpIHtcbiAgICAgICAgICAgIHNlbmRQcm9taXNlZFJlc3VsdChyZXN1bHQpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzZW5kUHJvbWlzZWRSZXN1bHQoc2VuZFJlc3BvbnNlUHJvbWlzZSk7XG4gICAgICAgICAgfSAvLyBMZXQgQ2hyb21lIGtub3cgdGhhdCB0aGUgbGlzdGVuZXIgaXMgcmVwbHlpbmcuXG5cblxuICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9O1xuICAgICAgfSk7XG5cbiAgICAgIGNvbnN0IHdyYXBwZWRTZW5kTWVzc2FnZUNhbGxiYWNrID0gKHtcbiAgICAgICAgcmVqZWN0LFxuICAgICAgICByZXNvbHZlXG4gICAgICB9LCByZXBseSkgPT4ge1xuICAgICAgICBpZiAoZXh0ZW5zaW9uQVBJcy5ydW50aW1lLmxhc3RFcnJvcikge1xuICAgICAgICAgIC8vIERldGVjdCB3aGVuIG5vbmUgb2YgdGhlIGxpc3RlbmVycyByZXBsaWVkIHRvIHRoZSBzZW5kTWVzc2FnZSBjYWxsIGFuZCByZXNvbHZlXG4gICAgICAgICAgLy8gdGhlIHByb21pc2UgdG8gdW5kZWZpbmVkIGFzIGluIEZpcmVmb3guXG4gICAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9tb3ppbGxhL3dlYmV4dGVuc2lvbi1wb2x5ZmlsbC9pc3N1ZXMvMTMwXG4gICAgICAgICAgaWYgKGV4dGVuc2lvbkFQSXMucnVudGltZS5sYXN0RXJyb3IubWVzc2FnZSA9PT0gQ0hST01FX1NFTkRfTUVTU0FHRV9DQUxMQkFDS19OT19SRVNQT05TRV9NRVNTQUdFKSB7XG4gICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJlamVjdChuZXcgRXJyb3IoZXh0ZW5zaW9uQVBJcy5ydW50aW1lLmxhc3RFcnJvci5tZXNzYWdlKSk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKHJlcGx5ICYmIHJlcGx5Ll9fbW96V2ViRXh0ZW5zaW9uUG9seWZpbGxSZWplY3RfXykge1xuICAgICAgICAgIC8vIENvbnZlcnQgYmFjayB0aGUgSlNPTiByZXByZXNlbnRhdGlvbiBvZiB0aGUgZXJyb3IgaW50b1xuICAgICAgICAgIC8vIGFuIEVycm9yIGluc3RhbmNlLlxuICAgICAgICAgIHJlamVjdChuZXcgRXJyb3IocmVwbHkubWVzc2FnZSkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJlc29sdmUocmVwbHkpO1xuICAgICAgICB9XG4gICAgICB9O1xuXG4gICAgICBjb25zdCB3cmFwcGVkU2VuZE1lc3NhZ2UgPSAobmFtZSwgbWV0YWRhdGEsIGFwaU5hbWVzcGFjZU9iaiwgLi4uYXJncykgPT4ge1xuICAgICAgICBpZiAoYXJncy5sZW5ndGggPCBtZXRhZGF0YS5taW5BcmdzKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBFeHBlY3RlZCBhdCBsZWFzdCAke21ldGFkYXRhLm1pbkFyZ3N9ICR7cGx1cmFsaXplQXJndW1lbnRzKG1ldGFkYXRhLm1pbkFyZ3MpfSBmb3IgJHtuYW1lfSgpLCBnb3QgJHthcmdzLmxlbmd0aH1gKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChhcmdzLmxlbmd0aCA+IG1ldGFkYXRhLm1heEFyZ3MpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEV4cGVjdGVkIGF0IG1vc3QgJHttZXRhZGF0YS5tYXhBcmdzfSAke3BsdXJhbGl6ZUFyZ3VtZW50cyhtZXRhZGF0YS5tYXhBcmdzKX0gZm9yICR7bmFtZX0oKSwgZ290ICR7YXJncy5sZW5ndGh9YCk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICAgIGNvbnN0IHdyYXBwZWRDYiA9IHdyYXBwZWRTZW5kTWVzc2FnZUNhbGxiYWNrLmJpbmQobnVsbCwge1xuICAgICAgICAgICAgcmVzb2x2ZSxcbiAgICAgICAgICAgIHJlamVjdFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGFyZ3MucHVzaCh3cmFwcGVkQ2IpO1xuICAgICAgICAgIGFwaU5hbWVzcGFjZU9iai5zZW5kTWVzc2FnZSguLi5hcmdzKTtcbiAgICAgICAgfSk7XG4gICAgICB9O1xuXG4gICAgICBjb25zdCBzdGF0aWNXcmFwcGVycyA9IHtcbiAgICAgICAgZGV2dG9vbHM6IHtcbiAgICAgICAgICBuZXR3b3JrOiB7XG4gICAgICAgICAgICBvblJlcXVlc3RGaW5pc2hlZDogd3JhcEV2ZW50KG9uUmVxdWVzdEZpbmlzaGVkV3JhcHBlcnMpXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBydW50aW1lOiB7XG4gICAgICAgICAgb25NZXNzYWdlOiB3cmFwRXZlbnQob25NZXNzYWdlV3JhcHBlcnMpLFxuICAgICAgICAgIG9uTWVzc2FnZUV4dGVybmFsOiB3cmFwRXZlbnQob25NZXNzYWdlV3JhcHBlcnMpLFxuICAgICAgICAgIHNlbmRNZXNzYWdlOiB3cmFwcGVkU2VuZE1lc3NhZ2UuYmluZChudWxsLCBcInNlbmRNZXNzYWdlXCIsIHtcbiAgICAgICAgICAgIG1pbkFyZ3M6IDEsXG4gICAgICAgICAgICBtYXhBcmdzOiAzXG4gICAgICAgICAgfSlcbiAgICAgICAgfSxcbiAgICAgICAgdGFiczoge1xuICAgICAgICAgIHNlbmRNZXNzYWdlOiB3cmFwcGVkU2VuZE1lc3NhZ2UuYmluZChudWxsLCBcInNlbmRNZXNzYWdlXCIsIHtcbiAgICAgICAgICAgIG1pbkFyZ3M6IDIsXG4gICAgICAgICAgICBtYXhBcmdzOiAzXG4gICAgICAgICAgfSlcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIGNvbnN0IHNldHRpbmdNZXRhZGF0YSA9IHtcbiAgICAgICAgY2xlYXI6IHtcbiAgICAgICAgICBtaW5BcmdzOiAxLFxuICAgICAgICAgIG1heEFyZ3M6IDFcbiAgICAgICAgfSxcbiAgICAgICAgZ2V0OiB7XG4gICAgICAgICAgbWluQXJnczogMSxcbiAgICAgICAgICBtYXhBcmdzOiAxXG4gICAgICAgIH0sXG4gICAgICAgIHNldDoge1xuICAgICAgICAgIG1pbkFyZ3M6IDEsXG4gICAgICAgICAgbWF4QXJnczogMVxuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgYXBpTWV0YWRhdGEucHJpdmFjeSA9IHtcbiAgICAgICAgbmV0d29yazoge1xuICAgICAgICAgIFwiKlwiOiBzZXR0aW5nTWV0YWRhdGFcbiAgICAgICAgfSxcbiAgICAgICAgc2VydmljZXM6IHtcbiAgICAgICAgICBcIipcIjogc2V0dGluZ01ldGFkYXRhXG4gICAgICAgIH0sXG4gICAgICAgIHdlYnNpdGVzOiB7XG4gICAgICAgICAgXCIqXCI6IHNldHRpbmdNZXRhZGF0YVxuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgcmV0dXJuIHdyYXBPYmplY3QoZXh0ZW5zaW9uQVBJcywgc3RhdGljV3JhcHBlcnMsIGFwaU1ldGFkYXRhKTtcbiAgICB9OyAvLyBUaGUgYnVpbGQgcHJvY2VzcyBhZGRzIGEgVU1EIHdyYXBwZXIgYXJvdW5kIHRoaXMgZmlsZSwgd2hpY2ggbWFrZXMgdGhlXG4gICAgLy8gYG1vZHVsZWAgdmFyaWFibGUgYXZhaWxhYmxlLlxuXG5cbiAgICBtb2R1bGUuZXhwb3J0cyA9IHdyYXBBUElzKGNocm9tZSk7XG4gIH0gZWxzZSB7XG4gICAgbW9kdWxlLmV4cG9ydHMgPSBnbG9iYWxUaGlzLmJyb3dzZXI7XG4gIH1cbn0pO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YnJvd3Nlci1wb2x5ZmlsbC5qcy5tYXBcbiIsIi8vIFRoZSBtb2R1bGUgY2FjaGVcbnZhciBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX18gPSB7fTtcblxuLy8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbmZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG5cdHZhciBjYWNoZWRNb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdO1xuXHRpZiAoY2FjaGVkTW9kdWxlICE9PSB1bmRlZmluZWQpIHtcblx0XHRyZXR1cm4gY2FjaGVkTW9kdWxlLmV4cG9ydHM7XG5cdH1cblx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcblx0dmFyIG1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF0gPSB7XG5cdFx0Ly8gbm8gbW9kdWxlLmlkIG5lZWRlZFxuXHRcdC8vIG5vIG1vZHVsZS5sb2FkZWQgbmVlZGVkXG5cdFx0ZXhwb3J0czoge31cblx0fTtcblxuXHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cblx0X193ZWJwYWNrX21vZHVsZXNfX1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cblx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcblx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xufVxuXG4iLCIvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuX193ZWJwYWNrX3JlcXVpcmVfXy5uID0gKG1vZHVsZSkgPT4ge1xuXHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cblx0XHQoKSA9PiAobW9kdWxlWydkZWZhdWx0J10pIDpcblx0XHQoKSA9PiAobW9kdWxlKTtcblx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgeyBhOiBnZXR0ZXIgfSk7XG5cdHJldHVybiBnZXR0ZXI7XG59OyIsIi8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb25zIGZvciBoYXJtb255IGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uZCA9IChleHBvcnRzLCBkZWZpbml0aW9uKSA9PiB7XG5cdGZvcih2YXIga2V5IGluIGRlZmluaXRpb24pIHtcblx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZGVmaW5pdGlvbiwga2V5KSAmJiAhX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIGtleSkpIHtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBrZXksIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBkZWZpbml0aW9uW2tleV0gfSk7XG5cdFx0fVxuXHR9XG59OyIsIl9fd2VicGFja19yZXF1aXJlX18ubyA9IChvYmosIHByb3ApID0+IChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKSkiLCIvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSAoZXhwb3J0cykgPT4ge1xuXHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcblx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcblx0fVxuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xufTsiLCIvKipcbiAqIFRoaXMgaXMgdGhlIG1haW4gZW50cnkgcG9pbnQgdG8gd2hhdCB3ZSByZWZlciB0byBhcyB0aGUgQVBJIG9mIHRoZSBleHRlbnNpb24uXG4gKiBUaGUgQVBJIGhhbmRsZXMgbW9zdCBpbnRlcmFjdGlvbnMgd2l0aCBBbGZhLCB0aGUgYnJvd3NlciwgYW5kIHRoZSBwYWdlIGJlaW5nXG4gKiB0ZXN0ZWQgYW5kIGV4cG9zZXMgYW4gaW50ZXJmYWNlIGZvciB0aGUgYXBwbGljYXRpb24gY29kZSB0byBjYWxsIHRocm91Z2hcbiAqIG1lc3NhZ2luZy5cbiAqXG4gKiBUaGUgQVBJIGlzIHJ1biBhcyBhIHBvc3NpYmx5IG5vbi1wZXJzaXN0ZW50IGJhY2tncm91bmQgc2NyaXB0IChvciBzZXJ2aWNlXG4gKiB3b3JrZXIsIGRlcGVuZGluZyBvbiBicm93c2VycykgaW4gdGhlIGJyb3dzZXIuXG4gKiBJdCBtdXN0IHRoZXJlZm9yZSBub3QgZGVwZW5kIG9uIGFueSBnbG9iYWwgc3RhdGUgYXMgc3VjaCBzdGF0ZSB3aWxsIGJlIGxvc3RcbiAqIHdoZW4gdGhlIGJhY2tncm91bmQgc2NyaXB0IGlzIHVubG9hZGVkLlxuICpcbiAqIE5vdGFibHksIHRoaXMgZm9yY2VzIHRoZSBwb3B1cCB0byBjb25uZWN0IGRpcmVjdGx5IHRvIHRoZSBkZXZ0b29scyBpbnN0YW5jZVxuICogb2YgdGhlIGluc3BlY3RlZCBwYWdlOyBhbmQgdGhpcyBmb3JjZXMgdGhlIHBvcHVwIG1hcCB0byBiZSBzdG9yZWQgaW4gbG9jYWxcbiAqIHN0b3JhZ2UuXG4gKi9cblxuaW1wb3J0IHsgTWFwIH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLW1hcFwiO1xuaW1wb3J0IHsgTm9uZSwgT3B0aW9uIH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLW9wdGlvblwiO1xuaW1wb3J0IGJyb3dzZXIgZnJvbSBcIndlYmV4dGVuc2lvbi1wb2x5ZmlsbFwiO1xuXG4vKipcbiAqIFN0b3JhZ2Uga2V5c1xuICovXG5jb25zdCBQT1BVUF9LRVkgPSBcInBvcHVwc01hcFwiO1xuXG4vKipcbiAqIE1hcCBmcm9tIHRhYklkIHRvIG9wZW4gcG9wdXAuXG4gKlxuICogQHJlbWFya3NcbiAqIEV2ZXJ5IGxpc3RlbmVyIHdpbGwgcmVsb2FkIHRoZSBwb3B1cHMgbWFwLCB0byBtYWtlIHN1cmUgaXQgaXMgdXAtdG8tZGF0ZS5cbiAqIExpc3RlbmVycyB0aGF0IHVwZGF0ZSBpdCBhbHNvIHNhdmUgaXQuXG4gKiBXaGVuIGNsaWNraW5nIHRoZSBleHRlbnNpb24gYnV0dG9uLCB3ZSBhbHNvIHRha2UgdGltZSB0byBjbGVhbiBpdCwgaW4gY2FzZVxuICogYW55dGhpbmcgYmFkIGhhcHBlbmVkIGF0IHNvbWUgcG9pbnQuXG4gKi9cblxubGV0IG15UG9wdXBzID0gTWFwLmVtcHR5KCk7XG5hc3luYyBmdW5jdGlvbiBsb2FkUG9wdXBzTWFwKCkge1xuICBjb25zdCBwb3B1cHMgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KFBPUFVQX0tFWSk7XG4gIG15UG9wdXBzID0gTWFwLmZyb20ocG9wdXBzPy5bUE9QVVBfS0VZXSA/PyBbXSk7XG59XG5hc3luYyBmdW5jdGlvbiBzYXZlUG9wdXBzTWFwKCkge1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHtcbiAgICBbUE9QVVBfS0VZXTogbXlQb3B1cHMudG9BcnJheSgpXG4gIH0pO1xufVxuYXN5bmMgZnVuY3Rpb24gd2luZG93RXhpc3RzKHdpbmRvd0lkKSB7XG4gIGlmICh3aW5kb3dJZCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHRyeSB7XG4gICAgYXdhaXQgYnJvd3Nlci53aW5kb3dzLmdldCh3aW5kb3dJZCk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICAvLyBXZSBhc3N1bWUgZXJyb3JzIG1vc3RseSBvY2N1ciBkdWUgdG8gbm9uLWV4aXN0ZW50IHdpbmRvdy5cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn1cblxuLyoqXG4gKiBSZW1vdmUgZW50cmllcyB3aXRoIG5vIGNvcnJlc3BvbmRpbmcgb3BlbmVkIHdpbmRvd1xuICpcbiAqIEByZW1hcmtzXG4gKiBUaGlzIHNob3VsZCBub3QgaGFwcGVuIHNpbmNlIHRoZSBzZXJ2aWNlIHdvcmtlciBzaG91bGQgcmVzdGFydCBhbmQgY2xlYW5cbiAqIHRoZSBtYXAgb24gd2luZG93IHJlbW92ZWQuIFRoaXMgaXMgaG93ZXZlciBub3QgZXhwZW5zaXZlIGJlY2F1c2Ugd2UgYXNzdW1lXG4gKiB0aGUgbWFwIHdpbGwgYmUgc21hbGw7IGFuZCB0aGlzIHByZXZlbnRzIGEgcG9zc2libGUgdmVjdG9yIG9mIG1lbW9yeSBsZWFrXG4gKiBzaW5jZSB0aGlzIGlzIHBlcnNpc3RlbnQgc3RvcmFnZSBhbmQgd2UgaGF2ZSByZXF1ZXN0ZWQgdW5saW1pdGVkIHN0b3JhZ2VcbiAqIHBlcm1pc3Npb24uXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGNsZWFuUG9wdXBzTWFwKCkge1xuICBsZXQgZXhpc3RpbmcgPSBNYXAuZW1wdHkoKTtcbiAgZm9yIChjb25zdCBbdGFiSWQsIHBvcHVwXSBvZiBteVBvcHVwcykge1xuICAgIGlmIChhd2FpdCB3aW5kb3dFeGlzdHMocG9wdXAud2luZG93SWQpKSB7XG4gICAgICBleGlzdGluZyA9IGV4aXN0aW5nLnNldCh0YWJJZCwgcG9wdXApO1xuICAgIH1cbiAgfVxuICBteVBvcHVwcyA9IGV4aXN0aW5nO1xufVxuXG4vKipcbiAqIENsZWFudXAgcG9wdXAtbWFwIHdoZW4gYSBwb3B1cCB3aW5kb3cgaXMgY2xvc2VkLlxuICpcbiAqIEByZW1hcmtzXG4gKiBUaGlzIGlzIHRyaWdnZXJlZCBieSB0aGUgb3RoZXIgbGlzdGVuZXJzIGNsb3NpbmcgcG9wdXAgd2luZG93cy5cbiAqL1xuYnJvd3Nlci53aW5kb3dzLm9uUmVtb3ZlZC5hZGRMaXN0ZW5lcihhc3luYyB3aW5kb3dJZCA9PiB7XG4gIGF3YWl0IGxvYWRQb3B1cHNNYXAoKTtcbiAgbGV0IGtleSA9IE5vbmU7XG4gIG15UG9wdXBzLmZpbmQoKHBvcHVwLCB0YWJJZCkgPT4ge1xuICAgIGlmIChwb3B1cC53aW5kb3dJZCA9PT0gd2luZG93SWQpIHtcbiAgICAgIGtleSA9IE9wdGlvbi5vZih0YWJJZCk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9KTtcbiAga2V5LmZvckVhY2goa2V5ID0+IG15UG9wdXBzID0gbXlQb3B1cHMuZGVsZXRlKGtleSkpO1xuICBhd2FpdCBzYXZlUG9wdXBzTWFwKCk7XG59KTtcblxuLyoqXG4gKiBDbG9zZSBwb3B1cCBpZiB1c2VyIG5hdmlnYXRlIHRvIGFub3RoZXIgcGFnZS5cbiAqL1xuYnJvd3Nlci50YWJzLm9uVXBkYXRlZC5hZGRMaXN0ZW5lcihhc3luYyB0YWJJZCA9PiB7XG4gIGF3YWl0IGxvYWRQb3B1cHNNYXAoKTtcbiAgY29uc3QgY3VycmVudFBvcHVwID0gbXlQb3B1cHMuZ2V0KHRhYklkKS5nZXRPcih1bmRlZmluZWQpO1xuICBpZiAoY3VycmVudFBvcHVwPy53aW5kb3dJZCkge1xuICAgIC8vIENsb3NlIHRoZSBwb3B1cCBpZiB0aGUgdXJsIGNoYW5nZXNcbiAgICBjb25zdCB0YWIgPSBhd2FpdCBicm93c2VyLnRhYnMuZ2V0KHRhYklkKTtcbiAgICBpZiAoY3VycmVudFBvcHVwPy51cmwgIT09IHRhYi51cmwgJiYgbmF2aWdhdG9yLnVzZXJBZ2VudC5pbmRleE9mKFwiRmlyZWZveFwiKSA9PT0gLTEpIHtcbiAgICAgIGF3YWl0IGJyb3dzZXIud2luZG93cy5yZW1vdmUoY3VycmVudFBvcHVwLndpbmRvd0lkKTtcbiAgICB9XG4gIH1cbn0pO1xuXG4vKipcbiAqIENsb3NlIHBvcHVwIGlmIHRoZSBhdWRpdGVkIHRhYiBpcyBjbG9zZWQuXG4gKi9cbmJyb3dzZXIudGFicy5vblJlbW92ZWQuYWRkTGlzdGVuZXIoYXN5bmMgdGFiSWQgPT4ge1xuICBhd2FpdCBsb2FkUG9wdXBzTWFwKCk7XG4gIGNvbnN0IGN1cnJlbnRQb3B1cCA9IG15UG9wdXBzLmdldCh0YWJJZCkuZ2V0T3IodW5kZWZpbmVkKTtcbiAgaWYgKGN1cnJlbnRQb3B1cD8ud2luZG93SWQpIHtcbiAgICAvLyBDbG9zZSB0aGUgcG9wdXAgaWYgdGhlIHRhYiBpcyBjbG9zZWRcbiAgICBhd2FpdCBicm93c2VyLndpbmRvd3MucmVtb3ZlKGN1cnJlbnRQb3B1cC53aW5kb3dJZCk7XG4gIH1cbn0pO1xuXG4vKipcbiAqIE9wZW4gcG9wdXAgd2hlbiBpY29uIGlzIGNsaWNrZWQuXG4gKiBJZiB0aGUgcG9wdXAgaXMgb3BlbiwgY2xvc2UgaXQuXG4gKi9cbmJyb3dzZXIuYWN0aW9uLm9uQ2xpY2tlZC5hZGRMaXN0ZW5lcihhc3luYyB0YWIgPT4ge1xuICAvLyBCYWlsIG91dCBpbW1lZGlhdGVseSBpZiB3ZSBjYW5ub3QgZ2V0IGEgdGFiSWRcbiAgaWYgKCF0YWIuaWQpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgYXdhaXQgbG9hZFBvcHVwc01hcCgpO1xuICBhd2FpdCBjbGVhblBvcHVwc01hcCgpO1xuXG4gIC8vIElmIHRoZSBjdXJyZW50IHRhYiBhbHJlYWR5IGhhcyBhbiBleHRlbnNpb24gcG9wdXAsIGNsb3NlIHRoZSBwb3B1cC5cbiAgY29uc3QgY3VycmVudFBvcHVwID0gbXlQb3B1cHMuZ2V0KHRhYi5pZCkuZ2V0T3IodW5kZWZpbmVkKTtcbiAgaWYgKGN1cnJlbnRQb3B1cD8ud2luZG93SWQpIHtcbiAgICBhd2FpdCBicm93c2VyLndpbmRvd3MucmVtb3ZlKGN1cnJlbnRQb3B1cC53aW5kb3dJZCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLy8gT3RoZXJ3aXNlLCBvcGVuIGEgbmV3IHBvcHVwLlxuICBjb25zdCBwb3B1cFVybCA9IG5ldyBVUkwoYnJvd3Nlci5ydW50aW1lLmdldFVSTChcImFwcC5odG1sXCIpKTtcblxuICAvKipcbiAgICogUGFzcyBhbG9uZyB0aGUgdGFiIElEIGFzIGEgcXVlcnkgcGFyYW1ldGVyLiBUaGUgYXBwbGljYXRpb24gY29kZSB1c2VzIHRoaXNcbiAgICogd2hlbiBtYWtpbmcgQVBJIGNhbGxzLlxuICAgKi9cbiAgcG9wdXBVcmwuc2VhcmNoUGFyYW1zLnNldChcInRhYklkXCIsIHRhYi5pZD8udG9TdHJpbmcoMTApIHx8IFwiXCIpO1xuICBjb25zdCBwb3B1cCA9IGF3YWl0IGJyb3dzZXIud2luZG93cy5jcmVhdGUoe1xuICAgIHVybDogcG9wdXBVcmwudG9TdHJpbmcoKSxcbiAgICB0eXBlOiBcInBhbmVsXCIsXG4gICAgaGVpZ2h0OiA2MDAsXG4gICAgd2lkdGg6IDgwMFxuICB9KTtcbiAgbXlQb3B1cHMgPSBteVBvcHVwcy5zZXQodGFiLmlkLCB7XG4gICAgd2luZG93SWQ6IHBvcHVwLmlkLFxuICAgIHVybDogdGFiLnVybFxuICB9KTtcbiAgYXdhaXQgc2F2ZVBvcHVwc01hcCgpO1xufSk7Il0sIm5hbWVzIjpbXSwiaWdub3JlTGlzdCI6W10sInNvdXJjZVJvb3QiOiIifQ==