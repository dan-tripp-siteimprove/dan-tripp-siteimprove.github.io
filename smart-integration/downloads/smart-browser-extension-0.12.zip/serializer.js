/**
 * WARNING!
 * Do not modify unless you understand what you're doing.
 *
 * It is of the uttermost importance that this file contains a single line call
 * to the library defined by Webpack. See `docs/serialization.md` for further
 * explanations.
 *
 * The name of the library is defined in `scripts/webpack.ts`.
 * The name of the value to call is defined in `./serialize-device.ts`.
 *
 * WARNING!
 */
globalThis.AlfaPageJSON;
