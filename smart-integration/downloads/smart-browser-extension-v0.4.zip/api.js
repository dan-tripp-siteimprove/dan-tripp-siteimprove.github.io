/******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/@siteimprove/alfa-array/src/array.js":
/*!***********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-array/src/array.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Array = void 0;
const alfa_clone_1 = __webpack_require__(/*! @siteimprove/alfa-clone */ "./node_modules/@siteimprove/alfa-clone/src/index.js");
const alfa_comparable_1 = __webpack_require__(/*! @siteimprove/alfa-comparable */ "./node_modules/@siteimprove/alfa-comparable/src/index.js");
const alfa_equatable_1 = __webpack_require__(/*! @siteimprove/alfa-equatable */ "./node_modules/@siteimprove/alfa-equatable/src/index.js");
const alfa_iterable_1 = __webpack_require__(/*! @siteimprove/alfa-iterable */ "./node_modules/@siteimprove/alfa-iterable/src/index.js");
const alfa_json_1 = __webpack_require__(/*! @siteimprove/alfa-json */ "./node_modules/@siteimprove/alfa-json/src/index.js");
const alfa_option_1 = __webpack_require__(/*! @siteimprove/alfa-option */ "./node_modules/@siteimprove/alfa-option/src/index.js");
const alfa_predicate_1 = __webpack_require__(/*! @siteimprove/alfa-predicate */ "./node_modules/@siteimprove/alfa-predicate/src/index.js");
const builtin = __webpack_require__(/*! ./builtin */ "./node_modules/@siteimprove/alfa-array/src/builtin.js");
const { not } = alfa_predicate_1.Predicate;
const { compareComparable } = alfa_comparable_1.Comparable;
/**
 * @public
 */
var Array;
(function (Array) {
    function isArray(value) {
        return builtin.Array.isArray(value);
    }
    Array.isArray = isArray;
    function of(...values) {
        return values;
    }
    Array.of = of;
    function empty() {
        return [];
    }
    Array.empty = empty;
    function allocate(capacity) {
        return new builtin.Array(capacity);
    }
    Array.allocate = allocate;
    /**
     * @remarks
     * Unlike the built-in function of the same name, this function will pass
     * along existing arrays as-is instead of returning a copy.
     */
    function from(iterable) {
        if (isArray(iterable)) {
            return iterable;
        }
        return [...iterable];
    }
    Array.from = from;
    function size(array) {
        return array.length;
    }
    Array.size = size;
    function isEmpty(array) {
        return array.length === 0;
    }
    Array.isEmpty = isEmpty;
    function copy(array) {
        return array.slice(0);
    }
    Array.copy = copy;
    function clone(array) {
        return array.map(alfa_clone_1.Clone.clone);
    }
    Array.clone = clone;
    function forEach(array, callback) {
        for (let i = 0, n = array.length; i < n; i++) {
            callback(array[i], i);
        }
    }
    Array.forEach = forEach;
    function map(array, mapper) {
        const result = new builtin.Array(array.length);
        for (let i = 0, n = array.length; i < n; i++) {
            result[i] = mapper(array[i], i);
        }
        return result;
    }
    Array.map = map;
    function flatMap(array, mapper) {
        const result = empty();
        for (let i = 0, n = array.length; i < n; i++) {
            result.push(...mapper(array[i], i));
        }
        return result;
    }
    Array.flatMap = flatMap;
    function flatten(array) {
        return flatMap(array, (array) => array);
    }
    Array.flatten = flatten;
    function reduce(array, reducer, accumulator) {
        for (let i = 0, n = array.length; i < n; i++) {
            accumulator = reducer(accumulator, array[i], i);
        }
        return accumulator;
    }
    Array.reduce = reduce;
    function reduceWhile(array, predicate, reducer, accumulator) {
        for (let i = 0, n = array.length; i < n; i++) {
            const value = array[i];
            if (predicate(value, i)) {
                accumulator = reducer(accumulator, value, i);
            }
            else {
                break;
            }
        }
        return accumulator;
    }
    Array.reduceWhile = reduceWhile;
    function reduceUntil(array, predicate, reducer, accumulator) {
        return reduceWhile(array, not(predicate), reducer, accumulator);
    }
    Array.reduceUntil = reduceUntil;
    function apply(array, mapper) {
        return flatMap(mapper, (mapper) => map(array, mapper));
    }
    Array.apply = apply;
    function filter(array, predicate) {
        const result = empty();
        for (let i = 0, n = array.length; i < n; i++) {
            const value = array[i];
            if (predicate(value, i)) {
                result.push(value);
            }
        }
        return result;
    }
    Array.filter = filter;
    function reject(array, predicate) {
        return filter(array, not(predicate));
    }
    Array.reject = reject;
    function find(array, predicate) {
        for (let i = 0, n = array.length; i < n; i++) {
            const value = array[i];
            if (predicate(value, i)) {
                return alfa_option_1.Option.of(value);
            }
        }
        return alfa_option_1.None;
    }
    Array.find = find;
    function findLast(array, predicate) {
        for (let i = array.length - 1; i >= 0; i--) {
            const value = array[i];
            if (predicate(value, i)) {
                return alfa_option_1.Option.of(value);
            }
        }
        return alfa_option_1.None;
    }
    Array.findLast = findLast;
    function includes(array, value) {
        return some(array, alfa_predicate_1.Predicate.equals(value));
    }
    Array.includes = includes;
    function collect(array, mapper) {
        const result = empty();
        for (let i = 0, n = array.length; i < n; i++) {
            for (const value of mapper(array[i], i)) {
                result.push(value);
            }
        }
        return result;
    }
    Array.collect = collect;
    function collectFirst(array, mapper) {
        for (let i = 0, n = array.length; i < n; i++) {
            const value = mapper(array[i], i);
            if (value.isSome()) {
                return value;
            }
        }
        return alfa_option_1.None;
    }
    Array.collectFirst = collectFirst;
    function some(array, predicate) {
        for (let i = 0, n = array.length; i < n; i++) {
            if (predicate(array[i], i)) {
                return true;
            }
        }
        return false;
    }
    Array.some = some;
    function none(array, predicate) {
        return every(array, not(predicate));
    }
    Array.none = none;
    function every(array, predicate) {
        for (let i = 0, n = array.length; i < n; i++) {
            if (!predicate(array[i], i)) {
                return false;
            }
        }
        return true;
    }
    Array.every = every;
    function count(array, predicate) {
        return reduce(array, (count, value, index) => (predicate(value, index) ? count + 1 : count), 0);
    }
    Array.count = count;
    function distinct(array) {
        const result = empty();
        for (let i = 0, n = array.length; i < n; i++) {
            const value = array[i];
            if (result.some(alfa_predicate_1.Predicate.equals(value))) {
                continue;
            }
            result.push(value);
        }
        return result;
    }
    Array.distinct = distinct;
    function get(array, index) {
        return index < array.length ? alfa_option_1.Option.of(array[index]) : alfa_option_1.None;
    }
    Array.get = get;
    function has(array, index) {
        return index < array.length;
    }
    Array.has = has;
    function set(array, index, value) {
        if (index < array.length) {
            array[index] = value;
        }
        return array;
    }
    Array.set = set;
    function insert(array, index, value) {
        if (index <= array.length) {
            array.splice(index, 0, value);
        }
        return array;
    }
    Array.insert = insert;
    function append(array, value) {
        array.push(value);
        return array;
    }
    Array.append = append;
    function prepend(array, value) {
        array.unshift(value);
        return array;
    }
    Array.prepend = prepend;
    function concat(array, ...iterables) {
        return [...alfa_iterable_1.Iterable.concat(array, ...iterables)];
    }
    Array.concat = concat;
    function subtract(array, ...iterables) {
        return [...alfa_iterable_1.Iterable.subtract(array, ...iterables)];
    }
    Array.subtract = subtract;
    function intersect(array, ...iterables) {
        return [...alfa_iterable_1.Iterable.intersect(array, ...iterables)];
    }
    Array.intersect = intersect;
    function zip(array, iterable) {
        const result = empty();
        const it = alfa_iterable_1.Iterable.iterator(iterable);
        for (let i = 0, n = array.length; i < n; i++) {
            const next = it.next();
            if (next.done === true) {
                break;
            }
            result.push([array[i], next.value]);
        }
        return result;
    }
    Array.zip = zip;
    function first(array) {
        return array.length > 0 ? alfa_option_1.Option.of(array[0]) : alfa_option_1.None;
    }
    Array.first = first;
    function last(array) {
        return array.length > 0 ? alfa_option_1.Option.of(array[array.length - 1]) : alfa_option_1.None;
    }
    Array.last = last;
    function sort(array) {
        return sortWith(array, compareComparable);
    }
    Array.sort = sort;
    function sortWith(array, comparer) {
        return array.sort(comparer);
    }
    Array.sortWith = sortWith;
    function compare(a, b) {
        return compareWith(a, b, compareComparable);
    }
    Array.compare = compare;
    function compareWith(a, b, comparer) {
        return alfa_iterable_1.Iterable.compareWith(a, b, comparer);
    }
    Array.compareWith = compareWith;
    function search(array, value, comparer) {
        let lower = 0;
        let upper = array.length - 1;
        while (lower <= upper) {
            const middle = (lower + (upper - lower) / 2) >>> 0;
            switch (comparer(value, array[middle])) {
                case alfa_comparable_1.Comparison.Greater:
                    lower = middle + 1;
                    break;
                case alfa_comparable_1.Comparison.Less:
                    upper = middle - 1;
                    break;
                case alfa_comparable_1.Comparison.Equal:
                    return middle;
            }
        }
        return lower;
    }
    Array.search = search;
    function equals(a, b) {
        if (a.length !== b.length) {
            return false;
        }
        for (let i = 0, n = a.length; i < n; i++) {
            if (!alfa_equatable_1.Equatable.equals(a[i], b[i])) {
                return false;
            }
        }
        return true;
    }
    Array.equals = equals;
    function hash(array, hash) {
        for (let i = 0, n = array.length; i < n; i++) {
            hash.writeUnknown(array[i]);
        }
        hash.writeUint32(array.length);
    }
    Array.hash = hash;
    function iterator(array) {
        return array[Symbol.iterator]();
    }
    Array.iterator = iterator;
    function toJSON(array) {
        return array.map((value) => alfa_json_1.Serializable.toJSON(value));
    }
    Array.toJSON = toJSON;
})(Array || (exports.Array = Array = {}));
//# sourceMappingURL=array.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-array/src/builtin.js":
/*!*************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-array/src/builtin.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

// This file defines exports from the builtin `Array` constructor for internal
// use only.
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Array = void 0;
/**
 * @internal
 */
const Builtin = Array;
exports.Array = Builtin;
//# sourceMappingURL=builtin.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-array/src/index.js":
/*!***********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-array/src/index.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

/**
 * This package provides functionality for working with arrays.
 *
 * @packageDocumentation
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(/*! ./array */ "./node_modules/@siteimprove/alfa-array/src/array.js"), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-bits/src/bits.js":
/*!*********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-bits/src/bits.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Bits = void 0;
/**
 * @public
 */
var Bits;
(function (Bits) {
    function bit(i) {
        return 1 << i;
    }
    Bits.bit = bit;
    function set(bits, i) {
        return bits | bit(i);
    }
    Bits.set = set;
    function clear(bits, i) {
        return bits & ~bit(i);
    }
    Bits.clear = clear;
    function test(bits, i) {
        return (bits & bit(i)) !== 0;
    }
    Bits.test = test;
    function take(bits, n) {
        return bits & ((1 << n) - 1);
    }
    Bits.take = take;
    function skip(bits, n) {
        return bits >>> n;
    }
    Bits.skip = skip;
    /**
     * @remarks
     * This is a 32-bit variant of the 64-bit population count algorithm outlined
     * on Wikipedia. Until ECMAScript natively provides an efficient population
     * count algorithm, this is the best we can do.
     *
     * {@link https://en.wikipedia.org/wiki/Hamming_weight}
     */
    function popCount(bits) {
        bits -= (bits >> 1) & 0x55555555;
        bits = (bits & 0x33333333) + ((bits >> 2) & 0x33333333);
        bits = (bits + (bits >> 4)) & 0x0f0f0f0f;
        bits += bits >> 8;
        bits += bits >> 16;
        return bits & 0x7f;
    }
    Bits.popCount = popCount;
})(Bits || (exports.Bits = Bits = {}));
//# sourceMappingURL=bits.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-bits/src/index.js":
/*!**********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-bits/src/index.js ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(/*! ./bits */ "./node_modules/@siteimprove/alfa-bits/src/bits.js"), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-clone/src/clone.js":
/*!***********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-clone/src/clone.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Clone = void 0;
/**
 * @public
 */
var Clone;
(function (Clone) {
    function clone(value) {
        return value.clone();
    }
    Clone.clone = clone;
})(Clone || (exports.Clone = Clone = {}));
//# sourceMappingURL=clone.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-clone/src/index.js":
/*!***********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-clone/src/index.js ***!
  \***********************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(/*! ./clone */ "./node_modules/@siteimprove/alfa-clone/src/clone.js"), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-comparable/src/comparable.js":
/*!*********************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-comparable/src/comparable.js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Comparable = void 0;
const alfa_refinement_1 = __webpack_require__(/*! @siteimprove/alfa-refinement */ "./node_modules/@siteimprove/alfa-refinement/src/index.js");
const comparison_1 = __webpack_require__(/*! ./comparison */ "./node_modules/@siteimprove/alfa-comparable/src/comparison.js");
const { isString, isNumber, isBigInt, isBoolean, isFunction, isObject } = alfa_refinement_1.Refinement;
/**
 * This namespace provides additional functions for the
 * {@link (Comparable:interface)} interface.
 *
 * @public
 */
var Comparable;
(function (Comparable) {
    /**
     * Check if an unknown value implements the {@link (Comparable:interface)}
     * interface.
     */
    function isComparable(value) {
        return isObject(value) && isFunction(value.compare);
    }
    Comparable.isComparable = isComparable;
    function compare(a, b) {
        if (isString(a)) {
            return compareString(a, b);
        }
        if (isNumber(a)) {
            return compareNumber(a, b);
        }
        if (isBigInt(a)) {
            return compareBigInt(a, b);
        }
        if (isBoolean(a)) {
            return compareBoolean(a, b);
        }
        return compareComparable(a, b);
    }
    Comparable.compare = compare;
    /**
     * @remarks
     * This should only be used in cases where branch mispredictions caused by the
     * more general {@link (Comparable:namespace).(compare:1)} are undesired.
     */
    function compareString(a, b) {
        return comparePrimitive(a, b);
    }
    Comparable.compareString = compareString;
    /**
     * @remarks
     * This should only be used in cases where branch mispredictions caused by the
     * more general {@link (Comparable:namespace).(compare:2)} are undesired.
     */
    function compareNumber(a, b) {
        return comparePrimitive(a, b);
    }
    Comparable.compareNumber = compareNumber;
    /**
     * @remarks
     * This should only be used in cases where branch mispredictions caused by the
     * more general {@link (Comparable:namespace).(compare:3)} are undesired.
     */
    function compareBigInt(a, b) {
        return comparePrimitive(a, b);
    }
    Comparable.compareBigInt = compareBigInt;
    /**
     * @remarks
     * This should only be used in cases where branch mispredictions caused by the
     * more general {@link (Comparable:namespace).(compare:4)} are undesired.
     */
    function compareBoolean(a, b) {
        return comparePrimitive(a, b);
    }
    Comparable.compareBoolean = compareBoolean;
    /**
     * @remarks
     * This should only be used in cases where branch mispredictions caused by the
     * more general {@link (Comparable:namespace).(compare:5)} are undesired.
     */
    function compareComparable(a, b) {
        return a.compare(b);
    }
    Comparable.compareComparable = compareComparable;
    /**
     * Compare two primitive values.
     */
    function comparePrimitive(a, b) {
        if (a < b) {
            return comparison_1.Comparison.Less;
        }
        if (a > b) {
            return comparison_1.Comparison.Greater;
        }
        return comparison_1.Comparison.Equal;
    }
    /**
     * Compare tuples lexicographically
     *
     * {@link https://en.wikipedia.org/wiki/Lexicographic_order}
     */
    function compareLexicographically(a, b, comparer) {
        for (let i = 0; i < a.length; i++) {
            const comparison = comparer[i](a[i], b[i]);
            if (comparison === comparison_1.Comparison.Equal) {
                continue;
            }
            return comparison;
        }
        return comparison_1.Comparison.Equal;
    }
    Comparable.compareLexicographically = compareLexicographically;
    /**
     * Check if one value is less than another.
     */
    function isLessThan(a, b) {
        return a.compare(b) < 0;
    }
    Comparable.isLessThan = isLessThan;
    /**
     * Check if one value is less than or equal to another.
     */
    function isLessThanOrEqual(a, b) {
        return a.compare(b) <= 0;
    }
    Comparable.isLessThanOrEqual = isLessThanOrEqual;
    /**
     * Check if one value is equal to another
     */
    function isEqual(a, b) {
        return a.compare(b) === 0;
    }
    Comparable.isEqual = isEqual;
    /**
     * Check if one value is greater than another.
     */
    function isGreaterThan(a, b) {
        return a.compare(b) > 0;
    }
    Comparable.isGreaterThan = isGreaterThan;
    /**
     * Check if one value is greater than or equal to another.
     */
    function isGreaterThanOrEqual(a, b) {
        return a.compare(b) >= 0;
    }
    Comparable.isGreaterThanOrEqual = isGreaterThanOrEqual;
})(Comparable || (exports.Comparable = Comparable = {}));
//# sourceMappingURL=comparable.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-comparable/src/comparer.js":
/*!*******************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-comparable/src/comparer.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
//# sourceMappingURL=comparer.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-comparable/src/comparison.js":
/*!*********************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-comparable/src/comparison.js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Comparison = void 0;
/**
 * @remarks
 * Comparisons are limited to the range [-1, 1] in order to avoid the potential
 * of over-/underflows when comparisons are implemented naively using
 * subtractions, such `a - b`; this would not be allowed.
 *
 * @public
 */
var Comparison;
(function (Comparison) {
    Comparison[Comparison["Less"] = -1] = "Less";
    Comparison[Comparison["Equal"] = 0] = "Equal";
    Comparison[Comparison["Greater"] = 1] = "Greater";
})(Comparison || (exports.Comparison = Comparison = {}));
//# sourceMappingURL=comparison.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-comparable/src/index.js":
/*!****************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-comparable/src/index.js ***!
  \****************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(/*! ./comparable */ "./node_modules/@siteimprove/alfa-comparable/src/comparable.js"), exports);
__exportStar(__webpack_require__(/*! ./comparer */ "./node_modules/@siteimprove/alfa-comparable/src/comparer.js"), exports);
__exportStar(__webpack_require__(/*! ./comparison */ "./node_modules/@siteimprove/alfa-comparable/src/comparison.js"), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-encoding/src/decoder.js":
/*!****************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-encoding/src/decoder.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Decoder = void 0;
/**
 * {@link https://encoding.spec.whatwg.org/#textdecoder}
 *
 * @public
 */
var Decoder;
(function (Decoder) {
    /**
     * {@link https://encoding.spec.whatwg.org/#dom-textdecoder-decode}
     * {@link https://encoding.spec.whatwg.org/#utf-8-decoder}
     */
    function decode(input) {
        let output = "";
        let i = 0;
        while (i < input.length) {
            let byte = input[i];
            let bytesNeeded = 0;
            let codePoint = 0;
            if (byte <= 0x7f) {
                bytesNeeded = 0;
                codePoint = byte & 0xff;
            }
            else if (byte <= 0xdf) {
                bytesNeeded = 1;
                codePoint = byte & 0x1f;
            }
            else if (byte <= 0xef) {
                bytesNeeded = 2;
                codePoint = byte & 0x0f;
            }
            else if (byte <= 0xf4) {
                bytesNeeded = 3;
                codePoint = byte & 0x07;
            }
            if (input.length - i - bytesNeeded > 0) {
                let k = 0;
                while (k < bytesNeeded) {
                    byte = input[i + k + 1];
                    codePoint = (codePoint << 6) | (byte & 0x3f);
                    k += 1;
                }
            }
            else {
                codePoint = 0xfffd;
                bytesNeeded = input.length - i;
            }
            output += String.fromCodePoint(codePoint);
            i += bytesNeeded + 1;
        }
        return output;
    }
    Decoder.decode = decode;
})(Decoder || (exports.Decoder = Decoder = {}));
//# sourceMappingURL=decoder.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-encoding/src/encoder.js":
/*!****************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-encoding/src/encoder.js ***!
  \****************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Encoder = void 0;
/**
 * {@link https://encoding.spec.whatwg.org/#textencoder}
 *
 * @public
 */
var Encoder;
(function (Encoder) {
    /**
     * {@link https://encoding.spec.whatwg.org/#dom-textencoder-encode}
     * {@link https://encoding.spec.whatwg.org/#utf-8-encoder}
     */
    function encode(input) {
        const output = [];
        const length = input.length;
        let i = 0;
        while (i < length) {
            const codePoint = input.codePointAt(i);
            let count = 0;
            let bits = 0;
            if (codePoint <= 0x7f) {
                count = 0;
                bits = 0x00;
            }
            else if (codePoint <= 0x7ff) {
                count = 6;
                bits = 0xc0;
            }
            else if (codePoint <= 0xffff) {
                count = 12;
                bits = 0xe0;
            }
            else if (codePoint <= 0x1fffff) {
                count = 18;
                bits = 0xf0;
            }
            output.push(bits | (codePoint >> count));
            count -= 6;
            while (count >= 0) {
                output.push(0x80 | ((codePoint >> count) & 0x3f));
                count -= 6;
            }
            i += codePoint >= 0x10000 ? 2 : 1;
        }
        return new Uint8Array(output);
    }
    Encoder.encode = encode;
})(Encoder || (exports.Encoder = Encoder = {}));
//# sourceMappingURL=encoder.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-encoding/src/index.js":
/*!**************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-encoding/src/index.js ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(/*! ./decoder */ "./node_modules/@siteimprove/alfa-encoding/src/decoder.js"), exports);
__exportStar(__webpack_require__(/*! ./encoder */ "./node_modules/@siteimprove/alfa-encoding/src/encoder.js"), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-equatable/src/equatable.js":
/*!*******************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-equatable/src/equatable.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Equatable = void 0;
/**
 * This namespace provides additional types and functions for the
 * {@link (Equatable:interface)} interface.
 *
 * @public
 */
var Equatable;
(function (Equatable) {
    // The following two type guards have been inlined from the
    // @siteimprove/alfa-refinement package to avoid creating a circular
    // dependency.
    function isFunction(value) {
        return typeof value === "function";
    }
    function isObject(value) {
        return typeof value === "object" && value !== null;
    }
    /**
     * Check if an unknown value implements the {@link (Equatable:interface)}
     * interface.
     */
    function isEquatable(value) {
        return isObject(value) && isFunction(value.equals);
    }
    Equatable.isEquatable = isEquatable;
    /**
     * Check if two unknown values are equal.
     *
     * @remarks
     * If either of the given values implement the {@link (Equatable:interface)}
     * interface, the equivalence constraints of the value will be used. If not,
     * strict equality will be used with the additional constraint that `NaN` is
     * equal to itself.
     */
    function equals(a, b) {
        if (a === b ||
            // `NaN` is the only value in JavaScript that is not equal to itself.
            (a !== a && b !== b)) {
            return true;
        }
        if (isEquatable(a)) {
            return a.equals(b);
        }
        if (isEquatable(b)) {
            return b.equals(a);
        }
        return false;
    }
    Equatable.equals = equals;
})(Equatable || (exports.Equatable = Equatable = {}));
//# sourceMappingURL=equatable.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-equatable/src/index.js":
/*!***************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-equatable/src/index.js ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(/*! ./equatable */ "./node_modules/@siteimprove/alfa-equatable/src/equatable.js"), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-fnv/src/fnv.js":
/*!*******************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-fnv/src/fnv.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.FNV = void 0;
const alfa_hash_1 = __webpack_require__(/*! @siteimprove/alfa-hash */ "./node_modules/@siteimprove/alfa-hash/src/index.js");
/**
 * @public
 */
class FNV extends alfa_hash_1.Hash {
    static empty() {
        return new FNV();
    }
    constructor() {
        super();
        this._hash = 2166136261;
    }
    finish() {
        return this._hash >>> 0; // Convert to unsigned 32-bit integer
    }
    write(data) {
        let hash = this._hash;
        for (const octet of data) {
            hash ^= octet;
            hash +=
                (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
        }
        this._hash = hash;
        return this;
    }
    equals(value) {
        return value instanceof FNV && value._hash === this._hash;
    }
}
exports.FNV = FNV;
//# sourceMappingURL=fnv.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-fnv/src/index.js":
/*!*********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-fnv/src/index.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(/*! ./fnv */ "./node_modules/@siteimprove/alfa-fnv/src/fnv.js"), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-hash/src/hash.js":
/*!*********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-hash/src/hash.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Hash = void 0;
const alfa_encoding_1 = __webpack_require__(/*! @siteimprove/alfa-encoding */ "./node_modules/@siteimprove/alfa-encoding/src/index.js");
const hashable_1 = __webpack_require__(/*! ./hashable */ "./node_modules/@siteimprove/alfa-hash/src/hashable.js");
const { keys } = Object;
/**
 * A special offset used for the builtin types `true`, `false`, `undefined`, and
 * `null`. The offset is designed to minimize the chance of collisions for data
 * structures that rely on 5-bit partitioning. We use the first 30 bits for 6 of
 * these partitions, leaving us 2 bits to encode the 4 builtin types.
 */
const builtinOffset = 2216757312;
/**
 * @public
 */
class Hash {
    constructor() { }
    writeString(data) {
        return this.write(alfa_encoding_1.Encoder.encode(data));
    }
    /**
     * @remarks
     * As JavaScript represents numbers in double-precision floating-point format,
     * numbers in general will be written as such.
     *
     * {@link https://en.wikipedia.org/wiki/Double-precision_floating-point_format}
     */
    writeNumber(data) {
        return this.writeFloat64(data);
    }
    writeInt(data, size = 32, signed = true) {
        const buffer = new ArrayBuffer(size / 8);
        const view = new DataView(buffer);
        switch (size) {
            case 8:
                signed ? view.setInt8(0, data) : view.setUint8(0, data);
                break;
            case 16:
                signed ? view.setInt16(0, data) : view.setUint16(0, data);
                break;
            case 32:
                signed ? view.setInt32(0, data) : view.setUint32(0, data);
        }
        return this.write(new Uint8Array(buffer));
    }
    writeInt8(data) {
        return this.writeInt(data, 8, true);
    }
    writeUint8(data) {
        return this.writeInt(data, 8, false);
    }
    writeInt16(data) {
        return this.writeInt(data, 16, true);
    }
    writeUint16(data) {
        return this.writeInt(data, 16, false);
    }
    writeInt32(data) {
        return this.writeInt(data, 32, true);
    }
    writeUint32(data) {
        return this.writeInt(data, 32, false);
    }
    writeBigInt(data, size = 64, signed = true) {
        const buffer = new ArrayBuffer(size / 8);
        const view = new DataView(buffer);
        switch (size) {
            case 64:
                signed ? view.setBigInt64(0, data) : view.setBigUint64(0, data);
        }
        return this.write(new Uint8Array(buffer));
    }
    writeBigInt64(data) {
        return this.writeBigInt(data, 64, true);
    }
    writeBigUint64(data) {
        return this.writeBigInt(data, 64, false);
    }
    writeFloat(data, size = 32) {
        const buffer = new ArrayBuffer(size / 8);
        const view = new DataView(buffer);
        switch (size) {
            case 32:
                view.setFloat32(0, data);
                break;
            case 64:
                view.setFloat64(0, data);
        }
        return this.write(new Uint8Array(buffer));
    }
    writeFloat32(data) {
        return this.writeFloat(data, 32);
    }
    writeFloat64(data) {
        return this.writeFloat(data, 64);
    }
    writeBoolean(data) {
        return this.writeUint8(builtinOffset + (data ? 1 : 0));
    }
    writeUndefined() {
        return this.writeUint32(builtinOffset + 2);
    }
    writeNull() {
        return this.writeUint32(builtinOffset + 3);
    }
    writeObject(data) {
        let hash = Hash._objectHashes.get(data);
        if (hash === undefined) {
            hash = Hash._getNextHash();
            Hash._objectHashes.set(data, hash);
        }
        return this.writeUint32(hash);
    }
    writeSymbol(data) {
        let hash = Hash._symbolHashes.get(data);
        if (hash === undefined) {
            hash = Hash._getNextHash();
            Hash._symbolHashes.set(data, hash);
        }
        return this.writeUint32(hash);
    }
    writeHashable(data) {
        data.hash(this);
        return this;
    }
    writeUnknown(data) {
        switch (typeof data) {
            case "string":
                return this.writeString(data);
            case "number":
                return this.writeNumber(data);
            case "bigint":
                return this.writeBigInt(data);
            case "boolean":
                return this.writeBoolean(data);
            case "symbol":
                return this.writeSymbol(data);
            case "undefined":
                return this.writeUndefined();
            case "object":
                if (data === null) {
                    return this.writeNull();
                }
                if (hashable_1.Hashable.isHashable(data)) {
                    return this.writeHashable(data);
                }
                return this.writeObject(data);
            case "function":
                return this.writeObject(data);
        }
    }
    writeJSON(data) {
        switch (typeof data) {
            case "string":
                return this.writeString(data);
            case "number":
                return this.writeNumber(data);
            case "boolean":
                return this.writeBoolean(data);
            case "object":
                if (Array.isArray(data)) {
                    for (let i = 0, n = data.length; i < n; i++) {
                        this.writeJSON(data[i]);
                    }
                    this.writeUint32(data.length);
                }
                else if (data !== null) {
                    for (const key of keys(data).sort()) {
                        const value = data[key];
                        this.writeString(key);
                        if (value !== undefined) {
                            this.writeJSON(value);
                        }
                        // Write a null byte as a separator between key/value pairs.
                        this.writeUint8(0);
                    }
                }
                return this;
        }
    }
    equals(value) {
        return value instanceof Hash && value.finish() === this.finish();
    }
    hash(hash) {
        hash.writeUint32(this.finish());
    }
    static _getNextHash() {
        const nextHash = Hash._nextHash;
        // Increase the hash, wrapping around when it reaches the limit of 32 bits.
        Hash._nextHash = (Hash._nextHash + 1) >>> 0;
        return nextHash;
    }
}
exports.Hash = Hash;
/**
 * A map from objects to their hash values. Objects are weakly referenced as
 * to not prevent them from being garbage collected.
 */
Hash._objectHashes = new WeakMap();
/**
 * A map from symbols to their hash values. As there's not currently a way to
 * weakly reference symbols, we have to instead use strong references.
 *
 * {@link https://github.com/tc39/proposal-symbols-as-weakmap-keys}
 */
Hash._symbolHashes = new Map();
/**
 * The next available hash value. This is used for symbols and objects that
 * don't implement the {@link (Hashable:interface)} interface.
 */
Hash._nextHash = 0;
//# sourceMappingURL=hash.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-hash/src/hashable.js":
/*!*************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-hash/src/hashable.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Hashable = void 0;
const alfa_refinement_1 = __webpack_require__(/*! @siteimprove/alfa-refinement */ "./node_modules/@siteimprove/alfa-refinement/src/index.js");
const { isFunction, isObject } = alfa_refinement_1.Refinement;
/**
 * @public
 */
var Hashable;
(function (Hashable) {
    function isHashable(value) {
        return isObject(value) && isFunction(value.hash);
    }
    Hashable.isHashable = isHashable;
})(Hashable || (exports.Hashable = Hashable = {}));
//# sourceMappingURL=hashable.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-hash/src/index.js":
/*!**********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-hash/src/index.js ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(/*! ./hash */ "./node_modules/@siteimprove/alfa-hash/src/hash.js"), exports);
__exportStar(__webpack_require__(/*! ./hashable */ "./node_modules/@siteimprove/alfa-hash/src/hashable.js"), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-iterable/src/index.js":
/*!**************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-iterable/src/index.js ***!
  \**************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(/*! ./iterable */ "./node_modules/@siteimprove/alfa-iterable/src/iterable.js"), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-iterable/src/iterable.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-iterable/src/iterable.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Iterable = void 0;
const alfa_comparable_1 = __webpack_require__(/*! @siteimprove/alfa-comparable */ "./node_modules/@siteimprove/alfa-comparable/src/index.js");
const alfa_equatable_1 = __webpack_require__(/*! @siteimprove/alfa-equatable */ "./node_modules/@siteimprove/alfa-equatable/src/index.js");
const alfa_json_1 = __webpack_require__(/*! @siteimprove/alfa-json */ "./node_modules/@siteimprove/alfa-json/src/index.js");
const alfa_option_1 = __webpack_require__(/*! @siteimprove/alfa-option */ "./node_modules/@siteimprove/alfa-option/src/index.js");
const alfa_predicate_1 = __webpack_require__(/*! @siteimprove/alfa-predicate */ "./node_modules/@siteimprove/alfa-predicate/src/index.js");
const alfa_refinement_1 = __webpack_require__(/*! @siteimprove/alfa-refinement */ "./node_modules/@siteimprove/alfa-refinement/src/index.js");
const { not } = alfa_predicate_1.Predicate;
const { isObject } = alfa_refinement_1.Refinement;
const { compareComparable } = alfa_comparable_1.Comparable;
/**
 * @public
 */
var Iterable;
(function (Iterable) {
    function isIterable(value) {
        return isObject(value) && Symbol.iterator in value;
    }
    Iterable.isIterable = isIterable;
    function* empty() { }
    Iterable.empty = empty;
    function* from(arrayLike) {
        for (let i = 0, n = arrayLike.length; i < n; i++) {
            yield arrayLike[i];
        }
    }
    Iterable.from = from;
    function size(iterable) {
        return reduce(iterable, (size) => size + 1, 0);
    }
    Iterable.size = size;
    function isEmpty(iterable) {
        for (const _ of iterable) {
            return false;
        }
        return true;
    }
    Iterable.isEmpty = isEmpty;
    function forEach(iterable, callback) {
        let index = 0;
        for (const value of iterable) {
            callback(value, index++);
        }
    }
    Iterable.forEach = forEach;
    function* map(iterable, mapper) {
        let index = 0;
        for (const value of iterable) {
            yield mapper(value, index++);
        }
    }
    Iterable.map = map;
    function* flatMap(iterable, mapper) {
        let index = 0;
        for (const value of iterable) {
            yield* mapper(value, index++);
        }
    }
    Iterable.flatMap = flatMap;
    function* flatten(iterable) {
        for (const value of iterable) {
            yield* value;
        }
    }
    Iterable.flatten = flatten;
    function reduce(iterable, reducer, accumulator) {
        let index = 0;
        for (const value of iterable) {
            accumulator = reducer(accumulator, value, index++);
        }
        return accumulator;
    }
    Iterable.reduce = reduce;
    function reduceWhile(iterable, predicate, reducer, accumulator) {
        let index = 0;
        for (const value of iterable) {
            if (predicate(value, index)) {
                accumulator = reducer(accumulator, value, index++);
            }
            else {
                break;
            }
        }
        return accumulator;
    }
    Iterable.reduceWhile = reduceWhile;
    function reduceUntil(iterable, predicate, reducer, accumulator) {
        return reduceWhile(iterable, not(predicate), reducer, accumulator);
    }
    Iterable.reduceUntil = reduceUntil;
    function apply(iterable, mapper) {
        return flatMap(mapper, (mapper) => map(iterable, mapper));
    }
    Iterable.apply = apply;
    function* filter(iterable, predicate) {
        let index = 0;
        for (const value of iterable) {
            if (predicate(value, index++)) {
                yield value;
            }
        }
    }
    Iterable.filter = filter;
    function reject(iterable, predicate) {
        return filter(iterable, not(predicate));
    }
    Iterable.reject = reject;
    function find(iterable, predicate) {
        let index = 0;
        for (const value of iterable) {
            if (predicate(value, index++)) {
                return alfa_option_1.Option.of(value);
            }
        }
        return alfa_option_1.None;
    }
    Iterable.find = find;
    function findLast(iterable, predicate) {
        let index = 0;
        let result = alfa_option_1.None;
        for (const value of iterable) {
            if (predicate(value, index++)) {
                result = alfa_option_1.Option.of(value);
            }
        }
        return result;
    }
    Iterable.findLast = findLast;
    function includes(iterable, value) {
        return some(iterable, alfa_predicate_1.Predicate.equals(value));
    }
    Iterable.includes = includes;
    function collect(iterable, mapper) {
        return flatMap(iterable, mapper);
    }
    Iterable.collect = collect;
    function collectFirst(iterable, mapper) {
        return first(collect(iterable, mapper));
    }
    Iterable.collectFirst = collectFirst;
    function some(iterable, predicate) {
        let index = 0;
        for (const value of iterable) {
            if (predicate(value, index++)) {
                return true;
            }
        }
        return false;
    }
    Iterable.some = some;
    function none(iterable, predicate) {
        return every(iterable, not(predicate));
    }
    Iterable.none = none;
    function every(iterable, predicate) {
        let index = 0;
        for (const value of iterable) {
            if (!predicate(value, index++)) {
                return false;
            }
        }
        return true;
    }
    Iterable.every = every;
    function count(iterable, predicate) {
        return reduce(iterable, (count, value, index) => (predicate(value, index) ? count + 1 : count), 0);
    }
    Iterable.count = count;
    function* distinct(iterable) {
        const seen = [];
        for (const value of iterable) {
            if (seen.some(alfa_predicate_1.Predicate.equals(value))) {
                continue;
            }
            seen.push(value);
            yield value;
        }
    }
    Iterable.distinct = distinct;
    function get(iterable, index) {
        return index < 0 ? alfa_option_1.None : first(skip(iterable, index));
    }
    Iterable.get = get;
    function has(iterable, index) {
        return index < 0 ? false : !isEmpty(skip(iterable, index));
    }
    Iterable.has = has;
    function* set(iterable, index, value) {
        const it = iterator(iterable);
        while (index-- > 0) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            yield next.value;
        }
        const next = it.next();
        if (next.done === true) {
            return;
        }
        yield value;
        while (true) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            yield next.value;
        }
    }
    Iterable.set = set;
    function* insert(iterable, index, value) {
        const it = iterator(iterable);
        while (index-- > 0) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            yield next.value;
        }
        yield value;
        while (true) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            yield next.value;
        }
    }
    Iterable.insert = insert;
    function* append(iterable, value) {
        yield* iterable;
        yield value;
    }
    Iterable.append = append;
    function* prepend(iterable, value) {
        yield value;
        yield* iterable;
    }
    Iterable.prepend = prepend;
    function* concat(iterable, ...iterables) {
        yield* iterable;
        for (const iterable of iterables) {
            yield* iterable;
        }
    }
    Iterable.concat = concat;
    function subtract(iterable, ...iterables) {
        return reject(iterable, (value) => includes(flatten(iterables), value));
    }
    Iterable.subtract = subtract;
    function intersect(iterable, ...iterables) {
        return filter(iterable, (value) => includes(flatten(iterables), value));
    }
    Iterable.intersect = intersect;
    function* zip(a, b) {
        const itA = iterator(a);
        const itB = iterator(b);
        while (true) {
            const a = itA.next();
            const b = itB.next();
            if (a.done === true || b.done === true) {
                return;
            }
            yield [a.value, b.value];
        }
    }
    Iterable.zip = zip;
    function first(iterable) {
        for (const value of iterable) {
            return alfa_option_1.Option.of(value);
        }
        return alfa_option_1.None;
    }
    Iterable.first = first;
    function last(iterable) {
        let last = null;
        for (const value of iterable) {
            last = value;
        }
        return alfa_option_1.Option.from(last);
    }
    Iterable.last = last;
    function* take(iterable, count) {
        const it = iterator(iterable);
        while (count-- > 0) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            yield next.value;
        }
    }
    Iterable.take = take;
    function* takeWhile(iterable, predicate) {
        let index = 0;
        for (const value of iterable) {
            if (predicate(value, index++)) {
                yield value;
            }
            else {
                break;
            }
        }
    }
    Iterable.takeWhile = takeWhile;
    function takeUntil(iterable, predicate) {
        return takeWhile(iterable, not(predicate));
    }
    Iterable.takeUntil = takeUntil;
    function* takeLast(iterable, count = 1) {
        if (count <= 0) {
            return;
        }
        const last = [];
        for (const value of iterable) {
            last.push(value);
            if (last.length > count) {
                last.shift();
            }
        }
        yield* last;
    }
    Iterable.takeLast = takeLast;
    function* takeLastWhile(iterable, predicate) {
        const values = [...iterable];
        let last = values.length - 1;
        while (last >= 0) {
            if (predicate(values[last], last)) {
                last--;
            }
            else {
                break;
            }
        }
        for (let i = last, n = values.length - 1; i < n; i++) {
            yield values[i];
        }
    }
    Iterable.takeLastWhile = takeLastWhile;
    function takeLastUntil(iterable, predicate) {
        return takeLastWhile(iterable, not(predicate));
    }
    Iterable.takeLastUntil = takeLastUntil;
    function* skip(iterable, count) {
        const it = iterator(iterable);
        while (count-- > 0) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
        }
        while (true) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            yield next.value;
        }
    }
    Iterable.skip = skip;
    function* skipWhile(iterable, predicate) {
        let index = 0;
        let skipped = false;
        for (const value of iterable) {
            if (!skipped && predicate(value, index++)) {
                continue;
            }
            else {
                skipped = true;
                yield value;
            }
        }
    }
    Iterable.skipWhile = skipWhile;
    function skipUntil(iterable, predicate) {
        return skipWhile(iterable, not(predicate));
    }
    Iterable.skipUntil = skipUntil;
    function* skipLast(iterable, count = 1) {
        const it = iterator(iterable);
        const first = [];
        while (count-- > 0) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            first.push(next.value);
        }
        while (true) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            first.push(next.value);
            yield first.shift();
        }
    }
    Iterable.skipLast = skipLast;
    function* skipLastWhile(iterable, predicate) {
        const values = [...iterable];
        let last = values.length - 1;
        while (last >= 0) {
            if (predicate(values[last], last)) {
                last--;
            }
            else {
                break;
            }
        }
        for (let i = 0, n = last; i < n; i++) {
            yield values[i];
        }
    }
    Iterable.skipLastWhile = skipLastWhile;
    function skipLastUntil(iterable, predicate) {
        return skipLastWhile(iterable, not(predicate));
    }
    Iterable.skipLastUntil = skipLastUntil;
    function trim(iterable, predicate) {
        return trimTrailing(trimLeading(iterable, predicate), predicate);
    }
    Iterable.trim = trim;
    function trimLeading(iterable, predicate) {
        return skipWhile(iterable, predicate);
    }
    Iterable.trimLeading = trimLeading;
    function trimTrailing(iterable, predicate) {
        return skipLastWhile(iterable, predicate);
    }
    Iterable.trimTrailing = trimTrailing;
    function rest(iterable) {
        return skip(iterable, 1);
    }
    Iterable.rest = rest;
    function slice(iterable, start, end) {
        iterable = skip(iterable, start);
        if (end !== undefined) {
            iterable = take(iterable, end - start);
        }
        return iterable;
    }
    Iterable.slice = slice;
    function* reverse(iterable) {
        const array = Array.from(iterable);
        for (let i = array.length - 1; i >= 0; i--) {
            yield array[i];
        }
    }
    Iterable.reverse = reverse;
    function join(iterable, separator) {
        const it = iterator(iterable);
        let next = it.next();
        if (next.done === true) {
            return "";
        }
        let result = `${next.value}`;
        next = it.next();
        while (next.done !== true) {
            result += `${separator}${next.value}`;
            next = it.next();
        }
        return result;
    }
    Iterable.join = join;
    function sort(iterable) {
        return sortWith(iterable, compareComparable);
    }
    Iterable.sort = sort;
    function* sortWith(iterable, comparer) {
        yield* [...iterable].sort(comparer);
    }
    Iterable.sortWith = sortWith;
    function compare(a, b) {
        return compareWith(a, b, compareComparable);
    }
    Iterable.compare = compare;
    function compareWith(a, b, comparer) {
        const itA = iterator(a);
        const itB = iterator(b);
        let index = 0;
        while (true) {
            const a = itA.next();
            const b = itB.next();
            if (a.done === true) {
                return b.done === true ? alfa_comparable_1.Comparison.Equal : alfa_comparable_1.Comparison.Less;
            }
            if (b.done === true) {
                return alfa_comparable_1.Comparison.Greater;
            }
            const result = comparer(a.value, b.value, index++);
            if (result !== 0) {
                return result;
            }
        }
    }
    Iterable.compareWith = compareWith;
    function equals(a, b) {
        const itA = iterator(a);
        const itB = iterator(b);
        while (true) {
            const a = itA.next();
            const b = itB.next();
            if (a.done === true) {
                return b.done === true;
            }
            if (b.done === true || !alfa_equatable_1.Equatable.equals(a.value, b.value)) {
                return false;
            }
        }
    }
    Iterable.equals = equals;
    function hash(iterable, hash) {
        let size = 0;
        for (const value of iterable) {
            hash.writeUnknown(value);
            size++;
        }
        hash.writeUint32(size);
    }
    Iterable.hash = hash;
    function iterator(iterable) {
        return iterable[Symbol.iterator]();
    }
    Iterable.iterator = iterator;
    function groupBy(iterable, grouper) {
        const groups = [];
        let index = 0;
        for (const value of iterable) {
            const group = grouper(value, index++);
            const existing = groups.find(([existing]) => alfa_equatable_1.Equatable.equals(group, existing));
            if (existing === undefined) {
                groups.push([group, [value]]);
            }
            else {
                existing[1].push(value);
            }
        }
        return groups;
    }
    Iterable.groupBy = groupBy;
    function toJSON(iterable) {
        return [...map(iterable, (value) => alfa_json_1.Serializable.toJSON(value))];
    }
    Iterable.toJSON = toJSON;
})(Iterable || (exports.Iterable = Iterable = {}));
//# sourceMappingURL=iterable.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-json/src/builtin.js":
/*!************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-json/src/builtin.js ***!
  \************************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

// This file defines exports from the builtin `JSON` constructor for internal
// use only.
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.JSON = void 0;
/**
 * @internal
 */
const Builtin = JSON;
exports.JSON = Builtin;
//# sourceMappingURL=builtin.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-json/src/index.js":
/*!**********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-json/src/index.js ***!
  \**********************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(/*! ./json */ "./node_modules/@siteimprove/alfa-json/src/json.js"), exports);
__exportStar(__webpack_require__(/*! ./serializable */ "./node_modules/@siteimprove/alfa-json/src/serializable.js"), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-json/src/json.js":
/*!*********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-json/src/json.js ***!
  \*********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.JSON = void 0;
const builtin = __webpack_require__(/*! ./builtin */ "./node_modules/@siteimprove/alfa-json/src/builtin.js");
/**
 * @public
 */
var JSON;
(function (JSON) {
    function parse(value) {
        return builtin.JSON.parse(value);
    }
    JSON.parse = parse;
    function stringify(value) {
        return builtin.JSON.stringify(value);
    }
    JSON.stringify = stringify;
})(JSON || (exports.JSON = JSON = {}));
//# sourceMappingURL=json.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-json/src/serializable.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-json/src/serializable.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Serializable = void 0;
const alfa_refinement_1 = __webpack_require__(/*! @siteimprove/alfa-refinement */ "./node_modules/@siteimprove/alfa-refinement/src/index.js");
const { keys } = Object;
const { isArray } = Array;
const { isFunction, isObject, isString, isNumber, isBoolean, isNull } = alfa_refinement_1.Refinement;
/**
 * @public
 */
var Serializable;
(function (Serializable) {
    function isSerializable(value) {
        return isObject(value) && isFunction(value.toJSON);
    }
    Serializable.isSerializable = isSerializable;
    function toJSON(value, options) {
        if (isSerializable(value)) {
            return value.toJSON(options);
        }
        if (isString(value) ||
            isNumber(value) ||
            isBoolean(value) ||
            isNull(value)) {
            return value;
        }
        if (isArray(value)) {
            return value.map(toJSON);
        }
        if (isObject(value)) {
            const json = {};
            for (const key of keys(value)) {
                if (value[key] !== undefined) {
                    json[key] = toJSON(value[key], options);
                }
            }
            return json;
        }
        return null;
    }
    Serializable.toJSON = toJSON;
})(Serializable || (exports.Serializable = Serializable = {}));
//# sourceMappingURL=serializable.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-map/src/index.js":
/*!*********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-map/src/index.js ***!
  \*********************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(/*! ./map */ "./node_modules/@siteimprove/alfa-map/src/map.js"), exports);
__exportStar(__webpack_require__(/*! ./node */ "./node_modules/@siteimprove/alfa-map/src/node.js"), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-map/src/map.js":
/*!*******************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-map/src/map.js ***!
  \*******************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Map = void 0;
const alfa_array_1 = __webpack_require__(/*! @siteimprove/alfa-array */ "./node_modules/@siteimprove/alfa-array/src/index.js");
const alfa_fnv_1 = __webpack_require__(/*! @siteimprove/alfa-fnv */ "./node_modules/@siteimprove/alfa-fnv/src/index.js");
const alfa_iterable_1 = __webpack_require__(/*! @siteimprove/alfa-iterable */ "./node_modules/@siteimprove/alfa-iterable/src/index.js");
const alfa_json_1 = __webpack_require__(/*! @siteimprove/alfa-json */ "./node_modules/@siteimprove/alfa-json/src/index.js");
const alfa_predicate_1 = __webpack_require__(/*! @siteimprove/alfa-predicate */ "./node_modules/@siteimprove/alfa-predicate/src/index.js");
const node_1 = __webpack_require__(/*! ./node */ "./node_modules/@siteimprove/alfa-map/src/node.js");
const { not } = alfa_predicate_1.Predicate;
/**
 * @public
 */
class Map {
    static of(...entries) {
        return entries.reduce((map, [key, value]) => map.set(key, value), Map.empty());
    }
    static empty() {
        return this._empty;
    }
    constructor(root, size) {
        this._root = root;
        this._size = size;
    }
    get size() {
        return this._size;
    }
    isEmpty() {
        return this._size === 0;
    }
    forEach(callback) {
        alfa_iterable_1.Iterable.forEach(this, ([key, value]) => callback(value, key));
    }
    map(mapper) {
        return new Map(this._root.map(mapper), this._size);
    }
    /**
     * Apply a map of functions to each corresponding value of this map.
     *
     * @remarks
     * Keys without a corresponding function or value are dropped from the
     * resulting map.
     *
     * @example
     * ```ts
     * Map.of(["a", 1], ["b", 2])
     *   .apply(Map.of(["a", (x) => x + 1], ["b", (x) => x * 2]))
     *   .toArray();
     * // => [["a", 2], ["b", 4]]
     * ```
     */
    apply(mapper) {
        return this.collect((value, key) => mapper.get(key).map((mapper) => mapper(value)));
    }
    /**
     * @remarks
     * As the order of maps is undefined, it is also undefined which keys are
     * kept when duplicate keys are encountered.
     */
    flatMap(mapper) {
        return this.reduce((map, value, key) => map.concat(mapper(value, key)), Map.empty());
    }
    /**
     * @remarks
     * As the order of maps is undefined, it is also undefined which keys are
     * kept when duplicate keys are encountered.
     */
    flatten() {
        return this.flatMap((map) => map);
    }
    reduce(reducer, accumulator) {
        return alfa_iterable_1.Iterable.reduce(this, (accumulator, [key, value]) => reducer(accumulator, value, key), accumulator);
    }
    filter(predicate) {
        return this.reduce((map, value, key) => (predicate(value, key) ? map.set(key, value) : map), Map.empty());
    }
    reject(predicate) {
        return this.filter(not(predicate));
    }
    find(predicate) {
        return alfa_iterable_1.Iterable.find(this, ([key, value]) => predicate(value, key)).map(([, value]) => value);
    }
    includes(value) {
        return alfa_iterable_1.Iterable.includes(this.values(), value);
    }
    collect(mapper) {
        return Map.from(alfa_iterable_1.Iterable.collect(this, ([key, value]) => mapper(value, key).map((value) => [key, value])));
    }
    collectFirst(mapper) {
        return alfa_iterable_1.Iterable.collectFirst(this, ([key, value]) => mapper(value, key));
    }
    some(predicate) {
        return alfa_iterable_1.Iterable.some(this, ([key, value]) => predicate(value, key));
    }
    none(predicate) {
        return alfa_iterable_1.Iterable.none(this, ([key, value]) => predicate(value, key));
    }
    every(predicate) {
        return alfa_iterable_1.Iterable.every(this, ([key, value]) => predicate(value, key));
    }
    count(predicate) {
        return alfa_iterable_1.Iterable.count(this, ([key, value]) => predicate(value, key));
    }
    /**
     * @remarks
     * As the order of maps is undefined, it is also undefined which keys are
     * kept when duplicate values are encountered.
     */
    distinct() {
        let seen = Map.empty();
        // We optimize for the case where there are more distinct values than there
        // are duplicate values by starting with the current map and removing
        // duplicates as we find them.
        let map = this;
        for (const [key, value] of map) {
            if (seen.has(value)) {
                map = map.delete(key);
            }
            else {
                seen = seen.set(value, value);
            }
        }
        return map;
    }
    get(key) {
        return this._root.get(key, hash(key), 0);
    }
    has(key) {
        return this.get(key).isSome();
    }
    set(key, value) {
        const { result: root, status } = this._root.set(key, value, hash(key), 0);
        if (status === "unchanged") {
            return this;
        }
        return new Map(root, this._size + (status === "updated" ? 0 : 1));
    }
    delete(key) {
        const { result: root, status } = this._root.delete(key, hash(key), 0);
        if (status === "unchanged") {
            return this;
        }
        return new Map(root, this._size - 1);
    }
    concat(iterable) {
        return alfa_iterable_1.Iterable.reduce(iterable, (map, [key, value]) => map.set(key, value), this);
    }
    subtract(iterable) {
        return alfa_iterable_1.Iterable.reduce(iterable, (map, [key]) => map.delete(key), this);
    }
    intersect(iterable) {
        return Map.fromIterable(alfa_iterable_1.Iterable.filter(iterable, ([key]) => this.has(key)));
    }
    tee(callback, ...args) {
        callback(this, ...args);
        return this;
    }
    equals(value) {
        return (value instanceof Map &&
            value._size === this._size &&
            value._root.equals(this._root));
    }
    hash(hash) {
        for (const [key, value] of this) {
            hash.writeUnknown(key).writeUnknown(value);
        }
        hash.writeUint32(this._size);
    }
    keys() {
        return alfa_iterable_1.Iterable.map(this._root, (entry) => entry[0]);
    }
    values() {
        return alfa_iterable_1.Iterable.map(this._root, (entry) => entry[1]);
    }
    *iterator() {
        yield* this._root;
    }
    [Symbol.iterator]() {
        return this.iterator();
    }
    toArray() {
        return [...this];
    }
    toJSON() {
        return this.toArray().map(([key, value]) => [
            alfa_json_1.Serializable.toJSON(key),
            alfa_json_1.Serializable.toJSON(value),
        ]);
    }
    toString() {
        const entries = this.toArray()
            .map(([key, value]) => `${key} => ${value}`)
            .join(", ");
        return `Map {${entries === "" ? "" : ` ${entries} `}}`;
    }
}
exports.Map = Map;
Map._empty = new Map(node_1.Empty, 0);
/**
 * @public
 */
(function (Map) {
    function isMap(value) {
        return value instanceof Map;
    }
    Map.isMap = isMap;
    function from(iterable) {
        if (isMap(iterable)) {
            return iterable;
        }
        if (alfa_array_1.Array.isArray(iterable)) {
            return fromArray(iterable);
        }
        return fromIterable(iterable);
    }
    Map.from = from;
    function fromArray(array) {
        return alfa_array_1.Array.reduce(array, (map, [key, value]) => map.set(key, value), Map.empty());
    }
    Map.fromArray = fromArray;
    function fromIterable(iterable) {
        return alfa_iterable_1.Iterable.reduce(iterable, (map, [key, value]) => map.set(key, value), Map.empty());
    }
    Map.fromIterable = fromIterable;
})(Map || (exports.Map = Map = {}));
function hash(key) {
    return alfa_fnv_1.FNV.empty().writeUnknown(key).finish();
}
//# sourceMappingURL=map.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-map/src/node.js":
/*!********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-map/src/node.js ***!
  \********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Sparse = exports.Collision = exports.Leaf = exports.Empty = exports.Node = void 0;
const alfa_bits_1 = __webpack_require__(/*! @siteimprove/alfa-bits */ "./node_modules/@siteimprove/alfa-bits/src/index.js");
const alfa_equatable_1 = __webpack_require__(/*! @siteimprove/alfa-equatable */ "./node_modules/@siteimprove/alfa-equatable/src/index.js");
const alfa_option_1 = __webpack_require__(/*! @siteimprove/alfa-option */ "./node_modules/@siteimprove/alfa-option/src/index.js");
const status_1 = __webpack_require__(/*! ./status */ "./node_modules/@siteimprove/alfa-map/src/status.js");
const { bit, take, skip, test, set, clear, popCount } = alfa_bits_1.Bits;
/**
 * @internal
 */
var Node;
(function (Node) {
    Node.Bits = 5;
    function fragment(hash, shift) {
        return take(skip(hash, shift), Node.Bits);
    }
    Node.fragment = fragment;
    function index(fragment, mask) {
        return popCount(take(mask, fragment));
    }
    Node.index = index;
})(Node || (exports.Node = Node = {}));
/**
 * @internal
 */
exports.Empty = new (class Empty {
    isEmpty() {
        return true;
    }
    isLeaf() {
        return false;
    }
    get() {
        return alfa_option_1.None;
    }
    set(key, value, hash) {
        return status_1.Status.created(Leaf.of(hash, key, value));
    }
    delete() {
        return status_1.Status.unchanged(this);
    }
    map() {
        return this;
    }
    equals(value) {
        return value instanceof Empty;
    }
    *[Symbol.iterator]() { }
})();
/**
 * @internal
 */
class Leaf {
    static of(hash, key, value) {
        return new Leaf(hash, key, value);
    }
    constructor(hash, key, value) {
        this._hash = hash;
        this._key = key;
        this._value = value;
    }
    get key() {
        return this._key;
    }
    get value() {
        return this._value;
    }
    isEmpty() {
        return false;
    }
    isLeaf() {
        return true;
    }
    get(key, hash, shift) {
        return hash === this._hash && alfa_equatable_1.Equatable.equals(key, this._key)
            ? alfa_option_1.Option.of(this._value)
            : alfa_option_1.None;
    }
    set(key, value, hash, shift) {
        if (hash === this._hash) {
            if (alfa_equatable_1.Equatable.equals(key, this._key)) {
                if (alfa_equatable_1.Equatable.equals(value, this._value)) {
                    return status_1.Status.unchanged(this);
                }
                return status_1.Status.updated(Leaf.of(hash, key, value));
            }
            return status_1.Status.created(Collision.of(hash, [this, Leaf.of(hash, key, value)]));
        }
        const fragment = Node.fragment(this._hash, shift);
        return Sparse.of(bit(fragment), [this]).set(key, value, hash, shift);
    }
    delete(key, hash) {
        return hash === this._hash && alfa_equatable_1.Equatable.equals(key, this._key)
            ? status_1.Status.deleted(exports.Empty)
            : status_1.Status.unchanged(this);
    }
    map(mapper) {
        return Leaf.of(this._hash, this._key, mapper(this._value, this._key));
    }
    equals(value) {
        return (value instanceof Leaf &&
            value._hash === this._hash &&
            alfa_equatable_1.Equatable.equals(value._key, this._key) &&
            alfa_equatable_1.Equatable.equals(value._value, this._value));
    }
    *[Symbol.iterator]() {
        yield [this._key, this._value];
    }
}
exports.Leaf = Leaf;
/**
 * @internal
 */
class Collision {
    static of(hash, nodes) {
        return new Collision(hash, nodes);
    }
    constructor(hash, nodes) {
        this._hash = hash;
        this._nodes = nodes;
    }
    isEmpty() {
        return false;
    }
    isLeaf() {
        return false;
    }
    get(key, hash, shift) {
        if (hash === this._hash) {
            for (const node of this._nodes) {
                const value = node.get(key, hash, shift);
                if (value.isSome()) {
                    return value;
                }
            }
        }
        return alfa_option_1.None;
    }
    set(key, value, hash, shift) {
        if (hash === this._hash) {
            for (let i = 0, n = this._nodes.length; i < n; i++) {
                const node = this._nodes[i];
                if (alfa_equatable_1.Equatable.equals(key, node.key)) {
                    if (alfa_equatable_1.Equatable.equals(value, node.value)) {
                        return status_1.Status.unchanged(this);
                    }
                    return status_1.Status.updated(Collision.of(this._hash, replace(this._nodes, i, Leaf.of(hash, key, value))));
                }
            }
            return status_1.Status.created(Collision.of(this._hash, this._nodes.concat(Leaf.of(hash, key, value))));
        }
        const fragment = Node.fragment(this._hash, shift);
        return Sparse.of(bit(fragment), [this]).set(key, value, hash, shift);
    }
    delete(key, hash) {
        if (hash === this._hash) {
            for (let i = 0, n = this._nodes.length; i < n; i++) {
                const node = this._nodes[i];
                if (alfa_equatable_1.Equatable.equals(key, node.key)) {
                    const nodes = remove(this._nodes, i);
                    if (nodes.length === 1) {
                        // We just deleted the penultimate Leaf of the Collision, so we can
                        // remove the Collision and only keep the remaining Leaf.
                        return status_1.Status.deleted(nodes[0]);
                    }
                    return status_1.Status.deleted(Collision.of(this._hash, nodes));
                }
            }
        }
        return status_1.Status.unchanged(this);
    }
    map(mapper) {
        return Collision.of(this._hash, this._nodes.map((node) => node.map(mapper)));
    }
    equals(value) {
        return (value instanceof Collision &&
            value._hash === this._hash &&
            value._nodes.length === this._nodes.length &&
            value._nodes.every((node, i) => node.equals(this._nodes[i])));
    }
    *[Symbol.iterator]() {
        for (const node of this._nodes) {
            yield* node;
        }
    }
}
exports.Collision = Collision;
/**
 * @internal
 */
class Sparse {
    static of(mask, nodes) {
        return new Sparse(mask, nodes);
    }
    constructor(mask, nodes) {
        this._mask = mask;
        this._nodes = nodes;
    }
    isEmpty() {
        return false;
    }
    isLeaf() {
        return false;
    }
    get(key, hash, shift) {
        const fragment = Node.fragment(hash, shift);
        if (test(this._mask, fragment)) {
            const index = Node.index(fragment, this._mask);
            return this._nodes[index].get(key, hash, shift + Node.Bits);
        }
        return alfa_option_1.None;
    }
    set(key, value, hash, shift) {
        const fragment = Node.fragment(hash, shift);
        const index = Node.index(fragment, this._mask);
        if (test(this._mask, fragment)) {
            const { result: node, status } = this._nodes[index].set(key, value, hash, shift + Node.Bits);
            if (status === "unchanged") {
                return status_1.Status.unchanged(this);
            }
            const sparse = Sparse.of(this._mask, replace(this._nodes, index, node));
            switch (status) {
                case "created":
                    return status_1.Status.created(sparse);
                case "updated":
                default:
                    return status_1.Status.updated(sparse);
            }
        }
        return status_1.Status.created(Sparse.of(set(this._mask, fragment), insert(this._nodes, index, Leaf.of(hash, key, value))));
    }
    delete(key, hash, shift) {
        const fragment = Node.fragment(hash, shift);
        if (test(this._mask, fragment)) {
            const index = Node.index(fragment, this._mask);
            const { result: node, status } = this._nodes[index].delete(key, hash, shift + Node.Bits);
            if (status === "unchanged") {
                return status_1.Status.unchanged(this);
            }
            if (node.isEmpty()) {
                const nodes = remove(this._nodes, index);
                if (nodes.length === 1) {
                    // We deleted the penultimate child of the Sparse, we may be able to
                    // simplify the tree.
                    if (nodes[0].isLeaf() || nodes[0] instanceof Collision) {
                        // The last child is leaf-like, hence hashes will be fully matched
                        // against its key(s) and we can remove the current Sparse
                        return status_1.Status.deleted(nodes[0]);
                    }
                    // Otherwise, the last child is a Sparse. We can't simply collapse the
                    // tree by removing the current Sparse, since it will cause the child
                    // mask to be tested with the wrong shift (its depth in the tree would
                    // be different).
                    // We could do some further optimisations (e.g., if the child's
                    // children are all leaf-like, we could instead delete the lone child
                    // and connect directly to the grandchildren). This is, however,
                    // getting hairy to make all cases working fine, and we assume this
                    // kind of situation is not too frequent. So we pay the price of
                    // keeping a non-branching Sparse until we need to optimise that.
                }
                return status_1.Status.deleted(Sparse.of(clear(this._mask, fragment), nodes));
            }
            return status_1.Status.deleted(Sparse.of(this._mask, replace(this._nodes, index, node)));
        }
        return status_1.Status.unchanged(this);
    }
    map(mapper) {
        return Sparse.of(this._mask, this._nodes.map((node) => node.map(mapper)));
    }
    equals(value) {
        return (value instanceof Sparse &&
            value._mask === this._mask &&
            value._nodes.length === this._nodes.length &&
            value._nodes.every((node, i) => node.equals(this._nodes[i])));
    }
    *[Symbol.iterator]() {
        for (const node of this._nodes) {
            yield* node;
        }
    }
}
exports.Sparse = Sparse;
function insert(array, index, value) {
    const result = new Array(array.length + 1);
    result[index] = value;
    for (let i = 0, n = index; i < n; i++) {
        result[i] = array[i];
    }
    for (let i = index, n = array.length; i < n; i++) {
        result[i + 1] = array[i];
    }
    return result;
}
function remove(array, index) {
    const result = new Array(array.length - 1);
    for (let i = 0, n = index; i < n; i++) {
        result[i] = array[i];
    }
    for (let i = index, n = result.length; i < n; i++) {
        result[i] = array[i + 1];
    }
    return result;
}
function replace(array, index, value) {
    const result = array.slice(0);
    result[index] = value;
    return result;
}
//# sourceMappingURL=node.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-map/src/status.js":
/*!**********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-map/src/status.js ***!
  \**********************************************************/
/***/ ((__unused_webpack_module, exports) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Status = void 0;
/**
 * @internal
 */
var Status;
(function (Status_1) {
    class Status {
        constructor(result) {
            this._result = result;
        }
        get result() {
            return this._result;
        }
    }
    class Created extends Status {
        static of(result) {
            return new Created(result);
        }
        constructor(result) {
            super(result);
        }
        get status() {
            return "created";
        }
    }
    Status_1.Created = Created;
    Status_1.created = Created.of;
    class Updated extends Status {
        static of(result) {
            return new Updated(result);
        }
        constructor(result) {
            super(result);
        }
        get status() {
            return "updated";
        }
    }
    Status_1.Updated = Updated;
    Status_1.updated = Updated.of;
    class Deleted extends Status {
        static of(result) {
            return new Deleted(result);
        }
        constructor(result) {
            super(result);
        }
        get status() {
            return "deleted";
        }
    }
    Status_1.Deleted = Deleted;
    Status_1.deleted = Deleted.of;
    class Unchanged extends Status {
        static of(result) {
            return new Unchanged(result);
        }
        constructor(result) {
            super(result);
        }
        get status() {
            return "unchanged";
        }
    }
    Status_1.Unchanged = Unchanged;
    Status_1.unchanged = Unchanged.of;
})(Status || (exports.Status = Status = {}));
//# sourceMappingURL=status.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-option/src/index.js":
/*!************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-option/src/index.js ***!
  \************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(/*! ./maybe */ "./node_modules/@siteimprove/alfa-option/src/maybe.js"), exports);
__exportStar(__webpack_require__(/*! ./none */ "./node_modules/@siteimprove/alfa-option/src/none.js"), exports);
__exportStar(__webpack_require__(/*! ./option */ "./node_modules/@siteimprove/alfa-option/src/option.js"), exports);
__exportStar(__webpack_require__(/*! ./some */ "./node_modules/@siteimprove/alfa-option/src/some.js"), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-option/src/maybe.js":
/*!************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-option/src/maybe.js ***!
  \************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Maybe = void 0;
const option_1 = __webpack_require__(/*! ./option */ "./node_modules/@siteimprove/alfa-option/src/option.js");
/**
 * @internal
 */
var Maybe;
(function (Maybe) {
    function toOption(maybe) {
        return option_1.Option.isOption(maybe) ? maybe : option_1.Option.of(maybe);
    }
    Maybe.toOption = toOption;
})(Maybe || (exports.Maybe = Maybe = {}));
//# sourceMappingURL=maybe.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-option/src/none.js":
/*!***********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-option/src/none.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.None = void 0;
const alfa_comparable_1 = __webpack_require__(/*! @siteimprove/alfa-comparable */ "./node_modules/@siteimprove/alfa-comparable/src/index.js");
const { compareComparable } = alfa_comparable_1.Comparable;
/**
 * @public
 */
exports.None = new (class None {
    isSome() {
        return false;
    }
    isNone() {
        return true;
    }
    map() {
        return this;
    }
    forEach() {
        return;
    }
    apply() {
        return this;
    }
    flatMap() {
        return this;
    }
    flatten() {
        return this;
    }
    reduce(reducer, accumulator) {
        return accumulator;
    }
    filter() {
        return this;
    }
    reject() {
        return this;
    }
    includes() {
        return false;
    }
    some() {
        return false;
    }
    none() {
        return true;
    }
    every() {
        return true;
    }
    and() {
        return this;
    }
    andThen() {
        return this;
    }
    or(option) {
        return option;
    }
    orElse(option) {
        return option();
    }
    /**
     * @internal
     */
    getUnsafe(message = "Attempted to .getUnsafe() from None") {
        throw new Error(message);
    }
    getOr(value) {
        return value;
    }
    getOrElse(value) {
        return value();
    }
    tee() {
        return this;
    }
    compare(option) {
        return this.compareWith(option, compareComparable);
    }
    compareWith(option) {
        return option.isNone() ? alfa_comparable_1.Comparison.Equal : alfa_comparable_1.Comparison.Less;
    }
    equals(value) {
        return value instanceof None;
    }
    hash(hash) {
        hash.writeBoolean(false);
    }
    *[Symbol.iterator]() { }
    toArray() {
        return [];
    }
    toJSON() {
        return {
            type: "none",
        };
    }
    toString() {
        return "None";
    }
})();
//# sourceMappingURL=none.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-option/src/option.js":
/*!*************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-option/src/option.js ***!
  \*************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Option = void 0;
const none_1 = __webpack_require__(/*! ./none */ "./node_modules/@siteimprove/alfa-option/src/none.js");
const some_1 = __webpack_require__(/*! ./some */ "./node_modules/@siteimprove/alfa-option/src/some.js");
/**
 * @public
 */
var Option;
(function (Option) {
    function isOption(value) {
        return isSome(value) || isNone(value);
    }
    Option.isOption = isOption;
    function isSome(value) {
        return some_1.Some.isSome(value);
    }
    Option.isSome = isSome;
    function isNone(value) {
        return value === none_1.None;
    }
    Option.isNone = isNone;
    function of(value) {
        return some_1.Some.of(value);
    }
    Option.of = of;
    function empty() {
        return none_1.None;
    }
    Option.empty = empty;
    function from(value) {
        return value === null || value === undefined ? none_1.None : some_1.Some.of(value);
    }
    Option.from = from;
})(Option || (exports.Option = Option = {}));
//# sourceMappingURL=option.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-option/src/some.js":
/*!***********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-option/src/some.js ***!
  \***********************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Some = void 0;
const alfa_comparable_1 = __webpack_require__(/*! @siteimprove/alfa-comparable */ "./node_modules/@siteimprove/alfa-comparable/src/index.js");
const alfa_equatable_1 = __webpack_require__(/*! @siteimprove/alfa-equatable */ "./node_modules/@siteimprove/alfa-equatable/src/index.js");
const alfa_json_1 = __webpack_require__(/*! @siteimprove/alfa-json */ "./node_modules/@siteimprove/alfa-json/src/index.js");
const alfa_predicate_1 = __webpack_require__(/*! @siteimprove/alfa-predicate */ "./node_modules/@siteimprove/alfa-predicate/src/index.js");
const none_1 = __webpack_require__(/*! ./none */ "./node_modules/@siteimprove/alfa-option/src/none.js");
const { not, test } = alfa_predicate_1.Predicate;
const { compareComparable } = alfa_comparable_1.Comparable;
/**
 * @public
 */
class Some {
    static of(value) {
        return new Some(value);
    }
    constructor(value) {
        this._value = value;
    }
    isSome() {
        return true;
    }
    isNone() {
        return false;
    }
    map(mapper) {
        return new Some(mapper(this._value));
    }
    forEach(mapper) {
        mapper(this._value);
    }
    apply(mapper) {
        return mapper.map((mapper) => mapper(this._value));
    }
    flatMap(mapper) {
        return mapper(this._value);
    }
    flatten() {
        return this._value;
    }
    reduce(reducer, accumulator) {
        return reducer(accumulator, this._value);
    }
    filter(predicate) {
        return test(predicate, this._value) ? this : none_1.None;
    }
    reject(predicate) {
        return this.filter(not(predicate));
    }
    includes(value) {
        return alfa_equatable_1.Equatable.equals(value, this._value);
    }
    some(predicate) {
        return test(predicate, this._value);
    }
    none(predicate) {
        return test(not(predicate), this._value);
    }
    every(predicate) {
        return test(predicate, this._value);
    }
    and(option) {
        return option;
    }
    andThen(option) {
        return option(this._value);
    }
    or() {
        return this;
    }
    orElse() {
        return this;
    }
    get() {
        return this._value;
    }
    /**
     * @internal
     */
    getUnsafe() {
        return this._value;
    }
    getOr() {
        return this._value;
    }
    getOrElse() {
        return this._value;
    }
    tee(callback) {
        callback(this._value);
        return this;
    }
    compare(option) {
        return this.compareWith(option, compareComparable);
    }
    compareWith(option, comparer) {
        return option.isSome()
            ? comparer(this._value, option._value)
            : alfa_comparable_1.Comparison.Greater;
    }
    equals(value) {
        return value instanceof Some && alfa_equatable_1.Equatable.equals(value._value, this._value);
    }
    hash(hash) {
        hash.writeBoolean(true).writeUnknown(this._value);
    }
    *[Symbol.iterator]() {
        yield this._value;
    }
    toArray() {
        return [this._value];
    }
    toJSON() {
        return {
            type: "some",
            value: alfa_json_1.Serializable.toJSON(this._value),
        };
    }
    toString() {
        return `Some { ${this._value} }`;
    }
}
exports.Some = Some;
/**
 * @public
 */
(function (Some) {
    function isSome(value) {
        return value instanceof Some;
    }
    Some.isSome = isSome;
})(Some || (exports.Some = Some = {}));
//# sourceMappingURL=some.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-predicate/src/index.js":
/*!***************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-predicate/src/index.js ***!
  \***************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(/*! ./predicate */ "./node_modules/@siteimprove/alfa-predicate/src/predicate.js"), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-predicate/src/predicate.js":
/*!*******************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-predicate/src/predicate.js ***!
  \*******************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Predicate = void 0;
const alfa_equatable_1 = __webpack_require__(/*! @siteimprove/alfa-equatable */ "./node_modules/@siteimprove/alfa-equatable/src/index.js");
/**
 * @public
 */
var Predicate;
(function (Predicate) {
    function test(predicate, value, ...args) {
        return predicate(value, ...args);
    }
    Predicate.test = test;
    function fold(predicate, ifTrue, ifFalse, value, ...args) {
        return predicate(value, ...args) ? ifTrue(value) : ifFalse(value);
    }
    Predicate.fold = fold;
    function not(predicate) {
        return (value, ...args) => !predicate(value, ...args);
    }
    Predicate.not = not;
    function and(...predicates) {
        return (value, ...args) => {
            for (let i = 0, n = predicates.length; i < n; i++) {
                if (!predicates[i](value, ...args)) {
                    return false;
                }
            }
            return true;
        };
    }
    Predicate.and = and;
    function or(...predicates) {
        return (value, ...args) => {
            for (let i = 0, n = predicates.length; i < n; i++) {
                if (predicates[i](value, ...args)) {
                    return true;
                }
            }
            return false;
        };
    }
    Predicate.or = or;
    function xor(...predicates) {
        return and(or(...predicates), not(and(...predicates)));
    }
    Predicate.xor = xor;
    function nor(...predicates) {
        return not(or(...predicates));
    }
    Predicate.nor = nor;
    function nand(...predicates) {
        return not(and(...predicates));
    }
    Predicate.nand = nand;
    function equals(...values) {
        return (other) => values.some((value) => alfa_equatable_1.Equatable.equals(other, value));
    }
    Predicate.equals = equals;
    function property(property, predicate) {
        return (value, ...args) => predicate(value[property], ...args);
    }
    Predicate.property = property;
    function tee(predicate, callback) {
        return (value, ...args) => {
            const result = predicate(value, ...args);
            callback(value, result, ...args);
            return result;
        };
    }
    Predicate.tee = tee;
})(Predicate || (exports.Predicate = Predicate = {}));
//# sourceMappingURL=predicate.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-refinement/src/index.js":
/*!****************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-refinement/src/index.js ***!
  \****************************************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {

"use strict";

var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(/*! ./refinement */ "./node_modules/@siteimprove/alfa-refinement/src/refinement.js"), exports);
//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-refinement/src/refinement.js":
/*!*********************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-refinement/src/refinement.js ***!
  \*********************************************************************/
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {

"use strict";

Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Refinement = void 0;
const alfa_predicate_1 = __webpack_require__(/*! @siteimprove/alfa-predicate */ "./node_modules/@siteimprove/alfa-predicate/src/index.js");
/**
 * @public
 */
var Refinement;
(function (Refinement) {
    Refinement.test = alfa_predicate_1.Predicate.test;
    Refinement.fold = alfa_predicate_1.Predicate.fold;
    Refinement.not = alfa_predicate_1.Predicate.not;
    Refinement.and = alfa_predicate_1.Predicate.and;
    Refinement.or = alfa_predicate_1.Predicate.or;
    Refinement.xor = alfa_predicate_1.Predicate.xor;
    Refinement.nor = alfa_predicate_1.Predicate.nor;
    Refinement.nand = alfa_predicate_1.Predicate.nand;
    Refinement.equals = alfa_predicate_1.Predicate.equals;
    function isString(value) {
        return typeof value === "string";
    }
    Refinement.isString = isString;
    function isNumber(value) {
        return typeof value === "number";
    }
    Refinement.isNumber = isNumber;
    function isBigInt(value) {
        return typeof value === "bigint";
    }
    Refinement.isBigInt = isBigInt;
    function isBoolean(value) {
        return typeof value === "boolean";
    }
    Refinement.isBoolean = isBoolean;
    function isNull(value) {
        return value === null;
    }
    Refinement.isNull = isNull;
    function isUndefined(value) {
        return value === undefined;
    }
    Refinement.isUndefined = isUndefined;
    function isSymbol(value) {
        return typeof value === "symbol";
    }
    Refinement.isSymbol = isSymbol;
    function isFunction(value) {
        return typeof value === "function";
    }
    Refinement.isFunction = isFunction;
    function isObject(value) {
        return typeof value === "object" && value !== null;
    }
    Refinement.isObject = isObject;
    Refinement.isPrimitive = Refinement.or(isString, Refinement.or(isNumber, Refinement.or(isBigInt, Refinement.or(isBoolean, Refinement.or(isNull, Refinement.or(isUndefined, isSymbol))))));
})(Refinement || (exports.Refinement = Refinement = {}));
//# sourceMappingURL=refinement.js.map

/***/ }),

/***/ "./node_modules/webextension-polyfill/dist/browser-polyfill.js":
/*!*********************************************************************!*\
  !*** ./node_modules/webextension-polyfill/dist/browser-polyfill.js ***!
  \*********************************************************************/
/***/ (function(module, exports) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;(function (global, factory) {
  if (true) {
    !(__WEBPACK_AMD_DEFINE_ARRAY__ = [module], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory),
		__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
		(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  } else { var mod; }
})(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : this, function (module) {
  /* webextension-polyfill - v0.10.0 - Fri Aug 12 2022 19:42:44 */

  /* -*- Mode: indent-tabs-mode: nil; js-indent-level: 2 -*- */

  /* vim: set sts=2 sw=2 et tw=80: */

  /* This Source Code Form is subject to the terms of the Mozilla Public
   * License, v. 2.0. If a copy of the MPL was not distributed with this
   * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
  "use strict";

  if (!globalThis.chrome?.runtime?.id) {
    throw new Error("This script should only be loaded in a browser extension.");
  }

  if (typeof globalThis.browser === "undefined" || Object.getPrototypeOf(globalThis.browser) !== Object.prototype) {
    const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received."; // Wrapping the bulk of this polyfill in a one-time-use function is a minor
    // optimization for Firefox. Since Spidermonkey does not fully parse the
    // contents of a function until the first time it's called, and since it will
    // never actually need to be called, this allows the polyfill to be included
    // in Firefox nearly for free.

    const wrapAPIs = extensionAPIs => {
      // NOTE: apiMetadata is associated to the content of the api-metadata.json file
      // at build time by replacing the following "include" with the content of the
      // JSON file.
      const apiMetadata = {
        "alarms": {
          "clear": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "clearAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "get": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "bookmarks": {
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getChildren": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getRecent": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getSubTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTree": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "browserAction": {
          "disable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "enable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "getBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getBadgeText": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "openPopup": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setBadgeText": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "browsingData": {
          "remove": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "removeCache": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCookies": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeDownloads": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFormData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeHistory": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeLocalStorage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePasswords": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePluginData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "settings": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "commands": {
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "contextMenus": {
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "cookies": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAllCookieStores": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "set": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "devtools": {
          "inspectedWindow": {
            "eval": {
              "minArgs": 1,
              "maxArgs": 2,
              "singleCallbackArg": false
            }
          },
          "panels": {
            "create": {
              "minArgs": 3,
              "maxArgs": 3,
              "singleCallbackArg": true
            },
            "elements": {
              "createSidebarPane": {
                "minArgs": 1,
                "maxArgs": 1
              }
            }
          }
        },
        "downloads": {
          "cancel": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "download": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "erase": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFileIcon": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "open": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "pause": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFile": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "resume": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "extension": {
          "isAllowedFileSchemeAccess": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "isAllowedIncognitoAccess": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "history": {
          "addUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "deleteRange": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getVisits": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "i18n": {
          "detectLanguage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAcceptLanguages": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "identity": {
          "launchWebAuthFlow": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "idle": {
          "queryState": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "management": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getSelf": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setEnabled": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "uninstallSelf": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "notifications": {
          "clear": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPermissionLevel": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "pageAction": {
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "hide": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "permissions": {
          "contains": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "request": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "runtime": {
          "getBackgroundPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPlatformInfo": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "openOptionsPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "requestUpdateCheck": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "sendMessage": {
            "minArgs": 1,
            "maxArgs": 3
          },
          "sendNativeMessage": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "setUninstallURL": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "sessions": {
          "getDevices": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getRecentlyClosed": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "restore": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "storage": {
          "local": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "managed": {
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            }
          },
          "sync": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          }
        },
        "tabs": {
          "captureVisibleTab": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "detectLanguage": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "discard": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "duplicate": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "executeScript": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getZoom": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getZoomSettings": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goBack": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goForward": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "highlight": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "insertCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "query": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "reload": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "sendMessage": {
            "minArgs": 2,
            "maxArgs": 3
          },
          "setZoom": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "setZoomSettings": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "update": {
            "minArgs": 1,
            "maxArgs": 2
          }
        },
        "topSites": {
          "get": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "webNavigation": {
          "getAllFrames": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFrame": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "webRequest": {
          "handlerBehaviorChanged": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "windows": {
          "create": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getLastFocused": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        }
      };

      if (Object.keys(apiMetadata).length === 0) {
        throw new Error("api-metadata.json has not been included in browser-polyfill");
      }
      /**
       * A WeakMap subclass which creates and stores a value for any key which does
       * not exist when accessed, but behaves exactly as an ordinary WeakMap
       * otherwise.
       *
       * @param {function} createItem
       *        A function which will be called in order to create the value for any
       *        key which does not exist, the first time it is accessed. The
       *        function receives, as its only argument, the key being created.
       */


      class DefaultWeakMap extends WeakMap {
        constructor(createItem, items = undefined) {
          super(items);
          this.createItem = createItem;
        }

        get(key) {
          if (!this.has(key)) {
            this.set(key, this.createItem(key));
          }

          return super.get(key);
        }

      }
      /**
       * Returns true if the given object is an object with a `then` method, and can
       * therefore be assumed to behave as a Promise.
       *
       * @param {*} value The value to test.
       * @returns {boolean} True if the value is thenable.
       */


      const isThenable = value => {
        return value && typeof value === "object" && typeof value.then === "function";
      };
      /**
       * Creates and returns a function which, when called, will resolve or reject
       * the given promise based on how it is called:
       *
       * - If, when called, `chrome.runtime.lastError` contains a non-null object,
       *   the promise is rejected with that value.
       * - If the function is called with exactly one argument, the promise is
       *   resolved to that value.
       * - Otherwise, the promise is resolved to an array containing all of the
       *   function's arguments.
       *
       * @param {object} promise
       *        An object containing the resolution and rejection functions of a
       *        promise.
       * @param {function} promise.resolve
       *        The promise's resolution function.
       * @param {function} promise.reject
       *        The promise's rejection function.
       * @param {object} metadata
       *        Metadata about the wrapped method which has created the callback.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function}
       *        The generated callback function.
       */


      const makeCallback = (promise, metadata) => {
        return (...callbackArgs) => {
          if (extensionAPIs.runtime.lastError) {
            promise.reject(new Error(extensionAPIs.runtime.lastError.message));
          } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
            promise.resolve(callbackArgs[0]);
          } else {
            promise.resolve(callbackArgs);
          }
        };
      };

      const pluralizeArguments = numArgs => numArgs == 1 ? "argument" : "arguments";
      /**
       * Creates a wrapper function for a method with the given name and metadata.
       *
       * @param {string} name
       *        The name of the method which is being wrapped.
       * @param {object} metadata
       *        Metadata about the method being wrapped.
       * @param {integer} metadata.minArgs
       *        The minimum number of arguments which must be passed to the
       *        function. If called with fewer than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {integer} metadata.maxArgs
       *        The maximum number of arguments which may be passed to the
       *        function. If called with more than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function(object, ...*)}
       *       The generated wrapper function.
       */


      const wrapAsyncFunction = (name, metadata) => {
        return function asyncFunctionWrapper(target, ...args) {
          if (args.length < metadata.minArgs) {
            throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
          }

          if (args.length > metadata.maxArgs) {
            throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
          }

          return new Promise((resolve, reject) => {
            if (metadata.fallbackToNoCallback) {
              // This API method has currently no callback on Chrome, but it return a promise on Firefox,
              // and so the polyfill will try to call it with a callback first, and it will fallback
              // to not passing the callback if the first call fails.
              try {
                target[name](...args, makeCallback({
                  resolve,
                  reject
                }, metadata));
              } catch (cbError) {
                console.warn(`${name} API method doesn't seem to support the callback parameter, ` + "falling back to call it without a callback: ", cbError);
                target[name](...args); // Update the API method metadata, so that the next API calls will not try to
                // use the unsupported callback anymore.

                metadata.fallbackToNoCallback = false;
                metadata.noCallback = true;
                resolve();
              }
            } else if (metadata.noCallback) {
              target[name](...args);
              resolve();
            } else {
              target[name](...args, makeCallback({
                resolve,
                reject
              }, metadata));
            }
          });
        };
      };
      /**
       * Wraps an existing method of the target object, so that calls to it are
       * intercepted by the given wrapper function. The wrapper function receives,
       * as its first argument, the original `target` object, followed by each of
       * the arguments passed to the original method.
       *
       * @param {object} target
       *        The original target object that the wrapped method belongs to.
       * @param {function} method
       *        The method being wrapped. This is used as the target of the Proxy
       *        object which is created to wrap the method.
       * @param {function} wrapper
       *        The wrapper function which is called in place of a direct invocation
       *        of the wrapped method.
       *
       * @returns {Proxy<function>}
       *        A Proxy object for the given method, which invokes the given wrapper
       *        method in its place.
       */


      const wrapMethod = (target, method, wrapper) => {
        return new Proxy(method, {
          apply(targetMethod, thisObj, args) {
            return wrapper.call(thisObj, target, ...args);
          }

        });
      };

      let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
      /**
       * Wraps an object in a Proxy which intercepts and wraps certain methods
       * based on the given `wrappers` and `metadata` objects.
       *
       * @param {object} target
       *        The target object to wrap.
       *
       * @param {object} [wrappers = {}]
       *        An object tree containing wrapper functions for special cases. Any
       *        function present in this object tree is called in place of the
       *        method in the same location in the `target` object tree. These
       *        wrapper methods are invoked as described in {@see wrapMethod}.
       *
       * @param {object} [metadata = {}]
       *        An object tree containing metadata used to automatically generate
       *        Promise-based wrapper functions for asynchronous. Any function in
       *        the `target` object tree which has a corresponding metadata object
       *        in the same location in the `metadata` tree is replaced with an
       *        automatically-generated wrapper function, as described in
       *        {@see wrapAsyncFunction}
       *
       * @returns {Proxy<object>}
       */

      const wrapObject = (target, wrappers = {}, metadata = {}) => {
        let cache = Object.create(null);
        let handlers = {
          has(proxyTarget, prop) {
            return prop in target || prop in cache;
          },

          get(proxyTarget, prop, receiver) {
            if (prop in cache) {
              return cache[prop];
            }

            if (!(prop in target)) {
              return undefined;
            }

            let value = target[prop];

            if (typeof value === "function") {
              // This is a method on the underlying object. Check if we need to do
              // any wrapping.
              if (typeof wrappers[prop] === "function") {
                // We have a special-case wrapper for this method.
                value = wrapMethod(target, target[prop], wrappers[prop]);
              } else if (hasOwnProperty(metadata, prop)) {
                // This is an async method that we have metadata for. Create a
                // Promise wrapper for it.
                let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                value = wrapMethod(target, target[prop], wrapper);
              } else {
                // This is a method that we don't know or care about. Return the
                // original method, bound to the underlying object.
                value = value.bind(target);
              }
            } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
              // This is an object that we need to do some wrapping for the children
              // of. Create a sub-object wrapper for it with the appropriate child
              // metadata.
              value = wrapObject(value, wrappers[prop], metadata[prop]);
            } else if (hasOwnProperty(metadata, "*")) {
              // Wrap all properties in * namespace.
              value = wrapObject(value, wrappers[prop], metadata["*"]);
            } else {
              // We don't need to do any wrapping for this property,
              // so just forward all access to the underlying object.
              Object.defineProperty(cache, prop, {
                configurable: true,
                enumerable: true,

                get() {
                  return target[prop];
                },

                set(value) {
                  target[prop] = value;
                }

              });
              return value;
            }

            cache[prop] = value;
            return value;
          },

          set(proxyTarget, prop, value, receiver) {
            if (prop in cache) {
              cache[prop] = value;
            } else {
              target[prop] = value;
            }

            return true;
          },

          defineProperty(proxyTarget, prop, desc) {
            return Reflect.defineProperty(cache, prop, desc);
          },

          deleteProperty(proxyTarget, prop) {
            return Reflect.deleteProperty(cache, prop);
          }

        }; // Per contract of the Proxy API, the "get" proxy handler must return the
        // original value of the target if that value is declared read-only and
        // non-configurable. For this reason, we create an object with the
        // prototype set to `target` instead of using `target` directly.
        // Otherwise we cannot return a custom object for APIs that
        // are declared read-only and non-configurable, such as `chrome.devtools`.
        //
        // The proxy handlers themselves will still use the original `target`
        // instead of the `proxyTarget`, so that the methods and properties are
        // dereferenced via the original targets.

        let proxyTarget = Object.create(target);
        return new Proxy(proxyTarget, handlers);
      };
      /**
       * Creates a set of wrapper functions for an event object, which handles
       * wrapping of listener functions that those messages are passed.
       *
       * A single wrapper is created for each listener function, and stored in a
       * map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
       * retrieve the original wrapper, so that  attempts to remove a
       * previously-added listener work as expected.
       *
       * @param {DefaultWeakMap<function, function>} wrapperMap
       *        A DefaultWeakMap object which will create the appropriate wrapper
       *        for a given listener function when one does not exist, and retrieve
       *        an existing one when it does.
       *
       * @returns {object}
       */


      const wrapEvent = wrapperMap => ({
        addListener(target, listener, ...args) {
          target.addListener(wrapperMap.get(listener), ...args);
        },

        hasListener(target, listener) {
          return target.hasListener(wrapperMap.get(listener));
        },

        removeListener(target, listener) {
          target.removeListener(wrapperMap.get(listener));
        }

      });

      const onRequestFinishedWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }
        /**
         * Wraps an onRequestFinished listener function so that it will return a
         * `getContent()` property which returns a `Promise` rather than using a
         * callback API.
         *
         * @param {object} req
         *        The HAR entry object representing the network request.
         */


        return function onRequestFinished(req) {
          const wrappedReq = wrapObject(req, {}
          /* wrappers */
          , {
            getContent: {
              minArgs: 0,
              maxArgs: 0
            }
          });
          listener(wrappedReq);
        };
      });
      const onMessageWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }
        /**
         * Wraps a message listener function so that it may send responses based on
         * its return value, rather than by returning a sentinel value and calling a
         * callback. If the listener function returns a Promise, the response is
         * sent when the promise either resolves or rejects.
         *
         * @param {*} message
         *        The message sent by the other end of the channel.
         * @param {object} sender
         *        Details about the sender of the message.
         * @param {function(*)} sendResponse
         *        A callback which, when called with an arbitrary argument, sends
         *        that value as a response.
         * @returns {boolean}
         *        True if the wrapped listener returned a Promise, which will later
         *        yield a response. False otherwise.
         */


        return function onMessage(message, sender, sendResponse) {
          let didCallSendResponse = false;
          let wrappedSendResponse;
          let sendResponsePromise = new Promise(resolve => {
            wrappedSendResponse = function (response) {
              didCallSendResponse = true;
              resolve(response);
            };
          });
          let result;

          try {
            result = listener(message, sender, wrappedSendResponse);
          } catch (err) {
            result = Promise.reject(err);
          }

          const isResultThenable = result !== true && isThenable(result); // If the listener didn't returned true or a Promise, or called
          // wrappedSendResponse synchronously, we can exit earlier
          // because there will be no response sent from this listener.

          if (result !== true && !isResultThenable && !didCallSendResponse) {
            return false;
          } // A small helper to send the message if the promise resolves
          // and an error if the promise rejects (a wrapped sendMessage has
          // to translate the message into a resolved promise or a rejected
          // promise).


          const sendPromisedResult = promise => {
            promise.then(msg => {
              // send the message value.
              sendResponse(msg);
            }, error => {
              // Send a JSON representation of the error if the rejected value
              // is an instance of error, or the object itself otherwise.
              let message;

              if (error && (error instanceof Error || typeof error.message === "string")) {
                message = error.message;
              } else {
                message = "An unexpected error occurred";
              }

              sendResponse({
                __mozWebExtensionPolyfillReject__: true,
                message
              });
            }).catch(err => {
              // Print an error on the console if unable to send the response.
              console.error("Failed to send onMessage rejected reply", err);
            });
          }; // If the listener returned a Promise, send the resolved value as a
          // result, otherwise wait the promise related to the wrappedSendResponse
          // callback to resolve and send it as a response.


          if (isResultThenable) {
            sendPromisedResult(result);
          } else {
            sendPromisedResult(sendResponsePromise);
          } // Let Chrome know that the listener is replying.


          return true;
        };
      });

      const wrappedSendMessageCallback = ({
        reject,
        resolve
      }, reply) => {
        if (extensionAPIs.runtime.lastError) {
          // Detect when none of the listeners replied to the sendMessage call and resolve
          // the promise to undefined as in Firefox.
          // See https://github.com/mozilla/webextension-polyfill/issues/130
          if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
            resolve();
          } else {
            reject(new Error(extensionAPIs.runtime.lastError.message));
          }
        } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
          // Convert back the JSON representation of the error into
          // an Error instance.
          reject(new Error(reply.message));
        } else {
          resolve(reply);
        }
      };

      const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
        if (args.length < metadata.minArgs) {
          throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
        }

        if (args.length > metadata.maxArgs) {
          throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
        }

        return new Promise((resolve, reject) => {
          const wrappedCb = wrappedSendMessageCallback.bind(null, {
            resolve,
            reject
          });
          args.push(wrappedCb);
          apiNamespaceObj.sendMessage(...args);
        });
      };

      const staticWrappers = {
        devtools: {
          network: {
            onRequestFinished: wrapEvent(onRequestFinishedWrappers)
          }
        },
        runtime: {
          onMessage: wrapEvent(onMessageWrappers),
          onMessageExternal: wrapEvent(onMessageWrappers),
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 1,
            maxArgs: 3
          })
        },
        tabs: {
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 2,
            maxArgs: 3
          })
        }
      };
      const settingMetadata = {
        clear: {
          minArgs: 1,
          maxArgs: 1
        },
        get: {
          minArgs: 1,
          maxArgs: 1
        },
        set: {
          minArgs: 1,
          maxArgs: 1
        }
      };
      apiMetadata.privacy = {
        network: {
          "*": settingMetadata
        },
        services: {
          "*": settingMetadata
        },
        websites: {
          "*": settingMetadata
        }
      };
      return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
    }; // The build process adds a UMD wrapper around this file, which makes the
    // `module` variable available.


    module.exports = wrapAPIs(chrome);
  } else {
    module.exports = globalThis.browser;
  }
});
//# sourceMappingURL=browser-polyfill.js.map


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
/*!************************!*\
  !*** ./src/api/api.ts ***!
  \************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _siteimprove_alfa_map__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-map */ "./node_modules/@siteimprove/alfa-map/src/index.js");
/* harmony import */ var _siteimprove_alfa_map__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_siteimprove_alfa_map__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @siteimprove/alfa-option */ "./node_modules/@siteimprove/alfa-option/src/index.js");
/* harmony import */ var _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! webextension-polyfill */ "./node_modules/webextension-polyfill/dist/browser-polyfill.js");
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(webextension_polyfill__WEBPACK_IMPORTED_MODULE_2__);
/**
 * This is the main entry point to what we refer to as the API of the extension.
 * The API handles most interactions with Alfa, the browser, and the page being
 * tested and exposes an interface for the application code to call through
 * messaging.
 *
 * The API is run as a possibly non-persistent background script (or service
 * worker, depending on browsers) in the browser.
 * It must therefore not depend on any global state as such state will be lost
 * when the background script is unloaded.
 *
 * Notably, this forces the popup to connect directly to the devtools instance
 * of the inspected page; and this forces the popup map to be stored in local
 * storage.
 */





/**
 * Storage keys
 */
const POPUP_KEY = "popupsMap";

/**
 * Map from tabId to open popup.
 *
 * @remarks
 * Every listener will reload the popups map, to make sure it is up-to-date.
 * Listeners that update it also save it.
 * When clicking the extension button, we also take time to clean it, in case
 * anything bad happened at some point.
 */

let myPopups = _siteimprove_alfa_map__WEBPACK_IMPORTED_MODULE_0__.Map.empty();
async function loadPopupsMap() {
  const popups = await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().storage.local.get(POPUP_KEY);
  myPopups = _siteimprove_alfa_map__WEBPACK_IMPORTED_MODULE_0__.Map.from(popups?.[POPUP_KEY] ?? []);
}
async function savePopupsMap() {
  await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().storage.local.set({
    [POPUP_KEY]: myPopups.toArray()
  });
}
async function windowExists(windowId) {
  if (windowId === undefined) {
    return false;
  }
  try {
    await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().windows.get(windowId);
    return true;
  } catch (e) {
    // We assume errors mostly occur due to non-existent window.
    return false;
  }
}

/**
 * Remove entries with no corresponding opened window
 *
 * @remarks
 * This should not happen since the service worker should restart and clean
 * the map on window removed. This is however not expensive because we assume
 * the map will be small; and this prevents a possible vector of memory leak
 * since this is persistent storage and we have requested unlimited storage
 * permission.
 */
async function cleanPopupsMap() {
  let existing = _siteimprove_alfa_map__WEBPACK_IMPORTED_MODULE_0__.Map.empty();
  for (const [tabId, popup] of myPopups) {
    if (await windowExists(popup.windowId)) {
      existing = existing.set(tabId, popup);
    }
  }
  myPopups = existing;
}

/**
 * Cleanup popup-map when a popup window is closed.
 *
 * @remarks
 * This is triggered by the other listeners closing popup windows.
 */
webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().windows.onRemoved.addListener(async windowId => {
  await loadPopupsMap();
  let key = _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_1__.None;
  myPopups.find((popup, tabId) => {
    if (popup.windowId === windowId) {
      key = _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_1__.Option.of(tabId);
      return true;
    }
    return false;
  });
  key.forEach(key => myPopups = myPopups.delete(key));
  await savePopupsMap();
});

/**
 * Close popup if user navigate to another page.
 */
webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().tabs.onUpdated.addListener(async tabId => {
  await loadPopupsMap();
  const currentPopup = myPopups.get(tabId).getOr(undefined);
  if (currentPopup?.windowId) {
    // Close the popup if the url changes
    const tab = await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().tabs.get(tabId);
    if (currentPopup?.url !== tab.url && navigator.userAgent.indexOf("Firefox") === -1) {
      await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().windows.remove(currentPopup.windowId);
    }
  }
});

/**
 * Close popup if the audited tab is closed.
 */
webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().tabs.onRemoved.addListener(async tabId => {
  await loadPopupsMap();
  const currentPopup = myPopups.get(tabId).getOr(undefined);
  if (currentPopup?.windowId) {
    // Close the popup if the tab is closed
    await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().windows.remove(currentPopup.windowId);
  }
});

/**
 * Open popup when icon is clicked.
 * If the popup is open, close it.
 */
webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().action.onClicked.addListener(async tab => {
  // Bail out immediately if we cannot get a tabId
  if (!tab.id) {
    return;
  }
  await loadPopupsMap();
  await cleanPopupsMap();

  // If the current tab already has an extension popup, close the popup.
  const currentPopup = myPopups.get(tab.id).getOr(undefined);
  if (currentPopup?.windowId) {
    await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().windows.remove(currentPopup.windowId);
    return;
  }

  // Otherwise, open a new popup.
  const popupUrl = new URL(webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().runtime.getURL("app.html"));

  /**
   * Pass along the tab ID as a query parameter. The application code uses this
   * when making API calls.
   */
  popupUrl.searchParams.set("tabId", tab.id?.toString(10) || "");
  const popup = await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().windows.create({
    url: popupUrl.toString(),
    type: "panel",
    height: 600,
    width: 800
  });
  myPopups = myPopups.set(tab.id, {
    windowId: popup.id,
    url: tab.url
  });
  await savePopupsMap();
});
})();

/******/ })()
;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBpLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7O0FDclZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7O0FDVkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7QUN0QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQ2xEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7O0FDakJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7O0FDYkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQ2pCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7QUNuSkE7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQ0ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7QUNqQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7QUNuQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQ3hEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7O0FDbERBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQ2xCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7O0FDckRBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7QUNqQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7O0FDakNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7QUNqQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQ3BOQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7QUNmQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7QUNsQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQ2pCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQ25pQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7QUNWQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7QUNsQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7O0FDbEJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQzFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7QUNsQkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7O0FDcE9BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQ3JUQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7QUNyRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQ3BCQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7O0FDZEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7QUN2R0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQ25DQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQ3JJQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7O0FDakJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7OztBQ3hFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7O0FDakJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7OztBQ3hEQTtBQUNBO0FBQ0E7QUFBQTtBQUFBO0FBQUE7QUFDQTtBQVNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7OztBQ3B2Q0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7O0FDdkJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7O0FDUEE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7QUNQQTs7Ozs7QUNBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDTkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtYXJyYXkvc3JjL2FycmF5LmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtYXJyYXkvc3JjL2J1aWx0aW4uanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1hcnJheS9zcmMvaW5kZXguanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1iaXRzL3NyYy9iaXRzLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtYml0cy9zcmMvaW5kZXguanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1jbG9uZS9zcmMvY2xvbmUuanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1jbG9uZS9zcmMvaW5kZXguanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1jb21wYXJhYmxlL3NyYy9jb21wYXJhYmxlLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtY29tcGFyYWJsZS9zcmMvY29tcGFyZXIuanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1jb21wYXJhYmxlL3NyYy9jb21wYXJpc29uLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtY29tcGFyYWJsZS9zcmMvaW5kZXguanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1lbmNvZGluZy9zcmMvZGVjb2Rlci5qcyIsIndlYnBhY2s6Ly9Ac2l0ZWltcHJvdmUvYWxmYS13ZWItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLWVuY29kaW5nL3NyYy9lbmNvZGVyLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtZW5jb2Rpbmcvc3JjL2luZGV4LmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtZXF1YXRhYmxlL3NyYy9lcXVhdGFibGUuanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1lcXVhdGFibGUvc3JjL2luZGV4LmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtZm52L3NyYy9mbnYuanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1mbnYvc3JjL2luZGV4LmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtaGFzaC9zcmMvaGFzaC5qcyIsIndlYnBhY2s6Ly9Ac2l0ZWltcHJvdmUvYWxmYS13ZWItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLWhhc2gvc3JjL2hhc2hhYmxlLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtaGFzaC9zcmMvaW5kZXguanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1pdGVyYWJsZS9zcmMvaW5kZXguanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1pdGVyYWJsZS9zcmMvaXRlcmFibGUuanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1qc29uL3NyYy9idWlsdGluLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtanNvbi9zcmMvaW5kZXguanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1qc29uL3NyYy9qc29uLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtanNvbi9zcmMvc2VyaWFsaXphYmxlLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtbWFwL3NyYy9pbmRleC5qcyIsIndlYnBhY2s6Ly9Ac2l0ZWltcHJvdmUvYWxmYS13ZWItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLW1hcC9zcmMvbWFwLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtbWFwL3NyYy9ub2RlLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtbWFwL3NyYy9zdGF0dXMuanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1vcHRpb24vc3JjL2luZGV4LmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtb3B0aW9uL3NyYy9tYXliZS5qcyIsIndlYnBhY2s6Ly9Ac2l0ZWltcHJvdmUvYWxmYS13ZWItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLW9wdGlvbi9zcmMvbm9uZS5qcyIsIndlYnBhY2s6Ly9Ac2l0ZWltcHJvdmUvYWxmYS13ZWItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLW9wdGlvbi9zcmMvb3B0aW9uLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtb3B0aW9uL3NyYy9zb21lLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtcHJlZGljYXRlL3NyYy9pbmRleC5qcyIsIndlYnBhY2s6Ly9Ac2l0ZWltcHJvdmUvYWxmYS13ZWItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLXByZWRpY2F0ZS9zcmMvcHJlZGljYXRlLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtcmVmaW5lbWVudC9zcmMvaW5kZXguanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1yZWZpbmVtZW50L3NyYy9yZWZpbmVtZW50LmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvd2ViZXh0ZW5zaW9uLXBvbHlmaWxsL2Rpc3QvYnJvd3Nlci1wb2x5ZmlsbC5qcyIsIndlYnBhY2s6Ly9Ac2l0ZWltcHJvdmUvYWxmYS13ZWItZXh0ZW5zaW9uL3dlYnBhY2svYm9vdHN0cmFwIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vd2VicGFjay9ydW50aW1lL2NvbXBhdCBnZXQgZGVmYXVsdCBleHBvcnQiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi93ZWJwYWNrL3J1bnRpbWUvZGVmaW5lIHByb3BlcnR5IGdldHRlcnMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi93ZWJwYWNrL3J1bnRpbWUvaGFzT3duUHJvcGVydHkgc2hvcnRoYW5kIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vd2VicGFjay9ydW50aW1lL21ha2UgbmFtZXNwYWNlIG9iamVjdCIsIndlYnBhY2s6Ly9Ac2l0ZWltcHJvdmUvYWxmYS13ZWItZXh0ZW5zaW9uLy4vc3JjL2FwaS9hcGkudHMiXSwic291cmNlc0NvbnRlbnQiOlsiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5leHBvcnRzLkFycmF5ID0gdm9pZCAwO1xuY29uc3QgYWxmYV9jbG9uZV8xID0gcmVxdWlyZShcIkBzaXRlaW1wcm92ZS9hbGZhLWNsb25lXCIpO1xuY29uc3QgYWxmYV9jb21wYXJhYmxlXzEgPSByZXF1aXJlKFwiQHNpdGVpbXByb3ZlL2FsZmEtY29tcGFyYWJsZVwiKTtcbmNvbnN0IGFsZmFfZXF1YXRhYmxlXzEgPSByZXF1aXJlKFwiQHNpdGVpbXByb3ZlL2FsZmEtZXF1YXRhYmxlXCIpO1xuY29uc3QgYWxmYV9pdGVyYWJsZV8xID0gcmVxdWlyZShcIkBzaXRlaW1wcm92ZS9hbGZhLWl0ZXJhYmxlXCIpO1xuY29uc3QgYWxmYV9qc29uXzEgPSByZXF1aXJlKFwiQHNpdGVpbXByb3ZlL2FsZmEtanNvblwiKTtcbmNvbnN0IGFsZmFfb3B0aW9uXzEgPSByZXF1aXJlKFwiQHNpdGVpbXByb3ZlL2FsZmEtb3B0aW9uXCIpO1xuY29uc3QgYWxmYV9wcmVkaWNhdGVfMSA9IHJlcXVpcmUoXCJAc2l0ZWltcHJvdmUvYWxmYS1wcmVkaWNhdGVcIik7XG5jb25zdCBidWlsdGluID0gcmVxdWlyZShcIi4vYnVpbHRpblwiKTtcbmNvbnN0IHsgbm90IH0gPSBhbGZhX3ByZWRpY2F0ZV8xLlByZWRpY2F0ZTtcbmNvbnN0IHsgY29tcGFyZUNvbXBhcmFibGUgfSA9IGFsZmFfY29tcGFyYWJsZV8xLkNvbXBhcmFibGU7XG4vKipcbiAqIEBwdWJsaWNcbiAqL1xudmFyIEFycmF5O1xuKGZ1bmN0aW9uIChBcnJheSkge1xuICAgIGZ1bmN0aW9uIGlzQXJyYXkodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIGJ1aWx0aW4uQXJyYXkuaXNBcnJheSh2YWx1ZSk7XG4gICAgfVxuICAgIEFycmF5LmlzQXJyYXkgPSBpc0FycmF5O1xuICAgIGZ1bmN0aW9uIG9mKC4uLnZhbHVlcykge1xuICAgICAgICByZXR1cm4gdmFsdWVzO1xuICAgIH1cbiAgICBBcnJheS5vZiA9IG9mO1xuICAgIGZ1bmN0aW9uIGVtcHR5KCkge1xuICAgICAgICByZXR1cm4gW107XG4gICAgfVxuICAgIEFycmF5LmVtcHR5ID0gZW1wdHk7XG4gICAgZnVuY3Rpb24gYWxsb2NhdGUoY2FwYWNpdHkpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBidWlsdGluLkFycmF5KGNhcGFjaXR5KTtcbiAgICB9XG4gICAgQXJyYXkuYWxsb2NhdGUgPSBhbGxvY2F0ZTtcbiAgICAvKipcbiAgICAgKiBAcmVtYXJrc1xuICAgICAqIFVubGlrZSB0aGUgYnVpbHQtaW4gZnVuY3Rpb24gb2YgdGhlIHNhbWUgbmFtZSwgdGhpcyBmdW5jdGlvbiB3aWxsIHBhc3NcbiAgICAgKiBhbG9uZyBleGlzdGluZyBhcnJheXMgYXMtaXMgaW5zdGVhZCBvZiByZXR1cm5pbmcgYSBjb3B5LlxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGZyb20oaXRlcmFibGUpIHtcbiAgICAgICAgaWYgKGlzQXJyYXkoaXRlcmFibGUpKSB7XG4gICAgICAgICAgICByZXR1cm4gaXRlcmFibGU7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIFsuLi5pdGVyYWJsZV07XG4gICAgfVxuICAgIEFycmF5LmZyb20gPSBmcm9tO1xuICAgIGZ1bmN0aW9uIHNpemUoYXJyYXkpIHtcbiAgICAgICAgcmV0dXJuIGFycmF5Lmxlbmd0aDtcbiAgICB9XG4gICAgQXJyYXkuc2l6ZSA9IHNpemU7XG4gICAgZnVuY3Rpb24gaXNFbXB0eShhcnJheSkge1xuICAgICAgICByZXR1cm4gYXJyYXkubGVuZ3RoID09PSAwO1xuICAgIH1cbiAgICBBcnJheS5pc0VtcHR5ID0gaXNFbXB0eTtcbiAgICBmdW5jdGlvbiBjb3B5KGFycmF5KSB7XG4gICAgICAgIHJldHVybiBhcnJheS5zbGljZSgwKTtcbiAgICB9XG4gICAgQXJyYXkuY29weSA9IGNvcHk7XG4gICAgZnVuY3Rpb24gY2xvbmUoYXJyYXkpIHtcbiAgICAgICAgcmV0dXJuIGFycmF5Lm1hcChhbGZhX2Nsb25lXzEuQ2xvbmUuY2xvbmUpO1xuICAgIH1cbiAgICBBcnJheS5jbG9uZSA9IGNsb25lO1xuICAgIGZ1bmN0aW9uIGZvckVhY2goYXJyYXksIGNhbGxiYWNrKSB7XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBuID0gYXJyYXkubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICBjYWxsYmFjayhhcnJheVtpXSwgaSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgQXJyYXkuZm9yRWFjaCA9IGZvckVhY2g7XG4gICAgZnVuY3Rpb24gbWFwKGFycmF5LCBtYXBwZXIpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gbmV3IGJ1aWx0aW4uQXJyYXkoYXJyYXkubGVuZ3RoKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG4gPSBhcnJheS5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIHJlc3VsdFtpXSA9IG1hcHBlcihhcnJheVtpXSwgaSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgQXJyYXkubWFwID0gbWFwO1xuICAgIGZ1bmN0aW9uIGZsYXRNYXAoYXJyYXksIG1hcHBlcikge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBlbXB0eSgpO1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IGFycmF5Lmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgcmVzdWx0LnB1c2goLi4ubWFwcGVyKGFycmF5W2ldLCBpKSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgQXJyYXkuZmxhdE1hcCA9IGZsYXRNYXA7XG4gICAgZnVuY3Rpb24gZmxhdHRlbihhcnJheSkge1xuICAgICAgICByZXR1cm4gZmxhdE1hcChhcnJheSwgKGFycmF5KSA9PiBhcnJheSk7XG4gICAgfVxuICAgIEFycmF5LmZsYXR0ZW4gPSBmbGF0dGVuO1xuICAgIGZ1bmN0aW9uIHJlZHVjZShhcnJheSwgcmVkdWNlciwgYWNjdW11bGF0b3IpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG4gPSBhcnJheS5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIGFjY3VtdWxhdG9yID0gcmVkdWNlcihhY2N1bXVsYXRvciwgYXJyYXlbaV0sIGkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBhY2N1bXVsYXRvcjtcbiAgICB9XG4gICAgQXJyYXkucmVkdWNlID0gcmVkdWNlO1xuICAgIGZ1bmN0aW9uIHJlZHVjZVdoaWxlKGFycmF5LCBwcmVkaWNhdGUsIHJlZHVjZXIsIGFjY3VtdWxhdG9yKSB7XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBuID0gYXJyYXkubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCB2YWx1ZSA9IGFycmF5W2ldO1xuICAgICAgICAgICAgaWYgKHByZWRpY2F0ZSh2YWx1ZSwgaSkpIHtcbiAgICAgICAgICAgICAgICBhY2N1bXVsYXRvciA9IHJlZHVjZXIoYWNjdW11bGF0b3IsIHZhbHVlLCBpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBhY2N1bXVsYXRvcjtcbiAgICB9XG4gICAgQXJyYXkucmVkdWNlV2hpbGUgPSByZWR1Y2VXaGlsZTtcbiAgICBmdW5jdGlvbiByZWR1Y2VVbnRpbChhcnJheSwgcHJlZGljYXRlLCByZWR1Y2VyLCBhY2N1bXVsYXRvcikge1xuICAgICAgICByZXR1cm4gcmVkdWNlV2hpbGUoYXJyYXksIG5vdChwcmVkaWNhdGUpLCByZWR1Y2VyLCBhY2N1bXVsYXRvcik7XG4gICAgfVxuICAgIEFycmF5LnJlZHVjZVVudGlsID0gcmVkdWNlVW50aWw7XG4gICAgZnVuY3Rpb24gYXBwbHkoYXJyYXksIG1hcHBlcikge1xuICAgICAgICByZXR1cm4gZmxhdE1hcChtYXBwZXIsIChtYXBwZXIpID0+IG1hcChhcnJheSwgbWFwcGVyKSk7XG4gICAgfVxuICAgIEFycmF5LmFwcGx5ID0gYXBwbHk7XG4gICAgZnVuY3Rpb24gZmlsdGVyKGFycmF5LCBwcmVkaWNhdGUpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gZW1wdHkoKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG4gPSBhcnJheS5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gYXJyYXlbaV07XG4gICAgICAgICAgICBpZiAocHJlZGljYXRlKHZhbHVlLCBpKSkge1xuICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKHZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBBcnJheS5maWx0ZXIgPSBmaWx0ZXI7XG4gICAgZnVuY3Rpb24gcmVqZWN0KGFycmF5LCBwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIGZpbHRlcihhcnJheSwgbm90KHByZWRpY2F0ZSkpO1xuICAgIH1cbiAgICBBcnJheS5yZWplY3QgPSByZWplY3Q7XG4gICAgZnVuY3Rpb24gZmluZChhcnJheSwgcHJlZGljYXRlKSB7XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBuID0gYXJyYXkubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCB2YWx1ZSA9IGFycmF5W2ldO1xuICAgICAgICAgICAgaWYgKHByZWRpY2F0ZSh2YWx1ZSwgaSkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gYWxmYV9vcHRpb25fMS5PcHRpb24ub2YodmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBhbGZhX29wdGlvbl8xLk5vbmU7XG4gICAgfVxuICAgIEFycmF5LmZpbmQgPSBmaW5kO1xuICAgIGZ1bmN0aW9uIGZpbmRMYXN0KGFycmF5LCBwcmVkaWNhdGUpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IGFycmF5Lmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgICAgICAgICBjb25zdCB2YWx1ZSA9IGFycmF5W2ldO1xuICAgICAgICAgICAgaWYgKHByZWRpY2F0ZSh2YWx1ZSwgaSkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gYWxmYV9vcHRpb25fMS5PcHRpb24ub2YodmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBhbGZhX29wdGlvbl8xLk5vbmU7XG4gICAgfVxuICAgIEFycmF5LmZpbmRMYXN0ID0gZmluZExhc3Q7XG4gICAgZnVuY3Rpb24gaW5jbHVkZXMoYXJyYXksIHZhbHVlKSB7XG4gICAgICAgIHJldHVybiBzb21lKGFycmF5LCBhbGZhX3ByZWRpY2F0ZV8xLlByZWRpY2F0ZS5lcXVhbHModmFsdWUpKTtcbiAgICB9XG4gICAgQXJyYXkuaW5jbHVkZXMgPSBpbmNsdWRlcztcbiAgICBmdW5jdGlvbiBjb2xsZWN0KGFycmF5LCBtYXBwZXIpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gZW1wdHkoKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG4gPSBhcnJheS5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIGZvciAoY29uc3QgdmFsdWUgb2YgbWFwcGVyKGFycmF5W2ldLCBpKSkge1xuICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKHZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBBcnJheS5jb2xsZWN0ID0gY29sbGVjdDtcbiAgICBmdW5jdGlvbiBjb2xsZWN0Rmlyc3QoYXJyYXksIG1hcHBlcikge1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IGFycmF5Lmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBtYXBwZXIoYXJyYXlbaV0sIGkpO1xuICAgICAgICAgICAgaWYgKHZhbHVlLmlzU29tZSgpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBhbGZhX29wdGlvbl8xLk5vbmU7XG4gICAgfVxuICAgIEFycmF5LmNvbGxlY3RGaXJzdCA9IGNvbGxlY3RGaXJzdDtcbiAgICBmdW5jdGlvbiBzb21lKGFycmF5LCBwcmVkaWNhdGUpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG4gPSBhcnJheS5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIGlmIChwcmVkaWNhdGUoYXJyYXlbaV0sIGkpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBBcnJheS5zb21lID0gc29tZTtcbiAgICBmdW5jdGlvbiBub25lKGFycmF5LCBwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIGV2ZXJ5KGFycmF5LCBub3QocHJlZGljYXRlKSk7XG4gICAgfVxuICAgIEFycmF5Lm5vbmUgPSBub25lO1xuICAgIGZ1bmN0aW9uIGV2ZXJ5KGFycmF5LCBwcmVkaWNhdGUpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG4gPSBhcnJheS5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIGlmICghcHJlZGljYXRlKGFycmF5W2ldLCBpKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgQXJyYXkuZXZlcnkgPSBldmVyeTtcbiAgICBmdW5jdGlvbiBjb3VudChhcnJheSwgcHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiByZWR1Y2UoYXJyYXksIChjb3VudCwgdmFsdWUsIGluZGV4KSA9PiAocHJlZGljYXRlKHZhbHVlLCBpbmRleCkgPyBjb3VudCArIDEgOiBjb3VudCksIDApO1xuICAgIH1cbiAgICBBcnJheS5jb3VudCA9IGNvdW50O1xuICAgIGZ1bmN0aW9uIGRpc3RpbmN0KGFycmF5KSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGVtcHR5KCk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBuID0gYXJyYXkubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCB2YWx1ZSA9IGFycmF5W2ldO1xuICAgICAgICAgICAgaWYgKHJlc3VsdC5zb21lKGFsZmFfcHJlZGljYXRlXzEuUHJlZGljYXRlLmVxdWFscyh2YWx1ZSkpKSB7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXN1bHQucHVzaCh2YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgQXJyYXkuZGlzdGluY3QgPSBkaXN0aW5jdDtcbiAgICBmdW5jdGlvbiBnZXQoYXJyYXksIGluZGV4KSB7XG4gICAgICAgIHJldHVybiBpbmRleCA8IGFycmF5Lmxlbmd0aCA/IGFsZmFfb3B0aW9uXzEuT3B0aW9uLm9mKGFycmF5W2luZGV4XSkgOiBhbGZhX29wdGlvbl8xLk5vbmU7XG4gICAgfVxuICAgIEFycmF5LmdldCA9IGdldDtcbiAgICBmdW5jdGlvbiBoYXMoYXJyYXksIGluZGV4KSB7XG4gICAgICAgIHJldHVybiBpbmRleCA8IGFycmF5Lmxlbmd0aDtcbiAgICB9XG4gICAgQXJyYXkuaGFzID0gaGFzO1xuICAgIGZ1bmN0aW9uIHNldChhcnJheSwgaW5kZXgsIHZhbHVlKSB7XG4gICAgICAgIGlmIChpbmRleCA8IGFycmF5Lmxlbmd0aCkge1xuICAgICAgICAgICAgYXJyYXlbaW5kZXhdID0gdmFsdWU7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGFycmF5O1xuICAgIH1cbiAgICBBcnJheS5zZXQgPSBzZXQ7XG4gICAgZnVuY3Rpb24gaW5zZXJ0KGFycmF5LCBpbmRleCwgdmFsdWUpIHtcbiAgICAgICAgaWYgKGluZGV4IDw9IGFycmF5Lmxlbmd0aCkge1xuICAgICAgICAgICAgYXJyYXkuc3BsaWNlKGluZGV4LCAwLCB2YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGFycmF5O1xuICAgIH1cbiAgICBBcnJheS5pbnNlcnQgPSBpbnNlcnQ7XG4gICAgZnVuY3Rpb24gYXBwZW5kKGFycmF5LCB2YWx1ZSkge1xuICAgICAgICBhcnJheS5wdXNoKHZhbHVlKTtcbiAgICAgICAgcmV0dXJuIGFycmF5O1xuICAgIH1cbiAgICBBcnJheS5hcHBlbmQgPSBhcHBlbmQ7XG4gICAgZnVuY3Rpb24gcHJlcGVuZChhcnJheSwgdmFsdWUpIHtcbiAgICAgICAgYXJyYXkudW5zaGlmdCh2YWx1ZSk7XG4gICAgICAgIHJldHVybiBhcnJheTtcbiAgICB9XG4gICAgQXJyYXkucHJlcGVuZCA9IHByZXBlbmQ7XG4gICAgZnVuY3Rpb24gY29uY2F0KGFycmF5LCAuLi5pdGVyYWJsZXMpIHtcbiAgICAgICAgcmV0dXJuIFsuLi5hbGZhX2l0ZXJhYmxlXzEuSXRlcmFibGUuY29uY2F0KGFycmF5LCAuLi5pdGVyYWJsZXMpXTtcbiAgICB9XG4gICAgQXJyYXkuY29uY2F0ID0gY29uY2F0O1xuICAgIGZ1bmN0aW9uIHN1YnRyYWN0KGFycmF5LCAuLi5pdGVyYWJsZXMpIHtcbiAgICAgICAgcmV0dXJuIFsuLi5hbGZhX2l0ZXJhYmxlXzEuSXRlcmFibGUuc3VidHJhY3QoYXJyYXksIC4uLml0ZXJhYmxlcyldO1xuICAgIH1cbiAgICBBcnJheS5zdWJ0cmFjdCA9IHN1YnRyYWN0O1xuICAgIGZ1bmN0aW9uIGludGVyc2VjdChhcnJheSwgLi4uaXRlcmFibGVzKSB7XG4gICAgICAgIHJldHVybiBbLi4uYWxmYV9pdGVyYWJsZV8xLkl0ZXJhYmxlLmludGVyc2VjdChhcnJheSwgLi4uaXRlcmFibGVzKV07XG4gICAgfVxuICAgIEFycmF5LmludGVyc2VjdCA9IGludGVyc2VjdDtcbiAgICBmdW5jdGlvbiB6aXAoYXJyYXksIGl0ZXJhYmxlKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGVtcHR5KCk7XG4gICAgICAgIGNvbnN0IGl0ID0gYWxmYV9pdGVyYWJsZV8xLkl0ZXJhYmxlLml0ZXJhdG9yKGl0ZXJhYmxlKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG4gPSBhcnJheS5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IG5leHQgPSBpdC5uZXh0KCk7XG4gICAgICAgICAgICBpZiAobmV4dC5kb25lID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXN1bHQucHVzaChbYXJyYXlbaV0sIG5leHQudmFsdWVdKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBBcnJheS56aXAgPSB6aXA7XG4gICAgZnVuY3Rpb24gZmlyc3QoYXJyYXkpIHtcbiAgICAgICAgcmV0dXJuIGFycmF5Lmxlbmd0aCA+IDAgPyBhbGZhX29wdGlvbl8xLk9wdGlvbi5vZihhcnJheVswXSkgOiBhbGZhX29wdGlvbl8xLk5vbmU7XG4gICAgfVxuICAgIEFycmF5LmZpcnN0ID0gZmlyc3Q7XG4gICAgZnVuY3Rpb24gbGFzdChhcnJheSkge1xuICAgICAgICByZXR1cm4gYXJyYXkubGVuZ3RoID4gMCA/IGFsZmFfb3B0aW9uXzEuT3B0aW9uLm9mKGFycmF5W2FycmF5Lmxlbmd0aCAtIDFdKSA6IGFsZmFfb3B0aW9uXzEuTm9uZTtcbiAgICB9XG4gICAgQXJyYXkubGFzdCA9IGxhc3Q7XG4gICAgZnVuY3Rpb24gc29ydChhcnJheSkge1xuICAgICAgICByZXR1cm4gc29ydFdpdGgoYXJyYXksIGNvbXBhcmVDb21wYXJhYmxlKTtcbiAgICB9XG4gICAgQXJyYXkuc29ydCA9IHNvcnQ7XG4gICAgZnVuY3Rpb24gc29ydFdpdGgoYXJyYXksIGNvbXBhcmVyKSB7XG4gICAgICAgIHJldHVybiBhcnJheS5zb3J0KGNvbXBhcmVyKTtcbiAgICB9XG4gICAgQXJyYXkuc29ydFdpdGggPSBzb3J0V2l0aDtcbiAgICBmdW5jdGlvbiBjb21wYXJlKGEsIGIpIHtcbiAgICAgICAgcmV0dXJuIGNvbXBhcmVXaXRoKGEsIGIsIGNvbXBhcmVDb21wYXJhYmxlKTtcbiAgICB9XG4gICAgQXJyYXkuY29tcGFyZSA9IGNvbXBhcmU7XG4gICAgZnVuY3Rpb24gY29tcGFyZVdpdGgoYSwgYiwgY29tcGFyZXIpIHtcbiAgICAgICAgcmV0dXJuIGFsZmFfaXRlcmFibGVfMS5JdGVyYWJsZS5jb21wYXJlV2l0aChhLCBiLCBjb21wYXJlcik7XG4gICAgfVxuICAgIEFycmF5LmNvbXBhcmVXaXRoID0gY29tcGFyZVdpdGg7XG4gICAgZnVuY3Rpb24gc2VhcmNoKGFycmF5LCB2YWx1ZSwgY29tcGFyZXIpIHtcbiAgICAgICAgbGV0IGxvd2VyID0gMDtcbiAgICAgICAgbGV0IHVwcGVyID0gYXJyYXkubGVuZ3RoIC0gMTtcbiAgICAgICAgd2hpbGUgKGxvd2VyIDw9IHVwcGVyKSB7XG4gICAgICAgICAgICBjb25zdCBtaWRkbGUgPSAobG93ZXIgKyAodXBwZXIgLSBsb3dlcikgLyAyKSA+Pj4gMDtcbiAgICAgICAgICAgIHN3aXRjaCAoY29tcGFyZXIodmFsdWUsIGFycmF5W21pZGRsZV0pKSB7XG4gICAgICAgICAgICAgICAgY2FzZSBhbGZhX2NvbXBhcmFibGVfMS5Db21wYXJpc29uLkdyZWF0ZXI6XG4gICAgICAgICAgICAgICAgICAgIGxvd2VyID0gbWlkZGxlICsgMTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSBhbGZhX2NvbXBhcmFibGVfMS5Db21wYXJpc29uLkxlc3M6XG4gICAgICAgICAgICAgICAgICAgIHVwcGVyID0gbWlkZGxlIC0gMTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSBhbGZhX2NvbXBhcmFibGVfMS5Db21wYXJpc29uLkVxdWFsOlxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbWlkZGxlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBsb3dlcjtcbiAgICB9XG4gICAgQXJyYXkuc2VhcmNoID0gc2VhcmNoO1xuICAgIGZ1bmN0aW9uIGVxdWFscyhhLCBiKSB7XG4gICAgICAgIGlmIChhLmxlbmd0aCAhPT0gYi5sZW5ndGgpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IGEubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICBpZiAoIWFsZmFfZXF1YXRhYmxlXzEuRXF1YXRhYmxlLmVxdWFscyhhW2ldLCBiW2ldKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgQXJyYXkuZXF1YWxzID0gZXF1YWxzO1xuICAgIGZ1bmN0aW9uIGhhc2goYXJyYXksIGhhc2gpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG4gPSBhcnJheS5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIGhhc2gud3JpdGVVbmtub3duKGFycmF5W2ldKTtcbiAgICAgICAgfVxuICAgICAgICBoYXNoLndyaXRlVWludDMyKGFycmF5Lmxlbmd0aCk7XG4gICAgfVxuICAgIEFycmF5Lmhhc2ggPSBoYXNoO1xuICAgIGZ1bmN0aW9uIGl0ZXJhdG9yKGFycmF5KSB7XG4gICAgICAgIHJldHVybiBhcnJheVtTeW1ib2wuaXRlcmF0b3JdKCk7XG4gICAgfVxuICAgIEFycmF5Lml0ZXJhdG9yID0gaXRlcmF0b3I7XG4gICAgZnVuY3Rpb24gdG9KU09OKGFycmF5KSB7XG4gICAgICAgIHJldHVybiBhcnJheS5tYXAoKHZhbHVlKSA9PiBhbGZhX2pzb25fMS5TZXJpYWxpemFibGUudG9KU09OKHZhbHVlKSk7XG4gICAgfVxuICAgIEFycmF5LnRvSlNPTiA9IHRvSlNPTjtcbn0pKEFycmF5IHx8IChleHBvcnRzLkFycmF5ID0gQXJyYXkgPSB7fSkpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YXJyYXkuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG4vLyBUaGlzIGZpbGUgZGVmaW5lcyBleHBvcnRzIGZyb20gdGhlIGJ1aWx0aW4gYEFycmF5YCBjb25zdHJ1Y3RvciBmb3IgaW50ZXJuYWxcbi8vIHVzZSBvbmx5LlxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5BcnJheSA9IHZvaWQgMDtcbi8qKlxuICogQGludGVybmFsXG4gKi9cbmNvbnN0IEJ1aWx0aW4gPSBBcnJheTtcbmV4cG9ydHMuQXJyYXkgPSBCdWlsdGluO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YnVpbHRpbi5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbi8qKlxuICogVGhpcyBwYWNrYWdlIHByb3ZpZGVzIGZ1bmN0aW9uYWxpdHkgZm9yIHdvcmtpbmcgd2l0aCBhcnJheXMuXG4gKlxuICogQHBhY2thZ2VEb2N1bWVudGF0aW9uXG4gKi9cbnZhciBfX2NyZWF0ZUJpbmRpbmcgPSAodGhpcyAmJiB0aGlzLl9fY3JlYXRlQmluZGluZykgfHwgKE9iamVjdC5jcmVhdGUgPyAoZnVuY3Rpb24obywgbSwgaywgazIpIHtcbiAgICBpZiAoazIgPT09IHVuZGVmaW5lZCkgazIgPSBrO1xuICAgIHZhciBkZXNjID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihtLCBrKTtcbiAgICBpZiAoIWRlc2MgfHwgKFwiZ2V0XCIgaW4gZGVzYyA/ICFtLl9fZXNNb2R1bGUgOiBkZXNjLndyaXRhYmxlIHx8IGRlc2MuY29uZmlndXJhYmxlKSkge1xuICAgICAgZGVzYyA9IHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBmdW5jdGlvbigpIHsgcmV0dXJuIG1ba107IH0gfTtcbiAgICB9XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG8sIGsyLCBkZXNjKTtcbn0pIDogKGZ1bmN0aW9uKG8sIG0sIGssIGsyKSB7XG4gICAgaWYgKGsyID09PSB1bmRlZmluZWQpIGsyID0gaztcbiAgICBvW2syXSA9IG1ba107XG59KSk7XG52YXIgX19leHBvcnRTdGFyID0gKHRoaXMgJiYgdGhpcy5fX2V4cG9ydFN0YXIpIHx8IGZ1bmN0aW9uKG0sIGV4cG9ydHMpIHtcbiAgICBmb3IgKHZhciBwIGluIG0pIGlmIChwICE9PSBcImRlZmF1bHRcIiAmJiAhT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKGV4cG9ydHMsIHApKSBfX2NyZWF0ZUJpbmRpbmcoZXhwb3J0cywgbSwgcCk7XG59O1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuX19leHBvcnRTdGFyKHJlcXVpcmUoXCIuL2FycmF5XCIpLCBleHBvcnRzKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5CaXRzID0gdm9pZCAwO1xuLyoqXG4gKiBAcHVibGljXG4gKi9cbnZhciBCaXRzO1xuKGZ1bmN0aW9uIChCaXRzKSB7XG4gICAgZnVuY3Rpb24gYml0KGkpIHtcbiAgICAgICAgcmV0dXJuIDEgPDwgaTtcbiAgICB9XG4gICAgQml0cy5iaXQgPSBiaXQ7XG4gICAgZnVuY3Rpb24gc2V0KGJpdHMsIGkpIHtcbiAgICAgICAgcmV0dXJuIGJpdHMgfCBiaXQoaSk7XG4gICAgfVxuICAgIEJpdHMuc2V0ID0gc2V0O1xuICAgIGZ1bmN0aW9uIGNsZWFyKGJpdHMsIGkpIHtcbiAgICAgICAgcmV0dXJuIGJpdHMgJiB+Yml0KGkpO1xuICAgIH1cbiAgICBCaXRzLmNsZWFyID0gY2xlYXI7XG4gICAgZnVuY3Rpb24gdGVzdChiaXRzLCBpKSB7XG4gICAgICAgIHJldHVybiAoYml0cyAmIGJpdChpKSkgIT09IDA7XG4gICAgfVxuICAgIEJpdHMudGVzdCA9IHRlc3Q7XG4gICAgZnVuY3Rpb24gdGFrZShiaXRzLCBuKSB7XG4gICAgICAgIHJldHVybiBiaXRzICYgKCgxIDw8IG4pIC0gMSk7XG4gICAgfVxuICAgIEJpdHMudGFrZSA9IHRha2U7XG4gICAgZnVuY3Rpb24gc2tpcChiaXRzLCBuKSB7XG4gICAgICAgIHJldHVybiBiaXRzID4+PiBuO1xuICAgIH1cbiAgICBCaXRzLnNraXAgPSBza2lwO1xuICAgIC8qKlxuICAgICAqIEByZW1hcmtzXG4gICAgICogVGhpcyBpcyBhIDMyLWJpdCB2YXJpYW50IG9mIHRoZSA2NC1iaXQgcG9wdWxhdGlvbiBjb3VudCBhbGdvcml0aG0gb3V0bGluZWRcbiAgICAgKiBvbiBXaWtpcGVkaWEuIFVudGlsIEVDTUFTY3JpcHQgbmF0aXZlbHkgcHJvdmlkZXMgYW4gZWZmaWNpZW50IHBvcHVsYXRpb25cbiAgICAgKiBjb3VudCBhbGdvcml0aG0sIHRoaXMgaXMgdGhlIGJlc3Qgd2UgY2FuIGRvLlxuICAgICAqXG4gICAgICoge0BsaW5rIGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL0hhbW1pbmdfd2VpZ2h0fVxuICAgICAqL1xuICAgIGZ1bmN0aW9uIHBvcENvdW50KGJpdHMpIHtcbiAgICAgICAgYml0cyAtPSAoYml0cyA+PiAxKSAmIDB4NTU1NTU1NTU7XG4gICAgICAgIGJpdHMgPSAoYml0cyAmIDB4MzMzMzMzMzMpICsgKChiaXRzID4+IDIpICYgMHgzMzMzMzMzMyk7XG4gICAgICAgIGJpdHMgPSAoYml0cyArIChiaXRzID4+IDQpKSAmIDB4MGYwZjBmMGY7XG4gICAgICAgIGJpdHMgKz0gYml0cyA+PiA4O1xuICAgICAgICBiaXRzICs9IGJpdHMgPj4gMTY7XG4gICAgICAgIHJldHVybiBiaXRzICYgMHg3ZjtcbiAgICB9XG4gICAgQml0cy5wb3BDb3VudCA9IHBvcENvdW50O1xufSkoQml0cyB8fCAoZXhwb3J0cy5CaXRzID0gQml0cyA9IHt9KSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1iaXRzLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xudmFyIF9fY3JlYXRlQmluZGluZyA9ICh0aGlzICYmIHRoaXMuX19jcmVhdGVCaW5kaW5nKSB8fCAoT2JqZWN0LmNyZWF0ZSA/IChmdW5jdGlvbihvLCBtLCBrLCBrMikge1xuICAgIGlmIChrMiA9PT0gdW5kZWZpbmVkKSBrMiA9IGs7XG4gICAgdmFyIGRlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKG0sIGspO1xuICAgIGlmICghZGVzYyB8fCAoXCJnZXRcIiBpbiBkZXNjID8gIW0uX19lc01vZHVsZSA6IGRlc2Mud3JpdGFibGUgfHwgZGVzYy5jb25maWd1cmFibGUpKSB7XG4gICAgICBkZXNjID0geyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGZ1bmN0aW9uKCkgeyByZXR1cm4gbVtrXTsgfSB9O1xuICAgIH1cbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkobywgazIsIGRlc2MpO1xufSkgOiAoZnVuY3Rpb24obywgbSwgaywgazIpIHtcbiAgICBpZiAoazIgPT09IHVuZGVmaW5lZCkgazIgPSBrO1xuICAgIG9bazJdID0gbVtrXTtcbn0pKTtcbnZhciBfX2V4cG9ydFN0YXIgPSAodGhpcyAmJiB0aGlzLl9fZXhwb3J0U3RhcikgfHwgZnVuY3Rpb24obSwgZXhwb3J0cykge1xuICAgIGZvciAodmFyIHAgaW4gbSkgaWYgKHAgIT09IFwiZGVmYXVsdFwiICYmICFPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoZXhwb3J0cywgcCkpIF9fY3JlYXRlQmluZGluZyhleHBvcnRzLCBtLCBwKTtcbn07XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5fX2V4cG9ydFN0YXIocmVxdWlyZShcIi4vYml0c1wiKSwgZXhwb3J0cyk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMuQ2xvbmUgPSB2b2lkIDA7XG4vKipcbiAqIEBwdWJsaWNcbiAqL1xudmFyIENsb25lO1xuKGZ1bmN0aW9uIChDbG9uZSkge1xuICAgIGZ1bmN0aW9uIGNsb25lKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZS5jbG9uZSgpO1xuICAgIH1cbiAgICBDbG9uZS5jbG9uZSA9IGNsb25lO1xufSkoQ2xvbmUgfHwgKGV4cG9ydHMuQ2xvbmUgPSBDbG9uZSA9IHt9KSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jbG9uZS5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbnZhciBfX2NyZWF0ZUJpbmRpbmcgPSAodGhpcyAmJiB0aGlzLl9fY3JlYXRlQmluZGluZykgfHwgKE9iamVjdC5jcmVhdGUgPyAoZnVuY3Rpb24obywgbSwgaywgazIpIHtcbiAgICBpZiAoazIgPT09IHVuZGVmaW5lZCkgazIgPSBrO1xuICAgIHZhciBkZXNjID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihtLCBrKTtcbiAgICBpZiAoIWRlc2MgfHwgKFwiZ2V0XCIgaW4gZGVzYyA/ICFtLl9fZXNNb2R1bGUgOiBkZXNjLndyaXRhYmxlIHx8IGRlc2MuY29uZmlndXJhYmxlKSkge1xuICAgICAgZGVzYyA9IHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBmdW5jdGlvbigpIHsgcmV0dXJuIG1ba107IH0gfTtcbiAgICB9XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG8sIGsyLCBkZXNjKTtcbn0pIDogKGZ1bmN0aW9uKG8sIG0sIGssIGsyKSB7XG4gICAgaWYgKGsyID09PSB1bmRlZmluZWQpIGsyID0gaztcbiAgICBvW2syXSA9IG1ba107XG59KSk7XG52YXIgX19leHBvcnRTdGFyID0gKHRoaXMgJiYgdGhpcy5fX2V4cG9ydFN0YXIpIHx8IGZ1bmN0aW9uKG0sIGV4cG9ydHMpIHtcbiAgICBmb3IgKHZhciBwIGluIG0pIGlmIChwICE9PSBcImRlZmF1bHRcIiAmJiAhT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKGV4cG9ydHMsIHApKSBfX2NyZWF0ZUJpbmRpbmcoZXhwb3J0cywgbSwgcCk7XG59O1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuX19leHBvcnRTdGFyKHJlcXVpcmUoXCIuL2Nsb25lXCIpLCBleHBvcnRzKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5Db21wYXJhYmxlID0gdm9pZCAwO1xuY29uc3QgYWxmYV9yZWZpbmVtZW50XzEgPSByZXF1aXJlKFwiQHNpdGVpbXByb3ZlL2FsZmEtcmVmaW5lbWVudFwiKTtcbmNvbnN0IGNvbXBhcmlzb25fMSA9IHJlcXVpcmUoXCIuL2NvbXBhcmlzb25cIik7XG5jb25zdCB7IGlzU3RyaW5nLCBpc051bWJlciwgaXNCaWdJbnQsIGlzQm9vbGVhbiwgaXNGdW5jdGlvbiwgaXNPYmplY3QgfSA9IGFsZmFfcmVmaW5lbWVudF8xLlJlZmluZW1lbnQ7XG4vKipcbiAqIFRoaXMgbmFtZXNwYWNlIHByb3ZpZGVzIGFkZGl0aW9uYWwgZnVuY3Rpb25zIGZvciB0aGVcbiAqIHtAbGluayAoQ29tcGFyYWJsZTppbnRlcmZhY2UpfSBpbnRlcmZhY2UuXG4gKlxuICogQHB1YmxpY1xuICovXG52YXIgQ29tcGFyYWJsZTtcbihmdW5jdGlvbiAoQ29tcGFyYWJsZSkge1xuICAgIC8qKlxuICAgICAqIENoZWNrIGlmIGFuIHVua25vd24gdmFsdWUgaW1wbGVtZW50cyB0aGUge0BsaW5rIChDb21wYXJhYmxlOmludGVyZmFjZSl9XG4gICAgICogaW50ZXJmYWNlLlxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGlzQ29tcGFyYWJsZSh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gaXNPYmplY3QodmFsdWUpICYmIGlzRnVuY3Rpb24odmFsdWUuY29tcGFyZSk7XG4gICAgfVxuICAgIENvbXBhcmFibGUuaXNDb21wYXJhYmxlID0gaXNDb21wYXJhYmxlO1xuICAgIGZ1bmN0aW9uIGNvbXBhcmUoYSwgYikge1xuICAgICAgICBpZiAoaXNTdHJpbmcoYSkpIHtcbiAgICAgICAgICAgIHJldHVybiBjb21wYXJlU3RyaW5nKGEsIGIpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc051bWJlcihhKSkge1xuICAgICAgICAgICAgcmV0dXJuIGNvbXBhcmVOdW1iZXIoYSwgYik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzQmlnSW50KGEpKSB7XG4gICAgICAgICAgICByZXR1cm4gY29tcGFyZUJpZ0ludChhLCBiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNCb29sZWFuKGEpKSB7XG4gICAgICAgICAgICByZXR1cm4gY29tcGFyZUJvb2xlYW4oYSwgYik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGNvbXBhcmVDb21wYXJhYmxlKGEsIGIpO1xuICAgIH1cbiAgICBDb21wYXJhYmxlLmNvbXBhcmUgPSBjb21wYXJlO1xuICAgIC8qKlxuICAgICAqIEByZW1hcmtzXG4gICAgICogVGhpcyBzaG91bGQgb25seSBiZSB1c2VkIGluIGNhc2VzIHdoZXJlIGJyYW5jaCBtaXNwcmVkaWN0aW9ucyBjYXVzZWQgYnkgdGhlXG4gICAgICogbW9yZSBnZW5lcmFsIHtAbGluayAoQ29tcGFyYWJsZTpuYW1lc3BhY2UpLihjb21wYXJlOjEpfSBhcmUgdW5kZXNpcmVkLlxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGNvbXBhcmVTdHJpbmcoYSwgYikge1xuICAgICAgICByZXR1cm4gY29tcGFyZVByaW1pdGl2ZShhLCBiKTtcbiAgICB9XG4gICAgQ29tcGFyYWJsZS5jb21wYXJlU3RyaW5nID0gY29tcGFyZVN0cmluZztcbiAgICAvKipcbiAgICAgKiBAcmVtYXJrc1xuICAgICAqIFRoaXMgc2hvdWxkIG9ubHkgYmUgdXNlZCBpbiBjYXNlcyB3aGVyZSBicmFuY2ggbWlzcHJlZGljdGlvbnMgY2F1c2VkIGJ5IHRoZVxuICAgICAqIG1vcmUgZ2VuZXJhbCB7QGxpbmsgKENvbXBhcmFibGU6bmFtZXNwYWNlKS4oY29tcGFyZToyKX0gYXJlIHVuZGVzaXJlZC5cbiAgICAgKi9cbiAgICBmdW5jdGlvbiBjb21wYXJlTnVtYmVyKGEsIGIpIHtcbiAgICAgICAgcmV0dXJuIGNvbXBhcmVQcmltaXRpdmUoYSwgYik7XG4gICAgfVxuICAgIENvbXBhcmFibGUuY29tcGFyZU51bWJlciA9IGNvbXBhcmVOdW1iZXI7XG4gICAgLyoqXG4gICAgICogQHJlbWFya3NcbiAgICAgKiBUaGlzIHNob3VsZCBvbmx5IGJlIHVzZWQgaW4gY2FzZXMgd2hlcmUgYnJhbmNoIG1pc3ByZWRpY3Rpb25zIGNhdXNlZCBieSB0aGVcbiAgICAgKiBtb3JlIGdlbmVyYWwge0BsaW5rIChDb21wYXJhYmxlOm5hbWVzcGFjZSkuKGNvbXBhcmU6Myl9IGFyZSB1bmRlc2lyZWQuXG4gICAgICovXG4gICAgZnVuY3Rpb24gY29tcGFyZUJpZ0ludChhLCBiKSB7XG4gICAgICAgIHJldHVybiBjb21wYXJlUHJpbWl0aXZlKGEsIGIpO1xuICAgIH1cbiAgICBDb21wYXJhYmxlLmNvbXBhcmVCaWdJbnQgPSBjb21wYXJlQmlnSW50O1xuICAgIC8qKlxuICAgICAqIEByZW1hcmtzXG4gICAgICogVGhpcyBzaG91bGQgb25seSBiZSB1c2VkIGluIGNhc2VzIHdoZXJlIGJyYW5jaCBtaXNwcmVkaWN0aW9ucyBjYXVzZWQgYnkgdGhlXG4gICAgICogbW9yZSBnZW5lcmFsIHtAbGluayAoQ29tcGFyYWJsZTpuYW1lc3BhY2UpLihjb21wYXJlOjQpfSBhcmUgdW5kZXNpcmVkLlxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGNvbXBhcmVCb29sZWFuKGEsIGIpIHtcbiAgICAgICAgcmV0dXJuIGNvbXBhcmVQcmltaXRpdmUoYSwgYik7XG4gICAgfVxuICAgIENvbXBhcmFibGUuY29tcGFyZUJvb2xlYW4gPSBjb21wYXJlQm9vbGVhbjtcbiAgICAvKipcbiAgICAgKiBAcmVtYXJrc1xuICAgICAqIFRoaXMgc2hvdWxkIG9ubHkgYmUgdXNlZCBpbiBjYXNlcyB3aGVyZSBicmFuY2ggbWlzcHJlZGljdGlvbnMgY2F1c2VkIGJ5IHRoZVxuICAgICAqIG1vcmUgZ2VuZXJhbCB7QGxpbmsgKENvbXBhcmFibGU6bmFtZXNwYWNlKS4oY29tcGFyZTo1KX0gYXJlIHVuZGVzaXJlZC5cbiAgICAgKi9cbiAgICBmdW5jdGlvbiBjb21wYXJlQ29tcGFyYWJsZShhLCBiKSB7XG4gICAgICAgIHJldHVybiBhLmNvbXBhcmUoYik7XG4gICAgfVxuICAgIENvbXBhcmFibGUuY29tcGFyZUNvbXBhcmFibGUgPSBjb21wYXJlQ29tcGFyYWJsZTtcbiAgICAvKipcbiAgICAgKiBDb21wYXJlIHR3byBwcmltaXRpdmUgdmFsdWVzLlxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGNvbXBhcmVQcmltaXRpdmUoYSwgYikge1xuICAgICAgICBpZiAoYSA8IGIpIHtcbiAgICAgICAgICAgIHJldHVybiBjb21wYXJpc29uXzEuQ29tcGFyaXNvbi5MZXNzO1xuICAgICAgICB9XG4gICAgICAgIGlmIChhID4gYikge1xuICAgICAgICAgICAgcmV0dXJuIGNvbXBhcmlzb25fMS5Db21wYXJpc29uLkdyZWF0ZXI7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGNvbXBhcmlzb25fMS5Db21wYXJpc29uLkVxdWFsO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBDb21wYXJlIHR1cGxlcyBsZXhpY29ncmFwaGljYWxseVxuICAgICAqXG4gICAgICoge0BsaW5rIGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL0xleGljb2dyYXBoaWNfb3JkZXJ9XG4gICAgICovXG4gICAgZnVuY3Rpb24gY29tcGFyZUxleGljb2dyYXBoaWNhbGx5KGEsIGIsIGNvbXBhcmVyKSB7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgYS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgY29tcGFyaXNvbiA9IGNvbXBhcmVyW2ldKGFbaV0sIGJbaV0pO1xuICAgICAgICAgICAgaWYgKGNvbXBhcmlzb24gPT09IGNvbXBhcmlzb25fMS5Db21wYXJpc29uLkVxdWFsKSB7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gY29tcGFyaXNvbjtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gY29tcGFyaXNvbl8xLkNvbXBhcmlzb24uRXF1YWw7XG4gICAgfVxuICAgIENvbXBhcmFibGUuY29tcGFyZUxleGljb2dyYXBoaWNhbGx5ID0gY29tcGFyZUxleGljb2dyYXBoaWNhbGx5O1xuICAgIC8qKlxuICAgICAqIENoZWNrIGlmIG9uZSB2YWx1ZSBpcyBsZXNzIHRoYW4gYW5vdGhlci5cbiAgICAgKi9cbiAgICBmdW5jdGlvbiBpc0xlc3NUaGFuKGEsIGIpIHtcbiAgICAgICAgcmV0dXJuIGEuY29tcGFyZShiKSA8IDA7XG4gICAgfVxuICAgIENvbXBhcmFibGUuaXNMZXNzVGhhbiA9IGlzTGVzc1RoYW47XG4gICAgLyoqXG4gICAgICogQ2hlY2sgaWYgb25lIHZhbHVlIGlzIGxlc3MgdGhhbiBvciBlcXVhbCB0byBhbm90aGVyLlxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGlzTGVzc1RoYW5PckVxdWFsKGEsIGIpIHtcbiAgICAgICAgcmV0dXJuIGEuY29tcGFyZShiKSA8PSAwO1xuICAgIH1cbiAgICBDb21wYXJhYmxlLmlzTGVzc1RoYW5PckVxdWFsID0gaXNMZXNzVGhhbk9yRXF1YWw7XG4gICAgLyoqXG4gICAgICogQ2hlY2sgaWYgb25lIHZhbHVlIGlzIGVxdWFsIHRvIGFub3RoZXJcbiAgICAgKi9cbiAgICBmdW5jdGlvbiBpc0VxdWFsKGEsIGIpIHtcbiAgICAgICAgcmV0dXJuIGEuY29tcGFyZShiKSA9PT0gMDtcbiAgICB9XG4gICAgQ29tcGFyYWJsZS5pc0VxdWFsID0gaXNFcXVhbDtcbiAgICAvKipcbiAgICAgKiBDaGVjayBpZiBvbmUgdmFsdWUgaXMgZ3JlYXRlciB0aGFuIGFub3RoZXIuXG4gICAgICovXG4gICAgZnVuY3Rpb24gaXNHcmVhdGVyVGhhbihhLCBiKSB7XG4gICAgICAgIHJldHVybiBhLmNvbXBhcmUoYikgPiAwO1xuICAgIH1cbiAgICBDb21wYXJhYmxlLmlzR3JlYXRlclRoYW4gPSBpc0dyZWF0ZXJUaGFuO1xuICAgIC8qKlxuICAgICAqIENoZWNrIGlmIG9uZSB2YWx1ZSBpcyBncmVhdGVyIHRoYW4gb3IgZXF1YWwgdG8gYW5vdGhlci5cbiAgICAgKi9cbiAgICBmdW5jdGlvbiBpc0dyZWF0ZXJUaGFuT3JFcXVhbChhLCBiKSB7XG4gICAgICAgIHJldHVybiBhLmNvbXBhcmUoYikgPj0gMDtcbiAgICB9XG4gICAgQ29tcGFyYWJsZS5pc0dyZWF0ZXJUaGFuT3JFcXVhbCA9IGlzR3JlYXRlclRoYW5PckVxdWFsO1xufSkoQ29tcGFyYWJsZSB8fCAoZXhwb3J0cy5Db21wYXJhYmxlID0gQ29tcGFyYWJsZSA9IHt9KSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jb21wYXJhYmxlLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y29tcGFyZXIuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5leHBvcnRzLkNvbXBhcmlzb24gPSB2b2lkIDA7XG4vKipcbiAqIEByZW1hcmtzXG4gKiBDb21wYXJpc29ucyBhcmUgbGltaXRlZCB0byB0aGUgcmFuZ2UgWy0xLCAxXSBpbiBvcmRlciB0byBhdm9pZCB0aGUgcG90ZW50aWFsXG4gKiBvZiBvdmVyLS91bmRlcmZsb3dzIHdoZW4gY29tcGFyaXNvbnMgYXJlIGltcGxlbWVudGVkIG5haXZlbHkgdXNpbmdcbiAqIHN1YnRyYWN0aW9ucywgc3VjaCBgYSAtIGJgOyB0aGlzIHdvdWxkIG5vdCBiZSBhbGxvd2VkLlxuICpcbiAqIEBwdWJsaWNcbiAqL1xudmFyIENvbXBhcmlzb247XG4oZnVuY3Rpb24gKENvbXBhcmlzb24pIHtcbiAgICBDb21wYXJpc29uW0NvbXBhcmlzb25bXCJMZXNzXCJdID0gLTFdID0gXCJMZXNzXCI7XG4gICAgQ29tcGFyaXNvbltDb21wYXJpc29uW1wiRXF1YWxcIl0gPSAwXSA9IFwiRXF1YWxcIjtcbiAgICBDb21wYXJpc29uW0NvbXBhcmlzb25bXCJHcmVhdGVyXCJdID0gMV0gPSBcIkdyZWF0ZXJcIjtcbn0pKENvbXBhcmlzb24gfHwgKGV4cG9ydHMuQ29tcGFyaXNvbiA9IENvbXBhcmlzb24gPSB7fSkpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y29tcGFyaXNvbi5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbnZhciBfX2NyZWF0ZUJpbmRpbmcgPSAodGhpcyAmJiB0aGlzLl9fY3JlYXRlQmluZGluZykgfHwgKE9iamVjdC5jcmVhdGUgPyAoZnVuY3Rpb24obywgbSwgaywgazIpIHtcbiAgICBpZiAoazIgPT09IHVuZGVmaW5lZCkgazIgPSBrO1xuICAgIHZhciBkZXNjID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihtLCBrKTtcbiAgICBpZiAoIWRlc2MgfHwgKFwiZ2V0XCIgaW4gZGVzYyA/ICFtLl9fZXNNb2R1bGUgOiBkZXNjLndyaXRhYmxlIHx8IGRlc2MuY29uZmlndXJhYmxlKSkge1xuICAgICAgZGVzYyA9IHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBmdW5jdGlvbigpIHsgcmV0dXJuIG1ba107IH0gfTtcbiAgICB9XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG8sIGsyLCBkZXNjKTtcbn0pIDogKGZ1bmN0aW9uKG8sIG0sIGssIGsyKSB7XG4gICAgaWYgKGsyID09PSB1bmRlZmluZWQpIGsyID0gaztcbiAgICBvW2syXSA9IG1ba107XG59KSk7XG52YXIgX19leHBvcnRTdGFyID0gKHRoaXMgJiYgdGhpcy5fX2V4cG9ydFN0YXIpIHx8IGZ1bmN0aW9uKG0sIGV4cG9ydHMpIHtcbiAgICBmb3IgKHZhciBwIGluIG0pIGlmIChwICE9PSBcImRlZmF1bHRcIiAmJiAhT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKGV4cG9ydHMsIHApKSBfX2NyZWF0ZUJpbmRpbmcoZXhwb3J0cywgbSwgcCk7XG59O1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuX19leHBvcnRTdGFyKHJlcXVpcmUoXCIuL2NvbXBhcmFibGVcIiksIGV4cG9ydHMpO1xuX19leHBvcnRTdGFyKHJlcXVpcmUoXCIuL2NvbXBhcmVyXCIpLCBleHBvcnRzKTtcbl9fZXhwb3J0U3RhcihyZXF1aXJlKFwiLi9jb21wYXJpc29uXCIpLCBleHBvcnRzKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5EZWNvZGVyID0gdm9pZCAwO1xuLyoqXG4gKiB7QGxpbmsgaHR0cHM6Ly9lbmNvZGluZy5zcGVjLndoYXR3Zy5vcmcvI3RleHRkZWNvZGVyfVxuICpcbiAqIEBwdWJsaWNcbiAqL1xudmFyIERlY29kZXI7XG4oZnVuY3Rpb24gKERlY29kZXIpIHtcbiAgICAvKipcbiAgICAgKiB7QGxpbmsgaHR0cHM6Ly9lbmNvZGluZy5zcGVjLndoYXR3Zy5vcmcvI2RvbS10ZXh0ZGVjb2Rlci1kZWNvZGV9XG4gICAgICoge0BsaW5rIGh0dHBzOi8vZW5jb2Rpbmcuc3BlYy53aGF0d2cub3JnLyN1dGYtOC1kZWNvZGVyfVxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGRlY29kZShpbnB1dCkge1xuICAgICAgICBsZXQgb3V0cHV0ID0gXCJcIjtcbiAgICAgICAgbGV0IGkgPSAwO1xuICAgICAgICB3aGlsZSAoaSA8IGlucHV0Lmxlbmd0aCkge1xuICAgICAgICAgICAgbGV0IGJ5dGUgPSBpbnB1dFtpXTtcbiAgICAgICAgICAgIGxldCBieXRlc05lZWRlZCA9IDA7XG4gICAgICAgICAgICBsZXQgY29kZVBvaW50ID0gMDtcbiAgICAgICAgICAgIGlmIChieXRlIDw9IDB4N2YpIHtcbiAgICAgICAgICAgICAgICBieXRlc05lZWRlZCA9IDA7XG4gICAgICAgICAgICAgICAgY29kZVBvaW50ID0gYnl0ZSAmIDB4ZmY7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChieXRlIDw9IDB4ZGYpIHtcbiAgICAgICAgICAgICAgICBieXRlc05lZWRlZCA9IDE7XG4gICAgICAgICAgICAgICAgY29kZVBvaW50ID0gYnl0ZSAmIDB4MWY7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChieXRlIDw9IDB4ZWYpIHtcbiAgICAgICAgICAgICAgICBieXRlc05lZWRlZCA9IDI7XG4gICAgICAgICAgICAgICAgY29kZVBvaW50ID0gYnl0ZSAmIDB4MGY7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChieXRlIDw9IDB4ZjQpIHtcbiAgICAgICAgICAgICAgICBieXRlc05lZWRlZCA9IDM7XG4gICAgICAgICAgICAgICAgY29kZVBvaW50ID0gYnl0ZSAmIDB4MDc7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoaW5wdXQubGVuZ3RoIC0gaSAtIGJ5dGVzTmVlZGVkID4gMCkge1xuICAgICAgICAgICAgICAgIGxldCBrID0gMDtcbiAgICAgICAgICAgICAgICB3aGlsZSAoayA8IGJ5dGVzTmVlZGVkKSB7XG4gICAgICAgICAgICAgICAgICAgIGJ5dGUgPSBpbnB1dFtpICsgayArIDFdO1xuICAgICAgICAgICAgICAgICAgICBjb2RlUG9pbnQgPSAoY29kZVBvaW50IDw8IDYpIHwgKGJ5dGUgJiAweDNmKTtcbiAgICAgICAgICAgICAgICAgICAgayArPSAxO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGNvZGVQb2ludCA9IDB4ZmZmZDtcbiAgICAgICAgICAgICAgICBieXRlc05lZWRlZCA9IGlucHV0Lmxlbmd0aCAtIGk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBvdXRwdXQgKz0gU3RyaW5nLmZyb21Db2RlUG9pbnQoY29kZVBvaW50KTtcbiAgICAgICAgICAgIGkgKz0gYnl0ZXNOZWVkZWQgKyAxO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBvdXRwdXQ7XG4gICAgfVxuICAgIERlY29kZXIuZGVjb2RlID0gZGVjb2RlO1xufSkoRGVjb2RlciB8fCAoZXhwb3J0cy5EZWNvZGVyID0gRGVjb2RlciA9IHt9KSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1kZWNvZGVyLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5FbmNvZGVyID0gdm9pZCAwO1xuLyoqXG4gKiB7QGxpbmsgaHR0cHM6Ly9lbmNvZGluZy5zcGVjLndoYXR3Zy5vcmcvI3RleHRlbmNvZGVyfVxuICpcbiAqIEBwdWJsaWNcbiAqL1xudmFyIEVuY29kZXI7XG4oZnVuY3Rpb24gKEVuY29kZXIpIHtcbiAgICAvKipcbiAgICAgKiB7QGxpbmsgaHR0cHM6Ly9lbmNvZGluZy5zcGVjLndoYXR3Zy5vcmcvI2RvbS10ZXh0ZW5jb2Rlci1lbmNvZGV9XG4gICAgICoge0BsaW5rIGh0dHBzOi8vZW5jb2Rpbmcuc3BlYy53aGF0d2cub3JnLyN1dGYtOC1lbmNvZGVyfVxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGVuY29kZShpbnB1dCkge1xuICAgICAgICBjb25zdCBvdXRwdXQgPSBbXTtcbiAgICAgICAgY29uc3QgbGVuZ3RoID0gaW5wdXQubGVuZ3RoO1xuICAgICAgICBsZXQgaSA9IDA7XG4gICAgICAgIHdoaWxlIChpIDwgbGVuZ3RoKSB7XG4gICAgICAgICAgICBjb25zdCBjb2RlUG9pbnQgPSBpbnB1dC5jb2RlUG9pbnRBdChpKTtcbiAgICAgICAgICAgIGxldCBjb3VudCA9IDA7XG4gICAgICAgICAgICBsZXQgYml0cyA9IDA7XG4gICAgICAgICAgICBpZiAoY29kZVBvaW50IDw9IDB4N2YpIHtcbiAgICAgICAgICAgICAgICBjb3VudCA9IDA7XG4gICAgICAgICAgICAgICAgYml0cyA9IDB4MDA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChjb2RlUG9pbnQgPD0gMHg3ZmYpIHtcbiAgICAgICAgICAgICAgICBjb3VudCA9IDY7XG4gICAgICAgICAgICAgICAgYml0cyA9IDB4YzA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChjb2RlUG9pbnQgPD0gMHhmZmZmKSB7XG4gICAgICAgICAgICAgICAgY291bnQgPSAxMjtcbiAgICAgICAgICAgICAgICBiaXRzID0gMHhlMDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGNvZGVQb2ludCA8PSAweDFmZmZmZikge1xuICAgICAgICAgICAgICAgIGNvdW50ID0gMTg7XG4gICAgICAgICAgICAgICAgYml0cyA9IDB4ZjA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBvdXRwdXQucHVzaChiaXRzIHwgKGNvZGVQb2ludCA+PiBjb3VudCkpO1xuICAgICAgICAgICAgY291bnQgLT0gNjtcbiAgICAgICAgICAgIHdoaWxlIChjb3VudCA+PSAwKSB7XG4gICAgICAgICAgICAgICAgb3V0cHV0LnB1c2goMHg4MCB8ICgoY29kZVBvaW50ID4+IGNvdW50KSAmIDB4M2YpKTtcbiAgICAgICAgICAgICAgICBjb3VudCAtPSA2O1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaSArPSBjb2RlUG9pbnQgPj0gMHgxMDAwMCA/IDIgOiAxO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBuZXcgVWludDhBcnJheShvdXRwdXQpO1xuICAgIH1cbiAgICBFbmNvZGVyLmVuY29kZSA9IGVuY29kZTtcbn0pKEVuY29kZXIgfHwgKGV4cG9ydHMuRW5jb2RlciA9IEVuY29kZXIgPSB7fSkpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZW5jb2Rlci5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbnZhciBfX2NyZWF0ZUJpbmRpbmcgPSAodGhpcyAmJiB0aGlzLl9fY3JlYXRlQmluZGluZykgfHwgKE9iamVjdC5jcmVhdGUgPyAoZnVuY3Rpb24obywgbSwgaywgazIpIHtcbiAgICBpZiAoazIgPT09IHVuZGVmaW5lZCkgazIgPSBrO1xuICAgIHZhciBkZXNjID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihtLCBrKTtcbiAgICBpZiAoIWRlc2MgfHwgKFwiZ2V0XCIgaW4gZGVzYyA/ICFtLl9fZXNNb2R1bGUgOiBkZXNjLndyaXRhYmxlIHx8IGRlc2MuY29uZmlndXJhYmxlKSkge1xuICAgICAgZGVzYyA9IHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBmdW5jdGlvbigpIHsgcmV0dXJuIG1ba107IH0gfTtcbiAgICB9XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG8sIGsyLCBkZXNjKTtcbn0pIDogKGZ1bmN0aW9uKG8sIG0sIGssIGsyKSB7XG4gICAgaWYgKGsyID09PSB1bmRlZmluZWQpIGsyID0gaztcbiAgICBvW2syXSA9IG1ba107XG59KSk7XG52YXIgX19leHBvcnRTdGFyID0gKHRoaXMgJiYgdGhpcy5fX2V4cG9ydFN0YXIpIHx8IGZ1bmN0aW9uKG0sIGV4cG9ydHMpIHtcbiAgICBmb3IgKHZhciBwIGluIG0pIGlmIChwICE9PSBcImRlZmF1bHRcIiAmJiAhT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKGV4cG9ydHMsIHApKSBfX2NyZWF0ZUJpbmRpbmcoZXhwb3J0cywgbSwgcCk7XG59O1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuX19leHBvcnRTdGFyKHJlcXVpcmUoXCIuL2RlY29kZXJcIiksIGV4cG9ydHMpO1xuX19leHBvcnRTdGFyKHJlcXVpcmUoXCIuL2VuY29kZXJcIiksIGV4cG9ydHMpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXguanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5leHBvcnRzLkVxdWF0YWJsZSA9IHZvaWQgMDtcbi8qKlxuICogVGhpcyBuYW1lc3BhY2UgcHJvdmlkZXMgYWRkaXRpb25hbCB0eXBlcyBhbmQgZnVuY3Rpb25zIGZvciB0aGVcbiAqIHtAbGluayAoRXF1YXRhYmxlOmludGVyZmFjZSl9IGludGVyZmFjZS5cbiAqXG4gKiBAcHVibGljXG4gKi9cbnZhciBFcXVhdGFibGU7XG4oZnVuY3Rpb24gKEVxdWF0YWJsZSkge1xuICAgIC8vIFRoZSBmb2xsb3dpbmcgdHdvIHR5cGUgZ3VhcmRzIGhhdmUgYmVlbiBpbmxpbmVkIGZyb20gdGhlXG4gICAgLy8gQHNpdGVpbXByb3ZlL2FsZmEtcmVmaW5lbWVudCBwYWNrYWdlIHRvIGF2b2lkIGNyZWF0aW5nIGEgY2lyY3VsYXJcbiAgICAvLyBkZXBlbmRlbmN5LlxuICAgIGZ1bmN0aW9uIGlzRnVuY3Rpb24odmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJmdW5jdGlvblwiO1xuICAgIH1cbiAgICBmdW5jdGlvbiBpc09iamVjdCh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIHZhbHVlICE9PSBudWxsO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBDaGVjayBpZiBhbiB1bmtub3duIHZhbHVlIGltcGxlbWVudHMgdGhlIHtAbGluayAoRXF1YXRhYmxlOmludGVyZmFjZSl9XG4gICAgICogaW50ZXJmYWNlLlxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGlzRXF1YXRhYmxlKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiBpc09iamVjdCh2YWx1ZSkgJiYgaXNGdW5jdGlvbih2YWx1ZS5lcXVhbHMpO1xuICAgIH1cbiAgICBFcXVhdGFibGUuaXNFcXVhdGFibGUgPSBpc0VxdWF0YWJsZTtcbiAgICAvKipcbiAgICAgKiBDaGVjayBpZiB0d28gdW5rbm93biB2YWx1ZXMgYXJlIGVxdWFsLlxuICAgICAqXG4gICAgICogQHJlbWFya3NcbiAgICAgKiBJZiBlaXRoZXIgb2YgdGhlIGdpdmVuIHZhbHVlcyBpbXBsZW1lbnQgdGhlIHtAbGluayAoRXF1YXRhYmxlOmludGVyZmFjZSl9XG4gICAgICogaW50ZXJmYWNlLCB0aGUgZXF1aXZhbGVuY2UgY29uc3RyYWludHMgb2YgdGhlIHZhbHVlIHdpbGwgYmUgdXNlZC4gSWYgbm90LFxuICAgICAqIHN0cmljdCBlcXVhbGl0eSB3aWxsIGJlIHVzZWQgd2l0aCB0aGUgYWRkaXRpb25hbCBjb25zdHJhaW50IHRoYXQgYE5hTmAgaXNcbiAgICAgKiBlcXVhbCB0byBpdHNlbGYuXG4gICAgICovXG4gICAgZnVuY3Rpb24gZXF1YWxzKGEsIGIpIHtcbiAgICAgICAgaWYgKGEgPT09IGIgfHxcbiAgICAgICAgICAgIC8vIGBOYU5gIGlzIHRoZSBvbmx5IHZhbHVlIGluIEphdmFTY3JpcHQgdGhhdCBpcyBub3QgZXF1YWwgdG8gaXRzZWxmLlxuICAgICAgICAgICAgKGEgIT09IGEgJiYgYiAhPT0gYikpIHtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0VxdWF0YWJsZShhKSkge1xuICAgICAgICAgICAgcmV0dXJuIGEuZXF1YWxzKGIpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0VxdWF0YWJsZShiKSkge1xuICAgICAgICAgICAgcmV0dXJuIGIuZXF1YWxzKGEpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgRXF1YXRhYmxlLmVxdWFscyA9IGVxdWFscztcbn0pKEVxdWF0YWJsZSB8fCAoZXhwb3J0cy5FcXVhdGFibGUgPSBFcXVhdGFibGUgPSB7fSkpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9ZXF1YXRhYmxlLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xudmFyIF9fY3JlYXRlQmluZGluZyA9ICh0aGlzICYmIHRoaXMuX19jcmVhdGVCaW5kaW5nKSB8fCAoT2JqZWN0LmNyZWF0ZSA/IChmdW5jdGlvbihvLCBtLCBrLCBrMikge1xuICAgIGlmIChrMiA9PT0gdW5kZWZpbmVkKSBrMiA9IGs7XG4gICAgdmFyIGRlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKG0sIGspO1xuICAgIGlmICghZGVzYyB8fCAoXCJnZXRcIiBpbiBkZXNjID8gIW0uX19lc01vZHVsZSA6IGRlc2Mud3JpdGFibGUgfHwgZGVzYy5jb25maWd1cmFibGUpKSB7XG4gICAgICBkZXNjID0geyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGZ1bmN0aW9uKCkgeyByZXR1cm4gbVtrXTsgfSB9O1xuICAgIH1cbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkobywgazIsIGRlc2MpO1xufSkgOiAoZnVuY3Rpb24obywgbSwgaywgazIpIHtcbiAgICBpZiAoazIgPT09IHVuZGVmaW5lZCkgazIgPSBrO1xuICAgIG9bazJdID0gbVtrXTtcbn0pKTtcbnZhciBfX2V4cG9ydFN0YXIgPSAodGhpcyAmJiB0aGlzLl9fZXhwb3J0U3RhcikgfHwgZnVuY3Rpb24obSwgZXhwb3J0cykge1xuICAgIGZvciAodmFyIHAgaW4gbSkgaWYgKHAgIT09IFwiZGVmYXVsdFwiICYmICFPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoZXhwb3J0cywgcCkpIF9fY3JlYXRlQmluZGluZyhleHBvcnRzLCBtLCBwKTtcbn07XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5fX2V4cG9ydFN0YXIocmVxdWlyZShcIi4vZXF1YXRhYmxlXCIpLCBleHBvcnRzKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5GTlYgPSB2b2lkIDA7XG5jb25zdCBhbGZhX2hhc2hfMSA9IHJlcXVpcmUoXCJAc2l0ZWltcHJvdmUvYWxmYS1oYXNoXCIpO1xuLyoqXG4gKiBAcHVibGljXG4gKi9cbmNsYXNzIEZOViBleHRlbmRzIGFsZmFfaGFzaF8xLkhhc2gge1xuICAgIHN0YXRpYyBlbXB0eSgpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBGTlYoKTtcbiAgICB9XG4gICAgY29uc3RydWN0b3IoKSB7XG4gICAgICAgIHN1cGVyKCk7XG4gICAgICAgIHRoaXMuX2hhc2ggPSAyMTY2MTM2MjYxO1xuICAgIH1cbiAgICBmaW5pc2goKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9oYXNoID4+PiAwOyAvLyBDb252ZXJ0IHRvIHVuc2lnbmVkIDMyLWJpdCBpbnRlZ2VyXG4gICAgfVxuICAgIHdyaXRlKGRhdGEpIHtcbiAgICAgICAgbGV0IGhhc2ggPSB0aGlzLl9oYXNoO1xuICAgICAgICBmb3IgKGNvbnN0IG9jdGV0IG9mIGRhdGEpIHtcbiAgICAgICAgICAgIGhhc2ggXj0gb2N0ZXQ7XG4gICAgICAgICAgICBoYXNoICs9XG4gICAgICAgICAgICAgICAgKGhhc2ggPDwgMSkgKyAoaGFzaCA8PCA0KSArIChoYXNoIDw8IDcpICsgKGhhc2ggPDwgOCkgKyAoaGFzaCA8PCAyNCk7XG4gICAgICAgIH1cbiAgICAgICAgdGhpcy5faGFzaCA9IGhhc2g7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBlcXVhbHModmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgRk5WICYmIHZhbHVlLl9oYXNoID09PSB0aGlzLl9oYXNoO1xuICAgIH1cbn1cbmV4cG9ydHMuRk5WID0gRk5WO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Zm52LmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xudmFyIF9fY3JlYXRlQmluZGluZyA9ICh0aGlzICYmIHRoaXMuX19jcmVhdGVCaW5kaW5nKSB8fCAoT2JqZWN0LmNyZWF0ZSA/IChmdW5jdGlvbihvLCBtLCBrLCBrMikge1xuICAgIGlmIChrMiA9PT0gdW5kZWZpbmVkKSBrMiA9IGs7XG4gICAgdmFyIGRlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKG0sIGspO1xuICAgIGlmICghZGVzYyB8fCAoXCJnZXRcIiBpbiBkZXNjID8gIW0uX19lc01vZHVsZSA6IGRlc2Mud3JpdGFibGUgfHwgZGVzYy5jb25maWd1cmFibGUpKSB7XG4gICAgICBkZXNjID0geyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGZ1bmN0aW9uKCkgeyByZXR1cm4gbVtrXTsgfSB9O1xuICAgIH1cbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkobywgazIsIGRlc2MpO1xufSkgOiAoZnVuY3Rpb24obywgbSwgaywgazIpIHtcbiAgICBpZiAoazIgPT09IHVuZGVmaW5lZCkgazIgPSBrO1xuICAgIG9bazJdID0gbVtrXTtcbn0pKTtcbnZhciBfX2V4cG9ydFN0YXIgPSAodGhpcyAmJiB0aGlzLl9fZXhwb3J0U3RhcikgfHwgZnVuY3Rpb24obSwgZXhwb3J0cykge1xuICAgIGZvciAodmFyIHAgaW4gbSkgaWYgKHAgIT09IFwiZGVmYXVsdFwiICYmICFPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoZXhwb3J0cywgcCkpIF9fY3JlYXRlQmluZGluZyhleHBvcnRzLCBtLCBwKTtcbn07XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5fX2V4cG9ydFN0YXIocmVxdWlyZShcIi4vZm52XCIpLCBleHBvcnRzKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5IYXNoID0gdm9pZCAwO1xuY29uc3QgYWxmYV9lbmNvZGluZ18xID0gcmVxdWlyZShcIkBzaXRlaW1wcm92ZS9hbGZhLWVuY29kaW5nXCIpO1xuY29uc3QgaGFzaGFibGVfMSA9IHJlcXVpcmUoXCIuL2hhc2hhYmxlXCIpO1xuY29uc3QgeyBrZXlzIH0gPSBPYmplY3Q7XG4vKipcbiAqIEEgc3BlY2lhbCBvZmZzZXQgdXNlZCBmb3IgdGhlIGJ1aWx0aW4gdHlwZXMgYHRydWVgLCBgZmFsc2VgLCBgdW5kZWZpbmVkYCwgYW5kXG4gKiBgbnVsbGAuIFRoZSBvZmZzZXQgaXMgZGVzaWduZWQgdG8gbWluaW1pemUgdGhlIGNoYW5jZSBvZiBjb2xsaXNpb25zIGZvciBkYXRhXG4gKiBzdHJ1Y3R1cmVzIHRoYXQgcmVseSBvbiA1LWJpdCBwYXJ0aXRpb25pbmcuIFdlIHVzZSB0aGUgZmlyc3QgMzAgYml0cyBmb3IgNiBvZlxuICogdGhlc2UgcGFydGl0aW9ucywgbGVhdmluZyB1cyAyIGJpdHMgdG8gZW5jb2RlIHRoZSA0IGJ1aWx0aW4gdHlwZXMuXG4gKi9cbmNvbnN0IGJ1aWx0aW5PZmZzZXQgPSAyMjE2NzU3MzEyO1xuLyoqXG4gKiBAcHVibGljXG4gKi9cbmNsYXNzIEhhc2gge1xuICAgIGNvbnN0cnVjdG9yKCkgeyB9XG4gICAgd3JpdGVTdHJpbmcoZGF0YSkge1xuICAgICAgICByZXR1cm4gdGhpcy53cml0ZShhbGZhX2VuY29kaW5nXzEuRW5jb2Rlci5lbmNvZGUoZGF0YSkpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBAcmVtYXJrc1xuICAgICAqIEFzIEphdmFTY3JpcHQgcmVwcmVzZW50cyBudW1iZXJzIGluIGRvdWJsZS1wcmVjaXNpb24gZmxvYXRpbmctcG9pbnQgZm9ybWF0LFxuICAgICAqIG51bWJlcnMgaW4gZ2VuZXJhbCB3aWxsIGJlIHdyaXR0ZW4gYXMgc3VjaC5cbiAgICAgKlxuICAgICAqIHtAbGluayBodHRwczovL2VuLndpa2lwZWRpYS5vcmcvd2lraS9Eb3VibGUtcHJlY2lzaW9uX2Zsb2F0aW5nLXBvaW50X2Zvcm1hdH1cbiAgICAgKi9cbiAgICB3cml0ZU51bWJlcihkYXRhKSB7XG4gICAgICAgIHJldHVybiB0aGlzLndyaXRlRmxvYXQ2NChkYXRhKTtcbiAgICB9XG4gICAgd3JpdGVJbnQoZGF0YSwgc2l6ZSA9IDMyLCBzaWduZWQgPSB0cnVlKSB7XG4gICAgICAgIGNvbnN0IGJ1ZmZlciA9IG5ldyBBcnJheUJ1ZmZlcihzaXplIC8gOCk7XG4gICAgICAgIGNvbnN0IHZpZXcgPSBuZXcgRGF0YVZpZXcoYnVmZmVyKTtcbiAgICAgICAgc3dpdGNoIChzaXplKSB7XG4gICAgICAgICAgICBjYXNlIDg6XG4gICAgICAgICAgICAgICAgc2lnbmVkID8gdmlldy5zZXRJbnQ4KDAsIGRhdGEpIDogdmlldy5zZXRVaW50OCgwLCBkYXRhKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgMTY6XG4gICAgICAgICAgICAgICAgc2lnbmVkID8gdmlldy5zZXRJbnQxNigwLCBkYXRhKSA6IHZpZXcuc2V0VWludDE2KDAsIGRhdGEpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSAzMjpcbiAgICAgICAgICAgICAgICBzaWduZWQgPyB2aWV3LnNldEludDMyKDAsIGRhdGEpIDogdmlldy5zZXRVaW50MzIoMCwgZGF0YSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMud3JpdGUobmV3IFVpbnQ4QXJyYXkoYnVmZmVyKSk7XG4gICAgfVxuICAgIHdyaXRlSW50OChkYXRhKSB7XG4gICAgICAgIHJldHVybiB0aGlzLndyaXRlSW50KGRhdGEsIDgsIHRydWUpO1xuICAgIH1cbiAgICB3cml0ZVVpbnQ4KGRhdGEpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVJbnQoZGF0YSwgOCwgZmFsc2UpO1xuICAgIH1cbiAgICB3cml0ZUludDE2KGRhdGEpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVJbnQoZGF0YSwgMTYsIHRydWUpO1xuICAgIH1cbiAgICB3cml0ZVVpbnQxNihkYXRhKSB7XG4gICAgICAgIHJldHVybiB0aGlzLndyaXRlSW50KGRhdGEsIDE2LCBmYWxzZSk7XG4gICAgfVxuICAgIHdyaXRlSW50MzIoZGF0YSkge1xuICAgICAgICByZXR1cm4gdGhpcy53cml0ZUludChkYXRhLCAzMiwgdHJ1ZSk7XG4gICAgfVxuICAgIHdyaXRlVWludDMyKGRhdGEpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVJbnQoZGF0YSwgMzIsIGZhbHNlKTtcbiAgICB9XG4gICAgd3JpdGVCaWdJbnQoZGF0YSwgc2l6ZSA9IDY0LCBzaWduZWQgPSB0cnVlKSB7XG4gICAgICAgIGNvbnN0IGJ1ZmZlciA9IG5ldyBBcnJheUJ1ZmZlcihzaXplIC8gOCk7XG4gICAgICAgIGNvbnN0IHZpZXcgPSBuZXcgRGF0YVZpZXcoYnVmZmVyKTtcbiAgICAgICAgc3dpdGNoIChzaXplKSB7XG4gICAgICAgICAgICBjYXNlIDY0OlxuICAgICAgICAgICAgICAgIHNpZ25lZCA/IHZpZXcuc2V0QmlnSW50NjQoMCwgZGF0YSkgOiB2aWV3LnNldEJpZ1VpbnQ2NCgwLCBkYXRhKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy53cml0ZShuZXcgVWludDhBcnJheShidWZmZXIpKTtcbiAgICB9XG4gICAgd3JpdGVCaWdJbnQ2NChkYXRhKSB7XG4gICAgICAgIHJldHVybiB0aGlzLndyaXRlQmlnSW50KGRhdGEsIDY0LCB0cnVlKTtcbiAgICB9XG4gICAgd3JpdGVCaWdVaW50NjQoZGF0YSkge1xuICAgICAgICByZXR1cm4gdGhpcy53cml0ZUJpZ0ludChkYXRhLCA2NCwgZmFsc2UpO1xuICAgIH1cbiAgICB3cml0ZUZsb2F0KGRhdGEsIHNpemUgPSAzMikge1xuICAgICAgICBjb25zdCBidWZmZXIgPSBuZXcgQXJyYXlCdWZmZXIoc2l6ZSAvIDgpO1xuICAgICAgICBjb25zdCB2aWV3ID0gbmV3IERhdGFWaWV3KGJ1ZmZlcik7XG4gICAgICAgIHN3aXRjaCAoc2l6ZSkge1xuICAgICAgICAgICAgY2FzZSAzMjpcbiAgICAgICAgICAgICAgICB2aWV3LnNldEZsb2F0MzIoMCwgZGF0YSk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIDY0OlxuICAgICAgICAgICAgICAgIHZpZXcuc2V0RmxvYXQ2NCgwLCBkYXRhKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy53cml0ZShuZXcgVWludDhBcnJheShidWZmZXIpKTtcbiAgICB9XG4gICAgd3JpdGVGbG9hdDMyKGRhdGEpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVGbG9hdChkYXRhLCAzMik7XG4gICAgfVxuICAgIHdyaXRlRmxvYXQ2NChkYXRhKSB7XG4gICAgICAgIHJldHVybiB0aGlzLndyaXRlRmxvYXQoZGF0YSwgNjQpO1xuICAgIH1cbiAgICB3cml0ZUJvb2xlYW4oZGF0YSkge1xuICAgICAgICByZXR1cm4gdGhpcy53cml0ZVVpbnQ4KGJ1aWx0aW5PZmZzZXQgKyAoZGF0YSA/IDEgOiAwKSk7XG4gICAgfVxuICAgIHdyaXRlVW5kZWZpbmVkKCkge1xuICAgICAgICByZXR1cm4gdGhpcy53cml0ZVVpbnQzMihidWlsdGluT2Zmc2V0ICsgMik7XG4gICAgfVxuICAgIHdyaXRlTnVsbCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVVaW50MzIoYnVpbHRpbk9mZnNldCArIDMpO1xuICAgIH1cbiAgICB3cml0ZU9iamVjdChkYXRhKSB7XG4gICAgICAgIGxldCBoYXNoID0gSGFzaC5fb2JqZWN0SGFzaGVzLmdldChkYXRhKTtcbiAgICAgICAgaWYgKGhhc2ggPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgaGFzaCA9IEhhc2guX2dldE5leHRIYXNoKCk7XG4gICAgICAgICAgICBIYXNoLl9vYmplY3RIYXNoZXMuc2V0KGRhdGEsIGhhc2gpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLndyaXRlVWludDMyKGhhc2gpO1xuICAgIH1cbiAgICB3cml0ZVN5bWJvbChkYXRhKSB7XG4gICAgICAgIGxldCBoYXNoID0gSGFzaC5fc3ltYm9sSGFzaGVzLmdldChkYXRhKTtcbiAgICAgICAgaWYgKGhhc2ggPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgaGFzaCA9IEhhc2guX2dldE5leHRIYXNoKCk7XG4gICAgICAgICAgICBIYXNoLl9zeW1ib2xIYXNoZXMuc2V0KGRhdGEsIGhhc2gpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLndyaXRlVWludDMyKGhhc2gpO1xuICAgIH1cbiAgICB3cml0ZUhhc2hhYmxlKGRhdGEpIHtcbiAgICAgICAgZGF0YS5oYXNoKHRoaXMpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgd3JpdGVVbmtub3duKGRhdGEpIHtcbiAgICAgICAgc3dpdGNoICh0eXBlb2YgZGF0YSkge1xuICAgICAgICAgICAgY2FzZSBcInN0cmluZ1wiOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLndyaXRlU3RyaW5nKGRhdGEpO1xuICAgICAgICAgICAgY2FzZSBcIm51bWJlclwiOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLndyaXRlTnVtYmVyKGRhdGEpO1xuICAgICAgICAgICAgY2FzZSBcImJpZ2ludFwiOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLndyaXRlQmlnSW50KGRhdGEpO1xuICAgICAgICAgICAgY2FzZSBcImJvb2xlYW5cIjpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy53cml0ZUJvb2xlYW4oZGF0YSk7XG4gICAgICAgICAgICBjYXNlIFwic3ltYm9sXCI6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVTeW1ib2woZGF0YSk7XG4gICAgICAgICAgICBjYXNlIFwidW5kZWZpbmVkXCI6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVVbmRlZmluZWQoKTtcbiAgICAgICAgICAgIGNhc2UgXCJvYmplY3RcIjpcbiAgICAgICAgICAgICAgICBpZiAoZGF0YSA9PT0gbnVsbCkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy53cml0ZU51bGwoKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgaWYgKGhhc2hhYmxlXzEuSGFzaGFibGUuaXNIYXNoYWJsZShkYXRhKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy53cml0ZUhhc2hhYmxlKGRhdGEpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy53cml0ZU9iamVjdChkYXRhKTtcbiAgICAgICAgICAgIGNhc2UgXCJmdW5jdGlvblwiOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLndyaXRlT2JqZWN0KGRhdGEpO1xuICAgICAgICB9XG4gICAgfVxuICAgIHdyaXRlSlNPTihkYXRhKSB7XG4gICAgICAgIHN3aXRjaCAodHlwZW9mIGRhdGEpIHtcbiAgICAgICAgICAgIGNhc2UgXCJzdHJpbmdcIjpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy53cml0ZVN0cmluZyhkYXRhKTtcbiAgICAgICAgICAgIGNhc2UgXCJudW1iZXJcIjpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy53cml0ZU51bWJlcihkYXRhKTtcbiAgICAgICAgICAgIGNhc2UgXCJib29sZWFuXCI6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVCb29sZWFuKGRhdGEpO1xuICAgICAgICAgICAgY2FzZSBcIm9iamVjdFwiOlxuICAgICAgICAgICAgICAgIGlmIChBcnJheS5pc0FycmF5KGRhdGEpKSB7XG4gICAgICAgICAgICAgICAgICAgIGZvciAobGV0IGkgPSAwLCBuID0gZGF0YS5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMud3JpdGVKU09OKGRhdGFbaV0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHRoaXMud3JpdGVVaW50MzIoZGF0YS5sZW5ndGgpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICBlbHNlIGlmIChkYXRhICE9PSBudWxsKSB7XG4gICAgICAgICAgICAgICAgICAgIGZvciAoY29uc3Qga2V5IG9mIGtleXMoZGF0YSkuc29ydCgpKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICBjb25zdCB2YWx1ZSA9IGRhdGFba2V5XTtcbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMud3JpdGVTdHJpbmcoa2V5KTtcbiAgICAgICAgICAgICAgICAgICAgICAgIGlmICh2YWx1ZSAhPT0gdW5kZWZpbmVkKSB7XG4gICAgICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy53cml0ZUpTT04odmFsdWUpO1xuICAgICAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gV3JpdGUgYSBudWxsIGJ5dGUgYXMgYSBzZXBhcmF0b3IgYmV0d2VlbiBrZXkvdmFsdWUgcGFpcnMuXG4gICAgICAgICAgICAgICAgICAgICAgICB0aGlzLndyaXRlVWludDgoMCk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH1cbiAgICB9XG4gICAgZXF1YWxzKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIEhhc2ggJiYgdmFsdWUuZmluaXNoKCkgPT09IHRoaXMuZmluaXNoKCk7XG4gICAgfVxuICAgIGhhc2goaGFzaCkge1xuICAgICAgICBoYXNoLndyaXRlVWludDMyKHRoaXMuZmluaXNoKCkpO1xuICAgIH1cbiAgICBzdGF0aWMgX2dldE5leHRIYXNoKCkge1xuICAgICAgICBjb25zdCBuZXh0SGFzaCA9IEhhc2guX25leHRIYXNoO1xuICAgICAgICAvLyBJbmNyZWFzZSB0aGUgaGFzaCwgd3JhcHBpbmcgYXJvdW5kIHdoZW4gaXQgcmVhY2hlcyB0aGUgbGltaXQgb2YgMzIgYml0cy5cbiAgICAgICAgSGFzaC5fbmV4dEhhc2ggPSAoSGFzaC5fbmV4dEhhc2ggKyAxKSA+Pj4gMDtcbiAgICAgICAgcmV0dXJuIG5leHRIYXNoO1xuICAgIH1cbn1cbmV4cG9ydHMuSGFzaCA9IEhhc2g7XG4vKipcbiAqIEEgbWFwIGZyb20gb2JqZWN0cyB0byB0aGVpciBoYXNoIHZhbHVlcy4gT2JqZWN0cyBhcmUgd2Vha2x5IHJlZmVyZW5jZWQgYXNcbiAqIHRvIG5vdCBwcmV2ZW50IHRoZW0gZnJvbSBiZWluZyBnYXJiYWdlIGNvbGxlY3RlZC5cbiAqL1xuSGFzaC5fb2JqZWN0SGFzaGVzID0gbmV3IFdlYWtNYXAoKTtcbi8qKlxuICogQSBtYXAgZnJvbSBzeW1ib2xzIHRvIHRoZWlyIGhhc2ggdmFsdWVzLiBBcyB0aGVyZSdzIG5vdCBjdXJyZW50bHkgYSB3YXkgdG9cbiAqIHdlYWtseSByZWZlcmVuY2Ugc3ltYm9scywgd2UgaGF2ZSB0byBpbnN0ZWFkIHVzZSBzdHJvbmcgcmVmZXJlbmNlcy5cbiAqXG4gKiB7QGxpbmsgaHR0cHM6Ly9naXRodWIuY29tL3RjMzkvcHJvcG9zYWwtc3ltYm9scy1hcy13ZWFrbWFwLWtleXN9XG4gKi9cbkhhc2guX3N5bWJvbEhhc2hlcyA9IG5ldyBNYXAoKTtcbi8qKlxuICogVGhlIG5leHQgYXZhaWxhYmxlIGhhc2ggdmFsdWUuIFRoaXMgaXMgdXNlZCBmb3Igc3ltYm9scyBhbmQgb2JqZWN0cyB0aGF0XG4gKiBkb24ndCBpbXBsZW1lbnQgdGhlIHtAbGluayAoSGFzaGFibGU6aW50ZXJmYWNlKX0gaW50ZXJmYWNlLlxuICovXG5IYXNoLl9uZXh0SGFzaCA9IDA7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1oYXNoLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5IYXNoYWJsZSA9IHZvaWQgMDtcbmNvbnN0IGFsZmFfcmVmaW5lbWVudF8xID0gcmVxdWlyZShcIkBzaXRlaW1wcm92ZS9hbGZhLXJlZmluZW1lbnRcIik7XG5jb25zdCB7IGlzRnVuY3Rpb24sIGlzT2JqZWN0IH0gPSBhbGZhX3JlZmluZW1lbnRfMS5SZWZpbmVtZW50O1xuLyoqXG4gKiBAcHVibGljXG4gKi9cbnZhciBIYXNoYWJsZTtcbihmdW5jdGlvbiAoSGFzaGFibGUpIHtcbiAgICBmdW5jdGlvbiBpc0hhc2hhYmxlKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiBpc09iamVjdCh2YWx1ZSkgJiYgaXNGdW5jdGlvbih2YWx1ZS5oYXNoKTtcbiAgICB9XG4gICAgSGFzaGFibGUuaXNIYXNoYWJsZSA9IGlzSGFzaGFibGU7XG59KShIYXNoYWJsZSB8fCAoZXhwb3J0cy5IYXNoYWJsZSA9IEhhc2hhYmxlID0ge30pKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWhhc2hhYmxlLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xudmFyIF9fY3JlYXRlQmluZGluZyA9ICh0aGlzICYmIHRoaXMuX19jcmVhdGVCaW5kaW5nKSB8fCAoT2JqZWN0LmNyZWF0ZSA/IChmdW5jdGlvbihvLCBtLCBrLCBrMikge1xuICAgIGlmIChrMiA9PT0gdW5kZWZpbmVkKSBrMiA9IGs7XG4gICAgdmFyIGRlc2MgPSBPYmplY3QuZ2V0T3duUHJvcGVydHlEZXNjcmlwdG9yKG0sIGspO1xuICAgIGlmICghZGVzYyB8fCAoXCJnZXRcIiBpbiBkZXNjID8gIW0uX19lc01vZHVsZSA6IGRlc2Mud3JpdGFibGUgfHwgZGVzYy5jb25maWd1cmFibGUpKSB7XG4gICAgICBkZXNjID0geyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGZ1bmN0aW9uKCkgeyByZXR1cm4gbVtrXTsgfSB9O1xuICAgIH1cbiAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkobywgazIsIGRlc2MpO1xufSkgOiAoZnVuY3Rpb24obywgbSwgaywgazIpIHtcbiAgICBpZiAoazIgPT09IHVuZGVmaW5lZCkgazIgPSBrO1xuICAgIG9bazJdID0gbVtrXTtcbn0pKTtcbnZhciBfX2V4cG9ydFN0YXIgPSAodGhpcyAmJiB0aGlzLl9fZXhwb3J0U3RhcikgfHwgZnVuY3Rpb24obSwgZXhwb3J0cykge1xuICAgIGZvciAodmFyIHAgaW4gbSkgaWYgKHAgIT09IFwiZGVmYXVsdFwiICYmICFPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwoZXhwb3J0cywgcCkpIF9fY3JlYXRlQmluZGluZyhleHBvcnRzLCBtLCBwKTtcbn07XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5fX2V4cG9ydFN0YXIocmVxdWlyZShcIi4vaGFzaFwiKSwgZXhwb3J0cyk7XG5fX2V4cG9ydFN0YXIocmVxdWlyZShcIi4vaGFzaGFibGVcIiksIGV4cG9ydHMpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXguanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG52YXIgX19jcmVhdGVCaW5kaW5nID0gKHRoaXMgJiYgdGhpcy5fX2NyZWF0ZUJpbmRpbmcpIHx8IChPYmplY3QuY3JlYXRlID8gKGZ1bmN0aW9uKG8sIG0sIGssIGsyKSB7XG4gICAgaWYgKGsyID09PSB1bmRlZmluZWQpIGsyID0gaztcbiAgICB2YXIgZGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IobSwgayk7XG4gICAgaWYgKCFkZXNjIHx8IChcImdldFwiIGluIGRlc2MgPyAhbS5fX2VzTW9kdWxlIDogZGVzYy53cml0YWJsZSB8fCBkZXNjLmNvbmZpZ3VyYWJsZSkpIHtcbiAgICAgIGRlc2MgPSB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZnVuY3Rpb24oKSB7IHJldHVybiBtW2tdOyB9IH07XG4gICAgfVxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvLCBrMiwgZGVzYyk7XG59KSA6IChmdW5jdGlvbihvLCBtLCBrLCBrMikge1xuICAgIGlmIChrMiA9PT0gdW5kZWZpbmVkKSBrMiA9IGs7XG4gICAgb1trMl0gPSBtW2tdO1xufSkpO1xudmFyIF9fZXhwb3J0U3RhciA9ICh0aGlzICYmIHRoaXMuX19leHBvcnRTdGFyKSB8fCBmdW5jdGlvbihtLCBleHBvcnRzKSB7XG4gICAgZm9yICh2YXIgcCBpbiBtKSBpZiAocCAhPT0gXCJkZWZhdWx0XCIgJiYgIU9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChleHBvcnRzLCBwKSkgX19jcmVhdGVCaW5kaW5nKGV4cG9ydHMsIG0sIHApO1xufTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbl9fZXhwb3J0U3RhcihyZXF1aXJlKFwiLi9pdGVyYWJsZVwiKSwgZXhwb3J0cyk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMuSXRlcmFibGUgPSB2b2lkIDA7XG5jb25zdCBhbGZhX2NvbXBhcmFibGVfMSA9IHJlcXVpcmUoXCJAc2l0ZWltcHJvdmUvYWxmYS1jb21wYXJhYmxlXCIpO1xuY29uc3QgYWxmYV9lcXVhdGFibGVfMSA9IHJlcXVpcmUoXCJAc2l0ZWltcHJvdmUvYWxmYS1lcXVhdGFibGVcIik7XG5jb25zdCBhbGZhX2pzb25fMSA9IHJlcXVpcmUoXCJAc2l0ZWltcHJvdmUvYWxmYS1qc29uXCIpO1xuY29uc3QgYWxmYV9vcHRpb25fMSA9IHJlcXVpcmUoXCJAc2l0ZWltcHJvdmUvYWxmYS1vcHRpb25cIik7XG5jb25zdCBhbGZhX3ByZWRpY2F0ZV8xID0gcmVxdWlyZShcIkBzaXRlaW1wcm92ZS9hbGZhLXByZWRpY2F0ZVwiKTtcbmNvbnN0IGFsZmFfcmVmaW5lbWVudF8xID0gcmVxdWlyZShcIkBzaXRlaW1wcm92ZS9hbGZhLXJlZmluZW1lbnRcIik7XG5jb25zdCB7IG5vdCB9ID0gYWxmYV9wcmVkaWNhdGVfMS5QcmVkaWNhdGU7XG5jb25zdCB7IGlzT2JqZWN0IH0gPSBhbGZhX3JlZmluZW1lbnRfMS5SZWZpbmVtZW50O1xuY29uc3QgeyBjb21wYXJlQ29tcGFyYWJsZSB9ID0gYWxmYV9jb21wYXJhYmxlXzEuQ29tcGFyYWJsZTtcbi8qKlxuICogQHB1YmxpY1xuICovXG52YXIgSXRlcmFibGU7XG4oZnVuY3Rpb24gKEl0ZXJhYmxlKSB7XG4gICAgZnVuY3Rpb24gaXNJdGVyYWJsZSh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gaXNPYmplY3QodmFsdWUpICYmIFN5bWJvbC5pdGVyYXRvciBpbiB2YWx1ZTtcbiAgICB9XG4gICAgSXRlcmFibGUuaXNJdGVyYWJsZSA9IGlzSXRlcmFibGU7XG4gICAgZnVuY3Rpb24qIGVtcHR5KCkgeyB9XG4gICAgSXRlcmFibGUuZW1wdHkgPSBlbXB0eTtcbiAgICBmdW5jdGlvbiogZnJvbShhcnJheUxpa2UpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG4gPSBhcnJheUxpa2UubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICB5aWVsZCBhcnJheUxpa2VbaV07XG4gICAgICAgIH1cbiAgICB9XG4gICAgSXRlcmFibGUuZnJvbSA9IGZyb207XG4gICAgZnVuY3Rpb24gc2l6ZShpdGVyYWJsZSkge1xuICAgICAgICByZXR1cm4gcmVkdWNlKGl0ZXJhYmxlLCAoc2l6ZSkgPT4gc2l6ZSArIDEsIDApO1xuICAgIH1cbiAgICBJdGVyYWJsZS5zaXplID0gc2l6ZTtcbiAgICBmdW5jdGlvbiBpc0VtcHR5KGl0ZXJhYmxlKSB7XG4gICAgICAgIGZvciAoY29uc3QgXyBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBJdGVyYWJsZS5pc0VtcHR5ID0gaXNFbXB0eTtcbiAgICBmdW5jdGlvbiBmb3JFYWNoKGl0ZXJhYmxlLCBjYWxsYmFjaykge1xuICAgICAgICBsZXQgaW5kZXggPSAwO1xuICAgICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIGl0ZXJhYmxlKSB7XG4gICAgICAgICAgICBjYWxsYmFjayh2YWx1ZSwgaW5kZXgrKyk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgSXRlcmFibGUuZm9yRWFjaCA9IGZvckVhY2g7XG4gICAgZnVuY3Rpb24qIG1hcChpdGVyYWJsZSwgbWFwcGVyKSB7XG4gICAgICAgIGxldCBpbmRleCA9IDA7XG4gICAgICAgIGZvciAoY29uc3QgdmFsdWUgb2YgaXRlcmFibGUpIHtcbiAgICAgICAgICAgIHlpZWxkIG1hcHBlcih2YWx1ZSwgaW5kZXgrKyk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgSXRlcmFibGUubWFwID0gbWFwO1xuICAgIGZ1bmN0aW9uKiBmbGF0TWFwKGl0ZXJhYmxlLCBtYXBwZXIpIHtcbiAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgeWllbGQqIG1hcHBlcih2YWx1ZSwgaW5kZXgrKyk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgSXRlcmFibGUuZmxhdE1hcCA9IGZsYXRNYXA7XG4gICAgZnVuY3Rpb24qIGZsYXR0ZW4oaXRlcmFibGUpIHtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgeWllbGQqIHZhbHVlO1xuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLmZsYXR0ZW4gPSBmbGF0dGVuO1xuICAgIGZ1bmN0aW9uIHJlZHVjZShpdGVyYWJsZSwgcmVkdWNlciwgYWNjdW11bGF0b3IpIHtcbiAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgYWNjdW11bGF0b3IgPSByZWR1Y2VyKGFjY3VtdWxhdG9yLCB2YWx1ZSwgaW5kZXgrKyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGFjY3VtdWxhdG9yO1xuICAgIH1cbiAgICBJdGVyYWJsZS5yZWR1Y2UgPSByZWR1Y2U7XG4gICAgZnVuY3Rpb24gcmVkdWNlV2hpbGUoaXRlcmFibGUsIHByZWRpY2F0ZSwgcmVkdWNlciwgYWNjdW11bGF0b3IpIHtcbiAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgaWYgKHByZWRpY2F0ZSh2YWx1ZSwgaW5kZXgpKSB7XG4gICAgICAgICAgICAgICAgYWNjdW11bGF0b3IgPSByZWR1Y2VyKGFjY3VtdWxhdG9yLCB2YWx1ZSwgaW5kZXgrKyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYWNjdW11bGF0b3I7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnJlZHVjZVdoaWxlID0gcmVkdWNlV2hpbGU7XG4gICAgZnVuY3Rpb24gcmVkdWNlVW50aWwoaXRlcmFibGUsIHByZWRpY2F0ZSwgcmVkdWNlciwgYWNjdW11bGF0b3IpIHtcbiAgICAgICAgcmV0dXJuIHJlZHVjZVdoaWxlKGl0ZXJhYmxlLCBub3QocHJlZGljYXRlKSwgcmVkdWNlciwgYWNjdW11bGF0b3IpO1xuICAgIH1cbiAgICBJdGVyYWJsZS5yZWR1Y2VVbnRpbCA9IHJlZHVjZVVudGlsO1xuICAgIGZ1bmN0aW9uIGFwcGx5KGl0ZXJhYmxlLCBtYXBwZXIpIHtcbiAgICAgICAgcmV0dXJuIGZsYXRNYXAobWFwcGVyLCAobWFwcGVyKSA9PiBtYXAoaXRlcmFibGUsIG1hcHBlcikpO1xuICAgIH1cbiAgICBJdGVyYWJsZS5hcHBseSA9IGFwcGx5O1xuICAgIGZ1bmN0aW9uKiBmaWx0ZXIoaXRlcmFibGUsIHByZWRpY2F0ZSkge1xuICAgICAgICBsZXQgaW5kZXggPSAwO1xuICAgICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIGl0ZXJhYmxlKSB7XG4gICAgICAgICAgICBpZiAocHJlZGljYXRlKHZhbHVlLCBpbmRleCsrKSkge1xuICAgICAgICAgICAgICAgIHlpZWxkIHZhbHVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLmZpbHRlciA9IGZpbHRlcjtcbiAgICBmdW5jdGlvbiByZWplY3QoaXRlcmFibGUsIHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gZmlsdGVyKGl0ZXJhYmxlLCBub3QocHJlZGljYXRlKSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnJlamVjdCA9IHJlamVjdDtcbiAgICBmdW5jdGlvbiBmaW5kKGl0ZXJhYmxlLCBwcmVkaWNhdGUpIHtcbiAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgaWYgKHByZWRpY2F0ZSh2YWx1ZSwgaW5kZXgrKykpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gYWxmYV9vcHRpb25fMS5PcHRpb24ub2YodmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBhbGZhX29wdGlvbl8xLk5vbmU7XG4gICAgfVxuICAgIEl0ZXJhYmxlLmZpbmQgPSBmaW5kO1xuICAgIGZ1bmN0aW9uIGZpbmRMYXN0KGl0ZXJhYmxlLCBwcmVkaWNhdGUpIHtcbiAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgbGV0IHJlc3VsdCA9IGFsZmFfb3B0aW9uXzEuTm9uZTtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgaWYgKHByZWRpY2F0ZSh2YWx1ZSwgaW5kZXgrKykpIHtcbiAgICAgICAgICAgICAgICByZXN1bHQgPSBhbGZhX29wdGlvbl8xLk9wdGlvbi5vZih2YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgSXRlcmFibGUuZmluZExhc3QgPSBmaW5kTGFzdDtcbiAgICBmdW5jdGlvbiBpbmNsdWRlcyhpdGVyYWJsZSwgdmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHNvbWUoaXRlcmFibGUsIGFsZmFfcHJlZGljYXRlXzEuUHJlZGljYXRlLmVxdWFscyh2YWx1ZSkpO1xuICAgIH1cbiAgICBJdGVyYWJsZS5pbmNsdWRlcyA9IGluY2x1ZGVzO1xuICAgIGZ1bmN0aW9uIGNvbGxlY3QoaXRlcmFibGUsIG1hcHBlcikge1xuICAgICAgICByZXR1cm4gZmxhdE1hcChpdGVyYWJsZSwgbWFwcGVyKTtcbiAgICB9XG4gICAgSXRlcmFibGUuY29sbGVjdCA9IGNvbGxlY3Q7XG4gICAgZnVuY3Rpb24gY29sbGVjdEZpcnN0KGl0ZXJhYmxlLCBtYXBwZXIpIHtcbiAgICAgICAgcmV0dXJuIGZpcnN0KGNvbGxlY3QoaXRlcmFibGUsIG1hcHBlcikpO1xuICAgIH1cbiAgICBJdGVyYWJsZS5jb2xsZWN0Rmlyc3QgPSBjb2xsZWN0Rmlyc3Q7XG4gICAgZnVuY3Rpb24gc29tZShpdGVyYWJsZSwgcHJlZGljYXRlKSB7XG4gICAgICAgIGxldCBpbmRleCA9IDA7XG4gICAgICAgIGZvciAoY29uc3QgdmFsdWUgb2YgaXRlcmFibGUpIHtcbiAgICAgICAgICAgIGlmIChwcmVkaWNhdGUodmFsdWUsIGluZGV4KyspKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBJdGVyYWJsZS5zb21lID0gc29tZTtcbiAgICBmdW5jdGlvbiBub25lKGl0ZXJhYmxlLCBwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIGV2ZXJ5KGl0ZXJhYmxlLCBub3QocHJlZGljYXRlKSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLm5vbmUgPSBub25lO1xuICAgIGZ1bmN0aW9uIGV2ZXJ5KGl0ZXJhYmxlLCBwcmVkaWNhdGUpIHtcbiAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgaWYgKCFwcmVkaWNhdGUodmFsdWUsIGluZGV4KyspKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBJdGVyYWJsZS5ldmVyeSA9IGV2ZXJ5O1xuICAgIGZ1bmN0aW9uIGNvdW50KGl0ZXJhYmxlLCBwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIHJlZHVjZShpdGVyYWJsZSwgKGNvdW50LCB2YWx1ZSwgaW5kZXgpID0+IChwcmVkaWNhdGUodmFsdWUsIGluZGV4KSA/IGNvdW50ICsgMSA6IGNvdW50KSwgMCk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLmNvdW50ID0gY291bnQ7XG4gICAgZnVuY3Rpb24qIGRpc3RpbmN0KGl0ZXJhYmxlKSB7XG4gICAgICAgIGNvbnN0IHNlZW4gPSBbXTtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgaWYgKHNlZW4uc29tZShhbGZhX3ByZWRpY2F0ZV8xLlByZWRpY2F0ZS5lcXVhbHModmFsdWUpKSkge1xuICAgICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgc2Vlbi5wdXNoKHZhbHVlKTtcbiAgICAgICAgICAgIHlpZWxkIHZhbHVlO1xuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLmRpc3RpbmN0ID0gZGlzdGluY3Q7XG4gICAgZnVuY3Rpb24gZ2V0KGl0ZXJhYmxlLCBpbmRleCkge1xuICAgICAgICByZXR1cm4gaW5kZXggPCAwID8gYWxmYV9vcHRpb25fMS5Ob25lIDogZmlyc3Qoc2tpcChpdGVyYWJsZSwgaW5kZXgpKTtcbiAgICB9XG4gICAgSXRlcmFibGUuZ2V0ID0gZ2V0O1xuICAgIGZ1bmN0aW9uIGhhcyhpdGVyYWJsZSwgaW5kZXgpIHtcbiAgICAgICAgcmV0dXJuIGluZGV4IDwgMCA/IGZhbHNlIDogIWlzRW1wdHkoc2tpcChpdGVyYWJsZSwgaW5kZXgpKTtcbiAgICB9XG4gICAgSXRlcmFibGUuaGFzID0gaGFzO1xuICAgIGZ1bmN0aW9uKiBzZXQoaXRlcmFibGUsIGluZGV4LCB2YWx1ZSkge1xuICAgICAgICBjb25zdCBpdCA9IGl0ZXJhdG9yKGl0ZXJhYmxlKTtcbiAgICAgICAgd2hpbGUgKGluZGV4LS0gPiAwKSB7XG4gICAgICAgICAgICBjb25zdCBuZXh0ID0gaXQubmV4dCgpO1xuICAgICAgICAgICAgaWYgKG5leHQuZG9uZSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHlpZWxkIG5leHQudmFsdWU7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgbmV4dCA9IGl0Lm5leHQoKTtcbiAgICAgICAgaWYgKG5leHQuZG9uZSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHlpZWxkIHZhbHVlO1xuICAgICAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgICAgICAgY29uc3QgbmV4dCA9IGl0Lm5leHQoKTtcbiAgICAgICAgICAgIGlmIChuZXh0LmRvbmUgPT09IHRydWUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB5aWVsZCBuZXh0LnZhbHVlO1xuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLnNldCA9IHNldDtcbiAgICBmdW5jdGlvbiogaW5zZXJ0KGl0ZXJhYmxlLCBpbmRleCwgdmFsdWUpIHtcbiAgICAgICAgY29uc3QgaXQgPSBpdGVyYXRvcihpdGVyYWJsZSk7XG4gICAgICAgIHdoaWxlIChpbmRleC0tID4gMCkge1xuICAgICAgICAgICAgY29uc3QgbmV4dCA9IGl0Lm5leHQoKTtcbiAgICAgICAgICAgIGlmIChuZXh0LmRvbmUgPT09IHRydWUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB5aWVsZCBuZXh0LnZhbHVlO1xuICAgICAgICB9XG4gICAgICAgIHlpZWxkIHZhbHVlO1xuICAgICAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgICAgICAgY29uc3QgbmV4dCA9IGl0Lm5leHQoKTtcbiAgICAgICAgICAgIGlmIChuZXh0LmRvbmUgPT09IHRydWUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB5aWVsZCBuZXh0LnZhbHVlO1xuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLmluc2VydCA9IGluc2VydDtcbiAgICBmdW5jdGlvbiogYXBwZW5kKGl0ZXJhYmxlLCB2YWx1ZSkge1xuICAgICAgICB5aWVsZCogaXRlcmFibGU7XG4gICAgICAgIHlpZWxkIHZhbHVlO1xuICAgIH1cbiAgICBJdGVyYWJsZS5hcHBlbmQgPSBhcHBlbmQ7XG4gICAgZnVuY3Rpb24qIHByZXBlbmQoaXRlcmFibGUsIHZhbHVlKSB7XG4gICAgICAgIHlpZWxkIHZhbHVlO1xuICAgICAgICB5aWVsZCogaXRlcmFibGU7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnByZXBlbmQgPSBwcmVwZW5kO1xuICAgIGZ1bmN0aW9uKiBjb25jYXQoaXRlcmFibGUsIC4uLml0ZXJhYmxlcykge1xuICAgICAgICB5aWVsZCogaXRlcmFibGU7XG4gICAgICAgIGZvciAoY29uc3QgaXRlcmFibGUgb2YgaXRlcmFibGVzKSB7XG4gICAgICAgICAgICB5aWVsZCogaXRlcmFibGU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgSXRlcmFibGUuY29uY2F0ID0gY29uY2F0O1xuICAgIGZ1bmN0aW9uIHN1YnRyYWN0KGl0ZXJhYmxlLCAuLi5pdGVyYWJsZXMpIHtcbiAgICAgICAgcmV0dXJuIHJlamVjdChpdGVyYWJsZSwgKHZhbHVlKSA9PiBpbmNsdWRlcyhmbGF0dGVuKGl0ZXJhYmxlcyksIHZhbHVlKSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnN1YnRyYWN0ID0gc3VidHJhY3Q7XG4gICAgZnVuY3Rpb24gaW50ZXJzZWN0KGl0ZXJhYmxlLCAuLi5pdGVyYWJsZXMpIHtcbiAgICAgICAgcmV0dXJuIGZpbHRlcihpdGVyYWJsZSwgKHZhbHVlKSA9PiBpbmNsdWRlcyhmbGF0dGVuKGl0ZXJhYmxlcyksIHZhbHVlKSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLmludGVyc2VjdCA9IGludGVyc2VjdDtcbiAgICBmdW5jdGlvbiogemlwKGEsIGIpIHtcbiAgICAgICAgY29uc3QgaXRBID0gaXRlcmF0b3IoYSk7XG4gICAgICAgIGNvbnN0IGl0QiA9IGl0ZXJhdG9yKGIpO1xuICAgICAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgICAgICAgY29uc3QgYSA9IGl0QS5uZXh0KCk7XG4gICAgICAgICAgICBjb25zdCBiID0gaXRCLm5leHQoKTtcbiAgICAgICAgICAgIGlmIChhLmRvbmUgPT09IHRydWUgfHwgYi5kb25lID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgeWllbGQgW2EudmFsdWUsIGIudmFsdWVdO1xuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLnppcCA9IHppcDtcbiAgICBmdW5jdGlvbiBmaXJzdChpdGVyYWJsZSkge1xuICAgICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIGl0ZXJhYmxlKSB7XG4gICAgICAgICAgICByZXR1cm4gYWxmYV9vcHRpb25fMS5PcHRpb24ub2YodmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBhbGZhX29wdGlvbl8xLk5vbmU7XG4gICAgfVxuICAgIEl0ZXJhYmxlLmZpcnN0ID0gZmlyc3Q7XG4gICAgZnVuY3Rpb24gbGFzdChpdGVyYWJsZSkge1xuICAgICAgICBsZXQgbGFzdCA9IG51bGw7XG4gICAgICAgIGZvciAoY29uc3QgdmFsdWUgb2YgaXRlcmFibGUpIHtcbiAgICAgICAgICAgIGxhc3QgPSB2YWx1ZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYWxmYV9vcHRpb25fMS5PcHRpb24uZnJvbShsYXN0KTtcbiAgICB9XG4gICAgSXRlcmFibGUubGFzdCA9IGxhc3Q7XG4gICAgZnVuY3Rpb24qIHRha2UoaXRlcmFibGUsIGNvdW50KSB7XG4gICAgICAgIGNvbnN0IGl0ID0gaXRlcmF0b3IoaXRlcmFibGUpO1xuICAgICAgICB3aGlsZSAoY291bnQtLSA+IDApIHtcbiAgICAgICAgICAgIGNvbnN0IG5leHQgPSBpdC5uZXh0KCk7XG4gICAgICAgICAgICBpZiAobmV4dC5kb25lID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgeWllbGQgbmV4dC52YWx1ZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBJdGVyYWJsZS50YWtlID0gdGFrZTtcbiAgICBmdW5jdGlvbiogdGFrZVdoaWxlKGl0ZXJhYmxlLCBwcmVkaWNhdGUpIHtcbiAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgaWYgKHByZWRpY2F0ZSh2YWx1ZSwgaW5kZXgrKykpIHtcbiAgICAgICAgICAgICAgICB5aWVsZCB2YWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLnRha2VXaGlsZSA9IHRha2VXaGlsZTtcbiAgICBmdW5jdGlvbiB0YWtlVW50aWwoaXRlcmFibGUsIHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gdGFrZVdoaWxlKGl0ZXJhYmxlLCBub3QocHJlZGljYXRlKSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnRha2VVbnRpbCA9IHRha2VVbnRpbDtcbiAgICBmdW5jdGlvbiogdGFrZUxhc3QoaXRlcmFibGUsIGNvdW50ID0gMSkge1xuICAgICAgICBpZiAoY291bnQgPD0gMCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGxhc3QgPSBbXTtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgbGFzdC5wdXNoKHZhbHVlKTtcbiAgICAgICAgICAgIGlmIChsYXN0Lmxlbmd0aCA+IGNvdW50KSB7XG4gICAgICAgICAgICAgICAgbGFzdC5zaGlmdCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHlpZWxkKiBsYXN0O1xuICAgIH1cbiAgICBJdGVyYWJsZS50YWtlTGFzdCA9IHRha2VMYXN0O1xuICAgIGZ1bmN0aW9uKiB0YWtlTGFzdFdoaWxlKGl0ZXJhYmxlLCBwcmVkaWNhdGUpIHtcbiAgICAgICAgY29uc3QgdmFsdWVzID0gWy4uLml0ZXJhYmxlXTtcbiAgICAgICAgbGV0IGxhc3QgPSB2YWx1ZXMubGVuZ3RoIC0gMTtcbiAgICAgICAgd2hpbGUgKGxhc3QgPj0gMCkge1xuICAgICAgICAgICAgaWYgKHByZWRpY2F0ZSh2YWx1ZXNbbGFzdF0sIGxhc3QpKSB7XG4gICAgICAgICAgICAgICAgbGFzdC0tO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChsZXQgaSA9IGxhc3QsIG4gPSB2YWx1ZXMubGVuZ3RoIC0gMTsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgeWllbGQgdmFsdWVzW2ldO1xuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLnRha2VMYXN0V2hpbGUgPSB0YWtlTGFzdFdoaWxlO1xuICAgIGZ1bmN0aW9uIHRha2VMYXN0VW50aWwoaXRlcmFibGUsIHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gdGFrZUxhc3RXaGlsZShpdGVyYWJsZSwgbm90KHByZWRpY2F0ZSkpO1xuICAgIH1cbiAgICBJdGVyYWJsZS50YWtlTGFzdFVudGlsID0gdGFrZUxhc3RVbnRpbDtcbiAgICBmdW5jdGlvbiogc2tpcChpdGVyYWJsZSwgY291bnQpIHtcbiAgICAgICAgY29uc3QgaXQgPSBpdGVyYXRvcihpdGVyYWJsZSk7XG4gICAgICAgIHdoaWxlIChjb3VudC0tID4gMCkge1xuICAgICAgICAgICAgY29uc3QgbmV4dCA9IGl0Lm5leHQoKTtcbiAgICAgICAgICAgIGlmIChuZXh0LmRvbmUgPT09IHRydWUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgICAgIGNvbnN0IG5leHQgPSBpdC5uZXh0KCk7XG4gICAgICAgICAgICBpZiAobmV4dC5kb25lID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgeWllbGQgbmV4dC52YWx1ZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBJdGVyYWJsZS5za2lwID0gc2tpcDtcbiAgICBmdW5jdGlvbiogc2tpcFdoaWxlKGl0ZXJhYmxlLCBwcmVkaWNhdGUpIHtcbiAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgbGV0IHNraXBwZWQgPSBmYWxzZTtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgaWYgKCFza2lwcGVkICYmIHByZWRpY2F0ZSh2YWx1ZSwgaW5kZXgrKykpIHtcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHNraXBwZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHlpZWxkIHZhbHVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLnNraXBXaGlsZSA9IHNraXBXaGlsZTtcbiAgICBmdW5jdGlvbiBza2lwVW50aWwoaXRlcmFibGUsIHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gc2tpcFdoaWxlKGl0ZXJhYmxlLCBub3QocHJlZGljYXRlKSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnNraXBVbnRpbCA9IHNraXBVbnRpbDtcbiAgICBmdW5jdGlvbiogc2tpcExhc3QoaXRlcmFibGUsIGNvdW50ID0gMSkge1xuICAgICAgICBjb25zdCBpdCA9IGl0ZXJhdG9yKGl0ZXJhYmxlKTtcbiAgICAgICAgY29uc3QgZmlyc3QgPSBbXTtcbiAgICAgICAgd2hpbGUgKGNvdW50LS0gPiAwKSB7XG4gICAgICAgICAgICBjb25zdCBuZXh0ID0gaXQubmV4dCgpO1xuICAgICAgICAgICAgaWYgKG5leHQuZG9uZSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZpcnN0LnB1c2gobmV4dC52YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgICAgIGNvbnN0IG5leHQgPSBpdC5uZXh0KCk7XG4gICAgICAgICAgICBpZiAobmV4dC5kb25lID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZmlyc3QucHVzaChuZXh0LnZhbHVlKTtcbiAgICAgICAgICAgIHlpZWxkIGZpcnN0LnNoaWZ0KCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgSXRlcmFibGUuc2tpcExhc3QgPSBza2lwTGFzdDtcbiAgICBmdW5jdGlvbiogc2tpcExhc3RXaGlsZShpdGVyYWJsZSwgcHJlZGljYXRlKSB7XG4gICAgICAgIGNvbnN0IHZhbHVlcyA9IFsuLi5pdGVyYWJsZV07XG4gICAgICAgIGxldCBsYXN0ID0gdmFsdWVzLmxlbmd0aCAtIDE7XG4gICAgICAgIHdoaWxlIChsYXN0ID49IDApIHtcbiAgICAgICAgICAgIGlmIChwcmVkaWNhdGUodmFsdWVzW2xhc3RdLCBsYXN0KSkge1xuICAgICAgICAgICAgICAgIGxhc3QtLTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBuID0gbGFzdDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgeWllbGQgdmFsdWVzW2ldO1xuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLnNraXBMYXN0V2hpbGUgPSBza2lwTGFzdFdoaWxlO1xuICAgIGZ1bmN0aW9uIHNraXBMYXN0VW50aWwoaXRlcmFibGUsIHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gc2tpcExhc3RXaGlsZShpdGVyYWJsZSwgbm90KHByZWRpY2F0ZSkpO1xuICAgIH1cbiAgICBJdGVyYWJsZS5za2lwTGFzdFVudGlsID0gc2tpcExhc3RVbnRpbDtcbiAgICBmdW5jdGlvbiB0cmltKGl0ZXJhYmxlLCBwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIHRyaW1UcmFpbGluZyh0cmltTGVhZGluZyhpdGVyYWJsZSwgcHJlZGljYXRlKSwgcHJlZGljYXRlKTtcbiAgICB9XG4gICAgSXRlcmFibGUudHJpbSA9IHRyaW07XG4gICAgZnVuY3Rpb24gdHJpbUxlYWRpbmcoaXRlcmFibGUsIHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gc2tpcFdoaWxlKGl0ZXJhYmxlLCBwcmVkaWNhdGUpO1xuICAgIH1cbiAgICBJdGVyYWJsZS50cmltTGVhZGluZyA9IHRyaW1MZWFkaW5nO1xuICAgIGZ1bmN0aW9uIHRyaW1UcmFpbGluZyhpdGVyYWJsZSwgcHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiBza2lwTGFzdFdoaWxlKGl0ZXJhYmxlLCBwcmVkaWNhdGUpO1xuICAgIH1cbiAgICBJdGVyYWJsZS50cmltVHJhaWxpbmcgPSB0cmltVHJhaWxpbmc7XG4gICAgZnVuY3Rpb24gcmVzdChpdGVyYWJsZSkge1xuICAgICAgICByZXR1cm4gc2tpcChpdGVyYWJsZSwgMSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnJlc3QgPSByZXN0O1xuICAgIGZ1bmN0aW9uIHNsaWNlKGl0ZXJhYmxlLCBzdGFydCwgZW5kKSB7XG4gICAgICAgIGl0ZXJhYmxlID0gc2tpcChpdGVyYWJsZSwgc3RhcnQpO1xuICAgICAgICBpZiAoZW5kICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIGl0ZXJhYmxlID0gdGFrZShpdGVyYWJsZSwgZW5kIC0gc3RhcnQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBpdGVyYWJsZTtcbiAgICB9XG4gICAgSXRlcmFibGUuc2xpY2UgPSBzbGljZTtcbiAgICBmdW5jdGlvbiogcmV2ZXJzZShpdGVyYWJsZSkge1xuICAgICAgICBjb25zdCBhcnJheSA9IEFycmF5LmZyb20oaXRlcmFibGUpO1xuICAgICAgICBmb3IgKGxldCBpID0gYXJyYXkubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcbiAgICAgICAgICAgIHlpZWxkIGFycmF5W2ldO1xuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLnJldmVyc2UgPSByZXZlcnNlO1xuICAgIGZ1bmN0aW9uIGpvaW4oaXRlcmFibGUsIHNlcGFyYXRvcikge1xuICAgICAgICBjb25zdCBpdCA9IGl0ZXJhdG9yKGl0ZXJhYmxlKTtcbiAgICAgICAgbGV0IG5leHQgPSBpdC5uZXh0KCk7XG4gICAgICAgIGlmIChuZXh0LmRvbmUgPT09IHRydWUpIHtcbiAgICAgICAgICAgIHJldHVybiBcIlwiO1xuICAgICAgICB9XG4gICAgICAgIGxldCByZXN1bHQgPSBgJHtuZXh0LnZhbHVlfWA7XG4gICAgICAgIG5leHQgPSBpdC5uZXh0KCk7XG4gICAgICAgIHdoaWxlIChuZXh0LmRvbmUgIT09IHRydWUpIHtcbiAgICAgICAgICAgIHJlc3VsdCArPSBgJHtzZXBhcmF0b3J9JHtuZXh0LnZhbHVlfWA7XG4gICAgICAgICAgICBuZXh0ID0gaXQubmV4dCgpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIEl0ZXJhYmxlLmpvaW4gPSBqb2luO1xuICAgIGZ1bmN0aW9uIHNvcnQoaXRlcmFibGUpIHtcbiAgICAgICAgcmV0dXJuIHNvcnRXaXRoKGl0ZXJhYmxlLCBjb21wYXJlQ29tcGFyYWJsZSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnNvcnQgPSBzb3J0O1xuICAgIGZ1bmN0aW9uKiBzb3J0V2l0aChpdGVyYWJsZSwgY29tcGFyZXIpIHtcbiAgICAgICAgeWllbGQqIFsuLi5pdGVyYWJsZV0uc29ydChjb21wYXJlcik7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnNvcnRXaXRoID0gc29ydFdpdGg7XG4gICAgZnVuY3Rpb24gY29tcGFyZShhLCBiKSB7XG4gICAgICAgIHJldHVybiBjb21wYXJlV2l0aChhLCBiLCBjb21wYXJlQ29tcGFyYWJsZSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLmNvbXBhcmUgPSBjb21wYXJlO1xuICAgIGZ1bmN0aW9uIGNvbXBhcmVXaXRoKGEsIGIsIGNvbXBhcmVyKSB7XG4gICAgICAgIGNvbnN0IGl0QSA9IGl0ZXJhdG9yKGEpO1xuICAgICAgICBjb25zdCBpdEIgPSBpdGVyYXRvcihiKTtcbiAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgICAgIGNvbnN0IGEgPSBpdEEubmV4dCgpO1xuICAgICAgICAgICAgY29uc3QgYiA9IGl0Qi5uZXh0KCk7XG4gICAgICAgICAgICBpZiAoYS5kb25lID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGIuZG9uZSA9PT0gdHJ1ZSA/IGFsZmFfY29tcGFyYWJsZV8xLkNvbXBhcmlzb24uRXF1YWwgOiBhbGZhX2NvbXBhcmFibGVfMS5Db21wYXJpc29uLkxlc3M7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoYi5kb25lID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGFsZmFfY29tcGFyYWJsZV8xLkNvbXBhcmlzb24uR3JlYXRlcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGNvbXBhcmVyKGEudmFsdWUsIGIudmFsdWUsIGluZGV4KyspO1xuICAgICAgICAgICAgaWYgKHJlc3VsdCAhPT0gMCkge1xuICAgICAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgSXRlcmFibGUuY29tcGFyZVdpdGggPSBjb21wYXJlV2l0aDtcbiAgICBmdW5jdGlvbiBlcXVhbHMoYSwgYikge1xuICAgICAgICBjb25zdCBpdEEgPSBpdGVyYXRvcihhKTtcbiAgICAgICAgY29uc3QgaXRCID0gaXRlcmF0b3IoYik7XG4gICAgICAgIHdoaWxlICh0cnVlKSB7XG4gICAgICAgICAgICBjb25zdCBhID0gaXRBLm5leHQoKTtcbiAgICAgICAgICAgIGNvbnN0IGIgPSBpdEIubmV4dCgpO1xuICAgICAgICAgICAgaWYgKGEuZG9uZSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBiLmRvbmUgPT09IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoYi5kb25lID09PSB0cnVlIHx8ICFhbGZhX2VxdWF0YWJsZV8xLkVxdWF0YWJsZS5lcXVhbHMoYS52YWx1ZSwgYi52YWx1ZSkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgSXRlcmFibGUuZXF1YWxzID0gZXF1YWxzO1xuICAgIGZ1bmN0aW9uIGhhc2goaXRlcmFibGUsIGhhc2gpIHtcbiAgICAgICAgbGV0IHNpemUgPSAwO1xuICAgICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIGl0ZXJhYmxlKSB7XG4gICAgICAgICAgICBoYXNoLndyaXRlVW5rbm93bih2YWx1ZSk7XG4gICAgICAgICAgICBzaXplKys7XG4gICAgICAgIH1cbiAgICAgICAgaGFzaC53cml0ZVVpbnQzMihzaXplKTtcbiAgICB9XG4gICAgSXRlcmFibGUuaGFzaCA9IGhhc2g7XG4gICAgZnVuY3Rpb24gaXRlcmF0b3IoaXRlcmFibGUpIHtcbiAgICAgICAgcmV0dXJuIGl0ZXJhYmxlW1N5bWJvbC5pdGVyYXRvcl0oKTtcbiAgICB9XG4gICAgSXRlcmFibGUuaXRlcmF0b3IgPSBpdGVyYXRvcjtcbiAgICBmdW5jdGlvbiBncm91cEJ5KGl0ZXJhYmxlLCBncm91cGVyKSB7XG4gICAgICAgIGNvbnN0IGdyb3VwcyA9IFtdO1xuICAgICAgICBsZXQgaW5kZXggPSAwO1xuICAgICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIGl0ZXJhYmxlKSB7XG4gICAgICAgICAgICBjb25zdCBncm91cCA9IGdyb3VwZXIodmFsdWUsIGluZGV4KyspO1xuICAgICAgICAgICAgY29uc3QgZXhpc3RpbmcgPSBncm91cHMuZmluZCgoW2V4aXN0aW5nXSkgPT4gYWxmYV9lcXVhdGFibGVfMS5FcXVhdGFibGUuZXF1YWxzKGdyb3VwLCBleGlzdGluZykpO1xuICAgICAgICAgICAgaWYgKGV4aXN0aW5nID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICBncm91cHMucHVzaChbZ3JvdXAsIFt2YWx1ZV1dKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGV4aXN0aW5nWzFdLnB1c2godmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBncm91cHM7XG4gICAgfVxuICAgIEl0ZXJhYmxlLmdyb3VwQnkgPSBncm91cEJ5O1xuICAgIGZ1bmN0aW9uIHRvSlNPTihpdGVyYWJsZSkge1xuICAgICAgICByZXR1cm4gWy4uLm1hcChpdGVyYWJsZSwgKHZhbHVlKSA9PiBhbGZhX2pzb25fMS5TZXJpYWxpemFibGUudG9KU09OKHZhbHVlKSldO1xuICAgIH1cbiAgICBJdGVyYWJsZS50b0pTT04gPSB0b0pTT047XG59KShJdGVyYWJsZSB8fCAoZXhwb3J0cy5JdGVyYWJsZSA9IEl0ZXJhYmxlID0ge30pKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWl0ZXJhYmxlLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuLy8gVGhpcyBmaWxlIGRlZmluZXMgZXhwb3J0cyBmcm9tIHRoZSBidWlsdGluIGBKU09OYCBjb25zdHJ1Y3RvciBmb3IgaW50ZXJuYWxcbi8vIHVzZSBvbmx5LlxuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5KU09OID0gdm9pZCAwO1xuLyoqXG4gKiBAaW50ZXJuYWxcbiAqL1xuY29uc3QgQnVpbHRpbiA9IEpTT047XG5leHBvcnRzLkpTT04gPSBCdWlsdGluO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YnVpbHRpbi5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbnZhciBfX2NyZWF0ZUJpbmRpbmcgPSAodGhpcyAmJiB0aGlzLl9fY3JlYXRlQmluZGluZykgfHwgKE9iamVjdC5jcmVhdGUgPyAoZnVuY3Rpb24obywgbSwgaywgazIpIHtcbiAgICBpZiAoazIgPT09IHVuZGVmaW5lZCkgazIgPSBrO1xuICAgIHZhciBkZXNjID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihtLCBrKTtcbiAgICBpZiAoIWRlc2MgfHwgKFwiZ2V0XCIgaW4gZGVzYyA/ICFtLl9fZXNNb2R1bGUgOiBkZXNjLndyaXRhYmxlIHx8IGRlc2MuY29uZmlndXJhYmxlKSkge1xuICAgICAgZGVzYyA9IHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBmdW5jdGlvbigpIHsgcmV0dXJuIG1ba107IH0gfTtcbiAgICB9XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG8sIGsyLCBkZXNjKTtcbn0pIDogKGZ1bmN0aW9uKG8sIG0sIGssIGsyKSB7XG4gICAgaWYgKGsyID09PSB1bmRlZmluZWQpIGsyID0gaztcbiAgICBvW2syXSA9IG1ba107XG59KSk7XG52YXIgX19leHBvcnRTdGFyID0gKHRoaXMgJiYgdGhpcy5fX2V4cG9ydFN0YXIpIHx8IGZ1bmN0aW9uKG0sIGV4cG9ydHMpIHtcbiAgICBmb3IgKHZhciBwIGluIG0pIGlmIChwICE9PSBcImRlZmF1bHRcIiAmJiAhT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKGV4cG9ydHMsIHApKSBfX2NyZWF0ZUJpbmRpbmcoZXhwb3J0cywgbSwgcCk7XG59O1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuX19leHBvcnRTdGFyKHJlcXVpcmUoXCIuL2pzb25cIiksIGV4cG9ydHMpO1xuX19leHBvcnRTdGFyKHJlcXVpcmUoXCIuL3NlcmlhbGl6YWJsZVwiKSwgZXhwb3J0cyk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMuSlNPTiA9IHZvaWQgMDtcbmNvbnN0IGJ1aWx0aW4gPSByZXF1aXJlKFwiLi9idWlsdGluXCIpO1xuLyoqXG4gKiBAcHVibGljXG4gKi9cbnZhciBKU09OO1xuKGZ1bmN0aW9uIChKU09OKSB7XG4gICAgZnVuY3Rpb24gcGFyc2UodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIGJ1aWx0aW4uSlNPTi5wYXJzZSh2YWx1ZSk7XG4gICAgfVxuICAgIEpTT04ucGFyc2UgPSBwYXJzZTtcbiAgICBmdW5jdGlvbiBzdHJpbmdpZnkodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIGJ1aWx0aW4uSlNPTi5zdHJpbmdpZnkodmFsdWUpO1xuICAgIH1cbiAgICBKU09OLnN0cmluZ2lmeSA9IHN0cmluZ2lmeTtcbn0pKEpTT04gfHwgKGV4cG9ydHMuSlNPTiA9IEpTT04gPSB7fSkpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9anNvbi5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMuU2VyaWFsaXphYmxlID0gdm9pZCAwO1xuY29uc3QgYWxmYV9yZWZpbmVtZW50XzEgPSByZXF1aXJlKFwiQHNpdGVpbXByb3ZlL2FsZmEtcmVmaW5lbWVudFwiKTtcbmNvbnN0IHsga2V5cyB9ID0gT2JqZWN0O1xuY29uc3QgeyBpc0FycmF5IH0gPSBBcnJheTtcbmNvbnN0IHsgaXNGdW5jdGlvbiwgaXNPYmplY3QsIGlzU3RyaW5nLCBpc051bWJlciwgaXNCb29sZWFuLCBpc051bGwgfSA9IGFsZmFfcmVmaW5lbWVudF8xLlJlZmluZW1lbnQ7XG4vKipcbiAqIEBwdWJsaWNcbiAqL1xudmFyIFNlcmlhbGl6YWJsZTtcbihmdW5jdGlvbiAoU2VyaWFsaXphYmxlKSB7XG4gICAgZnVuY3Rpb24gaXNTZXJpYWxpemFibGUodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIGlzT2JqZWN0KHZhbHVlKSAmJiBpc0Z1bmN0aW9uKHZhbHVlLnRvSlNPTik7XG4gICAgfVxuICAgIFNlcmlhbGl6YWJsZS5pc1NlcmlhbGl6YWJsZSA9IGlzU2VyaWFsaXphYmxlO1xuICAgIGZ1bmN0aW9uIHRvSlNPTih2YWx1ZSwgb3B0aW9ucykge1xuICAgICAgICBpZiAoaXNTZXJpYWxpemFibGUodmFsdWUpKSB7XG4gICAgICAgICAgICByZXR1cm4gdmFsdWUudG9KU09OKG9wdGlvbnMpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc1N0cmluZyh2YWx1ZSkgfHxcbiAgICAgICAgICAgIGlzTnVtYmVyKHZhbHVlKSB8fFxuICAgICAgICAgICAgaXNCb29sZWFuKHZhbHVlKSB8fFxuICAgICAgICAgICAgaXNOdWxsKHZhbHVlKSkge1xuICAgICAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0FycmF5KHZhbHVlKSkge1xuICAgICAgICAgICAgcmV0dXJuIHZhbHVlLm1hcCh0b0pTT04pO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc09iamVjdCh2YWx1ZSkpIHtcbiAgICAgICAgICAgIGNvbnN0IGpzb24gPSB7fTtcbiAgICAgICAgICAgIGZvciAoY29uc3Qga2V5IG9mIGtleXModmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgaWYgKHZhbHVlW2tleV0gIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICBqc29uW2tleV0gPSB0b0pTT04odmFsdWVba2V5XSwgb3B0aW9ucyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGpzb247XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIFNlcmlhbGl6YWJsZS50b0pTT04gPSB0b0pTT047XG59KShTZXJpYWxpemFibGUgfHwgKGV4cG9ydHMuU2VyaWFsaXphYmxlID0gU2VyaWFsaXphYmxlID0ge30pKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXNlcmlhbGl6YWJsZS5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbnZhciBfX2NyZWF0ZUJpbmRpbmcgPSAodGhpcyAmJiB0aGlzLl9fY3JlYXRlQmluZGluZykgfHwgKE9iamVjdC5jcmVhdGUgPyAoZnVuY3Rpb24obywgbSwgaywgazIpIHtcbiAgICBpZiAoazIgPT09IHVuZGVmaW5lZCkgazIgPSBrO1xuICAgIHZhciBkZXNjID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihtLCBrKTtcbiAgICBpZiAoIWRlc2MgfHwgKFwiZ2V0XCIgaW4gZGVzYyA/ICFtLl9fZXNNb2R1bGUgOiBkZXNjLndyaXRhYmxlIHx8IGRlc2MuY29uZmlndXJhYmxlKSkge1xuICAgICAgZGVzYyA9IHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBmdW5jdGlvbigpIHsgcmV0dXJuIG1ba107IH0gfTtcbiAgICB9XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG8sIGsyLCBkZXNjKTtcbn0pIDogKGZ1bmN0aW9uKG8sIG0sIGssIGsyKSB7XG4gICAgaWYgKGsyID09PSB1bmRlZmluZWQpIGsyID0gaztcbiAgICBvW2syXSA9IG1ba107XG59KSk7XG52YXIgX19leHBvcnRTdGFyID0gKHRoaXMgJiYgdGhpcy5fX2V4cG9ydFN0YXIpIHx8IGZ1bmN0aW9uKG0sIGV4cG9ydHMpIHtcbiAgICBmb3IgKHZhciBwIGluIG0pIGlmIChwICE9PSBcImRlZmF1bHRcIiAmJiAhT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKGV4cG9ydHMsIHApKSBfX2NyZWF0ZUJpbmRpbmcoZXhwb3J0cywgbSwgcCk7XG59O1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuX19leHBvcnRTdGFyKHJlcXVpcmUoXCIuL21hcFwiKSwgZXhwb3J0cyk7XG5fX2V4cG9ydFN0YXIocmVxdWlyZShcIi4vbm9kZVwiKSwgZXhwb3J0cyk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMuTWFwID0gdm9pZCAwO1xuY29uc3QgYWxmYV9hcnJheV8xID0gcmVxdWlyZShcIkBzaXRlaW1wcm92ZS9hbGZhLWFycmF5XCIpO1xuY29uc3QgYWxmYV9mbnZfMSA9IHJlcXVpcmUoXCJAc2l0ZWltcHJvdmUvYWxmYS1mbnZcIik7XG5jb25zdCBhbGZhX2l0ZXJhYmxlXzEgPSByZXF1aXJlKFwiQHNpdGVpbXByb3ZlL2FsZmEtaXRlcmFibGVcIik7XG5jb25zdCBhbGZhX2pzb25fMSA9IHJlcXVpcmUoXCJAc2l0ZWltcHJvdmUvYWxmYS1qc29uXCIpO1xuY29uc3QgYWxmYV9wcmVkaWNhdGVfMSA9IHJlcXVpcmUoXCJAc2l0ZWltcHJvdmUvYWxmYS1wcmVkaWNhdGVcIik7XG5jb25zdCBub2RlXzEgPSByZXF1aXJlKFwiLi9ub2RlXCIpO1xuY29uc3QgeyBub3QgfSA9IGFsZmFfcHJlZGljYXRlXzEuUHJlZGljYXRlO1xuLyoqXG4gKiBAcHVibGljXG4gKi9cbmNsYXNzIE1hcCB7XG4gICAgc3RhdGljIG9mKC4uLmVudHJpZXMpIHtcbiAgICAgICAgcmV0dXJuIGVudHJpZXMucmVkdWNlKChtYXAsIFtrZXksIHZhbHVlXSkgPT4gbWFwLnNldChrZXksIHZhbHVlKSwgTWFwLmVtcHR5KCkpO1xuICAgIH1cbiAgICBzdGF0aWMgZW1wdHkoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9lbXB0eTtcbiAgICB9XG4gICAgY29uc3RydWN0b3Iocm9vdCwgc2l6ZSkge1xuICAgICAgICB0aGlzLl9yb290ID0gcm9vdDtcbiAgICAgICAgdGhpcy5fc2l6ZSA9IHNpemU7XG4gICAgfVxuICAgIGdldCBzaXplKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fc2l6ZTtcbiAgICB9XG4gICAgaXNFbXB0eSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3NpemUgPT09IDA7XG4gICAgfVxuICAgIGZvckVhY2goY2FsbGJhY2spIHtcbiAgICAgICAgYWxmYV9pdGVyYWJsZV8xLkl0ZXJhYmxlLmZvckVhY2godGhpcywgKFtrZXksIHZhbHVlXSkgPT4gY2FsbGJhY2sodmFsdWUsIGtleSkpO1xuICAgIH1cbiAgICBtYXAobWFwcGVyKSB7XG4gICAgICAgIHJldHVybiBuZXcgTWFwKHRoaXMuX3Jvb3QubWFwKG1hcHBlciksIHRoaXMuX3NpemUpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBBcHBseSBhIG1hcCBvZiBmdW5jdGlvbnMgdG8gZWFjaCBjb3JyZXNwb25kaW5nIHZhbHVlIG9mIHRoaXMgbWFwLlxuICAgICAqXG4gICAgICogQHJlbWFya3NcbiAgICAgKiBLZXlzIHdpdGhvdXQgYSBjb3JyZXNwb25kaW5nIGZ1bmN0aW9uIG9yIHZhbHVlIGFyZSBkcm9wcGVkIGZyb20gdGhlXG4gICAgICogcmVzdWx0aW5nIG1hcC5cbiAgICAgKlxuICAgICAqIEBleGFtcGxlXG4gICAgICogYGBgdHNcbiAgICAgKiBNYXAub2YoW1wiYVwiLCAxXSwgW1wiYlwiLCAyXSlcbiAgICAgKiAgIC5hcHBseShNYXAub2YoW1wiYVwiLCAoeCkgPT4geCArIDFdLCBbXCJiXCIsICh4KSA9PiB4ICogMl0pKVxuICAgICAqICAgLnRvQXJyYXkoKTtcbiAgICAgKiAvLyA9PiBbW1wiYVwiLCAyXSwgW1wiYlwiLCA0XV1cbiAgICAgKiBgYGBcbiAgICAgKi9cbiAgICBhcHBseShtYXBwZXIpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuY29sbGVjdCgodmFsdWUsIGtleSkgPT4gbWFwcGVyLmdldChrZXkpLm1hcCgobWFwcGVyKSA9PiBtYXBwZXIodmFsdWUpKSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEByZW1hcmtzXG4gICAgICogQXMgdGhlIG9yZGVyIG9mIG1hcHMgaXMgdW5kZWZpbmVkLCBpdCBpcyBhbHNvIHVuZGVmaW5lZCB3aGljaCBrZXlzIGFyZVxuICAgICAqIGtlcHQgd2hlbiBkdXBsaWNhdGUga2V5cyBhcmUgZW5jb3VudGVyZWQuXG4gICAgICovXG4gICAgZmxhdE1hcChtYXBwZXIpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMucmVkdWNlKChtYXAsIHZhbHVlLCBrZXkpID0+IG1hcC5jb25jYXQobWFwcGVyKHZhbHVlLCBrZXkpKSwgTWFwLmVtcHR5KCkpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBAcmVtYXJrc1xuICAgICAqIEFzIHRoZSBvcmRlciBvZiBtYXBzIGlzIHVuZGVmaW5lZCwgaXQgaXMgYWxzbyB1bmRlZmluZWQgd2hpY2gga2V5cyBhcmVcbiAgICAgKiBrZXB0IHdoZW4gZHVwbGljYXRlIGtleXMgYXJlIGVuY291bnRlcmVkLlxuICAgICAqL1xuICAgIGZsYXR0ZW4oKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmZsYXRNYXAoKG1hcCkgPT4gbWFwKTtcbiAgICB9XG4gICAgcmVkdWNlKHJlZHVjZXIsIGFjY3VtdWxhdG9yKSB7XG4gICAgICAgIHJldHVybiBhbGZhX2l0ZXJhYmxlXzEuSXRlcmFibGUucmVkdWNlKHRoaXMsIChhY2N1bXVsYXRvciwgW2tleSwgdmFsdWVdKSA9PiByZWR1Y2VyKGFjY3VtdWxhdG9yLCB2YWx1ZSwga2V5KSwgYWNjdW11bGF0b3IpO1xuICAgIH1cbiAgICBmaWx0ZXIocHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnJlZHVjZSgobWFwLCB2YWx1ZSwga2V5KSA9PiAocHJlZGljYXRlKHZhbHVlLCBrZXkpID8gbWFwLnNldChrZXksIHZhbHVlKSA6IG1hcCksIE1hcC5lbXB0eSgpKTtcbiAgICB9XG4gICAgcmVqZWN0KHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gdGhpcy5maWx0ZXIobm90KHByZWRpY2F0ZSkpO1xuICAgIH1cbiAgICBmaW5kKHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gYWxmYV9pdGVyYWJsZV8xLkl0ZXJhYmxlLmZpbmQodGhpcywgKFtrZXksIHZhbHVlXSkgPT4gcHJlZGljYXRlKHZhbHVlLCBrZXkpKS5tYXAoKFssIHZhbHVlXSkgPT4gdmFsdWUpO1xuICAgIH1cbiAgICBpbmNsdWRlcyh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gYWxmYV9pdGVyYWJsZV8xLkl0ZXJhYmxlLmluY2x1ZGVzKHRoaXMudmFsdWVzKCksIHZhbHVlKTtcbiAgICB9XG4gICAgY29sbGVjdChtYXBwZXIpIHtcbiAgICAgICAgcmV0dXJuIE1hcC5mcm9tKGFsZmFfaXRlcmFibGVfMS5JdGVyYWJsZS5jb2xsZWN0KHRoaXMsIChba2V5LCB2YWx1ZV0pID0+IG1hcHBlcih2YWx1ZSwga2V5KS5tYXAoKHZhbHVlKSA9PiBba2V5LCB2YWx1ZV0pKSk7XG4gICAgfVxuICAgIGNvbGxlY3RGaXJzdChtYXBwZXIpIHtcbiAgICAgICAgcmV0dXJuIGFsZmFfaXRlcmFibGVfMS5JdGVyYWJsZS5jb2xsZWN0Rmlyc3QodGhpcywgKFtrZXksIHZhbHVlXSkgPT4gbWFwcGVyKHZhbHVlLCBrZXkpKTtcbiAgICB9XG4gICAgc29tZShwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIGFsZmFfaXRlcmFibGVfMS5JdGVyYWJsZS5zb21lKHRoaXMsIChba2V5LCB2YWx1ZV0pID0+IHByZWRpY2F0ZSh2YWx1ZSwga2V5KSk7XG4gICAgfVxuICAgIG5vbmUocHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiBhbGZhX2l0ZXJhYmxlXzEuSXRlcmFibGUubm9uZSh0aGlzLCAoW2tleSwgdmFsdWVdKSA9PiBwcmVkaWNhdGUodmFsdWUsIGtleSkpO1xuICAgIH1cbiAgICBldmVyeShwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIGFsZmFfaXRlcmFibGVfMS5JdGVyYWJsZS5ldmVyeSh0aGlzLCAoW2tleSwgdmFsdWVdKSA9PiBwcmVkaWNhdGUodmFsdWUsIGtleSkpO1xuICAgIH1cbiAgICBjb3VudChwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIGFsZmFfaXRlcmFibGVfMS5JdGVyYWJsZS5jb3VudCh0aGlzLCAoW2tleSwgdmFsdWVdKSA9PiBwcmVkaWNhdGUodmFsdWUsIGtleSkpO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBAcmVtYXJrc1xuICAgICAqIEFzIHRoZSBvcmRlciBvZiBtYXBzIGlzIHVuZGVmaW5lZCwgaXQgaXMgYWxzbyB1bmRlZmluZWQgd2hpY2gga2V5cyBhcmVcbiAgICAgKiBrZXB0IHdoZW4gZHVwbGljYXRlIHZhbHVlcyBhcmUgZW5jb3VudGVyZWQuXG4gICAgICovXG4gICAgZGlzdGluY3QoKSB7XG4gICAgICAgIGxldCBzZWVuID0gTWFwLmVtcHR5KCk7XG4gICAgICAgIC8vIFdlIG9wdGltaXplIGZvciB0aGUgY2FzZSB3aGVyZSB0aGVyZSBhcmUgbW9yZSBkaXN0aW5jdCB2YWx1ZXMgdGhhbiB0aGVyZVxuICAgICAgICAvLyBhcmUgZHVwbGljYXRlIHZhbHVlcyBieSBzdGFydGluZyB3aXRoIHRoZSBjdXJyZW50IG1hcCBhbmQgcmVtb3ZpbmdcbiAgICAgICAgLy8gZHVwbGljYXRlcyBhcyB3ZSBmaW5kIHRoZW0uXG4gICAgICAgIGxldCBtYXAgPSB0aGlzO1xuICAgICAgICBmb3IgKGNvbnN0IFtrZXksIHZhbHVlXSBvZiBtYXApIHtcbiAgICAgICAgICAgIGlmIChzZWVuLmhhcyh2YWx1ZSkpIHtcbiAgICAgICAgICAgICAgICBtYXAgPSBtYXAuZGVsZXRlKGtleSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBzZWVuID0gc2Vlbi5zZXQodmFsdWUsIHZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbWFwO1xuICAgIH1cbiAgICBnZXQoa2V5KSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9yb290LmdldChrZXksIGhhc2goa2V5KSwgMCk7XG4gICAgfVxuICAgIGhhcyhrZXkpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZ2V0KGtleSkuaXNTb21lKCk7XG4gICAgfVxuICAgIHNldChrZXksIHZhbHVlKSB7XG4gICAgICAgIGNvbnN0IHsgcmVzdWx0OiByb290LCBzdGF0dXMgfSA9IHRoaXMuX3Jvb3Quc2V0KGtleSwgdmFsdWUsIGhhc2goa2V5KSwgMCk7XG4gICAgICAgIGlmIChzdGF0dXMgPT09IFwidW5jaGFuZ2VkXCIpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBuZXcgTWFwKHJvb3QsIHRoaXMuX3NpemUgKyAoc3RhdHVzID09PSBcInVwZGF0ZWRcIiA/IDAgOiAxKSk7XG4gICAgfVxuICAgIGRlbGV0ZShrZXkpIHtcbiAgICAgICAgY29uc3QgeyByZXN1bHQ6IHJvb3QsIHN0YXR1cyB9ID0gdGhpcy5fcm9vdC5kZWxldGUoa2V5LCBoYXNoKGtleSksIDApO1xuICAgICAgICBpZiAoc3RhdHVzID09PSBcInVuY2hhbmdlZFwiKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbmV3IE1hcChyb290LCB0aGlzLl9zaXplIC0gMSk7XG4gICAgfVxuICAgIGNvbmNhdChpdGVyYWJsZSkge1xuICAgICAgICByZXR1cm4gYWxmYV9pdGVyYWJsZV8xLkl0ZXJhYmxlLnJlZHVjZShpdGVyYWJsZSwgKG1hcCwgW2tleSwgdmFsdWVdKSA9PiBtYXAuc2V0KGtleSwgdmFsdWUpLCB0aGlzKTtcbiAgICB9XG4gICAgc3VidHJhY3QoaXRlcmFibGUpIHtcbiAgICAgICAgcmV0dXJuIGFsZmFfaXRlcmFibGVfMS5JdGVyYWJsZS5yZWR1Y2UoaXRlcmFibGUsIChtYXAsIFtrZXldKSA9PiBtYXAuZGVsZXRlKGtleSksIHRoaXMpO1xuICAgIH1cbiAgICBpbnRlcnNlY3QoaXRlcmFibGUpIHtcbiAgICAgICAgcmV0dXJuIE1hcC5mcm9tSXRlcmFibGUoYWxmYV9pdGVyYWJsZV8xLkl0ZXJhYmxlLmZpbHRlcihpdGVyYWJsZSwgKFtrZXldKSA9PiB0aGlzLmhhcyhrZXkpKSk7XG4gICAgfVxuICAgIHRlZShjYWxsYmFjaywgLi4uYXJncykge1xuICAgICAgICBjYWxsYmFjayh0aGlzLCAuLi5hcmdzKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGVxdWFscyh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gKHZhbHVlIGluc3RhbmNlb2YgTWFwICYmXG4gICAgICAgICAgICB2YWx1ZS5fc2l6ZSA9PT0gdGhpcy5fc2l6ZSAmJlxuICAgICAgICAgICAgdmFsdWUuX3Jvb3QuZXF1YWxzKHRoaXMuX3Jvb3QpKTtcbiAgICB9XG4gICAgaGFzaChoYXNoKSB7XG4gICAgICAgIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIHRoaXMpIHtcbiAgICAgICAgICAgIGhhc2gud3JpdGVVbmtub3duKGtleSkud3JpdGVVbmtub3duKHZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgICBoYXNoLndyaXRlVWludDMyKHRoaXMuX3NpemUpO1xuICAgIH1cbiAgICBrZXlzKCkge1xuICAgICAgICByZXR1cm4gYWxmYV9pdGVyYWJsZV8xLkl0ZXJhYmxlLm1hcCh0aGlzLl9yb290LCAoZW50cnkpID0+IGVudHJ5WzBdKTtcbiAgICB9XG4gICAgdmFsdWVzKCkge1xuICAgICAgICByZXR1cm4gYWxmYV9pdGVyYWJsZV8xLkl0ZXJhYmxlLm1hcCh0aGlzLl9yb290LCAoZW50cnkpID0+IGVudHJ5WzFdKTtcbiAgICB9XG4gICAgKml0ZXJhdG9yKCkge1xuICAgICAgICB5aWVsZCogdGhpcy5fcm9vdDtcbiAgICB9XG4gICAgW1N5bWJvbC5pdGVyYXRvcl0oKSB7XG4gICAgICAgIHJldHVybiB0aGlzLml0ZXJhdG9yKCk7XG4gICAgfVxuICAgIHRvQXJyYXkoKSB7XG4gICAgICAgIHJldHVybiBbLi4udGhpc107XG4gICAgfVxuICAgIHRvSlNPTigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMudG9BcnJheSgpLm1hcCgoW2tleSwgdmFsdWVdKSA9PiBbXG4gICAgICAgICAgICBhbGZhX2pzb25fMS5TZXJpYWxpemFibGUudG9KU09OKGtleSksXG4gICAgICAgICAgICBhbGZhX2pzb25fMS5TZXJpYWxpemFibGUudG9KU09OKHZhbHVlKSxcbiAgICAgICAgXSk7XG4gICAgfVxuICAgIHRvU3RyaW5nKCkge1xuICAgICAgICBjb25zdCBlbnRyaWVzID0gdGhpcy50b0FycmF5KClcbiAgICAgICAgICAgIC5tYXAoKFtrZXksIHZhbHVlXSkgPT4gYCR7a2V5fSA9PiAke3ZhbHVlfWApXG4gICAgICAgICAgICAuam9pbihcIiwgXCIpO1xuICAgICAgICByZXR1cm4gYE1hcCB7JHtlbnRyaWVzID09PSBcIlwiID8gXCJcIiA6IGAgJHtlbnRyaWVzfSBgfX1gO1xuICAgIH1cbn1cbmV4cG9ydHMuTWFwID0gTWFwO1xuTWFwLl9lbXB0eSA9IG5ldyBNYXAobm9kZV8xLkVtcHR5LCAwKTtcbi8qKlxuICogQHB1YmxpY1xuICovXG4oZnVuY3Rpb24gKE1hcCkge1xuICAgIGZ1bmN0aW9uIGlzTWFwKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIE1hcDtcbiAgICB9XG4gICAgTWFwLmlzTWFwID0gaXNNYXA7XG4gICAgZnVuY3Rpb24gZnJvbShpdGVyYWJsZSkge1xuICAgICAgICBpZiAoaXNNYXAoaXRlcmFibGUpKSB7XG4gICAgICAgICAgICByZXR1cm4gaXRlcmFibGU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGFsZmFfYXJyYXlfMS5BcnJheS5pc0FycmF5KGl0ZXJhYmxlKSkge1xuICAgICAgICAgICAgcmV0dXJuIGZyb21BcnJheShpdGVyYWJsZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZyb21JdGVyYWJsZShpdGVyYWJsZSk7XG4gICAgfVxuICAgIE1hcC5mcm9tID0gZnJvbTtcbiAgICBmdW5jdGlvbiBmcm9tQXJyYXkoYXJyYXkpIHtcbiAgICAgICAgcmV0dXJuIGFsZmFfYXJyYXlfMS5BcnJheS5yZWR1Y2UoYXJyYXksIChtYXAsIFtrZXksIHZhbHVlXSkgPT4gbWFwLnNldChrZXksIHZhbHVlKSwgTWFwLmVtcHR5KCkpO1xuICAgIH1cbiAgICBNYXAuZnJvbUFycmF5ID0gZnJvbUFycmF5O1xuICAgIGZ1bmN0aW9uIGZyb21JdGVyYWJsZShpdGVyYWJsZSkge1xuICAgICAgICByZXR1cm4gYWxmYV9pdGVyYWJsZV8xLkl0ZXJhYmxlLnJlZHVjZShpdGVyYWJsZSwgKG1hcCwgW2tleSwgdmFsdWVdKSA9PiBtYXAuc2V0KGtleSwgdmFsdWUpLCBNYXAuZW1wdHkoKSk7XG4gICAgfVxuICAgIE1hcC5mcm9tSXRlcmFibGUgPSBmcm9tSXRlcmFibGU7XG59KShNYXAgfHwgKGV4cG9ydHMuTWFwID0gTWFwID0ge30pKTtcbmZ1bmN0aW9uIGhhc2goa2V5KSB7XG4gICAgcmV0dXJuIGFsZmFfZm52XzEuRk5WLmVtcHR5KCkud3JpdGVVbmtub3duKGtleSkuZmluaXNoKCk7XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1tYXAuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5leHBvcnRzLlNwYXJzZSA9IGV4cG9ydHMuQ29sbGlzaW9uID0gZXhwb3J0cy5MZWFmID0gZXhwb3J0cy5FbXB0eSA9IGV4cG9ydHMuTm9kZSA9IHZvaWQgMDtcbmNvbnN0IGFsZmFfYml0c18xID0gcmVxdWlyZShcIkBzaXRlaW1wcm92ZS9hbGZhLWJpdHNcIik7XG5jb25zdCBhbGZhX2VxdWF0YWJsZV8xID0gcmVxdWlyZShcIkBzaXRlaW1wcm92ZS9hbGZhLWVxdWF0YWJsZVwiKTtcbmNvbnN0IGFsZmFfb3B0aW9uXzEgPSByZXF1aXJlKFwiQHNpdGVpbXByb3ZlL2FsZmEtb3B0aW9uXCIpO1xuY29uc3Qgc3RhdHVzXzEgPSByZXF1aXJlKFwiLi9zdGF0dXNcIik7XG5jb25zdCB7IGJpdCwgdGFrZSwgc2tpcCwgdGVzdCwgc2V0LCBjbGVhciwgcG9wQ291bnQgfSA9IGFsZmFfYml0c18xLkJpdHM7XG4vKipcbiAqIEBpbnRlcm5hbFxuICovXG52YXIgTm9kZTtcbihmdW5jdGlvbiAoTm9kZSkge1xuICAgIE5vZGUuQml0cyA9IDU7XG4gICAgZnVuY3Rpb24gZnJhZ21lbnQoaGFzaCwgc2hpZnQpIHtcbiAgICAgICAgcmV0dXJuIHRha2Uoc2tpcChoYXNoLCBzaGlmdCksIE5vZGUuQml0cyk7XG4gICAgfVxuICAgIE5vZGUuZnJhZ21lbnQgPSBmcmFnbWVudDtcbiAgICBmdW5jdGlvbiBpbmRleChmcmFnbWVudCwgbWFzaykge1xuICAgICAgICByZXR1cm4gcG9wQ291bnQodGFrZShtYXNrLCBmcmFnbWVudCkpO1xuICAgIH1cbiAgICBOb2RlLmluZGV4ID0gaW5kZXg7XG59KShOb2RlIHx8IChleHBvcnRzLk5vZGUgPSBOb2RlID0ge30pKTtcbi8qKlxuICogQGludGVybmFsXG4gKi9cbmV4cG9ydHMuRW1wdHkgPSBuZXcgKGNsYXNzIEVtcHR5IHtcbiAgICBpc0VtcHR5KCkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaXNMZWFmKCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGdldCgpIHtcbiAgICAgICAgcmV0dXJuIGFsZmFfb3B0aW9uXzEuTm9uZTtcbiAgICB9XG4gICAgc2V0KGtleSwgdmFsdWUsIGhhc2gpIHtcbiAgICAgICAgcmV0dXJuIHN0YXR1c18xLlN0YXR1cy5jcmVhdGVkKExlYWYub2YoaGFzaCwga2V5LCB2YWx1ZSkpO1xuICAgIH1cbiAgICBkZWxldGUoKSB7XG4gICAgICAgIHJldHVybiBzdGF0dXNfMS5TdGF0dXMudW5jaGFuZ2VkKHRoaXMpO1xuICAgIH1cbiAgICBtYXAoKSB7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBlcXVhbHModmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgRW1wdHk7XG4gICAgfVxuICAgICpbU3ltYm9sLml0ZXJhdG9yXSgpIHsgfVxufSkoKTtcbi8qKlxuICogQGludGVybmFsXG4gKi9cbmNsYXNzIExlYWYge1xuICAgIHN0YXRpYyBvZihoYXNoLCBrZXksIHZhbHVlKSB7XG4gICAgICAgIHJldHVybiBuZXcgTGVhZihoYXNoLCBrZXksIHZhbHVlKTtcbiAgICB9XG4gICAgY29uc3RydWN0b3IoaGFzaCwga2V5LCB2YWx1ZSkge1xuICAgICAgICB0aGlzLl9oYXNoID0gaGFzaDtcbiAgICAgICAgdGhpcy5fa2V5ID0ga2V5O1xuICAgICAgICB0aGlzLl92YWx1ZSA9IHZhbHVlO1xuICAgIH1cbiAgICBnZXQga2V5KCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fa2V5O1xuICAgIH1cbiAgICBnZXQgdmFsdWUoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl92YWx1ZTtcbiAgICB9XG4gICAgaXNFbXB0eSgpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBpc0xlYWYoKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBnZXQoa2V5LCBoYXNoLCBzaGlmdCkge1xuICAgICAgICByZXR1cm4gaGFzaCA9PT0gdGhpcy5faGFzaCAmJiBhbGZhX2VxdWF0YWJsZV8xLkVxdWF0YWJsZS5lcXVhbHMoa2V5LCB0aGlzLl9rZXkpXG4gICAgICAgICAgICA/IGFsZmFfb3B0aW9uXzEuT3B0aW9uLm9mKHRoaXMuX3ZhbHVlKVxuICAgICAgICAgICAgOiBhbGZhX29wdGlvbl8xLk5vbmU7XG4gICAgfVxuICAgIHNldChrZXksIHZhbHVlLCBoYXNoLCBzaGlmdCkge1xuICAgICAgICBpZiAoaGFzaCA9PT0gdGhpcy5faGFzaCkge1xuICAgICAgICAgICAgaWYgKGFsZmFfZXF1YXRhYmxlXzEuRXF1YXRhYmxlLmVxdWFscyhrZXksIHRoaXMuX2tleSkpIHtcbiAgICAgICAgICAgICAgICBpZiAoYWxmYV9lcXVhdGFibGVfMS5FcXVhdGFibGUuZXF1YWxzKHZhbHVlLCB0aGlzLl92YWx1ZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHN0YXR1c18xLlN0YXR1cy51bmNoYW5nZWQodGhpcyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBzdGF0dXNfMS5TdGF0dXMudXBkYXRlZChMZWFmLm9mKGhhc2gsIGtleSwgdmFsdWUpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBzdGF0dXNfMS5TdGF0dXMuY3JlYXRlZChDb2xsaXNpb24ub2YoaGFzaCwgW3RoaXMsIExlYWYub2YoaGFzaCwga2V5LCB2YWx1ZSldKSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZnJhZ21lbnQgPSBOb2RlLmZyYWdtZW50KHRoaXMuX2hhc2gsIHNoaWZ0KTtcbiAgICAgICAgcmV0dXJuIFNwYXJzZS5vZihiaXQoZnJhZ21lbnQpLCBbdGhpc10pLnNldChrZXksIHZhbHVlLCBoYXNoLCBzaGlmdCk7XG4gICAgfVxuICAgIGRlbGV0ZShrZXksIGhhc2gpIHtcbiAgICAgICAgcmV0dXJuIGhhc2ggPT09IHRoaXMuX2hhc2ggJiYgYWxmYV9lcXVhdGFibGVfMS5FcXVhdGFibGUuZXF1YWxzKGtleSwgdGhpcy5fa2V5KVxuICAgICAgICAgICAgPyBzdGF0dXNfMS5TdGF0dXMuZGVsZXRlZChleHBvcnRzLkVtcHR5KVxuICAgICAgICAgICAgOiBzdGF0dXNfMS5TdGF0dXMudW5jaGFuZ2VkKHRoaXMpO1xuICAgIH1cbiAgICBtYXAobWFwcGVyKSB7XG4gICAgICAgIHJldHVybiBMZWFmLm9mKHRoaXMuX2hhc2gsIHRoaXMuX2tleSwgbWFwcGVyKHRoaXMuX3ZhbHVlLCB0aGlzLl9rZXkpKTtcbiAgICB9XG4gICAgZXF1YWxzKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiAodmFsdWUgaW5zdGFuY2VvZiBMZWFmICYmXG4gICAgICAgICAgICB2YWx1ZS5faGFzaCA9PT0gdGhpcy5faGFzaCAmJlxuICAgICAgICAgICAgYWxmYV9lcXVhdGFibGVfMS5FcXVhdGFibGUuZXF1YWxzKHZhbHVlLl9rZXksIHRoaXMuX2tleSkgJiZcbiAgICAgICAgICAgIGFsZmFfZXF1YXRhYmxlXzEuRXF1YXRhYmxlLmVxdWFscyh2YWx1ZS5fdmFsdWUsIHRoaXMuX3ZhbHVlKSk7XG4gICAgfVxuICAgICpbU3ltYm9sLml0ZXJhdG9yXSgpIHtcbiAgICAgICAgeWllbGQgW3RoaXMuX2tleSwgdGhpcy5fdmFsdWVdO1xuICAgIH1cbn1cbmV4cG9ydHMuTGVhZiA9IExlYWY7XG4vKipcbiAqIEBpbnRlcm5hbFxuICovXG5jbGFzcyBDb2xsaXNpb24ge1xuICAgIHN0YXRpYyBvZihoYXNoLCBub2Rlcykge1xuICAgICAgICByZXR1cm4gbmV3IENvbGxpc2lvbihoYXNoLCBub2Rlcyk7XG4gICAgfVxuICAgIGNvbnN0cnVjdG9yKGhhc2gsIG5vZGVzKSB7XG4gICAgICAgIHRoaXMuX2hhc2ggPSBoYXNoO1xuICAgICAgICB0aGlzLl9ub2RlcyA9IG5vZGVzO1xuICAgIH1cbiAgICBpc0VtcHR5KCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlzTGVhZigpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBnZXQoa2V5LCBoYXNoLCBzaGlmdCkge1xuICAgICAgICBpZiAoaGFzaCA9PT0gdGhpcy5faGFzaCkge1xuICAgICAgICAgICAgZm9yIChjb25zdCBub2RlIG9mIHRoaXMuX25vZGVzKSB7XG4gICAgICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBub2RlLmdldChrZXksIGhhc2gsIHNoaWZ0KTtcbiAgICAgICAgICAgICAgICBpZiAodmFsdWUuaXNTb21lKCkpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYWxmYV9vcHRpb25fMS5Ob25lO1xuICAgIH1cbiAgICBzZXQoa2V5LCB2YWx1ZSwgaGFzaCwgc2hpZnQpIHtcbiAgICAgICAgaWYgKGhhc2ggPT09IHRoaXMuX2hhc2gpIHtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwLCBuID0gdGhpcy5fbm9kZXMubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgbm9kZSA9IHRoaXMuX25vZGVzW2ldO1xuICAgICAgICAgICAgICAgIGlmIChhbGZhX2VxdWF0YWJsZV8xLkVxdWF0YWJsZS5lcXVhbHMoa2V5LCBub2RlLmtleSkpIHtcbiAgICAgICAgICAgICAgICAgICAgaWYgKGFsZmFfZXF1YXRhYmxlXzEuRXF1YXRhYmxlLmVxdWFscyh2YWx1ZSwgbm9kZS52YWx1ZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIHJldHVybiBzdGF0dXNfMS5TdGF0dXMudW5jaGFuZ2VkKHRoaXMpO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBzdGF0dXNfMS5TdGF0dXMudXBkYXRlZChDb2xsaXNpb24ub2YodGhpcy5faGFzaCwgcmVwbGFjZSh0aGlzLl9ub2RlcywgaSwgTGVhZi5vZihoYXNoLCBrZXksIHZhbHVlKSkpKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gc3RhdHVzXzEuU3RhdHVzLmNyZWF0ZWQoQ29sbGlzaW9uLm9mKHRoaXMuX2hhc2gsIHRoaXMuX25vZGVzLmNvbmNhdChMZWFmLm9mKGhhc2gsIGtleSwgdmFsdWUpKSkpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGZyYWdtZW50ID0gTm9kZS5mcmFnbWVudCh0aGlzLl9oYXNoLCBzaGlmdCk7XG4gICAgICAgIHJldHVybiBTcGFyc2Uub2YoYml0KGZyYWdtZW50KSwgW3RoaXNdKS5zZXQoa2V5LCB2YWx1ZSwgaGFzaCwgc2hpZnQpO1xuICAgIH1cbiAgICBkZWxldGUoa2V5LCBoYXNoKSB7XG4gICAgICAgIGlmIChoYXNoID09PSB0aGlzLl9oYXNoKSB7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IHRoaXMuX25vZGVzLmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgICAgIGNvbnN0IG5vZGUgPSB0aGlzLl9ub2Rlc1tpXTtcbiAgICAgICAgICAgICAgICBpZiAoYWxmYV9lcXVhdGFibGVfMS5FcXVhdGFibGUuZXF1YWxzKGtleSwgbm9kZS5rZXkpKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG5vZGVzID0gcmVtb3ZlKHRoaXMuX25vZGVzLCBpKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG5vZGVzLmxlbmd0aCA9PT0gMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gV2UganVzdCBkZWxldGVkIHRoZSBwZW51bHRpbWF0ZSBMZWFmIG9mIHRoZSBDb2xsaXNpb24sIHNvIHdlIGNhblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gcmVtb3ZlIHRoZSBDb2xsaXNpb24gYW5kIG9ubHkga2VlcCB0aGUgcmVtYWluaW5nIExlYWYuXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gc3RhdHVzXzEuU3RhdHVzLmRlbGV0ZWQobm9kZXNbMF0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBzdGF0dXNfMS5TdGF0dXMuZGVsZXRlZChDb2xsaXNpb24ub2YodGhpcy5faGFzaCwgbm9kZXMpKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHN0YXR1c18xLlN0YXR1cy51bmNoYW5nZWQodGhpcyk7XG4gICAgfVxuICAgIG1hcChtYXBwZXIpIHtcbiAgICAgICAgcmV0dXJuIENvbGxpc2lvbi5vZih0aGlzLl9oYXNoLCB0aGlzLl9ub2Rlcy5tYXAoKG5vZGUpID0+IG5vZGUubWFwKG1hcHBlcikpKTtcbiAgICB9XG4gICAgZXF1YWxzKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiAodmFsdWUgaW5zdGFuY2VvZiBDb2xsaXNpb24gJiZcbiAgICAgICAgICAgIHZhbHVlLl9oYXNoID09PSB0aGlzLl9oYXNoICYmXG4gICAgICAgICAgICB2YWx1ZS5fbm9kZXMubGVuZ3RoID09PSB0aGlzLl9ub2Rlcy5sZW5ndGggJiZcbiAgICAgICAgICAgIHZhbHVlLl9ub2Rlcy5ldmVyeSgobm9kZSwgaSkgPT4gbm9kZS5lcXVhbHModGhpcy5fbm9kZXNbaV0pKSk7XG4gICAgfVxuICAgICpbU3ltYm9sLml0ZXJhdG9yXSgpIHtcbiAgICAgICAgZm9yIChjb25zdCBub2RlIG9mIHRoaXMuX25vZGVzKSB7XG4gICAgICAgICAgICB5aWVsZCogbm9kZTtcbiAgICAgICAgfVxuICAgIH1cbn1cbmV4cG9ydHMuQ29sbGlzaW9uID0gQ29sbGlzaW9uO1xuLyoqXG4gKiBAaW50ZXJuYWxcbiAqL1xuY2xhc3MgU3BhcnNlIHtcbiAgICBzdGF0aWMgb2YobWFzaywgbm9kZXMpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBTcGFyc2UobWFzaywgbm9kZXMpO1xuICAgIH1cbiAgICBjb25zdHJ1Y3RvcihtYXNrLCBub2Rlcykge1xuICAgICAgICB0aGlzLl9tYXNrID0gbWFzaztcbiAgICAgICAgdGhpcy5fbm9kZXMgPSBub2RlcztcbiAgICB9XG4gICAgaXNFbXB0eSgpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBpc0xlYWYoKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgZ2V0KGtleSwgaGFzaCwgc2hpZnQpIHtcbiAgICAgICAgY29uc3QgZnJhZ21lbnQgPSBOb2RlLmZyYWdtZW50KGhhc2gsIHNoaWZ0KTtcbiAgICAgICAgaWYgKHRlc3QodGhpcy5fbWFzaywgZnJhZ21lbnQpKSB7XG4gICAgICAgICAgICBjb25zdCBpbmRleCA9IE5vZGUuaW5kZXgoZnJhZ21lbnQsIHRoaXMuX21hc2spO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX25vZGVzW2luZGV4XS5nZXQoa2V5LCBoYXNoLCBzaGlmdCArIE5vZGUuQml0cyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGFsZmFfb3B0aW9uXzEuTm9uZTtcbiAgICB9XG4gICAgc2V0KGtleSwgdmFsdWUsIGhhc2gsIHNoaWZ0KSB7XG4gICAgICAgIGNvbnN0IGZyYWdtZW50ID0gTm9kZS5mcmFnbWVudChoYXNoLCBzaGlmdCk7XG4gICAgICAgIGNvbnN0IGluZGV4ID0gTm9kZS5pbmRleChmcmFnbWVudCwgdGhpcy5fbWFzayk7XG4gICAgICAgIGlmICh0ZXN0KHRoaXMuX21hc2ssIGZyYWdtZW50KSkge1xuICAgICAgICAgICAgY29uc3QgeyByZXN1bHQ6IG5vZGUsIHN0YXR1cyB9ID0gdGhpcy5fbm9kZXNbaW5kZXhdLnNldChrZXksIHZhbHVlLCBoYXNoLCBzaGlmdCArIE5vZGUuQml0cyk7XG4gICAgICAgICAgICBpZiAoc3RhdHVzID09PSBcInVuY2hhbmdlZFwiKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHN0YXR1c18xLlN0YXR1cy51bmNoYW5nZWQodGhpcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBjb25zdCBzcGFyc2UgPSBTcGFyc2Uub2YodGhpcy5fbWFzaywgcmVwbGFjZSh0aGlzLl9ub2RlcywgaW5kZXgsIG5vZGUpKTtcbiAgICAgICAgICAgIHN3aXRjaCAoc3RhdHVzKSB7XG4gICAgICAgICAgICAgICAgY2FzZSBcImNyZWF0ZWRcIjpcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHN0YXR1c18xLlN0YXR1cy5jcmVhdGVkKHNwYXJzZSk7XG4gICAgICAgICAgICAgICAgY2FzZSBcInVwZGF0ZWRcIjpcbiAgICAgICAgICAgICAgICBkZWZhdWx0OlxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gc3RhdHVzXzEuU3RhdHVzLnVwZGF0ZWQoc3BhcnNlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gc3RhdHVzXzEuU3RhdHVzLmNyZWF0ZWQoU3BhcnNlLm9mKHNldCh0aGlzLl9tYXNrLCBmcmFnbWVudCksIGluc2VydCh0aGlzLl9ub2RlcywgaW5kZXgsIExlYWYub2YoaGFzaCwga2V5LCB2YWx1ZSkpKSk7XG4gICAgfVxuICAgIGRlbGV0ZShrZXksIGhhc2gsIHNoaWZ0KSB7XG4gICAgICAgIGNvbnN0IGZyYWdtZW50ID0gTm9kZS5mcmFnbWVudChoYXNoLCBzaGlmdCk7XG4gICAgICAgIGlmICh0ZXN0KHRoaXMuX21hc2ssIGZyYWdtZW50KSkge1xuICAgICAgICAgICAgY29uc3QgaW5kZXggPSBOb2RlLmluZGV4KGZyYWdtZW50LCB0aGlzLl9tYXNrKTtcbiAgICAgICAgICAgIGNvbnN0IHsgcmVzdWx0OiBub2RlLCBzdGF0dXMgfSA9IHRoaXMuX25vZGVzW2luZGV4XS5kZWxldGUoa2V5LCBoYXNoLCBzaGlmdCArIE5vZGUuQml0cyk7XG4gICAgICAgICAgICBpZiAoc3RhdHVzID09PSBcInVuY2hhbmdlZFwiKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHN0YXR1c18xLlN0YXR1cy51bmNoYW5nZWQodGhpcyk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAobm9kZS5pc0VtcHR5KCkpIHtcbiAgICAgICAgICAgICAgICBjb25zdCBub2RlcyA9IHJlbW92ZSh0aGlzLl9ub2RlcywgaW5kZXgpO1xuICAgICAgICAgICAgICAgIGlmIChub2Rlcy5sZW5ndGggPT09IDEpIHtcbiAgICAgICAgICAgICAgICAgICAgLy8gV2UgZGVsZXRlZCB0aGUgcGVudWx0aW1hdGUgY2hpbGQgb2YgdGhlIFNwYXJzZSwgd2UgbWF5IGJlIGFibGUgdG9cbiAgICAgICAgICAgICAgICAgICAgLy8gc2ltcGxpZnkgdGhlIHRyZWUuXG4gICAgICAgICAgICAgICAgICAgIGlmIChub2Rlc1swXS5pc0xlYWYoKSB8fCBub2Rlc1swXSBpbnN0YW5jZW9mIENvbGxpc2lvbikge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gVGhlIGxhc3QgY2hpbGQgaXMgbGVhZi1saWtlLCBoZW5jZSBoYXNoZXMgd2lsbCBiZSBmdWxseSBtYXRjaGVkXG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBhZ2FpbnN0IGl0cyBrZXkocykgYW5kIHdlIGNhbiByZW1vdmUgdGhlIGN1cnJlbnQgU3BhcnNlXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gc3RhdHVzXzEuU3RhdHVzLmRlbGV0ZWQobm9kZXNbMF0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIC8vIE90aGVyd2lzZSwgdGhlIGxhc3QgY2hpbGQgaXMgYSBTcGFyc2UuIFdlIGNhbid0IHNpbXBseSBjb2xsYXBzZSB0aGVcbiAgICAgICAgICAgICAgICAgICAgLy8gdHJlZSBieSByZW1vdmluZyB0aGUgY3VycmVudCBTcGFyc2UsIHNpbmNlIGl0IHdpbGwgY2F1c2UgdGhlIGNoaWxkXG4gICAgICAgICAgICAgICAgICAgIC8vIG1hc2sgdG8gYmUgdGVzdGVkIHdpdGggdGhlIHdyb25nIHNoaWZ0IChpdHMgZGVwdGggaW4gdGhlIHRyZWUgd291bGRcbiAgICAgICAgICAgICAgICAgICAgLy8gYmUgZGlmZmVyZW50KS5cbiAgICAgICAgICAgICAgICAgICAgLy8gV2UgY291bGQgZG8gc29tZSBmdXJ0aGVyIG9wdGltaXNhdGlvbnMgKGUuZy4sIGlmIHRoZSBjaGlsZCdzXG4gICAgICAgICAgICAgICAgICAgIC8vIGNoaWxkcmVuIGFyZSBhbGwgbGVhZi1saWtlLCB3ZSBjb3VsZCBpbnN0ZWFkIGRlbGV0ZSB0aGUgbG9uZSBjaGlsZFxuICAgICAgICAgICAgICAgICAgICAvLyBhbmQgY29ubmVjdCBkaXJlY3RseSB0byB0aGUgZ3JhbmRjaGlsZHJlbikuIFRoaXMgaXMsIGhvd2V2ZXIsXG4gICAgICAgICAgICAgICAgICAgIC8vIGdldHRpbmcgaGFpcnkgdG8gbWFrZSBhbGwgY2FzZXMgd29ya2luZyBmaW5lLCBhbmQgd2UgYXNzdW1lIHRoaXNcbiAgICAgICAgICAgICAgICAgICAgLy8ga2luZCBvZiBzaXR1YXRpb24gaXMgbm90IHRvbyBmcmVxdWVudC4gU28gd2UgcGF5IHRoZSBwcmljZSBvZlxuICAgICAgICAgICAgICAgICAgICAvLyBrZWVwaW5nIGEgbm9uLWJyYW5jaGluZyBTcGFyc2UgdW50aWwgd2UgbmVlZCB0byBvcHRpbWlzZSB0aGF0LlxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gc3RhdHVzXzEuU3RhdHVzLmRlbGV0ZWQoU3BhcnNlLm9mKGNsZWFyKHRoaXMuX21hc2ssIGZyYWdtZW50KSwgbm9kZXMpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBzdGF0dXNfMS5TdGF0dXMuZGVsZXRlZChTcGFyc2Uub2YodGhpcy5fbWFzaywgcmVwbGFjZSh0aGlzLl9ub2RlcywgaW5kZXgsIG5vZGUpKSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHN0YXR1c18xLlN0YXR1cy51bmNoYW5nZWQodGhpcyk7XG4gICAgfVxuICAgIG1hcChtYXBwZXIpIHtcbiAgICAgICAgcmV0dXJuIFNwYXJzZS5vZih0aGlzLl9tYXNrLCB0aGlzLl9ub2Rlcy5tYXAoKG5vZGUpID0+IG5vZGUubWFwKG1hcHBlcikpKTtcbiAgICB9XG4gICAgZXF1YWxzKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiAodmFsdWUgaW5zdGFuY2VvZiBTcGFyc2UgJiZcbiAgICAgICAgICAgIHZhbHVlLl9tYXNrID09PSB0aGlzLl9tYXNrICYmXG4gICAgICAgICAgICB2YWx1ZS5fbm9kZXMubGVuZ3RoID09PSB0aGlzLl9ub2Rlcy5sZW5ndGggJiZcbiAgICAgICAgICAgIHZhbHVlLl9ub2Rlcy5ldmVyeSgobm9kZSwgaSkgPT4gbm9kZS5lcXVhbHModGhpcy5fbm9kZXNbaV0pKSk7XG4gICAgfVxuICAgICpbU3ltYm9sLml0ZXJhdG9yXSgpIHtcbiAgICAgICAgZm9yIChjb25zdCBub2RlIG9mIHRoaXMuX25vZGVzKSB7XG4gICAgICAgICAgICB5aWVsZCogbm9kZTtcbiAgICAgICAgfVxuICAgIH1cbn1cbmV4cG9ydHMuU3BhcnNlID0gU3BhcnNlO1xuZnVuY3Rpb24gaW5zZXJ0KGFycmF5LCBpbmRleCwgdmFsdWUpIHtcbiAgICBjb25zdCByZXN1bHQgPSBuZXcgQXJyYXkoYXJyYXkubGVuZ3RoICsgMSk7XG4gICAgcmVzdWx0W2luZGV4XSA9IHZhbHVlO1xuICAgIGZvciAobGV0IGkgPSAwLCBuID0gaW5kZXg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgcmVzdWx0W2ldID0gYXJyYXlbaV07XG4gICAgfVxuICAgIGZvciAobGV0IGkgPSBpbmRleCwgbiA9IGFycmF5Lmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICByZXN1bHRbaSArIDFdID0gYXJyYXlbaV07XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG59XG5mdW5jdGlvbiByZW1vdmUoYXJyYXksIGluZGV4KSB7XG4gICAgY29uc3QgcmVzdWx0ID0gbmV3IEFycmF5KGFycmF5Lmxlbmd0aCAtIDEpO1xuICAgIGZvciAobGV0IGkgPSAwLCBuID0gaW5kZXg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgcmVzdWx0W2ldID0gYXJyYXlbaV07XG4gICAgfVxuICAgIGZvciAobGV0IGkgPSBpbmRleCwgbiA9IHJlc3VsdC5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgcmVzdWx0W2ldID0gYXJyYXlbaSArIDFdO1xuICAgIH1cbiAgICByZXR1cm4gcmVzdWx0O1xufVxuZnVuY3Rpb24gcmVwbGFjZShhcnJheSwgaW5kZXgsIHZhbHVlKSB7XG4gICAgY29uc3QgcmVzdWx0ID0gYXJyYXkuc2xpY2UoMCk7XG4gICAgcmVzdWx0W2luZGV4XSA9IHZhbHVlO1xuICAgIHJldHVybiByZXN1bHQ7XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1ub2RlLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5TdGF0dXMgPSB2b2lkIDA7XG4vKipcbiAqIEBpbnRlcm5hbFxuICovXG52YXIgU3RhdHVzO1xuKGZ1bmN0aW9uIChTdGF0dXNfMSkge1xuICAgIGNsYXNzIFN0YXR1cyB7XG4gICAgICAgIGNvbnN0cnVjdG9yKHJlc3VsdCkge1xuICAgICAgICAgICAgdGhpcy5fcmVzdWx0ID0gcmVzdWx0O1xuICAgICAgICB9XG4gICAgICAgIGdldCByZXN1bHQoKSB7XG4gICAgICAgICAgICByZXR1cm4gdGhpcy5fcmVzdWx0O1xuICAgICAgICB9XG4gICAgfVxuICAgIGNsYXNzIENyZWF0ZWQgZXh0ZW5kcyBTdGF0dXMge1xuICAgICAgICBzdGF0aWMgb2YocmVzdWx0KSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IENyZWF0ZWQocmVzdWx0KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdHJ1Y3RvcihyZXN1bHQpIHtcbiAgICAgICAgICAgIHN1cGVyKHJlc3VsdCk7XG4gICAgICAgIH1cbiAgICAgICAgZ2V0IHN0YXR1cygpIHtcbiAgICAgICAgICAgIHJldHVybiBcImNyZWF0ZWRcIjtcbiAgICAgICAgfVxuICAgIH1cbiAgICBTdGF0dXNfMS5DcmVhdGVkID0gQ3JlYXRlZDtcbiAgICBTdGF0dXNfMS5jcmVhdGVkID0gQ3JlYXRlZC5vZjtcbiAgICBjbGFzcyBVcGRhdGVkIGV4dGVuZHMgU3RhdHVzIHtcbiAgICAgICAgc3RhdGljIG9mKHJlc3VsdCkge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBVcGRhdGVkKHJlc3VsdCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3RydWN0b3IocmVzdWx0KSB7XG4gICAgICAgICAgICBzdXBlcihyZXN1bHQpO1xuICAgICAgICB9XG4gICAgICAgIGdldCBzdGF0dXMoKSB7XG4gICAgICAgICAgICByZXR1cm4gXCJ1cGRhdGVkXCI7XG4gICAgICAgIH1cbiAgICB9XG4gICAgU3RhdHVzXzEuVXBkYXRlZCA9IFVwZGF0ZWQ7XG4gICAgU3RhdHVzXzEudXBkYXRlZCA9IFVwZGF0ZWQub2Y7XG4gICAgY2xhc3MgRGVsZXRlZCBleHRlbmRzIFN0YXR1cyB7XG4gICAgICAgIHN0YXRpYyBvZihyZXN1bHQpIHtcbiAgICAgICAgICAgIHJldHVybiBuZXcgRGVsZXRlZChyZXN1bHQpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0cnVjdG9yKHJlc3VsdCkge1xuICAgICAgICAgICAgc3VwZXIocmVzdWx0KTtcbiAgICAgICAgfVxuICAgICAgICBnZXQgc3RhdHVzKCkge1xuICAgICAgICAgICAgcmV0dXJuIFwiZGVsZXRlZFwiO1xuICAgICAgICB9XG4gICAgfVxuICAgIFN0YXR1c18xLkRlbGV0ZWQgPSBEZWxldGVkO1xuICAgIFN0YXR1c18xLmRlbGV0ZWQgPSBEZWxldGVkLm9mO1xuICAgIGNsYXNzIFVuY2hhbmdlZCBleHRlbmRzIFN0YXR1cyB7XG4gICAgICAgIHN0YXRpYyBvZihyZXN1bHQpIHtcbiAgICAgICAgICAgIHJldHVybiBuZXcgVW5jaGFuZ2VkKHJlc3VsdCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3RydWN0b3IocmVzdWx0KSB7XG4gICAgICAgICAgICBzdXBlcihyZXN1bHQpO1xuICAgICAgICB9XG4gICAgICAgIGdldCBzdGF0dXMoKSB7XG4gICAgICAgICAgICByZXR1cm4gXCJ1bmNoYW5nZWRcIjtcbiAgICAgICAgfVxuICAgIH1cbiAgICBTdGF0dXNfMS5VbmNoYW5nZWQgPSBVbmNoYW5nZWQ7XG4gICAgU3RhdHVzXzEudW5jaGFuZ2VkID0gVW5jaGFuZ2VkLm9mO1xufSkoU3RhdHVzIHx8IChleHBvcnRzLlN0YXR1cyA9IFN0YXR1cyA9IHt9KSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1zdGF0dXMuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG52YXIgX19jcmVhdGVCaW5kaW5nID0gKHRoaXMgJiYgdGhpcy5fX2NyZWF0ZUJpbmRpbmcpIHx8IChPYmplY3QuY3JlYXRlID8gKGZ1bmN0aW9uKG8sIG0sIGssIGsyKSB7XG4gICAgaWYgKGsyID09PSB1bmRlZmluZWQpIGsyID0gaztcbiAgICB2YXIgZGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IobSwgayk7XG4gICAgaWYgKCFkZXNjIHx8IChcImdldFwiIGluIGRlc2MgPyAhbS5fX2VzTW9kdWxlIDogZGVzYy53cml0YWJsZSB8fCBkZXNjLmNvbmZpZ3VyYWJsZSkpIHtcbiAgICAgIGRlc2MgPSB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZnVuY3Rpb24oKSB7IHJldHVybiBtW2tdOyB9IH07XG4gICAgfVxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvLCBrMiwgZGVzYyk7XG59KSA6IChmdW5jdGlvbihvLCBtLCBrLCBrMikge1xuICAgIGlmIChrMiA9PT0gdW5kZWZpbmVkKSBrMiA9IGs7XG4gICAgb1trMl0gPSBtW2tdO1xufSkpO1xudmFyIF9fZXhwb3J0U3RhciA9ICh0aGlzICYmIHRoaXMuX19leHBvcnRTdGFyKSB8fCBmdW5jdGlvbihtLCBleHBvcnRzKSB7XG4gICAgZm9yICh2YXIgcCBpbiBtKSBpZiAocCAhPT0gXCJkZWZhdWx0XCIgJiYgIU9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChleHBvcnRzLCBwKSkgX19jcmVhdGVCaW5kaW5nKGV4cG9ydHMsIG0sIHApO1xufTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbl9fZXhwb3J0U3RhcihyZXF1aXJlKFwiLi9tYXliZVwiKSwgZXhwb3J0cyk7XG5fX2V4cG9ydFN0YXIocmVxdWlyZShcIi4vbm9uZVwiKSwgZXhwb3J0cyk7XG5fX2V4cG9ydFN0YXIocmVxdWlyZShcIi4vb3B0aW9uXCIpLCBleHBvcnRzKTtcbl9fZXhwb3J0U3RhcihyZXF1aXJlKFwiLi9zb21lXCIpLCBleHBvcnRzKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5NYXliZSA9IHZvaWQgMDtcbmNvbnN0IG9wdGlvbl8xID0gcmVxdWlyZShcIi4vb3B0aW9uXCIpO1xuLyoqXG4gKiBAaW50ZXJuYWxcbiAqL1xudmFyIE1heWJlO1xuKGZ1bmN0aW9uIChNYXliZSkge1xuICAgIGZ1bmN0aW9uIHRvT3B0aW9uKG1heWJlKSB7XG4gICAgICAgIHJldHVybiBvcHRpb25fMS5PcHRpb24uaXNPcHRpb24obWF5YmUpID8gbWF5YmUgOiBvcHRpb25fMS5PcHRpb24ub2YobWF5YmUpO1xuICAgIH1cbiAgICBNYXliZS50b09wdGlvbiA9IHRvT3B0aW9uO1xufSkoTWF5YmUgfHwgKGV4cG9ydHMuTWF5YmUgPSBNYXliZSA9IHt9KSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1tYXliZS5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbmV4cG9ydHMuTm9uZSA9IHZvaWQgMDtcbmNvbnN0IGFsZmFfY29tcGFyYWJsZV8xID0gcmVxdWlyZShcIkBzaXRlaW1wcm92ZS9hbGZhLWNvbXBhcmFibGVcIik7XG5jb25zdCB7IGNvbXBhcmVDb21wYXJhYmxlIH0gPSBhbGZhX2NvbXBhcmFibGVfMS5Db21wYXJhYmxlO1xuLyoqXG4gKiBAcHVibGljXG4gKi9cbmV4cG9ydHMuTm9uZSA9IG5ldyAoY2xhc3MgTm9uZSB7XG4gICAgaXNTb21lKCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlzTm9uZSgpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIG1hcCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGZvckVhY2goKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgYXBwbHkoKSB7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBmbGF0TWFwKCkge1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgZmxhdHRlbigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIHJlZHVjZShyZWR1Y2VyLCBhY2N1bXVsYXRvcikge1xuICAgICAgICByZXR1cm4gYWNjdW11bGF0b3I7XG4gICAgfVxuICAgIGZpbHRlcigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIHJlamVjdCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGluY2x1ZGVzKCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHNvbWUoKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgbm9uZSgpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGV2ZXJ5KCkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgYW5kKCkge1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgYW5kVGhlbigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIG9yKG9wdGlvbikge1xuICAgICAgICByZXR1cm4gb3B0aW9uO1xuICAgIH1cbiAgICBvckVsc2Uob3B0aW9uKSB7XG4gICAgICAgIHJldHVybiBvcHRpb24oKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgZ2V0VW5zYWZlKG1lc3NhZ2UgPSBcIkF0dGVtcHRlZCB0byAuZ2V0VW5zYWZlKCkgZnJvbSBOb25lXCIpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKG1lc3NhZ2UpO1xuICAgIH1cbiAgICBnZXRPcih2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgfVxuICAgIGdldE9yRWxzZSh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdmFsdWUoKTtcbiAgICB9XG4gICAgdGVlKCkge1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgY29tcGFyZShvcHRpb24pIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuY29tcGFyZVdpdGgob3B0aW9uLCBjb21wYXJlQ29tcGFyYWJsZSk7XG4gICAgfVxuICAgIGNvbXBhcmVXaXRoKG9wdGlvbikge1xuICAgICAgICByZXR1cm4gb3B0aW9uLmlzTm9uZSgpID8gYWxmYV9jb21wYXJhYmxlXzEuQ29tcGFyaXNvbi5FcXVhbCA6IGFsZmFfY29tcGFyYWJsZV8xLkNvbXBhcmlzb24uTGVzcztcbiAgICB9XG4gICAgZXF1YWxzKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIE5vbmU7XG4gICAgfVxuICAgIGhhc2goaGFzaCkge1xuICAgICAgICBoYXNoLndyaXRlQm9vbGVhbihmYWxzZSk7XG4gICAgfVxuICAgICpbU3ltYm9sLml0ZXJhdG9yXSgpIHsgfVxuICAgIHRvQXJyYXkoKSB7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG4gICAgdG9KU09OKCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgdHlwZTogXCJub25lXCIsXG4gICAgICAgIH07XG4gICAgfVxuICAgIHRvU3RyaW5nKCkge1xuICAgICAgICByZXR1cm4gXCJOb25lXCI7XG4gICAgfVxufSkoKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW5vbmUuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5leHBvcnRzLk9wdGlvbiA9IHZvaWQgMDtcbmNvbnN0IG5vbmVfMSA9IHJlcXVpcmUoXCIuL25vbmVcIik7XG5jb25zdCBzb21lXzEgPSByZXF1aXJlKFwiLi9zb21lXCIpO1xuLyoqXG4gKiBAcHVibGljXG4gKi9cbnZhciBPcHRpb247XG4oZnVuY3Rpb24gKE9wdGlvbikge1xuICAgIGZ1bmN0aW9uIGlzT3B0aW9uKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiBpc1NvbWUodmFsdWUpIHx8IGlzTm9uZSh2YWx1ZSk7XG4gICAgfVxuICAgIE9wdGlvbi5pc09wdGlvbiA9IGlzT3B0aW9uO1xuICAgIGZ1bmN0aW9uIGlzU29tZSh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gc29tZV8xLlNvbWUuaXNTb21lKHZhbHVlKTtcbiAgICB9XG4gICAgT3B0aW9uLmlzU29tZSA9IGlzU29tZTtcbiAgICBmdW5jdGlvbiBpc05vbmUodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlID09PSBub25lXzEuTm9uZTtcbiAgICB9XG4gICAgT3B0aW9uLmlzTm9uZSA9IGlzTm9uZTtcbiAgICBmdW5jdGlvbiBvZih2YWx1ZSkge1xuICAgICAgICByZXR1cm4gc29tZV8xLlNvbWUub2YodmFsdWUpO1xuICAgIH1cbiAgICBPcHRpb24ub2YgPSBvZjtcbiAgICBmdW5jdGlvbiBlbXB0eSgpIHtcbiAgICAgICAgcmV0dXJuIG5vbmVfMS5Ob25lO1xuICAgIH1cbiAgICBPcHRpb24uZW1wdHkgPSBlbXB0eTtcbiAgICBmdW5jdGlvbiBmcm9tKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZSA9PT0gbnVsbCB8fCB2YWx1ZSA9PT0gdW5kZWZpbmVkID8gbm9uZV8xLk5vbmUgOiBzb21lXzEuU29tZS5vZih2YWx1ZSk7XG4gICAgfVxuICAgIE9wdGlvbi5mcm9tID0gZnJvbTtcbn0pKE9wdGlvbiB8fCAoZXhwb3J0cy5PcHRpb24gPSBPcHRpb24gPSB7fSkpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9b3B0aW9uLmpzLm1hcCIsIlwidXNlIHN0cmljdFwiO1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuZXhwb3J0cy5Tb21lID0gdm9pZCAwO1xuY29uc3QgYWxmYV9jb21wYXJhYmxlXzEgPSByZXF1aXJlKFwiQHNpdGVpbXByb3ZlL2FsZmEtY29tcGFyYWJsZVwiKTtcbmNvbnN0IGFsZmFfZXF1YXRhYmxlXzEgPSByZXF1aXJlKFwiQHNpdGVpbXByb3ZlL2FsZmEtZXF1YXRhYmxlXCIpO1xuY29uc3QgYWxmYV9qc29uXzEgPSByZXF1aXJlKFwiQHNpdGVpbXByb3ZlL2FsZmEtanNvblwiKTtcbmNvbnN0IGFsZmFfcHJlZGljYXRlXzEgPSByZXF1aXJlKFwiQHNpdGVpbXByb3ZlL2FsZmEtcHJlZGljYXRlXCIpO1xuY29uc3Qgbm9uZV8xID0gcmVxdWlyZShcIi4vbm9uZVwiKTtcbmNvbnN0IHsgbm90LCB0ZXN0IH0gPSBhbGZhX3ByZWRpY2F0ZV8xLlByZWRpY2F0ZTtcbmNvbnN0IHsgY29tcGFyZUNvbXBhcmFibGUgfSA9IGFsZmFfY29tcGFyYWJsZV8xLkNvbXBhcmFibGU7XG4vKipcbiAqIEBwdWJsaWNcbiAqL1xuY2xhc3MgU29tZSB7XG4gICAgc3RhdGljIG9mKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiBuZXcgU29tZSh2YWx1ZSk7XG4gICAgfVxuICAgIGNvbnN0cnVjdG9yKHZhbHVlKSB7XG4gICAgICAgIHRoaXMuX3ZhbHVlID0gdmFsdWU7XG4gICAgfVxuICAgIGlzU29tZSgpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGlzTm9uZSgpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBtYXAobWFwcGVyKSB7XG4gICAgICAgIHJldHVybiBuZXcgU29tZShtYXBwZXIodGhpcy5fdmFsdWUpKTtcbiAgICB9XG4gICAgZm9yRWFjaChtYXBwZXIpIHtcbiAgICAgICAgbWFwcGVyKHRoaXMuX3ZhbHVlKTtcbiAgICB9XG4gICAgYXBwbHkobWFwcGVyKSB7XG4gICAgICAgIHJldHVybiBtYXBwZXIubWFwKChtYXBwZXIpID0+IG1hcHBlcih0aGlzLl92YWx1ZSkpO1xuICAgIH1cbiAgICBmbGF0TWFwKG1hcHBlcikge1xuICAgICAgICByZXR1cm4gbWFwcGVyKHRoaXMuX3ZhbHVlKTtcbiAgICB9XG4gICAgZmxhdHRlbigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3ZhbHVlO1xuICAgIH1cbiAgICByZWR1Y2UocmVkdWNlciwgYWNjdW11bGF0b3IpIHtcbiAgICAgICAgcmV0dXJuIHJlZHVjZXIoYWNjdW11bGF0b3IsIHRoaXMuX3ZhbHVlKTtcbiAgICB9XG4gICAgZmlsdGVyKHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gdGVzdChwcmVkaWNhdGUsIHRoaXMuX3ZhbHVlKSA/IHRoaXMgOiBub25lXzEuTm9uZTtcbiAgICB9XG4gICAgcmVqZWN0KHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gdGhpcy5maWx0ZXIobm90KHByZWRpY2F0ZSkpO1xuICAgIH1cbiAgICBpbmNsdWRlcyh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gYWxmYV9lcXVhdGFibGVfMS5FcXVhdGFibGUuZXF1YWxzKHZhbHVlLCB0aGlzLl92YWx1ZSk7XG4gICAgfVxuICAgIHNvbWUocHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiB0ZXN0KHByZWRpY2F0ZSwgdGhpcy5fdmFsdWUpO1xuICAgIH1cbiAgICBub25lKHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gdGVzdChub3QocHJlZGljYXRlKSwgdGhpcy5fdmFsdWUpO1xuICAgIH1cbiAgICBldmVyeShwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIHRlc3QocHJlZGljYXRlLCB0aGlzLl92YWx1ZSk7XG4gICAgfVxuICAgIGFuZChvcHRpb24pIHtcbiAgICAgICAgcmV0dXJuIG9wdGlvbjtcbiAgICB9XG4gICAgYW5kVGhlbihvcHRpb24pIHtcbiAgICAgICAgcmV0dXJuIG9wdGlvbih0aGlzLl92YWx1ZSk7XG4gICAgfVxuICAgIG9yKCkge1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgb3JFbHNlKCkge1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgZ2V0KCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fdmFsdWU7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEBpbnRlcm5hbFxuICAgICAqL1xuICAgIGdldFVuc2FmZSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3ZhbHVlO1xuICAgIH1cbiAgICBnZXRPcigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3ZhbHVlO1xuICAgIH1cbiAgICBnZXRPckVsc2UoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl92YWx1ZTtcbiAgICB9XG4gICAgdGVlKGNhbGxiYWNrKSB7XG4gICAgICAgIGNhbGxiYWNrKHRoaXMuX3ZhbHVlKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGNvbXBhcmUob3B0aW9uKSB7XG4gICAgICAgIHJldHVybiB0aGlzLmNvbXBhcmVXaXRoKG9wdGlvbiwgY29tcGFyZUNvbXBhcmFibGUpO1xuICAgIH1cbiAgICBjb21wYXJlV2l0aChvcHRpb24sIGNvbXBhcmVyKSB7XG4gICAgICAgIHJldHVybiBvcHRpb24uaXNTb21lKClcbiAgICAgICAgICAgID8gY29tcGFyZXIodGhpcy5fdmFsdWUsIG9wdGlvbi5fdmFsdWUpXG4gICAgICAgICAgICA6IGFsZmFfY29tcGFyYWJsZV8xLkNvbXBhcmlzb24uR3JlYXRlcjtcbiAgICB9XG4gICAgZXF1YWxzKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIFNvbWUgJiYgYWxmYV9lcXVhdGFibGVfMS5FcXVhdGFibGUuZXF1YWxzKHZhbHVlLl92YWx1ZSwgdGhpcy5fdmFsdWUpO1xuICAgIH1cbiAgICBoYXNoKGhhc2gpIHtcbiAgICAgICAgaGFzaC53cml0ZUJvb2xlYW4odHJ1ZSkud3JpdGVVbmtub3duKHRoaXMuX3ZhbHVlKTtcbiAgICB9XG4gICAgKltTeW1ib2wuaXRlcmF0b3JdKCkge1xuICAgICAgICB5aWVsZCB0aGlzLl92YWx1ZTtcbiAgICB9XG4gICAgdG9BcnJheSgpIHtcbiAgICAgICAgcmV0dXJuIFt0aGlzLl92YWx1ZV07XG4gICAgfVxuICAgIHRvSlNPTigpIHtcbiAgICAgICAgcmV0dXJuIHtcbiAgICAgICAgICAgIHR5cGU6IFwic29tZVwiLFxuICAgICAgICAgICAgdmFsdWU6IGFsZmFfanNvbl8xLlNlcmlhbGl6YWJsZS50b0pTT04odGhpcy5fdmFsdWUpLFxuICAgICAgICB9O1xuICAgIH1cbiAgICB0b1N0cmluZygpIHtcbiAgICAgICAgcmV0dXJuIGBTb21lIHsgJHt0aGlzLl92YWx1ZX0gfWA7XG4gICAgfVxufVxuZXhwb3J0cy5Tb21lID0gU29tZTtcbi8qKlxuICogQHB1YmxpY1xuICovXG4oZnVuY3Rpb24gKFNvbWUpIHtcbiAgICBmdW5jdGlvbiBpc1NvbWUodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgU29tZTtcbiAgICB9XG4gICAgU29tZS5pc1NvbWUgPSBpc1NvbWU7XG59KShTb21lIHx8IChleHBvcnRzLlNvbWUgPSBTb21lID0ge30pKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXNvbWUuanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG52YXIgX19jcmVhdGVCaW5kaW5nID0gKHRoaXMgJiYgdGhpcy5fX2NyZWF0ZUJpbmRpbmcpIHx8IChPYmplY3QuY3JlYXRlID8gKGZ1bmN0aW9uKG8sIG0sIGssIGsyKSB7XG4gICAgaWYgKGsyID09PSB1bmRlZmluZWQpIGsyID0gaztcbiAgICB2YXIgZGVzYyA9IE9iamVjdC5nZXRPd25Qcm9wZXJ0eURlc2NyaXB0b3IobSwgayk7XG4gICAgaWYgKCFkZXNjIHx8IChcImdldFwiIGluIGRlc2MgPyAhbS5fX2VzTW9kdWxlIDogZGVzYy53cml0YWJsZSB8fCBkZXNjLmNvbmZpZ3VyYWJsZSkpIHtcbiAgICAgIGRlc2MgPSB7IGVudW1lcmFibGU6IHRydWUsIGdldDogZnVuY3Rpb24oKSB7IHJldHVybiBtW2tdOyB9IH07XG4gICAgfVxuICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShvLCBrMiwgZGVzYyk7XG59KSA6IChmdW5jdGlvbihvLCBtLCBrLCBrMikge1xuICAgIGlmIChrMiA9PT0gdW5kZWZpbmVkKSBrMiA9IGs7XG4gICAgb1trMl0gPSBtW2tdO1xufSkpO1xudmFyIF9fZXhwb3J0U3RhciA9ICh0aGlzICYmIHRoaXMuX19leHBvcnRTdGFyKSB8fCBmdW5jdGlvbihtLCBleHBvcnRzKSB7XG4gICAgZm9yICh2YXIgcCBpbiBtKSBpZiAocCAhPT0gXCJkZWZhdWx0XCIgJiYgIU9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChleHBvcnRzLCBwKSkgX19jcmVhdGVCaW5kaW5nKGV4cG9ydHMsIG0sIHApO1xufTtcbk9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBcIl9fZXNNb2R1bGVcIiwgeyB2YWx1ZTogdHJ1ZSB9KTtcbl9fZXhwb3J0U3RhcihyZXF1aXJlKFwiLi9wcmVkaWNhdGVcIiksIGV4cG9ydHMpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXguanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5leHBvcnRzLlByZWRpY2F0ZSA9IHZvaWQgMDtcbmNvbnN0IGFsZmFfZXF1YXRhYmxlXzEgPSByZXF1aXJlKFwiQHNpdGVpbXByb3ZlL2FsZmEtZXF1YXRhYmxlXCIpO1xuLyoqXG4gKiBAcHVibGljXG4gKi9cbnZhciBQcmVkaWNhdGU7XG4oZnVuY3Rpb24gKFByZWRpY2F0ZSkge1xuICAgIGZ1bmN0aW9uIHRlc3QocHJlZGljYXRlLCB2YWx1ZSwgLi4uYXJncykge1xuICAgICAgICByZXR1cm4gcHJlZGljYXRlKHZhbHVlLCAuLi5hcmdzKTtcbiAgICB9XG4gICAgUHJlZGljYXRlLnRlc3QgPSB0ZXN0O1xuICAgIGZ1bmN0aW9uIGZvbGQocHJlZGljYXRlLCBpZlRydWUsIGlmRmFsc2UsIHZhbHVlLCAuLi5hcmdzKSB7XG4gICAgICAgIHJldHVybiBwcmVkaWNhdGUodmFsdWUsIC4uLmFyZ3MpID8gaWZUcnVlKHZhbHVlKSA6IGlmRmFsc2UodmFsdWUpO1xuICAgIH1cbiAgICBQcmVkaWNhdGUuZm9sZCA9IGZvbGQ7XG4gICAgZnVuY3Rpb24gbm90KHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gKHZhbHVlLCAuLi5hcmdzKSA9PiAhcHJlZGljYXRlKHZhbHVlLCAuLi5hcmdzKTtcbiAgICB9XG4gICAgUHJlZGljYXRlLm5vdCA9IG5vdDtcbiAgICBmdW5jdGlvbiBhbmQoLi4ucHJlZGljYXRlcykge1xuICAgICAgICByZXR1cm4gKHZhbHVlLCAuLi5hcmdzKSA9PiB7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IHByZWRpY2F0ZXMubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFwcmVkaWNhdGVzW2ldKHZhbHVlLCAuLi5hcmdzKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH07XG4gICAgfVxuICAgIFByZWRpY2F0ZS5hbmQgPSBhbmQ7XG4gICAgZnVuY3Rpb24gb3IoLi4ucHJlZGljYXRlcykge1xuICAgICAgICByZXR1cm4gKHZhbHVlLCAuLi5hcmdzKSA9PiB7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IHByZWRpY2F0ZXMubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICAgICAgaWYgKHByZWRpY2F0ZXNbaV0odmFsdWUsIC4uLmFyZ3MpKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfTtcbiAgICB9XG4gICAgUHJlZGljYXRlLm9yID0gb3I7XG4gICAgZnVuY3Rpb24geG9yKC4uLnByZWRpY2F0ZXMpIHtcbiAgICAgICAgcmV0dXJuIGFuZChvciguLi5wcmVkaWNhdGVzKSwgbm90KGFuZCguLi5wcmVkaWNhdGVzKSkpO1xuICAgIH1cbiAgICBQcmVkaWNhdGUueG9yID0geG9yO1xuICAgIGZ1bmN0aW9uIG5vciguLi5wcmVkaWNhdGVzKSB7XG4gICAgICAgIHJldHVybiBub3Qob3IoLi4ucHJlZGljYXRlcykpO1xuICAgIH1cbiAgICBQcmVkaWNhdGUubm9yID0gbm9yO1xuICAgIGZ1bmN0aW9uIG5hbmQoLi4ucHJlZGljYXRlcykge1xuICAgICAgICByZXR1cm4gbm90KGFuZCguLi5wcmVkaWNhdGVzKSk7XG4gICAgfVxuICAgIFByZWRpY2F0ZS5uYW5kID0gbmFuZDtcbiAgICBmdW5jdGlvbiBlcXVhbHMoLi4udmFsdWVzKSB7XG4gICAgICAgIHJldHVybiAob3RoZXIpID0+IHZhbHVlcy5zb21lKCh2YWx1ZSkgPT4gYWxmYV9lcXVhdGFibGVfMS5FcXVhdGFibGUuZXF1YWxzKG90aGVyLCB2YWx1ZSkpO1xuICAgIH1cbiAgICBQcmVkaWNhdGUuZXF1YWxzID0gZXF1YWxzO1xuICAgIGZ1bmN0aW9uIHByb3BlcnR5KHByb3BlcnR5LCBwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuICh2YWx1ZSwgLi4uYXJncykgPT4gcHJlZGljYXRlKHZhbHVlW3Byb3BlcnR5XSwgLi4uYXJncyk7XG4gICAgfVxuICAgIFByZWRpY2F0ZS5wcm9wZXJ0eSA9IHByb3BlcnR5O1xuICAgIGZ1bmN0aW9uIHRlZShwcmVkaWNhdGUsIGNhbGxiYWNrKSB7XG4gICAgICAgIHJldHVybiAodmFsdWUsIC4uLmFyZ3MpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IHByZWRpY2F0ZSh2YWx1ZSwgLi4uYXJncyk7XG4gICAgICAgICAgICBjYWxsYmFjayh2YWx1ZSwgcmVzdWx0LCAuLi5hcmdzKTtcbiAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgIH07XG4gICAgfVxuICAgIFByZWRpY2F0ZS50ZWUgPSB0ZWU7XG59KShQcmVkaWNhdGUgfHwgKGV4cG9ydHMuUHJlZGljYXRlID0gUHJlZGljYXRlID0ge30pKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXByZWRpY2F0ZS5qcy5tYXAiLCJcInVzZSBzdHJpY3RcIjtcbnZhciBfX2NyZWF0ZUJpbmRpbmcgPSAodGhpcyAmJiB0aGlzLl9fY3JlYXRlQmluZGluZykgfHwgKE9iamVjdC5jcmVhdGUgPyAoZnVuY3Rpb24obywgbSwgaywgazIpIHtcbiAgICBpZiAoazIgPT09IHVuZGVmaW5lZCkgazIgPSBrO1xuICAgIHZhciBkZXNjID0gT2JqZWN0LmdldE93blByb3BlcnR5RGVzY3JpcHRvcihtLCBrKTtcbiAgICBpZiAoIWRlc2MgfHwgKFwiZ2V0XCIgaW4gZGVzYyA/ICFtLl9fZXNNb2R1bGUgOiBkZXNjLndyaXRhYmxlIHx8IGRlc2MuY29uZmlndXJhYmxlKSkge1xuICAgICAgZGVzYyA9IHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBmdW5jdGlvbigpIHsgcmV0dXJuIG1ba107IH0gfTtcbiAgICB9XG4gICAgT2JqZWN0LmRlZmluZVByb3BlcnR5KG8sIGsyLCBkZXNjKTtcbn0pIDogKGZ1bmN0aW9uKG8sIG0sIGssIGsyKSB7XG4gICAgaWYgKGsyID09PSB1bmRlZmluZWQpIGsyID0gaztcbiAgICBvW2syXSA9IG1ba107XG59KSk7XG52YXIgX19leHBvcnRTdGFyID0gKHRoaXMgJiYgdGhpcy5fX2V4cG9ydFN0YXIpIHx8IGZ1bmN0aW9uKG0sIGV4cG9ydHMpIHtcbiAgICBmb3IgKHZhciBwIGluIG0pIGlmIChwICE9PSBcImRlZmF1bHRcIiAmJiAhT2JqZWN0LnByb3RvdHlwZS5oYXNPd25Qcm9wZXJ0eS5jYWxsKGV4cG9ydHMsIHApKSBfX2NyZWF0ZUJpbmRpbmcoZXhwb3J0cywgbSwgcCk7XG59O1xuT2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIFwiX19lc01vZHVsZVwiLCB7IHZhbHVlOiB0cnVlIH0pO1xuX19leHBvcnRTdGFyKHJlcXVpcmUoXCIuL3JlZmluZW1lbnRcIiksIGV4cG9ydHMpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXguanMubWFwIiwiXCJ1c2Ugc3RyaWN0XCI7XG5PYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgXCJfX2VzTW9kdWxlXCIsIHsgdmFsdWU6IHRydWUgfSk7XG5leHBvcnRzLlJlZmluZW1lbnQgPSB2b2lkIDA7XG5jb25zdCBhbGZhX3ByZWRpY2F0ZV8xID0gcmVxdWlyZShcIkBzaXRlaW1wcm92ZS9hbGZhLXByZWRpY2F0ZVwiKTtcbi8qKlxuICogQHB1YmxpY1xuICovXG52YXIgUmVmaW5lbWVudDtcbihmdW5jdGlvbiAoUmVmaW5lbWVudCkge1xuICAgIFJlZmluZW1lbnQudGVzdCA9IGFsZmFfcHJlZGljYXRlXzEuUHJlZGljYXRlLnRlc3Q7XG4gICAgUmVmaW5lbWVudC5mb2xkID0gYWxmYV9wcmVkaWNhdGVfMS5QcmVkaWNhdGUuZm9sZDtcbiAgICBSZWZpbmVtZW50Lm5vdCA9IGFsZmFfcHJlZGljYXRlXzEuUHJlZGljYXRlLm5vdDtcbiAgICBSZWZpbmVtZW50LmFuZCA9IGFsZmFfcHJlZGljYXRlXzEuUHJlZGljYXRlLmFuZDtcbiAgICBSZWZpbmVtZW50Lm9yID0gYWxmYV9wcmVkaWNhdGVfMS5QcmVkaWNhdGUub3I7XG4gICAgUmVmaW5lbWVudC54b3IgPSBhbGZhX3ByZWRpY2F0ZV8xLlByZWRpY2F0ZS54b3I7XG4gICAgUmVmaW5lbWVudC5ub3IgPSBhbGZhX3ByZWRpY2F0ZV8xLlByZWRpY2F0ZS5ub3I7XG4gICAgUmVmaW5lbWVudC5uYW5kID0gYWxmYV9wcmVkaWNhdGVfMS5QcmVkaWNhdGUubmFuZDtcbiAgICBSZWZpbmVtZW50LmVxdWFscyA9IGFsZmFfcHJlZGljYXRlXzEuUHJlZGljYXRlLmVxdWFscztcbiAgICBmdW5jdGlvbiBpc1N0cmluZyh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSBcInN0cmluZ1wiO1xuICAgIH1cbiAgICBSZWZpbmVtZW50LmlzU3RyaW5nID0gaXNTdHJpbmc7XG4gICAgZnVuY3Rpb24gaXNOdW1iZXIodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJudW1iZXJcIjtcbiAgICB9XG4gICAgUmVmaW5lbWVudC5pc051bWJlciA9IGlzTnVtYmVyO1xuICAgIGZ1bmN0aW9uIGlzQmlnSW50KHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwiYmlnaW50XCI7XG4gICAgfVxuICAgIFJlZmluZW1lbnQuaXNCaWdJbnQgPSBpc0JpZ0ludDtcbiAgICBmdW5jdGlvbiBpc0Jvb2xlYW4odmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJib29sZWFuXCI7XG4gICAgfVxuICAgIFJlZmluZW1lbnQuaXNCb29sZWFuID0gaXNCb29sZWFuO1xuICAgIGZ1bmN0aW9uIGlzTnVsbCh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdmFsdWUgPT09IG51bGw7XG4gICAgfVxuICAgIFJlZmluZW1lbnQuaXNOdWxsID0gaXNOdWxsO1xuICAgIGZ1bmN0aW9uIGlzVW5kZWZpbmVkKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZSA9PT0gdW5kZWZpbmVkO1xuICAgIH1cbiAgICBSZWZpbmVtZW50LmlzVW5kZWZpbmVkID0gaXNVbmRlZmluZWQ7XG4gICAgZnVuY3Rpb24gaXNTeW1ib2wodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJzeW1ib2xcIjtcbiAgICB9XG4gICAgUmVmaW5lbWVudC5pc1N5bWJvbCA9IGlzU3ltYm9sO1xuICAgIGZ1bmN0aW9uIGlzRnVuY3Rpb24odmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJmdW5jdGlvblwiO1xuICAgIH1cbiAgICBSZWZpbmVtZW50LmlzRnVuY3Rpb24gPSBpc0Z1bmN0aW9uO1xuICAgIGZ1bmN0aW9uIGlzT2JqZWN0KHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwib2JqZWN0XCIgJiYgdmFsdWUgIT09IG51bGw7XG4gICAgfVxuICAgIFJlZmluZW1lbnQuaXNPYmplY3QgPSBpc09iamVjdDtcbiAgICBSZWZpbmVtZW50LmlzUHJpbWl0aXZlID0gUmVmaW5lbWVudC5vcihpc1N0cmluZywgUmVmaW5lbWVudC5vcihpc051bWJlciwgUmVmaW5lbWVudC5vcihpc0JpZ0ludCwgUmVmaW5lbWVudC5vcihpc0Jvb2xlYW4sIFJlZmluZW1lbnQub3IoaXNOdWxsLCBSZWZpbmVtZW50Lm9yKGlzVW5kZWZpbmVkLCBpc1N5bWJvbCkpKSkpKTtcbn0pKFJlZmluZW1lbnQgfHwgKGV4cG9ydHMuUmVmaW5lbWVudCA9IFJlZmluZW1lbnQgPSB7fSkpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cmVmaW5lbWVudC5qcy5tYXAiLCIoZnVuY3Rpb24gKGdsb2JhbCwgZmFjdG9yeSkge1xuICBpZiAodHlwZW9mIGRlZmluZSA9PT0gXCJmdW5jdGlvblwiICYmIGRlZmluZS5hbWQpIHtcbiAgICBkZWZpbmUoXCJ3ZWJleHRlbnNpb24tcG9seWZpbGxcIiwgW1wibW9kdWxlXCJdLCBmYWN0b3J5KTtcbiAgfSBlbHNlIGlmICh0eXBlb2YgZXhwb3J0cyAhPT0gXCJ1bmRlZmluZWRcIikge1xuICAgIGZhY3RvcnkobW9kdWxlKTtcbiAgfSBlbHNlIHtcbiAgICB2YXIgbW9kID0ge1xuICAgICAgZXhwb3J0czoge31cbiAgICB9O1xuICAgIGZhY3RvcnkobW9kKTtcbiAgICBnbG9iYWwuYnJvd3NlciA9IG1vZC5leHBvcnRzO1xuICB9XG59KSh0eXBlb2YgZ2xvYmFsVGhpcyAhPT0gXCJ1bmRlZmluZWRcIiA/IGdsb2JhbFRoaXMgOiB0eXBlb2Ygc2VsZiAhPT0gXCJ1bmRlZmluZWRcIiA/IHNlbGYgOiB0aGlzLCBmdW5jdGlvbiAobW9kdWxlKSB7XG4gIC8qIHdlYmV4dGVuc2lvbi1wb2x5ZmlsbCAtIHYwLjEwLjAgLSBGcmkgQXVnIDEyIDIwMjIgMTk6NDI6NDQgKi9cblxuICAvKiAtKi0gTW9kZTogaW5kZW50LXRhYnMtbW9kZTogbmlsOyBqcy1pbmRlbnQtbGV2ZWw6IDIgLSotICovXG5cbiAgLyogdmltOiBzZXQgc3RzPTIgc3c9MiBldCB0dz04MDogKi9cblxuICAvKiBUaGlzIFNvdXJjZSBDb2RlIEZvcm0gaXMgc3ViamVjdCB0byB0aGUgdGVybXMgb2YgdGhlIE1vemlsbGEgUHVibGljXG4gICAqIExpY2Vuc2UsIHYuIDIuMC4gSWYgYSBjb3B5IG9mIHRoZSBNUEwgd2FzIG5vdCBkaXN0cmlidXRlZCB3aXRoIHRoaXNcbiAgICogZmlsZSwgWW91IGNhbiBvYnRhaW4gb25lIGF0IGh0dHA6Ly9tb3ppbGxhLm9yZy9NUEwvMi4wLy4gKi9cbiAgXCJ1c2Ugc3RyaWN0XCI7XG5cbiAgaWYgKCFnbG9iYWxUaGlzLmNocm9tZT8ucnVudGltZT8uaWQpIHtcbiAgICB0aHJvdyBuZXcgRXJyb3IoXCJUaGlzIHNjcmlwdCBzaG91bGQgb25seSBiZSBsb2FkZWQgaW4gYSBicm93c2VyIGV4dGVuc2lvbi5cIik7XG4gIH1cblxuICBpZiAodHlwZW9mIGdsb2JhbFRoaXMuYnJvd3NlciA9PT0gXCJ1bmRlZmluZWRcIiB8fCBPYmplY3QuZ2V0UHJvdG90eXBlT2YoZ2xvYmFsVGhpcy5icm93c2VyKSAhPT0gT2JqZWN0LnByb3RvdHlwZSkge1xuICAgIGNvbnN0IENIUk9NRV9TRU5EX01FU1NBR0VfQ0FMTEJBQ0tfTk9fUkVTUE9OU0VfTUVTU0FHRSA9IFwiVGhlIG1lc3NhZ2UgcG9ydCBjbG9zZWQgYmVmb3JlIGEgcmVzcG9uc2Ugd2FzIHJlY2VpdmVkLlwiOyAvLyBXcmFwcGluZyB0aGUgYnVsayBvZiB0aGlzIHBvbHlmaWxsIGluIGEgb25lLXRpbWUtdXNlIGZ1bmN0aW9uIGlzIGEgbWlub3JcbiAgICAvLyBvcHRpbWl6YXRpb24gZm9yIEZpcmVmb3guIFNpbmNlIFNwaWRlcm1vbmtleSBkb2VzIG5vdCBmdWxseSBwYXJzZSB0aGVcbiAgICAvLyBjb250ZW50cyBvZiBhIGZ1bmN0aW9uIHVudGlsIHRoZSBmaXJzdCB0aW1lIGl0J3MgY2FsbGVkLCBhbmQgc2luY2UgaXQgd2lsbFxuICAgIC8vIG5ldmVyIGFjdHVhbGx5IG5lZWQgdG8gYmUgY2FsbGVkLCB0aGlzIGFsbG93cyB0aGUgcG9seWZpbGwgdG8gYmUgaW5jbHVkZWRcbiAgICAvLyBpbiBGaXJlZm94IG5lYXJseSBmb3IgZnJlZS5cblxuICAgIGNvbnN0IHdyYXBBUElzID0gZXh0ZW5zaW9uQVBJcyA9PiB7XG4gICAgICAvLyBOT1RFOiBhcGlNZXRhZGF0YSBpcyBhc3NvY2lhdGVkIHRvIHRoZSBjb250ZW50IG9mIHRoZSBhcGktbWV0YWRhdGEuanNvbiBmaWxlXG4gICAgICAvLyBhdCBidWlsZCB0aW1lIGJ5IHJlcGxhY2luZyB0aGUgZm9sbG93aW5nIFwiaW5jbHVkZVwiIHdpdGggdGhlIGNvbnRlbnQgb2YgdGhlXG4gICAgICAvLyBKU09OIGZpbGUuXG4gICAgICBjb25zdCBhcGlNZXRhZGF0YSA9IHtcbiAgICAgICAgXCJhbGFybXNcIjoge1xuICAgICAgICAgIFwiY2xlYXJcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJjbGVhckFsbFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEFsbFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImJvb2ttYXJrc1wiOiB7XG4gICAgICAgICAgXCJjcmVhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRDaGlsZHJlblwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFJlY2VudFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFN1YlRyZWVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRUcmVlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwibW92ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZVRyZWVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZWFyY2hcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJ1cGRhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJicm93c2VyQWN0aW9uXCI6IHtcbiAgICAgICAgICBcImRpc2FibGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJlbmFibGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRCYWRnZUJhY2tncm91bmRDb2xvclwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEJhZGdlVGV4dFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFBvcHVwXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0VGl0bGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJvcGVuUG9wdXBcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRCYWRnZUJhY2tncm91bmRDb2xvclwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldEJhZGdlVGV4dFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldEljb25cIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRQb3B1cFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldFRpdGxlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiYnJvd3NpbmdEYXRhXCI6IHtcbiAgICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZUNhY2hlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlQ29va2llc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZURvd25sb2Fkc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZUZvcm1EYXRhXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlSGlzdG9yeVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZUxvY2FsU3RvcmFnZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZVBhc3N3b3Jkc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZVBsdWdpbkRhdGFcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXR0aW5nc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImNvbW1hbmRzXCI6IHtcbiAgICAgICAgICBcImdldEFsbFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImNvbnRleHRNZW51c1wiOiB7XG4gICAgICAgICAgXCJyZW1vdmVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVBbGxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJ1cGRhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJjb29raWVzXCI6IHtcbiAgICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEFsbFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEFsbENvb2tpZVN0b3Jlc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImRldnRvb2xzXCI6IHtcbiAgICAgICAgICBcImluc3BlY3RlZFdpbmRvd1wiOiB7XG4gICAgICAgICAgICBcImV2YWxcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDIsXG4gICAgICAgICAgICAgIFwic2luZ2xlQ2FsbGJhY2tBcmdcIjogZmFsc2VcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicGFuZWxzXCI6IHtcbiAgICAgICAgICAgIFwiY3JlYXRlXCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDMsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAzLFxuICAgICAgICAgICAgICBcInNpbmdsZUNhbGxiYWNrQXJnXCI6IHRydWVcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBcImVsZW1lbnRzXCI6IHtcbiAgICAgICAgICAgICAgXCJjcmVhdGVTaWRlYmFyUGFuZVwiOiB7XG4gICAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJkb3dubG9hZHNcIjoge1xuICAgICAgICAgIFwiY2FuY2VsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZG93bmxvYWRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJlcmFzZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEZpbGVJY29uXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwib3BlblwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInBhdXNlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlRmlsZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlc3VtZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNlYXJjaFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNob3dcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJleHRlbnNpb25cIjoge1xuICAgICAgICAgIFwiaXNBbGxvd2VkRmlsZVNjaGVtZUFjY2Vzc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImlzQWxsb3dlZEluY29nbml0b0FjY2Vzc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImhpc3RvcnlcIjoge1xuICAgICAgICAgIFwiYWRkVXJsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZGVsZXRlQWxsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZGVsZXRlUmFuZ2VcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJkZWxldGVVcmxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRWaXNpdHNcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZWFyY2hcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJpMThuXCI6IHtcbiAgICAgICAgICBcImRldGVjdExhbmd1YWdlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0QWNjZXB0TGFuZ3VhZ2VzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiaWRlbnRpdHlcIjoge1xuICAgICAgICAgIFwibGF1bmNoV2ViQXV0aEZsb3dcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJpZGxlXCI6IHtcbiAgICAgICAgICBcInF1ZXJ5U3RhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJtYW5hZ2VtZW50XCI6IHtcbiAgICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEFsbFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFNlbGZcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRFbmFibGVkXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwidW5pbnN0YWxsU2VsZlwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcIm5vdGlmaWNhdGlvbnNcIjoge1xuICAgICAgICAgIFwiY2xlYXJcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJjcmVhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRBbGxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRQZXJtaXNzaW9uTGV2ZWxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJ1cGRhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJwYWdlQWN0aW9uXCI6IHtcbiAgICAgICAgICBcImdldFBvcHVwXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0VGl0bGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJoaWRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0SWNvblwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldFBvcHVwXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0VGl0bGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzaG93XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwicGVybWlzc2lvbnNcIjoge1xuICAgICAgICAgIFwiY29udGFpbnNcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRBbGxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZXF1ZXN0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwicnVudGltZVwiOiB7XG4gICAgICAgICAgXCJnZXRCYWNrZ3JvdW5kUGFnZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFBsYXRmb3JtSW5mb1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcIm9wZW5PcHRpb25zUGFnZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlcXVlc3RVcGRhdGVDaGVja1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNlbmRNZXNzYWdlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDNcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2VuZE5hdGl2ZU1lc3NhZ2VcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRVbmluc3RhbGxVUkxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJzZXNzaW9uc1wiOiB7XG4gICAgICAgICAgXCJnZXREZXZpY2VzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0UmVjZW50bHlDbG9zZWRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZXN0b3JlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwic3RvcmFnZVwiOiB7XG4gICAgICAgICAgXCJsb2NhbFwiOiB7XG4gICAgICAgICAgICBcImNsZWFyXCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBcImdldEJ5dGVzSW5Vc2VcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwic2V0XCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSxcbiAgICAgICAgICBcIm1hbmFnZWRcIjoge1xuICAgICAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBcImdldEJ5dGVzSW5Vc2VcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic3luY1wiOiB7XG4gICAgICAgICAgICBcImNsZWFyXCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBcImdldEJ5dGVzSW5Vc2VcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBcInJlbW92ZVwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwic2V0XCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcInRhYnNcIjoge1xuICAgICAgICAgIFwiY2FwdHVyZVZpc2libGVUYWJcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJjcmVhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJkZXRlY3RMYW5ndWFnZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImRpc2NhcmRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJkdXBsaWNhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJleGVjdXRlU2NyaXB0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0Q3VycmVudFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFpvb21cIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRab29tU2V0dGluZ3NcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnb0JhY2tcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnb0ZvcndhcmRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJoaWdobGlnaHRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJpbnNlcnRDU1NcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJtb3ZlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicXVlcnlcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZWxvYWRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVDU1NcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZW5kTWVzc2FnZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAzXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldFpvb21cIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRab29tU2V0dGluZ3NcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJ1cGRhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJ0b3BTaXRlc1wiOiB7XG4gICAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJ3ZWJOYXZpZ2F0aW9uXCI6IHtcbiAgICAgICAgICBcImdldEFsbEZyYW1lc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEZyYW1lXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwid2ViUmVxdWVzdFwiOiB7XG4gICAgICAgICAgXCJoYW5kbGVyQmVoYXZpb3JDaGFuZ2VkXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwid2luZG93c1wiOiB7XG4gICAgICAgICAgXCJjcmVhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRBbGxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRDdXJyZW50XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0TGFzdEZvY3VzZWRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJ1cGRhdGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfTtcblxuICAgICAgaWYgKE9iamVjdC5rZXlzKGFwaU1ldGFkYXRhKS5sZW5ndGggPT09IDApIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKFwiYXBpLW1ldGFkYXRhLmpzb24gaGFzIG5vdCBiZWVuIGluY2x1ZGVkIGluIGJyb3dzZXItcG9seWZpbGxcIik7XG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIEEgV2Vha01hcCBzdWJjbGFzcyB3aGljaCBjcmVhdGVzIGFuZCBzdG9yZXMgYSB2YWx1ZSBmb3IgYW55IGtleSB3aGljaCBkb2VzXG4gICAgICAgKiBub3QgZXhpc3Qgd2hlbiBhY2Nlc3NlZCwgYnV0IGJlaGF2ZXMgZXhhY3RseSBhcyBhbiBvcmRpbmFyeSBXZWFrTWFwXG4gICAgICAgKiBvdGhlcndpc2UuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtmdW5jdGlvbn0gY3JlYXRlSXRlbVxuICAgICAgICogICAgICAgIEEgZnVuY3Rpb24gd2hpY2ggd2lsbCBiZSBjYWxsZWQgaW4gb3JkZXIgdG8gY3JlYXRlIHRoZSB2YWx1ZSBmb3IgYW55XG4gICAgICAgKiAgICAgICAga2V5IHdoaWNoIGRvZXMgbm90IGV4aXN0LCB0aGUgZmlyc3QgdGltZSBpdCBpcyBhY2Nlc3NlZC4gVGhlXG4gICAgICAgKiAgICAgICAgZnVuY3Rpb24gcmVjZWl2ZXMsIGFzIGl0cyBvbmx5IGFyZ3VtZW50LCB0aGUga2V5IGJlaW5nIGNyZWF0ZWQuXG4gICAgICAgKi9cblxuXG4gICAgICBjbGFzcyBEZWZhdWx0V2Vha01hcCBleHRlbmRzIFdlYWtNYXAge1xuICAgICAgICBjb25zdHJ1Y3RvcihjcmVhdGVJdGVtLCBpdGVtcyA9IHVuZGVmaW5lZCkge1xuICAgICAgICAgIHN1cGVyKGl0ZW1zKTtcbiAgICAgICAgICB0aGlzLmNyZWF0ZUl0ZW0gPSBjcmVhdGVJdGVtO1xuICAgICAgICB9XG5cbiAgICAgICAgZ2V0KGtleSkge1xuICAgICAgICAgIGlmICghdGhpcy5oYXMoa2V5KSkge1xuICAgICAgICAgICAgdGhpcy5zZXQoa2V5LCB0aGlzLmNyZWF0ZUl0ZW0oa2V5KSk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgcmV0dXJuIHN1cGVyLmdldChrZXkpO1xuICAgICAgICB9XG5cbiAgICAgIH1cbiAgICAgIC8qKlxuICAgICAgICogUmV0dXJucyB0cnVlIGlmIHRoZSBnaXZlbiBvYmplY3QgaXMgYW4gb2JqZWN0IHdpdGggYSBgdGhlbmAgbWV0aG9kLCBhbmQgY2FuXG4gICAgICAgKiB0aGVyZWZvcmUgYmUgYXNzdW1lZCB0byBiZWhhdmUgYXMgYSBQcm9taXNlLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7Kn0gdmFsdWUgVGhlIHZhbHVlIHRvIHRlc3QuXG4gICAgICAgKiBAcmV0dXJucyB7Ym9vbGVhbn0gVHJ1ZSBpZiB0aGUgdmFsdWUgaXMgdGhlbmFibGUuXG4gICAgICAgKi9cblxuXG4gICAgICBjb25zdCBpc1RoZW5hYmxlID0gdmFsdWUgPT4ge1xuICAgICAgICByZXR1cm4gdmFsdWUgJiYgdHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIHR5cGVvZiB2YWx1ZS50aGVuID09PSBcImZ1bmN0aW9uXCI7XG4gICAgICB9O1xuICAgICAgLyoqXG4gICAgICAgKiBDcmVhdGVzIGFuZCByZXR1cm5zIGEgZnVuY3Rpb24gd2hpY2gsIHdoZW4gY2FsbGVkLCB3aWxsIHJlc29sdmUgb3IgcmVqZWN0XG4gICAgICAgKiB0aGUgZ2l2ZW4gcHJvbWlzZSBiYXNlZCBvbiBob3cgaXQgaXMgY2FsbGVkOlxuICAgICAgICpcbiAgICAgICAqIC0gSWYsIHdoZW4gY2FsbGVkLCBgY2hyb21lLnJ1bnRpbWUubGFzdEVycm9yYCBjb250YWlucyBhIG5vbi1udWxsIG9iamVjdCxcbiAgICAgICAqICAgdGhlIHByb21pc2UgaXMgcmVqZWN0ZWQgd2l0aCB0aGF0IHZhbHVlLlxuICAgICAgICogLSBJZiB0aGUgZnVuY3Rpb24gaXMgY2FsbGVkIHdpdGggZXhhY3RseSBvbmUgYXJndW1lbnQsIHRoZSBwcm9taXNlIGlzXG4gICAgICAgKiAgIHJlc29sdmVkIHRvIHRoYXQgdmFsdWUuXG4gICAgICAgKiAtIE90aGVyd2lzZSwgdGhlIHByb21pc2UgaXMgcmVzb2x2ZWQgdG8gYW4gYXJyYXkgY29udGFpbmluZyBhbGwgb2YgdGhlXG4gICAgICAgKiAgIGZ1bmN0aW9uJ3MgYXJndW1lbnRzLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSBwcm9taXNlXG4gICAgICAgKiAgICAgICAgQW4gb2JqZWN0IGNvbnRhaW5pbmcgdGhlIHJlc29sdXRpb24gYW5kIHJlamVjdGlvbiBmdW5jdGlvbnMgb2YgYVxuICAgICAgICogICAgICAgIHByb21pc2UuXG4gICAgICAgKiBAcGFyYW0ge2Z1bmN0aW9ufSBwcm9taXNlLnJlc29sdmVcbiAgICAgICAqICAgICAgICBUaGUgcHJvbWlzZSdzIHJlc29sdXRpb24gZnVuY3Rpb24uXG4gICAgICAgKiBAcGFyYW0ge2Z1bmN0aW9ufSBwcm9taXNlLnJlamVjdFxuICAgICAgICogICAgICAgIFRoZSBwcm9taXNlJ3MgcmVqZWN0aW9uIGZ1bmN0aW9uLlxuICAgICAgICogQHBhcmFtIHtvYmplY3R9IG1ldGFkYXRhXG4gICAgICAgKiAgICAgICAgTWV0YWRhdGEgYWJvdXQgdGhlIHdyYXBwZWQgbWV0aG9kIHdoaWNoIGhhcyBjcmVhdGVkIHRoZSBjYWxsYmFjay5cbiAgICAgICAqIEBwYXJhbSB7Ym9vbGVhbn0gbWV0YWRhdGEuc2luZ2xlQ2FsbGJhY2tBcmdcbiAgICAgICAqICAgICAgICBXaGV0aGVyIG9yIG5vdCB0aGUgcHJvbWlzZSBpcyByZXNvbHZlZCB3aXRoIG9ubHkgdGhlIGZpcnN0XG4gICAgICAgKiAgICAgICAgYXJndW1lbnQgb2YgdGhlIGNhbGxiYWNrLCBhbHRlcm5hdGl2ZWx5IGFuIGFycmF5IG9mIGFsbCB0aGVcbiAgICAgICAqICAgICAgICBjYWxsYmFjayBhcmd1bWVudHMgaXMgcmVzb2x2ZWQuIEJ5IGRlZmF1bHQsIGlmIHRoZSBjYWxsYmFja1xuICAgICAgICogICAgICAgIGZ1bmN0aW9uIGlzIGludm9rZWQgd2l0aCBvbmx5IGEgc2luZ2xlIGFyZ3VtZW50LCB0aGF0IHdpbGwgYmVcbiAgICAgICAqICAgICAgICByZXNvbHZlZCB0byB0aGUgcHJvbWlzZSwgd2hpbGUgYWxsIGFyZ3VtZW50cyB3aWxsIGJlIHJlc29sdmVkIGFzXG4gICAgICAgKiAgICAgICAgYW4gYXJyYXkgaWYgbXVsdGlwbGUgYXJlIGdpdmVuLlxuICAgICAgICpcbiAgICAgICAqIEByZXR1cm5zIHtmdW5jdGlvbn1cbiAgICAgICAqICAgICAgICBUaGUgZ2VuZXJhdGVkIGNhbGxiYWNrIGZ1bmN0aW9uLlxuICAgICAgICovXG5cblxuICAgICAgY29uc3QgbWFrZUNhbGxiYWNrID0gKHByb21pc2UsIG1ldGFkYXRhKSA9PiB7XG4gICAgICAgIHJldHVybiAoLi4uY2FsbGJhY2tBcmdzKSA9PiB7XG4gICAgICAgICAgaWYgKGV4dGVuc2lvbkFQSXMucnVudGltZS5sYXN0RXJyb3IpIHtcbiAgICAgICAgICAgIHByb21pc2UucmVqZWN0KG5ldyBFcnJvcihleHRlbnNpb25BUElzLnJ1bnRpbWUubGFzdEVycm9yLm1lc3NhZ2UpKTtcbiAgICAgICAgICB9IGVsc2UgaWYgKG1ldGFkYXRhLnNpbmdsZUNhbGxiYWNrQXJnIHx8IGNhbGxiYWNrQXJncy5sZW5ndGggPD0gMSAmJiBtZXRhZGF0YS5zaW5nbGVDYWxsYmFja0FyZyAhPT0gZmFsc2UpIHtcbiAgICAgICAgICAgIHByb21pc2UucmVzb2x2ZShjYWxsYmFja0FyZ3NbMF0pO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBwcm9taXNlLnJlc29sdmUoY2FsbGJhY2tBcmdzKTtcbiAgICAgICAgICB9XG4gICAgICAgIH07XG4gICAgICB9O1xuXG4gICAgICBjb25zdCBwbHVyYWxpemVBcmd1bWVudHMgPSBudW1BcmdzID0+IG51bUFyZ3MgPT0gMSA/IFwiYXJndW1lbnRcIiA6IFwiYXJndW1lbnRzXCI7XG4gICAgICAvKipcbiAgICAgICAqIENyZWF0ZXMgYSB3cmFwcGVyIGZ1bmN0aW9uIGZvciBhIG1ldGhvZCB3aXRoIHRoZSBnaXZlbiBuYW1lIGFuZCBtZXRhZGF0YS5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge3N0cmluZ30gbmFtZVxuICAgICAgICogICAgICAgIFRoZSBuYW1lIG9mIHRoZSBtZXRob2Qgd2hpY2ggaXMgYmVpbmcgd3JhcHBlZC5cbiAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSBtZXRhZGF0YVxuICAgICAgICogICAgICAgIE1ldGFkYXRhIGFib3V0IHRoZSBtZXRob2QgYmVpbmcgd3JhcHBlZC5cbiAgICAgICAqIEBwYXJhbSB7aW50ZWdlcn0gbWV0YWRhdGEubWluQXJnc1xuICAgICAgICogICAgICAgIFRoZSBtaW5pbXVtIG51bWJlciBvZiBhcmd1bWVudHMgd2hpY2ggbXVzdCBiZSBwYXNzZWQgdG8gdGhlXG4gICAgICAgKiAgICAgICAgZnVuY3Rpb24uIElmIGNhbGxlZCB3aXRoIGZld2VyIHRoYW4gdGhpcyBudW1iZXIgb2YgYXJndW1lbnRzLCB0aGVcbiAgICAgICAqICAgICAgICB3cmFwcGVyIHdpbGwgcmFpc2UgYW4gZXhjZXB0aW9uLlxuICAgICAgICogQHBhcmFtIHtpbnRlZ2VyfSBtZXRhZGF0YS5tYXhBcmdzXG4gICAgICAgKiAgICAgICAgVGhlIG1heGltdW0gbnVtYmVyIG9mIGFyZ3VtZW50cyB3aGljaCBtYXkgYmUgcGFzc2VkIHRvIHRoZVxuICAgICAgICogICAgICAgIGZ1bmN0aW9uLiBJZiBjYWxsZWQgd2l0aCBtb3JlIHRoYW4gdGhpcyBudW1iZXIgb2YgYXJndW1lbnRzLCB0aGVcbiAgICAgICAqICAgICAgICB3cmFwcGVyIHdpbGwgcmFpc2UgYW4gZXhjZXB0aW9uLlxuICAgICAgICogQHBhcmFtIHtib29sZWFufSBtZXRhZGF0YS5zaW5nbGVDYWxsYmFja0FyZ1xuICAgICAgICogICAgICAgIFdoZXRoZXIgb3Igbm90IHRoZSBwcm9taXNlIGlzIHJlc29sdmVkIHdpdGggb25seSB0aGUgZmlyc3RcbiAgICAgICAqICAgICAgICBhcmd1bWVudCBvZiB0aGUgY2FsbGJhY2ssIGFsdGVybmF0aXZlbHkgYW4gYXJyYXkgb2YgYWxsIHRoZVxuICAgICAgICogICAgICAgIGNhbGxiYWNrIGFyZ3VtZW50cyBpcyByZXNvbHZlZC4gQnkgZGVmYXVsdCwgaWYgdGhlIGNhbGxiYWNrXG4gICAgICAgKiAgICAgICAgZnVuY3Rpb24gaXMgaW52b2tlZCB3aXRoIG9ubHkgYSBzaW5nbGUgYXJndW1lbnQsIHRoYXQgd2lsbCBiZVxuICAgICAgICogICAgICAgIHJlc29sdmVkIHRvIHRoZSBwcm9taXNlLCB3aGlsZSBhbGwgYXJndW1lbnRzIHdpbGwgYmUgcmVzb2x2ZWQgYXNcbiAgICAgICAqICAgICAgICBhbiBhcnJheSBpZiBtdWx0aXBsZSBhcmUgZ2l2ZW4uXG4gICAgICAgKlxuICAgICAgICogQHJldHVybnMge2Z1bmN0aW9uKG9iamVjdCwgLi4uKil9XG4gICAgICAgKiAgICAgICBUaGUgZ2VuZXJhdGVkIHdyYXBwZXIgZnVuY3Rpb24uXG4gICAgICAgKi9cblxuXG4gICAgICBjb25zdCB3cmFwQXN5bmNGdW5jdGlvbiA9IChuYW1lLCBtZXRhZGF0YSkgPT4ge1xuICAgICAgICByZXR1cm4gZnVuY3Rpb24gYXN5bmNGdW5jdGlvbldyYXBwZXIodGFyZ2V0LCAuLi5hcmdzKSB7XG4gICAgICAgICAgaWYgKGFyZ3MubGVuZ3RoIDwgbWV0YWRhdGEubWluQXJncykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBFeHBlY3RlZCBhdCBsZWFzdCAke21ldGFkYXRhLm1pbkFyZ3N9ICR7cGx1cmFsaXplQXJndW1lbnRzKG1ldGFkYXRhLm1pbkFyZ3MpfSBmb3IgJHtuYW1lfSgpLCBnb3QgJHthcmdzLmxlbmd0aH1gKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAoYXJncy5sZW5ndGggPiBtZXRhZGF0YS5tYXhBcmdzKSB7XG4gICAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEV4cGVjdGVkIGF0IG1vc3QgJHttZXRhZGF0YS5tYXhBcmdzfSAke3BsdXJhbGl6ZUFyZ3VtZW50cyhtZXRhZGF0YS5tYXhBcmdzKX0gZm9yICR7bmFtZX0oKSwgZ290ICR7YXJncy5sZW5ndGh9YCk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICAgIGlmIChtZXRhZGF0YS5mYWxsYmFja1RvTm9DYWxsYmFjaykge1xuICAgICAgICAgICAgICAvLyBUaGlzIEFQSSBtZXRob2QgaGFzIGN1cnJlbnRseSBubyBjYWxsYmFjayBvbiBDaHJvbWUsIGJ1dCBpdCByZXR1cm4gYSBwcm9taXNlIG9uIEZpcmVmb3gsXG4gICAgICAgICAgICAgIC8vIGFuZCBzbyB0aGUgcG9seWZpbGwgd2lsbCB0cnkgdG8gY2FsbCBpdCB3aXRoIGEgY2FsbGJhY2sgZmlyc3QsIGFuZCBpdCB3aWxsIGZhbGxiYWNrXG4gICAgICAgICAgICAgIC8vIHRvIG5vdCBwYXNzaW5nIHRoZSBjYWxsYmFjayBpZiB0aGUgZmlyc3QgY2FsbCBmYWlscy5cbiAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICB0YXJnZXRbbmFtZV0oLi4uYXJncywgbWFrZUNhbGxiYWNrKHtcbiAgICAgICAgICAgICAgICAgIHJlc29sdmUsXG4gICAgICAgICAgICAgICAgICByZWplY3RcbiAgICAgICAgICAgICAgICB9LCBtZXRhZGF0YSkpO1xuICAgICAgICAgICAgICB9IGNhdGNoIChjYkVycm9yKSB7XG4gICAgICAgICAgICAgICAgY29uc29sZS53YXJuKGAke25hbWV9IEFQSSBtZXRob2QgZG9lc24ndCBzZWVtIHRvIHN1cHBvcnQgdGhlIGNhbGxiYWNrIHBhcmFtZXRlciwgYCArIFwiZmFsbGluZyBiYWNrIHRvIGNhbGwgaXQgd2l0aG91dCBhIGNhbGxiYWNrOiBcIiwgY2JFcnJvcik7XG4gICAgICAgICAgICAgICAgdGFyZ2V0W25hbWVdKC4uLmFyZ3MpOyAvLyBVcGRhdGUgdGhlIEFQSSBtZXRob2QgbWV0YWRhdGEsIHNvIHRoYXQgdGhlIG5leHQgQVBJIGNhbGxzIHdpbGwgbm90IHRyeSB0b1xuICAgICAgICAgICAgICAgIC8vIHVzZSB0aGUgdW5zdXBwb3J0ZWQgY2FsbGJhY2sgYW55bW9yZS5cblxuICAgICAgICAgICAgICAgIG1ldGFkYXRhLmZhbGxiYWNrVG9Ob0NhbGxiYWNrID0gZmFsc2U7XG4gICAgICAgICAgICAgICAgbWV0YWRhdGEubm9DYWxsYmFjayA9IHRydWU7XG4gICAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2UgaWYgKG1ldGFkYXRhLm5vQ2FsbGJhY2spIHtcbiAgICAgICAgICAgICAgdGFyZ2V0W25hbWVdKC4uLmFyZ3MpO1xuICAgICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICB0YXJnZXRbbmFtZV0oLi4uYXJncywgbWFrZUNhbGxiYWNrKHtcbiAgICAgICAgICAgICAgICByZXNvbHZlLFxuICAgICAgICAgICAgICAgIHJlamVjdFxuICAgICAgICAgICAgICB9LCBtZXRhZGF0YSkpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgICB9O1xuICAgICAgfTtcbiAgICAgIC8qKlxuICAgICAgICogV3JhcHMgYW4gZXhpc3RpbmcgbWV0aG9kIG9mIHRoZSB0YXJnZXQgb2JqZWN0LCBzbyB0aGF0IGNhbGxzIHRvIGl0IGFyZVxuICAgICAgICogaW50ZXJjZXB0ZWQgYnkgdGhlIGdpdmVuIHdyYXBwZXIgZnVuY3Rpb24uIFRoZSB3cmFwcGVyIGZ1bmN0aW9uIHJlY2VpdmVzLFxuICAgICAgICogYXMgaXRzIGZpcnN0IGFyZ3VtZW50LCB0aGUgb3JpZ2luYWwgYHRhcmdldGAgb2JqZWN0LCBmb2xsb3dlZCBieSBlYWNoIG9mXG4gICAgICAgKiB0aGUgYXJndW1lbnRzIHBhc3NlZCB0byB0aGUgb3JpZ2luYWwgbWV0aG9kLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSB0YXJnZXRcbiAgICAgICAqICAgICAgICBUaGUgb3JpZ2luYWwgdGFyZ2V0IG9iamVjdCB0aGF0IHRoZSB3cmFwcGVkIG1ldGhvZCBiZWxvbmdzIHRvLlxuICAgICAgICogQHBhcmFtIHtmdW5jdGlvbn0gbWV0aG9kXG4gICAgICAgKiAgICAgICAgVGhlIG1ldGhvZCBiZWluZyB3cmFwcGVkLiBUaGlzIGlzIHVzZWQgYXMgdGhlIHRhcmdldCBvZiB0aGUgUHJveHlcbiAgICAgICAqICAgICAgICBvYmplY3Qgd2hpY2ggaXMgY3JlYXRlZCB0byB3cmFwIHRoZSBtZXRob2QuXG4gICAgICAgKiBAcGFyYW0ge2Z1bmN0aW9ufSB3cmFwcGVyXG4gICAgICAgKiAgICAgICAgVGhlIHdyYXBwZXIgZnVuY3Rpb24gd2hpY2ggaXMgY2FsbGVkIGluIHBsYWNlIG9mIGEgZGlyZWN0IGludm9jYXRpb25cbiAgICAgICAqICAgICAgICBvZiB0aGUgd3JhcHBlZCBtZXRob2QuXG4gICAgICAgKlxuICAgICAgICogQHJldHVybnMge1Byb3h5PGZ1bmN0aW9uPn1cbiAgICAgICAqICAgICAgICBBIFByb3h5IG9iamVjdCBmb3IgdGhlIGdpdmVuIG1ldGhvZCwgd2hpY2ggaW52b2tlcyB0aGUgZ2l2ZW4gd3JhcHBlclxuICAgICAgICogICAgICAgIG1ldGhvZCBpbiBpdHMgcGxhY2UuXG4gICAgICAgKi9cblxuXG4gICAgICBjb25zdCB3cmFwTWV0aG9kID0gKHRhcmdldCwgbWV0aG9kLCB3cmFwcGVyKSA9PiB7XG4gICAgICAgIHJldHVybiBuZXcgUHJveHkobWV0aG9kLCB7XG4gICAgICAgICAgYXBwbHkodGFyZ2V0TWV0aG9kLCB0aGlzT2JqLCBhcmdzKSB7XG4gICAgICAgICAgICByZXR1cm4gd3JhcHBlci5jYWxsKHRoaXNPYmosIHRhcmdldCwgLi4uYXJncyk7XG4gICAgICAgICAgfVxuXG4gICAgICAgIH0pO1xuICAgICAgfTtcblxuICAgICAgbGV0IGhhc093blByb3BlcnR5ID0gRnVuY3Rpb24uY2FsbC5iaW5kKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkpO1xuICAgICAgLyoqXG4gICAgICAgKiBXcmFwcyBhbiBvYmplY3QgaW4gYSBQcm94eSB3aGljaCBpbnRlcmNlcHRzIGFuZCB3cmFwcyBjZXJ0YWluIG1ldGhvZHNcbiAgICAgICAqIGJhc2VkIG9uIHRoZSBnaXZlbiBgd3JhcHBlcnNgIGFuZCBgbWV0YWRhdGFgIG9iamVjdHMuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtvYmplY3R9IHRhcmdldFxuICAgICAgICogICAgICAgIFRoZSB0YXJnZXQgb2JqZWN0IHRvIHdyYXAuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtvYmplY3R9IFt3cmFwcGVycyA9IHt9XVxuICAgICAgICogICAgICAgIEFuIG9iamVjdCB0cmVlIGNvbnRhaW5pbmcgd3JhcHBlciBmdW5jdGlvbnMgZm9yIHNwZWNpYWwgY2FzZXMuIEFueVxuICAgICAgICogICAgICAgIGZ1bmN0aW9uIHByZXNlbnQgaW4gdGhpcyBvYmplY3QgdHJlZSBpcyBjYWxsZWQgaW4gcGxhY2Ugb2YgdGhlXG4gICAgICAgKiAgICAgICAgbWV0aG9kIGluIHRoZSBzYW1lIGxvY2F0aW9uIGluIHRoZSBgdGFyZ2V0YCBvYmplY3QgdHJlZS4gVGhlc2VcbiAgICAgICAqICAgICAgICB3cmFwcGVyIG1ldGhvZHMgYXJlIGludm9rZWQgYXMgZGVzY3JpYmVkIGluIHtAc2VlIHdyYXBNZXRob2R9LlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSBbbWV0YWRhdGEgPSB7fV1cbiAgICAgICAqICAgICAgICBBbiBvYmplY3QgdHJlZSBjb250YWluaW5nIG1ldGFkYXRhIHVzZWQgdG8gYXV0b21hdGljYWxseSBnZW5lcmF0ZVxuICAgICAgICogICAgICAgIFByb21pc2UtYmFzZWQgd3JhcHBlciBmdW5jdGlvbnMgZm9yIGFzeW5jaHJvbm91cy4gQW55IGZ1bmN0aW9uIGluXG4gICAgICAgKiAgICAgICAgdGhlIGB0YXJnZXRgIG9iamVjdCB0cmVlIHdoaWNoIGhhcyBhIGNvcnJlc3BvbmRpbmcgbWV0YWRhdGEgb2JqZWN0XG4gICAgICAgKiAgICAgICAgaW4gdGhlIHNhbWUgbG9jYXRpb24gaW4gdGhlIGBtZXRhZGF0YWAgdHJlZSBpcyByZXBsYWNlZCB3aXRoIGFuXG4gICAgICAgKiAgICAgICAgYXV0b21hdGljYWxseS1nZW5lcmF0ZWQgd3JhcHBlciBmdW5jdGlvbiwgYXMgZGVzY3JpYmVkIGluXG4gICAgICAgKiAgICAgICAge0BzZWUgd3JhcEFzeW5jRnVuY3Rpb259XG4gICAgICAgKlxuICAgICAgICogQHJldHVybnMge1Byb3h5PG9iamVjdD59XG4gICAgICAgKi9cblxuICAgICAgY29uc3Qgd3JhcE9iamVjdCA9ICh0YXJnZXQsIHdyYXBwZXJzID0ge30sIG1ldGFkYXRhID0ge30pID0+IHtcbiAgICAgICAgbGV0IGNhY2hlID0gT2JqZWN0LmNyZWF0ZShudWxsKTtcbiAgICAgICAgbGV0IGhhbmRsZXJzID0ge1xuICAgICAgICAgIGhhcyhwcm94eVRhcmdldCwgcHJvcCkge1xuICAgICAgICAgICAgcmV0dXJuIHByb3AgaW4gdGFyZ2V0IHx8IHByb3AgaW4gY2FjaGU7XG4gICAgICAgICAgfSxcblxuICAgICAgICAgIGdldChwcm94eVRhcmdldCwgcHJvcCwgcmVjZWl2ZXIpIHtcbiAgICAgICAgICAgIGlmIChwcm9wIGluIGNhY2hlKSB7XG4gICAgICAgICAgICAgIHJldHVybiBjYWNoZVtwcm9wXTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgaWYgKCEocHJvcCBpbiB0YXJnZXQpKSB7XG4gICAgICAgICAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGxldCB2YWx1ZSA9IHRhcmdldFtwcm9wXTtcblxuICAgICAgICAgICAgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgICAgICAgIC8vIFRoaXMgaXMgYSBtZXRob2Qgb24gdGhlIHVuZGVybHlpbmcgb2JqZWN0LiBDaGVjayBpZiB3ZSBuZWVkIHRvIGRvXG4gICAgICAgICAgICAgIC8vIGFueSB3cmFwcGluZy5cbiAgICAgICAgICAgICAgaWYgKHR5cGVvZiB3cmFwcGVyc1twcm9wXSA9PT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgICAgICAgICAgLy8gV2UgaGF2ZSBhIHNwZWNpYWwtY2FzZSB3cmFwcGVyIGZvciB0aGlzIG1ldGhvZC5cbiAgICAgICAgICAgICAgICB2YWx1ZSA9IHdyYXBNZXRob2QodGFyZ2V0LCB0YXJnZXRbcHJvcF0sIHdyYXBwZXJzW3Byb3BdKTtcbiAgICAgICAgICAgICAgfSBlbHNlIGlmIChoYXNPd25Qcm9wZXJ0eShtZXRhZGF0YSwgcHJvcCkpIHtcbiAgICAgICAgICAgICAgICAvLyBUaGlzIGlzIGFuIGFzeW5jIG1ldGhvZCB0aGF0IHdlIGhhdmUgbWV0YWRhdGEgZm9yLiBDcmVhdGUgYVxuICAgICAgICAgICAgICAgIC8vIFByb21pc2Ugd3JhcHBlciBmb3IgaXQuXG4gICAgICAgICAgICAgICAgbGV0IHdyYXBwZXIgPSB3cmFwQXN5bmNGdW5jdGlvbihwcm9wLCBtZXRhZGF0YVtwcm9wXSk7XG4gICAgICAgICAgICAgICAgdmFsdWUgPSB3cmFwTWV0aG9kKHRhcmdldCwgdGFyZ2V0W3Byb3BdLCB3cmFwcGVyKTtcbiAgICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgICAvLyBUaGlzIGlzIGEgbWV0aG9kIHRoYXQgd2UgZG9uJ3Qga25vdyBvciBjYXJlIGFib3V0LiBSZXR1cm4gdGhlXG4gICAgICAgICAgICAgICAgLy8gb3JpZ2luYWwgbWV0aG9kLCBib3VuZCB0byB0aGUgdW5kZXJseWluZyBvYmplY3QuXG4gICAgICAgICAgICAgICAgdmFsdWUgPSB2YWx1ZS5iaW5kKHRhcmdldCk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH0gZWxzZSBpZiAodHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIHZhbHVlICE9PSBudWxsICYmIChoYXNPd25Qcm9wZXJ0eSh3cmFwcGVycywgcHJvcCkgfHwgaGFzT3duUHJvcGVydHkobWV0YWRhdGEsIHByb3ApKSkge1xuICAgICAgICAgICAgICAvLyBUaGlzIGlzIGFuIG9iamVjdCB0aGF0IHdlIG5lZWQgdG8gZG8gc29tZSB3cmFwcGluZyBmb3IgdGhlIGNoaWxkcmVuXG4gICAgICAgICAgICAgIC8vIG9mLiBDcmVhdGUgYSBzdWItb2JqZWN0IHdyYXBwZXIgZm9yIGl0IHdpdGggdGhlIGFwcHJvcHJpYXRlIGNoaWxkXG4gICAgICAgICAgICAgIC8vIG1ldGFkYXRhLlxuICAgICAgICAgICAgICB2YWx1ZSA9IHdyYXBPYmplY3QodmFsdWUsIHdyYXBwZXJzW3Byb3BdLCBtZXRhZGF0YVtwcm9wXSk7XG4gICAgICAgICAgICB9IGVsc2UgaWYgKGhhc093blByb3BlcnR5KG1ldGFkYXRhLCBcIipcIikpIHtcbiAgICAgICAgICAgICAgLy8gV3JhcCBhbGwgcHJvcGVydGllcyBpbiAqIG5hbWVzcGFjZS5cbiAgICAgICAgICAgICAgdmFsdWUgPSB3cmFwT2JqZWN0KHZhbHVlLCB3cmFwcGVyc1twcm9wXSwgbWV0YWRhdGFbXCIqXCJdKTtcbiAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgIC8vIFdlIGRvbid0IG5lZWQgdG8gZG8gYW55IHdyYXBwaW5nIGZvciB0aGlzIHByb3BlcnR5LFxuICAgICAgICAgICAgICAvLyBzbyBqdXN0IGZvcndhcmQgYWxsIGFjY2VzcyB0byB0aGUgdW5kZXJseWluZyBvYmplY3QuXG4gICAgICAgICAgICAgIE9iamVjdC5kZWZpbmVQcm9wZXJ0eShjYWNoZSwgcHJvcCwge1xuICAgICAgICAgICAgICAgIGNvbmZpZ3VyYWJsZTogdHJ1ZSxcbiAgICAgICAgICAgICAgICBlbnVtZXJhYmxlOiB0cnVlLFxuXG4gICAgICAgICAgICAgICAgZ2V0KCkge1xuICAgICAgICAgICAgICAgICAgcmV0dXJuIHRhcmdldFtwcm9wXTtcbiAgICAgICAgICAgICAgICB9LFxuXG4gICAgICAgICAgICAgICAgc2V0KHZhbHVlKSB7XG4gICAgICAgICAgICAgICAgICB0YXJnZXRbcHJvcF0gPSB2YWx1ZTtcbiAgICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgY2FjaGVbcHJvcF0gPSB2YWx1ZTtcbiAgICAgICAgICAgIHJldHVybiB2YWx1ZTtcbiAgICAgICAgICB9LFxuXG4gICAgICAgICAgc2V0KHByb3h5VGFyZ2V0LCBwcm9wLCB2YWx1ZSwgcmVjZWl2ZXIpIHtcbiAgICAgICAgICAgIGlmIChwcm9wIGluIGNhY2hlKSB7XG4gICAgICAgICAgICAgIGNhY2hlW3Byb3BdID0gdmFsdWU7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICB0YXJnZXRbcHJvcF0gPSB2YWx1ZTtcbiAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgICAgfSxcblxuICAgICAgICAgIGRlZmluZVByb3BlcnR5KHByb3h5VGFyZ2V0LCBwcm9wLCBkZXNjKSB7XG4gICAgICAgICAgICByZXR1cm4gUmVmbGVjdC5kZWZpbmVQcm9wZXJ0eShjYWNoZSwgcHJvcCwgZGVzYyk7XG4gICAgICAgICAgfSxcblxuICAgICAgICAgIGRlbGV0ZVByb3BlcnR5KHByb3h5VGFyZ2V0LCBwcm9wKSB7XG4gICAgICAgICAgICByZXR1cm4gUmVmbGVjdC5kZWxldGVQcm9wZXJ0eShjYWNoZSwgcHJvcCk7XG4gICAgICAgICAgfVxuXG4gICAgICAgIH07IC8vIFBlciBjb250cmFjdCBvZiB0aGUgUHJveHkgQVBJLCB0aGUgXCJnZXRcIiBwcm94eSBoYW5kbGVyIG11c3QgcmV0dXJuIHRoZVxuICAgICAgICAvLyBvcmlnaW5hbCB2YWx1ZSBvZiB0aGUgdGFyZ2V0IGlmIHRoYXQgdmFsdWUgaXMgZGVjbGFyZWQgcmVhZC1vbmx5IGFuZFxuICAgICAgICAvLyBub24tY29uZmlndXJhYmxlLiBGb3IgdGhpcyByZWFzb24sIHdlIGNyZWF0ZSBhbiBvYmplY3Qgd2l0aCB0aGVcbiAgICAgICAgLy8gcHJvdG90eXBlIHNldCB0byBgdGFyZ2V0YCBpbnN0ZWFkIG9mIHVzaW5nIGB0YXJnZXRgIGRpcmVjdGx5LlxuICAgICAgICAvLyBPdGhlcndpc2Ugd2UgY2Fubm90IHJldHVybiBhIGN1c3RvbSBvYmplY3QgZm9yIEFQSXMgdGhhdFxuICAgICAgICAvLyBhcmUgZGVjbGFyZWQgcmVhZC1vbmx5IGFuZCBub24tY29uZmlndXJhYmxlLCBzdWNoIGFzIGBjaHJvbWUuZGV2dG9vbHNgLlxuICAgICAgICAvL1xuICAgICAgICAvLyBUaGUgcHJveHkgaGFuZGxlcnMgdGhlbXNlbHZlcyB3aWxsIHN0aWxsIHVzZSB0aGUgb3JpZ2luYWwgYHRhcmdldGBcbiAgICAgICAgLy8gaW5zdGVhZCBvZiB0aGUgYHByb3h5VGFyZ2V0YCwgc28gdGhhdCB0aGUgbWV0aG9kcyBhbmQgcHJvcGVydGllcyBhcmVcbiAgICAgICAgLy8gZGVyZWZlcmVuY2VkIHZpYSB0aGUgb3JpZ2luYWwgdGFyZ2V0cy5cblxuICAgICAgICBsZXQgcHJveHlUYXJnZXQgPSBPYmplY3QuY3JlYXRlKHRhcmdldCk7XG4gICAgICAgIHJldHVybiBuZXcgUHJveHkocHJveHlUYXJnZXQsIGhhbmRsZXJzKTtcbiAgICAgIH07XG4gICAgICAvKipcbiAgICAgICAqIENyZWF0ZXMgYSBzZXQgb2Ygd3JhcHBlciBmdW5jdGlvbnMgZm9yIGFuIGV2ZW50IG9iamVjdCwgd2hpY2ggaGFuZGxlc1xuICAgICAgICogd3JhcHBpbmcgb2YgbGlzdGVuZXIgZnVuY3Rpb25zIHRoYXQgdGhvc2UgbWVzc2FnZXMgYXJlIHBhc3NlZC5cbiAgICAgICAqXG4gICAgICAgKiBBIHNpbmdsZSB3cmFwcGVyIGlzIGNyZWF0ZWQgZm9yIGVhY2ggbGlzdGVuZXIgZnVuY3Rpb24sIGFuZCBzdG9yZWQgaW4gYVxuICAgICAgICogbWFwLiBTdWJzZXF1ZW50IGNhbGxzIHRvIGBhZGRMaXN0ZW5lcmAsIGBoYXNMaXN0ZW5lcmAsIG9yIGByZW1vdmVMaXN0ZW5lcmBcbiAgICAgICAqIHJldHJpZXZlIHRoZSBvcmlnaW5hbCB3cmFwcGVyLCBzbyB0aGF0ICBhdHRlbXB0cyB0byByZW1vdmUgYVxuICAgICAgICogcHJldmlvdXNseS1hZGRlZCBsaXN0ZW5lciB3b3JrIGFzIGV4cGVjdGVkLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7RGVmYXVsdFdlYWtNYXA8ZnVuY3Rpb24sIGZ1bmN0aW9uPn0gd3JhcHBlck1hcFxuICAgICAgICogICAgICAgIEEgRGVmYXVsdFdlYWtNYXAgb2JqZWN0IHdoaWNoIHdpbGwgY3JlYXRlIHRoZSBhcHByb3ByaWF0ZSB3cmFwcGVyXG4gICAgICAgKiAgICAgICAgZm9yIGEgZ2l2ZW4gbGlzdGVuZXIgZnVuY3Rpb24gd2hlbiBvbmUgZG9lcyBub3QgZXhpc3QsIGFuZCByZXRyaWV2ZVxuICAgICAgICogICAgICAgIGFuIGV4aXN0aW5nIG9uZSB3aGVuIGl0IGRvZXMuXG4gICAgICAgKlxuICAgICAgICogQHJldHVybnMge29iamVjdH1cbiAgICAgICAqL1xuXG5cbiAgICAgIGNvbnN0IHdyYXBFdmVudCA9IHdyYXBwZXJNYXAgPT4gKHtcbiAgICAgICAgYWRkTGlzdGVuZXIodGFyZ2V0LCBsaXN0ZW5lciwgLi4uYXJncykge1xuICAgICAgICAgIHRhcmdldC5hZGRMaXN0ZW5lcih3cmFwcGVyTWFwLmdldChsaXN0ZW5lciksIC4uLmFyZ3MpO1xuICAgICAgICB9LFxuXG4gICAgICAgIGhhc0xpc3RlbmVyKHRhcmdldCwgbGlzdGVuZXIpIHtcbiAgICAgICAgICByZXR1cm4gdGFyZ2V0Lmhhc0xpc3RlbmVyKHdyYXBwZXJNYXAuZ2V0KGxpc3RlbmVyKSk7XG4gICAgICAgIH0sXG5cbiAgICAgICAgcmVtb3ZlTGlzdGVuZXIodGFyZ2V0LCBsaXN0ZW5lcikge1xuICAgICAgICAgIHRhcmdldC5yZW1vdmVMaXN0ZW5lcih3cmFwcGVyTWFwLmdldChsaXN0ZW5lcikpO1xuICAgICAgICB9XG5cbiAgICAgIH0pO1xuXG4gICAgICBjb25zdCBvblJlcXVlc3RGaW5pc2hlZFdyYXBwZXJzID0gbmV3IERlZmF1bHRXZWFrTWFwKGxpc3RlbmVyID0+IHtcbiAgICAgICAgaWYgKHR5cGVvZiBsaXN0ZW5lciAhPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgICAgcmV0dXJuIGxpc3RlbmVyO1xuICAgICAgICB9XG4gICAgICAgIC8qKlxuICAgICAgICAgKiBXcmFwcyBhbiBvblJlcXVlc3RGaW5pc2hlZCBsaXN0ZW5lciBmdW5jdGlvbiBzbyB0aGF0IGl0IHdpbGwgcmV0dXJuIGFcbiAgICAgICAgICogYGdldENvbnRlbnQoKWAgcHJvcGVydHkgd2hpY2ggcmV0dXJucyBhIGBQcm9taXNlYCByYXRoZXIgdGhhbiB1c2luZyBhXG4gICAgICAgICAqIGNhbGxiYWNrIEFQSS5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHtvYmplY3R9IHJlcVxuICAgICAgICAgKiAgICAgICAgVGhlIEhBUiBlbnRyeSBvYmplY3QgcmVwcmVzZW50aW5nIHRoZSBuZXR3b3JrIHJlcXVlc3QuXG4gICAgICAgICAqL1xuXG5cbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIG9uUmVxdWVzdEZpbmlzaGVkKHJlcSkge1xuICAgICAgICAgIGNvbnN0IHdyYXBwZWRSZXEgPSB3cmFwT2JqZWN0KHJlcSwge31cbiAgICAgICAgICAvKiB3cmFwcGVycyAqL1xuICAgICAgICAgICwge1xuICAgICAgICAgICAgZ2V0Q29udGVudDoge1xuICAgICAgICAgICAgICBtaW5BcmdzOiAwLFxuICAgICAgICAgICAgICBtYXhBcmdzOiAwXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgbGlzdGVuZXIod3JhcHBlZFJlcSk7XG4gICAgICAgIH07XG4gICAgICB9KTtcbiAgICAgIGNvbnN0IG9uTWVzc2FnZVdyYXBwZXJzID0gbmV3IERlZmF1bHRXZWFrTWFwKGxpc3RlbmVyID0+IHtcbiAgICAgICAgaWYgKHR5cGVvZiBsaXN0ZW5lciAhPT0gXCJmdW5jdGlvblwiKSB7XG4gICAgICAgICAgcmV0dXJuIGxpc3RlbmVyO1xuICAgICAgICB9XG4gICAgICAgIC8qKlxuICAgICAgICAgKiBXcmFwcyBhIG1lc3NhZ2UgbGlzdGVuZXIgZnVuY3Rpb24gc28gdGhhdCBpdCBtYXkgc2VuZCByZXNwb25zZXMgYmFzZWQgb25cbiAgICAgICAgICogaXRzIHJldHVybiB2YWx1ZSwgcmF0aGVyIHRoYW4gYnkgcmV0dXJuaW5nIGEgc2VudGluZWwgdmFsdWUgYW5kIGNhbGxpbmcgYVxuICAgICAgICAgKiBjYWxsYmFjay4gSWYgdGhlIGxpc3RlbmVyIGZ1bmN0aW9uIHJldHVybnMgYSBQcm9taXNlLCB0aGUgcmVzcG9uc2UgaXNcbiAgICAgICAgICogc2VudCB3aGVuIHRoZSBwcm9taXNlIGVpdGhlciByZXNvbHZlcyBvciByZWplY3RzLlxuICAgICAgICAgKlxuICAgICAgICAgKiBAcGFyYW0geyp9IG1lc3NhZ2VcbiAgICAgICAgICogICAgICAgIFRoZSBtZXNzYWdlIHNlbnQgYnkgdGhlIG90aGVyIGVuZCBvZiB0aGUgY2hhbm5lbC5cbiAgICAgICAgICogQHBhcmFtIHtvYmplY3R9IHNlbmRlclxuICAgICAgICAgKiAgICAgICAgRGV0YWlscyBhYm91dCB0aGUgc2VuZGVyIG9mIHRoZSBtZXNzYWdlLlxuICAgICAgICAgKiBAcGFyYW0ge2Z1bmN0aW9uKCopfSBzZW5kUmVzcG9uc2VcbiAgICAgICAgICogICAgICAgIEEgY2FsbGJhY2sgd2hpY2gsIHdoZW4gY2FsbGVkIHdpdGggYW4gYXJiaXRyYXJ5IGFyZ3VtZW50LCBzZW5kc1xuICAgICAgICAgKiAgICAgICAgdGhhdCB2YWx1ZSBhcyBhIHJlc3BvbnNlLlxuICAgICAgICAgKiBAcmV0dXJucyB7Ym9vbGVhbn1cbiAgICAgICAgICogICAgICAgIFRydWUgaWYgdGhlIHdyYXBwZWQgbGlzdGVuZXIgcmV0dXJuZWQgYSBQcm9taXNlLCB3aGljaCB3aWxsIGxhdGVyXG4gICAgICAgICAqICAgICAgICB5aWVsZCBhIHJlc3BvbnNlLiBGYWxzZSBvdGhlcndpc2UuXG4gICAgICAgICAqL1xuXG5cbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIG9uTWVzc2FnZShtZXNzYWdlLCBzZW5kZXIsIHNlbmRSZXNwb25zZSkge1xuICAgICAgICAgIGxldCBkaWRDYWxsU2VuZFJlc3BvbnNlID0gZmFsc2U7XG4gICAgICAgICAgbGV0IHdyYXBwZWRTZW5kUmVzcG9uc2U7XG4gICAgICAgICAgbGV0IHNlbmRSZXNwb25zZVByb21pc2UgPSBuZXcgUHJvbWlzZShyZXNvbHZlID0+IHtcbiAgICAgICAgICAgIHdyYXBwZWRTZW5kUmVzcG9uc2UgPSBmdW5jdGlvbiAocmVzcG9uc2UpIHtcbiAgICAgICAgICAgICAgZGlkQ2FsbFNlbmRSZXNwb25zZSA9IHRydWU7XG4gICAgICAgICAgICAgIHJlc29sdmUocmVzcG9uc2UpO1xuICAgICAgICAgICAgfTtcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBsZXQgcmVzdWx0O1xuXG4gICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgIHJlc3VsdCA9IGxpc3RlbmVyKG1lc3NhZ2UsIHNlbmRlciwgd3JhcHBlZFNlbmRSZXNwb25zZSk7XG4gICAgICAgICAgfSBjYXRjaCAoZXJyKSB7XG4gICAgICAgICAgICByZXN1bHQgPSBQcm9taXNlLnJlamVjdChlcnIpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIGNvbnN0IGlzUmVzdWx0VGhlbmFibGUgPSByZXN1bHQgIT09IHRydWUgJiYgaXNUaGVuYWJsZShyZXN1bHQpOyAvLyBJZiB0aGUgbGlzdGVuZXIgZGlkbid0IHJldHVybmVkIHRydWUgb3IgYSBQcm9taXNlLCBvciBjYWxsZWRcbiAgICAgICAgICAvLyB3cmFwcGVkU2VuZFJlc3BvbnNlIHN5bmNocm9ub3VzbHksIHdlIGNhbiBleGl0IGVhcmxpZXJcbiAgICAgICAgICAvLyBiZWNhdXNlIHRoZXJlIHdpbGwgYmUgbm8gcmVzcG9uc2Ugc2VudCBmcm9tIHRoaXMgbGlzdGVuZXIuXG5cbiAgICAgICAgICBpZiAocmVzdWx0ICE9PSB0cnVlICYmICFpc1Jlc3VsdFRoZW5hYmxlICYmICFkaWRDYWxsU2VuZFJlc3BvbnNlKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgfSAvLyBBIHNtYWxsIGhlbHBlciB0byBzZW5kIHRoZSBtZXNzYWdlIGlmIHRoZSBwcm9taXNlIHJlc29sdmVzXG4gICAgICAgICAgLy8gYW5kIGFuIGVycm9yIGlmIHRoZSBwcm9taXNlIHJlamVjdHMgKGEgd3JhcHBlZCBzZW5kTWVzc2FnZSBoYXNcbiAgICAgICAgICAvLyB0byB0cmFuc2xhdGUgdGhlIG1lc3NhZ2UgaW50byBhIHJlc29sdmVkIHByb21pc2Ugb3IgYSByZWplY3RlZFxuICAgICAgICAgIC8vIHByb21pc2UpLlxuXG5cbiAgICAgICAgICBjb25zdCBzZW5kUHJvbWlzZWRSZXN1bHQgPSBwcm9taXNlID0+IHtcbiAgICAgICAgICAgIHByb21pc2UudGhlbihtc2cgPT4ge1xuICAgICAgICAgICAgICAvLyBzZW5kIHRoZSBtZXNzYWdlIHZhbHVlLlxuICAgICAgICAgICAgICBzZW5kUmVzcG9uc2UobXNnKTtcbiAgICAgICAgICAgIH0sIGVycm9yID0+IHtcbiAgICAgICAgICAgICAgLy8gU2VuZCBhIEpTT04gcmVwcmVzZW50YXRpb24gb2YgdGhlIGVycm9yIGlmIHRoZSByZWplY3RlZCB2YWx1ZVxuICAgICAgICAgICAgICAvLyBpcyBhbiBpbnN0YW5jZSBvZiBlcnJvciwgb3IgdGhlIG9iamVjdCBpdHNlbGYgb3RoZXJ3aXNlLlxuICAgICAgICAgICAgICBsZXQgbWVzc2FnZTtcblxuICAgICAgICAgICAgICBpZiAoZXJyb3IgJiYgKGVycm9yIGluc3RhbmNlb2YgRXJyb3IgfHwgdHlwZW9mIGVycm9yLm1lc3NhZ2UgPT09IFwic3RyaW5nXCIpKSB7XG4gICAgICAgICAgICAgICAgbWVzc2FnZSA9IGVycm9yLm1lc3NhZ2U7XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgbWVzc2FnZSA9IFwiQW4gdW5leHBlY3RlZCBlcnJvciBvY2N1cnJlZFwiO1xuICAgICAgICAgICAgICB9XG5cbiAgICAgICAgICAgICAgc2VuZFJlc3BvbnNlKHtcbiAgICAgICAgICAgICAgICBfX21veldlYkV4dGVuc2lvblBvbHlmaWxsUmVqZWN0X186IHRydWUsXG4gICAgICAgICAgICAgICAgbWVzc2FnZVxuICAgICAgICAgICAgICB9KTtcbiAgICAgICAgICAgIH0pLmNhdGNoKGVyciA9PiB7XG4gICAgICAgICAgICAgIC8vIFByaW50IGFuIGVycm9yIG9uIHRoZSBjb25zb2xlIGlmIHVuYWJsZSB0byBzZW5kIHRoZSByZXNwb25zZS5cbiAgICAgICAgICAgICAgY29uc29sZS5lcnJvcihcIkZhaWxlZCB0byBzZW5kIG9uTWVzc2FnZSByZWplY3RlZCByZXBseVwiLCBlcnIpO1xuICAgICAgICAgICAgfSk7XG4gICAgICAgICAgfTsgLy8gSWYgdGhlIGxpc3RlbmVyIHJldHVybmVkIGEgUHJvbWlzZSwgc2VuZCB0aGUgcmVzb2x2ZWQgdmFsdWUgYXMgYVxuICAgICAgICAgIC8vIHJlc3VsdCwgb3RoZXJ3aXNlIHdhaXQgdGhlIHByb21pc2UgcmVsYXRlZCB0byB0aGUgd3JhcHBlZFNlbmRSZXNwb25zZVxuICAgICAgICAgIC8vIGNhbGxiYWNrIHRvIHJlc29sdmUgYW5kIHNlbmQgaXQgYXMgYSByZXNwb25zZS5cblxuXG4gICAgICAgICAgaWYgKGlzUmVzdWx0VGhlbmFibGUpIHtcbiAgICAgICAgICAgIHNlbmRQcm9taXNlZFJlc3VsdChyZXN1bHQpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICBzZW5kUHJvbWlzZWRSZXN1bHQoc2VuZFJlc3BvbnNlUHJvbWlzZSk7XG4gICAgICAgICAgfSAvLyBMZXQgQ2hyb21lIGtub3cgdGhhdCB0aGUgbGlzdGVuZXIgaXMgcmVwbHlpbmcuXG5cblxuICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9O1xuICAgICAgfSk7XG5cbiAgICAgIGNvbnN0IHdyYXBwZWRTZW5kTWVzc2FnZUNhbGxiYWNrID0gKHtcbiAgICAgICAgcmVqZWN0LFxuICAgICAgICByZXNvbHZlXG4gICAgICB9LCByZXBseSkgPT4ge1xuICAgICAgICBpZiAoZXh0ZW5zaW9uQVBJcy5ydW50aW1lLmxhc3RFcnJvcikge1xuICAgICAgICAgIC8vIERldGVjdCB3aGVuIG5vbmUgb2YgdGhlIGxpc3RlbmVycyByZXBsaWVkIHRvIHRoZSBzZW5kTWVzc2FnZSBjYWxsIGFuZCByZXNvbHZlXG4gICAgICAgICAgLy8gdGhlIHByb21pc2UgdG8gdW5kZWZpbmVkIGFzIGluIEZpcmVmb3guXG4gICAgICAgICAgLy8gU2VlIGh0dHBzOi8vZ2l0aHViLmNvbS9tb3ppbGxhL3dlYmV4dGVuc2lvbi1wb2x5ZmlsbC9pc3N1ZXMvMTMwXG4gICAgICAgICAgaWYgKGV4dGVuc2lvbkFQSXMucnVudGltZS5sYXN0RXJyb3IubWVzc2FnZSA9PT0gQ0hST01FX1NFTkRfTUVTU0FHRV9DQUxMQkFDS19OT19SRVNQT05TRV9NRVNTQUdFKSB7XG4gICAgICAgICAgICByZXNvbHZlKCk7XG4gICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgIHJlamVjdChuZXcgRXJyb3IoZXh0ZW5zaW9uQVBJcy5ydW50aW1lLmxhc3RFcnJvci5tZXNzYWdlKSk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2UgaWYgKHJlcGx5ICYmIHJlcGx5Ll9fbW96V2ViRXh0ZW5zaW9uUG9seWZpbGxSZWplY3RfXykge1xuICAgICAgICAgIC8vIENvbnZlcnQgYmFjayB0aGUgSlNPTiByZXByZXNlbnRhdGlvbiBvZiB0aGUgZXJyb3IgaW50b1xuICAgICAgICAgIC8vIGFuIEVycm9yIGluc3RhbmNlLlxuICAgICAgICAgIHJlamVjdChuZXcgRXJyb3IocmVwbHkubWVzc2FnZSkpO1xuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIHJlc29sdmUocmVwbHkpO1xuICAgICAgICB9XG4gICAgICB9O1xuXG4gICAgICBjb25zdCB3cmFwcGVkU2VuZE1lc3NhZ2UgPSAobmFtZSwgbWV0YWRhdGEsIGFwaU5hbWVzcGFjZU9iaiwgLi4uYXJncykgPT4ge1xuICAgICAgICBpZiAoYXJncy5sZW5ndGggPCBtZXRhZGF0YS5taW5BcmdzKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBFeHBlY3RlZCBhdCBsZWFzdCAke21ldGFkYXRhLm1pbkFyZ3N9ICR7cGx1cmFsaXplQXJndW1lbnRzKG1ldGFkYXRhLm1pbkFyZ3MpfSBmb3IgJHtuYW1lfSgpLCBnb3QgJHthcmdzLmxlbmd0aH1gKTtcbiAgICAgICAgfVxuXG4gICAgICAgIGlmIChhcmdzLmxlbmd0aCA+IG1ldGFkYXRhLm1heEFyZ3MpIHtcbiAgICAgICAgICB0aHJvdyBuZXcgRXJyb3IoYEV4cGVjdGVkIGF0IG1vc3QgJHttZXRhZGF0YS5tYXhBcmdzfSAke3BsdXJhbGl6ZUFyZ3VtZW50cyhtZXRhZGF0YS5tYXhBcmdzKX0gZm9yICR7bmFtZX0oKSwgZ290ICR7YXJncy5sZW5ndGh9YCk7XG4gICAgICAgIH1cblxuICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICAgIGNvbnN0IHdyYXBwZWRDYiA9IHdyYXBwZWRTZW5kTWVzc2FnZUNhbGxiYWNrLmJpbmQobnVsbCwge1xuICAgICAgICAgICAgcmVzb2x2ZSxcbiAgICAgICAgICAgIHJlamVjdFxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGFyZ3MucHVzaCh3cmFwcGVkQ2IpO1xuICAgICAgICAgIGFwaU5hbWVzcGFjZU9iai5zZW5kTWVzc2FnZSguLi5hcmdzKTtcbiAgICAgICAgfSk7XG4gICAgICB9O1xuXG4gICAgICBjb25zdCBzdGF0aWNXcmFwcGVycyA9IHtcbiAgICAgICAgZGV2dG9vbHM6IHtcbiAgICAgICAgICBuZXR3b3JrOiB7XG4gICAgICAgICAgICBvblJlcXVlc3RGaW5pc2hlZDogd3JhcEV2ZW50KG9uUmVxdWVzdEZpbmlzaGVkV3JhcHBlcnMpXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBydW50aW1lOiB7XG4gICAgICAgICAgb25NZXNzYWdlOiB3cmFwRXZlbnQob25NZXNzYWdlV3JhcHBlcnMpLFxuICAgICAgICAgIG9uTWVzc2FnZUV4dGVybmFsOiB3cmFwRXZlbnQob25NZXNzYWdlV3JhcHBlcnMpLFxuICAgICAgICAgIHNlbmRNZXNzYWdlOiB3cmFwcGVkU2VuZE1lc3NhZ2UuYmluZChudWxsLCBcInNlbmRNZXNzYWdlXCIsIHtcbiAgICAgICAgICAgIG1pbkFyZ3M6IDEsXG4gICAgICAgICAgICBtYXhBcmdzOiAzXG4gICAgICAgICAgfSlcbiAgICAgICAgfSxcbiAgICAgICAgdGFiczoge1xuICAgICAgICAgIHNlbmRNZXNzYWdlOiB3cmFwcGVkU2VuZE1lc3NhZ2UuYmluZChudWxsLCBcInNlbmRNZXNzYWdlXCIsIHtcbiAgICAgICAgICAgIG1pbkFyZ3M6IDIsXG4gICAgICAgICAgICBtYXhBcmdzOiAzXG4gICAgICAgICAgfSlcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIGNvbnN0IHNldHRpbmdNZXRhZGF0YSA9IHtcbiAgICAgICAgY2xlYXI6IHtcbiAgICAgICAgICBtaW5BcmdzOiAxLFxuICAgICAgICAgIG1heEFyZ3M6IDFcbiAgICAgICAgfSxcbiAgICAgICAgZ2V0OiB7XG4gICAgICAgICAgbWluQXJnczogMSxcbiAgICAgICAgICBtYXhBcmdzOiAxXG4gICAgICAgIH0sXG4gICAgICAgIHNldDoge1xuICAgICAgICAgIG1pbkFyZ3M6IDEsXG4gICAgICAgICAgbWF4QXJnczogMVxuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgYXBpTWV0YWRhdGEucHJpdmFjeSA9IHtcbiAgICAgICAgbmV0d29yazoge1xuICAgICAgICAgIFwiKlwiOiBzZXR0aW5nTWV0YWRhdGFcbiAgICAgICAgfSxcbiAgICAgICAgc2VydmljZXM6IHtcbiAgICAgICAgICBcIipcIjogc2V0dGluZ01ldGFkYXRhXG4gICAgICAgIH0sXG4gICAgICAgIHdlYnNpdGVzOiB7XG4gICAgICAgICAgXCIqXCI6IHNldHRpbmdNZXRhZGF0YVxuICAgICAgICB9XG4gICAgICB9O1xuICAgICAgcmV0dXJuIHdyYXBPYmplY3QoZXh0ZW5zaW9uQVBJcywgc3RhdGljV3JhcHBlcnMsIGFwaU1ldGFkYXRhKTtcbiAgICB9OyAvLyBUaGUgYnVpbGQgcHJvY2VzcyBhZGRzIGEgVU1EIHdyYXBwZXIgYXJvdW5kIHRoaXMgZmlsZSwgd2hpY2ggbWFrZXMgdGhlXG4gICAgLy8gYG1vZHVsZWAgdmFyaWFibGUgYXZhaWxhYmxlLlxuXG5cbiAgICBtb2R1bGUuZXhwb3J0cyA9IHdyYXBBUElzKGNocm9tZSk7XG4gIH0gZWxzZSB7XG4gICAgbW9kdWxlLmV4cG9ydHMgPSBnbG9iYWxUaGlzLmJyb3dzZXI7XG4gIH1cbn0pO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YnJvd3Nlci1wb2x5ZmlsbC5qcy5tYXBcbiIsIi8vIFRoZSBtb2R1bGUgY2FjaGVcbnZhciBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX18gPSB7fTtcblxuLy8gVGhlIHJlcXVpcmUgZnVuY3Rpb25cbmZ1bmN0aW9uIF9fd2VicGFja19yZXF1aXJlX18obW9kdWxlSWQpIHtcblx0Ly8gQ2hlY2sgaWYgbW9kdWxlIGlzIGluIGNhY2hlXG5cdHZhciBjYWNoZWRNb2R1bGUgPSBfX3dlYnBhY2tfbW9kdWxlX2NhY2hlX19bbW9kdWxlSWRdO1xuXHRpZiAoY2FjaGVkTW9kdWxlICE9PSB1bmRlZmluZWQpIHtcblx0XHRyZXR1cm4gY2FjaGVkTW9kdWxlLmV4cG9ydHM7XG5cdH1cblx0Ly8gQ3JlYXRlIGEgbmV3IG1vZHVsZSAoYW5kIHB1dCBpdCBpbnRvIHRoZSBjYWNoZSlcblx0dmFyIG1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF0gPSB7XG5cdFx0Ly8gbm8gbW9kdWxlLmlkIG5lZWRlZFxuXHRcdC8vIG5vIG1vZHVsZS5sb2FkZWQgbmVlZGVkXG5cdFx0ZXhwb3J0czoge31cblx0fTtcblxuXHQvLyBFeGVjdXRlIHRoZSBtb2R1bGUgZnVuY3Rpb25cblx0X193ZWJwYWNrX21vZHVsZXNfX1ttb2R1bGVJZF0uY2FsbChtb2R1bGUuZXhwb3J0cywgbW9kdWxlLCBtb2R1bGUuZXhwb3J0cywgX193ZWJwYWNrX3JlcXVpcmVfXyk7XG5cblx0Ly8gUmV0dXJuIHRoZSBleHBvcnRzIG9mIHRoZSBtb2R1bGVcblx0cmV0dXJuIG1vZHVsZS5leHBvcnRzO1xufVxuXG4iLCIvLyBnZXREZWZhdWx0RXhwb3J0IGZ1bmN0aW9uIGZvciBjb21wYXRpYmlsaXR5IHdpdGggbm9uLWhhcm1vbnkgbW9kdWxlc1xuX193ZWJwYWNrX3JlcXVpcmVfXy5uID0gKG1vZHVsZSkgPT4ge1xuXHR2YXIgZ2V0dGVyID0gbW9kdWxlICYmIG1vZHVsZS5fX2VzTW9kdWxlID9cblx0XHQoKSA9PiAobW9kdWxlWydkZWZhdWx0J10pIDpcblx0XHQoKSA9PiAobW9kdWxlKTtcblx0X193ZWJwYWNrX3JlcXVpcmVfXy5kKGdldHRlciwgeyBhOiBnZXR0ZXIgfSk7XG5cdHJldHVybiBnZXR0ZXI7XG59OyIsIi8vIGRlZmluZSBnZXR0ZXIgZnVuY3Rpb25zIGZvciBoYXJtb255IGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uZCA9IChleHBvcnRzLCBkZWZpbml0aW9uKSA9PiB7XG5cdGZvcih2YXIga2V5IGluIGRlZmluaXRpb24pIHtcblx0XHRpZihfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZGVmaW5pdGlvbiwga2V5KSAmJiAhX193ZWJwYWNrX3JlcXVpcmVfXy5vKGV4cG9ydHMsIGtleSkpIHtcblx0XHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBrZXksIHsgZW51bWVyYWJsZTogdHJ1ZSwgZ2V0OiBkZWZpbml0aW9uW2tleV0gfSk7XG5cdFx0fVxuXHR9XG59OyIsIl9fd2VicGFja19yZXF1aXJlX18ubyA9IChvYmosIHByb3ApID0+IChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5LmNhbGwob2JqLCBwcm9wKSkiLCIvLyBkZWZpbmUgX19lc01vZHVsZSBvbiBleHBvcnRzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLnIgPSAoZXhwb3J0cykgPT4ge1xuXHRpZih0eXBlb2YgU3ltYm9sICE9PSAndW5kZWZpbmVkJyAmJiBTeW1ib2wudG9TdHJpbmdUYWcpIHtcblx0XHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgU3ltYm9sLnRvU3RyaW5nVGFnLCB7IHZhbHVlOiAnTW9kdWxlJyB9KTtcblx0fVxuXHRPYmplY3QuZGVmaW5lUHJvcGVydHkoZXhwb3J0cywgJ19fZXNNb2R1bGUnLCB7IHZhbHVlOiB0cnVlIH0pO1xufTsiLCIvKipcbiAqIFRoaXMgaXMgdGhlIG1haW4gZW50cnkgcG9pbnQgdG8gd2hhdCB3ZSByZWZlciB0byBhcyB0aGUgQVBJIG9mIHRoZSBleHRlbnNpb24uXG4gKiBUaGUgQVBJIGhhbmRsZXMgbW9zdCBpbnRlcmFjdGlvbnMgd2l0aCBBbGZhLCB0aGUgYnJvd3NlciwgYW5kIHRoZSBwYWdlIGJlaW5nXG4gKiB0ZXN0ZWQgYW5kIGV4cG9zZXMgYW4gaW50ZXJmYWNlIGZvciB0aGUgYXBwbGljYXRpb24gY29kZSB0byBjYWxsIHRocm91Z2hcbiAqIG1lc3NhZ2luZy5cbiAqXG4gKiBUaGUgQVBJIGlzIHJ1biBhcyBhIHBvc3NpYmx5IG5vbi1wZXJzaXN0ZW50IGJhY2tncm91bmQgc2NyaXB0IChvciBzZXJ2aWNlXG4gKiB3b3JrZXIsIGRlcGVuZGluZyBvbiBicm93c2VycykgaW4gdGhlIGJyb3dzZXIuXG4gKiBJdCBtdXN0IHRoZXJlZm9yZSBub3QgZGVwZW5kIG9uIGFueSBnbG9iYWwgc3RhdGUgYXMgc3VjaCBzdGF0ZSB3aWxsIGJlIGxvc3RcbiAqIHdoZW4gdGhlIGJhY2tncm91bmQgc2NyaXB0IGlzIHVubG9hZGVkLlxuICpcbiAqIE5vdGFibHksIHRoaXMgZm9yY2VzIHRoZSBwb3B1cCB0byBjb25uZWN0IGRpcmVjdGx5IHRvIHRoZSBkZXZ0b29scyBpbnN0YW5jZVxuICogb2YgdGhlIGluc3BlY3RlZCBwYWdlOyBhbmQgdGhpcyBmb3JjZXMgdGhlIHBvcHVwIG1hcCB0byBiZSBzdG9yZWQgaW4gbG9jYWxcbiAqIHN0b3JhZ2UuXG4gKi9cblxuaW1wb3J0IHsgTWFwIH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLW1hcFwiO1xuaW1wb3J0IHsgTm9uZSwgT3B0aW9uIH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLW9wdGlvblwiO1xuaW1wb3J0IGJyb3dzZXIgZnJvbSBcIndlYmV4dGVuc2lvbi1wb2x5ZmlsbFwiO1xuXG4vKipcbiAqIFN0b3JhZ2Uga2V5c1xuICovXG5jb25zdCBQT1BVUF9LRVkgPSBcInBvcHVwc01hcFwiO1xuXG4vKipcbiAqIE1hcCBmcm9tIHRhYklkIHRvIG9wZW4gcG9wdXAuXG4gKlxuICogQHJlbWFya3NcbiAqIEV2ZXJ5IGxpc3RlbmVyIHdpbGwgcmVsb2FkIHRoZSBwb3B1cHMgbWFwLCB0byBtYWtlIHN1cmUgaXQgaXMgdXAtdG8tZGF0ZS5cbiAqIExpc3RlbmVycyB0aGF0IHVwZGF0ZSBpdCBhbHNvIHNhdmUgaXQuXG4gKiBXaGVuIGNsaWNraW5nIHRoZSBleHRlbnNpb24gYnV0dG9uLCB3ZSBhbHNvIHRha2UgdGltZSB0byBjbGVhbiBpdCwgaW4gY2FzZVxuICogYW55dGhpbmcgYmFkIGhhcHBlbmVkIGF0IHNvbWUgcG9pbnQuXG4gKi9cblxubGV0IG15UG9wdXBzID0gTWFwLmVtcHR5KCk7XG5hc3luYyBmdW5jdGlvbiBsb2FkUG9wdXBzTWFwKCkge1xuICBjb25zdCBwb3B1cHMgPSBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuZ2V0KFBPUFVQX0tFWSk7XG4gIG15UG9wdXBzID0gTWFwLmZyb20ocG9wdXBzPy5bUE9QVVBfS0VZXSA/PyBbXSk7XG59XG5hc3luYyBmdW5jdGlvbiBzYXZlUG9wdXBzTWFwKCkge1xuICBhd2FpdCBicm93c2VyLnN0b3JhZ2UubG9jYWwuc2V0KHtcbiAgICBbUE9QVVBfS0VZXTogbXlQb3B1cHMudG9BcnJheSgpXG4gIH0pO1xufVxuYXN5bmMgZnVuY3Rpb24gd2luZG93RXhpc3RzKHdpbmRvd0lkKSB7XG4gIGlmICh3aW5kb3dJZCA9PT0gdW5kZWZpbmVkKSB7XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9XG4gIHRyeSB7XG4gICAgYXdhaXQgYnJvd3Nlci53aW5kb3dzLmdldCh3aW5kb3dJZCk7XG4gICAgcmV0dXJuIHRydWU7XG4gIH0gY2F0Y2ggKGUpIHtcbiAgICAvLyBXZSBhc3N1bWUgZXJyb3JzIG1vc3RseSBvY2N1ciBkdWUgdG8gbm9uLWV4aXN0ZW50IHdpbmRvdy5cbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbn1cblxuLyoqXG4gKiBSZW1vdmUgZW50cmllcyB3aXRoIG5vIGNvcnJlc3BvbmRpbmcgb3BlbmVkIHdpbmRvd1xuICpcbiAqIEByZW1hcmtzXG4gKiBUaGlzIHNob3VsZCBub3QgaGFwcGVuIHNpbmNlIHRoZSBzZXJ2aWNlIHdvcmtlciBzaG91bGQgcmVzdGFydCBhbmQgY2xlYW5cbiAqIHRoZSBtYXAgb24gd2luZG93IHJlbW92ZWQuIFRoaXMgaXMgaG93ZXZlciBub3QgZXhwZW5zaXZlIGJlY2F1c2Ugd2UgYXNzdW1lXG4gKiB0aGUgbWFwIHdpbGwgYmUgc21hbGw7IGFuZCB0aGlzIHByZXZlbnRzIGEgcG9zc2libGUgdmVjdG9yIG9mIG1lbW9yeSBsZWFrXG4gKiBzaW5jZSB0aGlzIGlzIHBlcnNpc3RlbnQgc3RvcmFnZSBhbmQgd2UgaGF2ZSByZXF1ZXN0ZWQgdW5saW1pdGVkIHN0b3JhZ2VcbiAqIHBlcm1pc3Npb24uXG4gKi9cbmFzeW5jIGZ1bmN0aW9uIGNsZWFuUG9wdXBzTWFwKCkge1xuICBsZXQgZXhpc3RpbmcgPSBNYXAuZW1wdHkoKTtcbiAgZm9yIChjb25zdCBbdGFiSWQsIHBvcHVwXSBvZiBteVBvcHVwcykge1xuICAgIGlmIChhd2FpdCB3aW5kb3dFeGlzdHMocG9wdXAud2luZG93SWQpKSB7XG4gICAgICBleGlzdGluZyA9IGV4aXN0aW5nLnNldCh0YWJJZCwgcG9wdXApO1xuICAgIH1cbiAgfVxuICBteVBvcHVwcyA9IGV4aXN0aW5nO1xufVxuXG4vKipcbiAqIENsZWFudXAgcG9wdXAtbWFwIHdoZW4gYSBwb3B1cCB3aW5kb3cgaXMgY2xvc2VkLlxuICpcbiAqIEByZW1hcmtzXG4gKiBUaGlzIGlzIHRyaWdnZXJlZCBieSB0aGUgb3RoZXIgbGlzdGVuZXJzIGNsb3NpbmcgcG9wdXAgd2luZG93cy5cbiAqL1xuYnJvd3Nlci53aW5kb3dzLm9uUmVtb3ZlZC5hZGRMaXN0ZW5lcihhc3luYyB3aW5kb3dJZCA9PiB7XG4gIGF3YWl0IGxvYWRQb3B1cHNNYXAoKTtcbiAgbGV0IGtleSA9IE5vbmU7XG4gIG15UG9wdXBzLmZpbmQoKHBvcHVwLCB0YWJJZCkgPT4ge1xuICAgIGlmIChwb3B1cC53aW5kb3dJZCA9PT0gd2luZG93SWQpIHtcbiAgICAgIGtleSA9IE9wdGlvbi5vZih0YWJJZCk7XG4gICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgcmV0dXJuIGZhbHNlO1xuICB9KTtcbiAga2V5LmZvckVhY2goa2V5ID0+IG15UG9wdXBzID0gbXlQb3B1cHMuZGVsZXRlKGtleSkpO1xuICBhd2FpdCBzYXZlUG9wdXBzTWFwKCk7XG59KTtcblxuLyoqXG4gKiBDbG9zZSBwb3B1cCBpZiB1c2VyIG5hdmlnYXRlIHRvIGFub3RoZXIgcGFnZS5cbiAqL1xuYnJvd3Nlci50YWJzLm9uVXBkYXRlZC5hZGRMaXN0ZW5lcihhc3luYyB0YWJJZCA9PiB7XG4gIGF3YWl0IGxvYWRQb3B1cHNNYXAoKTtcbiAgY29uc3QgY3VycmVudFBvcHVwID0gbXlQb3B1cHMuZ2V0KHRhYklkKS5nZXRPcih1bmRlZmluZWQpO1xuICBpZiAoY3VycmVudFBvcHVwPy53aW5kb3dJZCkge1xuICAgIC8vIENsb3NlIHRoZSBwb3B1cCBpZiB0aGUgdXJsIGNoYW5nZXNcbiAgICBjb25zdCB0YWIgPSBhd2FpdCBicm93c2VyLnRhYnMuZ2V0KHRhYklkKTtcbiAgICBpZiAoY3VycmVudFBvcHVwPy51cmwgIT09IHRhYi51cmwgJiYgbmF2aWdhdG9yLnVzZXJBZ2VudC5pbmRleE9mKFwiRmlyZWZveFwiKSA9PT0gLTEpIHtcbiAgICAgIGF3YWl0IGJyb3dzZXIud2luZG93cy5yZW1vdmUoY3VycmVudFBvcHVwLndpbmRvd0lkKTtcbiAgICB9XG4gIH1cbn0pO1xuXG4vKipcbiAqIENsb3NlIHBvcHVwIGlmIHRoZSBhdWRpdGVkIHRhYiBpcyBjbG9zZWQuXG4gKi9cbmJyb3dzZXIudGFicy5vblJlbW92ZWQuYWRkTGlzdGVuZXIoYXN5bmMgdGFiSWQgPT4ge1xuICBhd2FpdCBsb2FkUG9wdXBzTWFwKCk7XG4gIGNvbnN0IGN1cnJlbnRQb3B1cCA9IG15UG9wdXBzLmdldCh0YWJJZCkuZ2V0T3IodW5kZWZpbmVkKTtcbiAgaWYgKGN1cnJlbnRQb3B1cD8ud2luZG93SWQpIHtcbiAgICAvLyBDbG9zZSB0aGUgcG9wdXAgaWYgdGhlIHRhYiBpcyBjbG9zZWRcbiAgICBhd2FpdCBicm93c2VyLndpbmRvd3MucmVtb3ZlKGN1cnJlbnRQb3B1cC53aW5kb3dJZCk7XG4gIH1cbn0pO1xuXG4vKipcbiAqIE9wZW4gcG9wdXAgd2hlbiBpY29uIGlzIGNsaWNrZWQuXG4gKiBJZiB0aGUgcG9wdXAgaXMgb3BlbiwgY2xvc2UgaXQuXG4gKi9cbmJyb3dzZXIuYWN0aW9uLm9uQ2xpY2tlZC5hZGRMaXN0ZW5lcihhc3luYyB0YWIgPT4ge1xuICAvLyBCYWlsIG91dCBpbW1lZGlhdGVseSBpZiB3ZSBjYW5ub3QgZ2V0IGEgdGFiSWRcbiAgaWYgKCF0YWIuaWQpIHtcbiAgICByZXR1cm47XG4gIH1cbiAgYXdhaXQgbG9hZFBvcHVwc01hcCgpO1xuICBhd2FpdCBjbGVhblBvcHVwc01hcCgpO1xuXG4gIC8vIElmIHRoZSBjdXJyZW50IHRhYiBhbHJlYWR5IGhhcyBhbiBleHRlbnNpb24gcG9wdXAsIGNsb3NlIHRoZSBwb3B1cC5cbiAgY29uc3QgY3VycmVudFBvcHVwID0gbXlQb3B1cHMuZ2V0KHRhYi5pZCkuZ2V0T3IodW5kZWZpbmVkKTtcbiAgaWYgKGN1cnJlbnRQb3B1cD8ud2luZG93SWQpIHtcbiAgICBhd2FpdCBicm93c2VyLndpbmRvd3MucmVtb3ZlKGN1cnJlbnRQb3B1cC53aW5kb3dJZCk7XG4gICAgcmV0dXJuO1xuICB9XG5cbiAgLy8gT3RoZXJ3aXNlLCBvcGVuIGEgbmV3IHBvcHVwLlxuICBjb25zdCBwb3B1cFVybCA9IG5ldyBVUkwoYnJvd3Nlci5ydW50aW1lLmdldFVSTChcImFwcC5odG1sXCIpKTtcblxuICAvKipcbiAgICogUGFzcyBhbG9uZyB0aGUgdGFiIElEIGFzIGEgcXVlcnkgcGFyYW1ldGVyLiBUaGUgYXBwbGljYXRpb24gY29kZSB1c2VzIHRoaXNcbiAgICogd2hlbiBtYWtpbmcgQVBJIGNhbGxzLlxuICAgKi9cbiAgcG9wdXBVcmwuc2VhcmNoUGFyYW1zLnNldChcInRhYklkXCIsIHRhYi5pZD8udG9TdHJpbmcoMTApIHx8IFwiXCIpO1xuICBjb25zdCBwb3B1cCA9IGF3YWl0IGJyb3dzZXIud2luZG93cy5jcmVhdGUoe1xuICAgIHVybDogcG9wdXBVcmwudG9TdHJpbmcoKSxcbiAgICB0eXBlOiBcInBhbmVsXCIsXG4gICAgaGVpZ2h0OiA2MDAsXG4gICAgd2lkdGg6IDgwMFxuICB9KTtcbiAgbXlQb3B1cHMgPSBteVBvcHVwcy5zZXQodGFiLmlkLCB7XG4gICAgd2luZG93SWQ6IHBvcHVwLmlkLFxuICAgIHVybDogdGFiLnVybFxuICB9KTtcbiAgYXdhaXQgc2F2ZVBvcHVwc01hcCgpO1xufSk7Il0sIm5hbWVzIjpbXSwic291cmNlUm9vdCI6IiJ9