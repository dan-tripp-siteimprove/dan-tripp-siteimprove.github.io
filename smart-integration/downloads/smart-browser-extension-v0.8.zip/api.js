(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define([], factory);
	else {
		var a = factory();
		for(var i in a) (typeof exports === 'object' ? exports : root)[i] = a[i];
	}
})(self, () => {
return /******/ (() => { // webpackBootstrap
/******/ 	var __webpack_modules__ = ({

/***/ "./node_modules/webextension-polyfill/dist/browser-polyfill.js":
/*!*********************************************************************!*\
  !*** ./node_modules/webextension-polyfill/dist/browser-polyfill.js ***!
  \*********************************************************************/
/***/ (function(module, exports) {

var __WEBPACK_AMD_DEFINE_FACTORY__, __WEBPACK_AMD_DEFINE_ARRAY__, __WEBPACK_AMD_DEFINE_RESULT__;(function (global, factory) {
  if (true) {
    !(__WEBPACK_AMD_DEFINE_ARRAY__ = [module], __WEBPACK_AMD_DEFINE_FACTORY__ = (factory),
		__WEBPACK_AMD_DEFINE_RESULT__ = (typeof __WEBPACK_AMD_DEFINE_FACTORY__ === 'function' ?
		(__WEBPACK_AMD_DEFINE_FACTORY__.apply(exports, __WEBPACK_AMD_DEFINE_ARRAY__)) : __WEBPACK_AMD_DEFINE_FACTORY__),
		__WEBPACK_AMD_DEFINE_RESULT__ !== undefined && (module.exports = __WEBPACK_AMD_DEFINE_RESULT__));
  } else { var mod; }
})(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : this, function (module) {
  /* webextension-polyfill - v0.10.0 - Fri Aug 12 2022 19:42:44 */

  /* -*- Mode: indent-tabs-mode: nil; js-indent-level: 2 -*- */

  /* vim: set sts=2 sw=2 et tw=80: */

  /* This Source Code Form is subject to the terms of the Mozilla Public
   * License, v. 2.0. If a copy of the MPL was not distributed with this
   * file, You can obtain one at http://mozilla.org/MPL/2.0/. */
  "use strict";

  if (!globalThis.chrome?.runtime?.id) {
    throw new Error("This script should only be loaded in a browser extension.");
  }

  if (typeof globalThis.browser === "undefined" || Object.getPrototypeOf(globalThis.browser) !== Object.prototype) {
    const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received."; // Wrapping the bulk of this polyfill in a one-time-use function is a minor
    // optimization for Firefox. Since Spidermonkey does not fully parse the
    // contents of a function until the first time it's called, and since it will
    // never actually need to be called, this allows the polyfill to be included
    // in Firefox nearly for free.

    const wrapAPIs = extensionAPIs => {
      // NOTE: apiMetadata is associated to the content of the api-metadata.json file
      // at build time by replacing the following "include" with the content of the
      // JSON file.
      const apiMetadata = {
        "alarms": {
          "clear": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "clearAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "get": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "bookmarks": {
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getChildren": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getRecent": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getSubTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTree": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeTree": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "browserAction": {
          "disable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "enable": {
            "minArgs": 0,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "getBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getBadgeText": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "openPopup": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setBadgeBackgroundColor": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setBadgeText": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "browsingData": {
          "remove": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "removeCache": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCookies": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeDownloads": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFormData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeHistory": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeLocalStorage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePasswords": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removePluginData": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "settings": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "commands": {
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "contextMenus": {
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "cookies": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAllCookieStores": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "set": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "devtools": {
          "inspectedWindow": {
            "eval": {
              "minArgs": 1,
              "maxArgs": 2,
              "singleCallbackArg": false
            }
          },
          "panels": {
            "create": {
              "minArgs": 3,
              "maxArgs": 3,
              "singleCallbackArg": true
            },
            "elements": {
              "createSidebarPane": {
                "minArgs": 1,
                "maxArgs": 1
              }
            }
          }
        },
        "downloads": {
          "cancel": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "download": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "erase": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFileIcon": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "open": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "pause": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeFile": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "resume": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "extension": {
          "isAllowedFileSchemeAccess": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "isAllowedIncognitoAccess": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "history": {
          "addUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "deleteRange": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "deleteUrl": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getVisits": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "search": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "i18n": {
          "detectLanguage": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAcceptLanguages": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "identity": {
          "launchWebAuthFlow": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "idle": {
          "queryState": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "management": {
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getSelf": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "setEnabled": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "uninstallSelf": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "notifications": {
          "clear": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPermissionLevel": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        },
        "pageAction": {
          "getPopup": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getTitle": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "hide": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setIcon": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "setPopup": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "setTitle": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          },
          "show": {
            "minArgs": 1,
            "maxArgs": 1,
            "fallbackToNoCallback": true
          }
        },
        "permissions": {
          "contains": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "request": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "runtime": {
          "getBackgroundPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getPlatformInfo": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "openOptionsPage": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "requestUpdateCheck": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "sendMessage": {
            "minArgs": 1,
            "maxArgs": 3
          },
          "sendNativeMessage": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "setUninstallURL": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "sessions": {
          "getDevices": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getRecentlyClosed": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "restore": {
            "minArgs": 0,
            "maxArgs": 1
          }
        },
        "storage": {
          "local": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          },
          "managed": {
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            }
          },
          "sync": {
            "clear": {
              "minArgs": 0,
              "maxArgs": 0
            },
            "get": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "getBytesInUse": {
              "minArgs": 0,
              "maxArgs": 1
            },
            "remove": {
              "minArgs": 1,
              "maxArgs": 1
            },
            "set": {
              "minArgs": 1,
              "maxArgs": 1
            }
          }
        },
        "tabs": {
          "captureVisibleTab": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "create": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "detectLanguage": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "discard": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "duplicate": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "executeScript": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 0
          },
          "getZoom": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getZoomSettings": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goBack": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "goForward": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "highlight": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "insertCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "move": {
            "minArgs": 2,
            "maxArgs": 2
          },
          "query": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "reload": {
            "minArgs": 0,
            "maxArgs": 2
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "removeCSS": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "sendMessage": {
            "minArgs": 2,
            "maxArgs": 3
          },
          "setZoom": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "setZoomSettings": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "update": {
            "minArgs": 1,
            "maxArgs": 2
          }
        },
        "topSites": {
          "get": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "webNavigation": {
          "getAllFrames": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "getFrame": {
            "minArgs": 1,
            "maxArgs": 1
          }
        },
        "webRequest": {
          "handlerBehaviorChanged": {
            "minArgs": 0,
            "maxArgs": 0
          }
        },
        "windows": {
          "create": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "get": {
            "minArgs": 1,
            "maxArgs": 2
          },
          "getAll": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getCurrent": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "getLastFocused": {
            "minArgs": 0,
            "maxArgs": 1
          },
          "remove": {
            "minArgs": 1,
            "maxArgs": 1
          },
          "update": {
            "minArgs": 2,
            "maxArgs": 2
          }
        }
      };

      if (Object.keys(apiMetadata).length === 0) {
        throw new Error("api-metadata.json has not been included in browser-polyfill");
      }
      /**
       * A WeakMap subclass which creates and stores a value for any key which does
       * not exist when accessed, but behaves exactly as an ordinary WeakMap
       * otherwise.
       *
       * @param {function} createItem
       *        A function which will be called in order to create the value for any
       *        key which does not exist, the first time it is accessed. The
       *        function receives, as its only argument, the key being created.
       */


      class DefaultWeakMap extends WeakMap {
        constructor(createItem, items = undefined) {
          super(items);
          this.createItem = createItem;
        }

        get(key) {
          if (!this.has(key)) {
            this.set(key, this.createItem(key));
          }

          return super.get(key);
        }

      }
      /**
       * Returns true if the given object is an object with a `then` method, and can
       * therefore be assumed to behave as a Promise.
       *
       * @param {*} value The value to test.
       * @returns {boolean} True if the value is thenable.
       */


      const isThenable = value => {
        return value && typeof value === "object" && typeof value.then === "function";
      };
      /**
       * Creates and returns a function which, when called, will resolve or reject
       * the given promise based on how it is called:
       *
       * - If, when called, `chrome.runtime.lastError` contains a non-null object,
       *   the promise is rejected with that value.
       * - If the function is called with exactly one argument, the promise is
       *   resolved to that value.
       * - Otherwise, the promise is resolved to an array containing all of the
       *   function's arguments.
       *
       * @param {object} promise
       *        An object containing the resolution and rejection functions of a
       *        promise.
       * @param {function} promise.resolve
       *        The promise's resolution function.
       * @param {function} promise.reject
       *        The promise's rejection function.
       * @param {object} metadata
       *        Metadata about the wrapped method which has created the callback.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function}
       *        The generated callback function.
       */


      const makeCallback = (promise, metadata) => {
        return (...callbackArgs) => {
          if (extensionAPIs.runtime.lastError) {
            promise.reject(new Error(extensionAPIs.runtime.lastError.message));
          } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
            promise.resolve(callbackArgs[0]);
          } else {
            promise.resolve(callbackArgs);
          }
        };
      };

      const pluralizeArguments = numArgs => numArgs == 1 ? "argument" : "arguments";
      /**
       * Creates a wrapper function for a method with the given name and metadata.
       *
       * @param {string} name
       *        The name of the method which is being wrapped.
       * @param {object} metadata
       *        Metadata about the method being wrapped.
       * @param {integer} metadata.minArgs
       *        The minimum number of arguments which must be passed to the
       *        function. If called with fewer than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {integer} metadata.maxArgs
       *        The maximum number of arguments which may be passed to the
       *        function. If called with more than this number of arguments, the
       *        wrapper will raise an exception.
       * @param {boolean} metadata.singleCallbackArg
       *        Whether or not the promise is resolved with only the first
       *        argument of the callback, alternatively an array of all the
       *        callback arguments is resolved. By default, if the callback
       *        function is invoked with only a single argument, that will be
       *        resolved to the promise, while all arguments will be resolved as
       *        an array if multiple are given.
       *
       * @returns {function(object, ...*)}
       *       The generated wrapper function.
       */


      const wrapAsyncFunction = (name, metadata) => {
        return function asyncFunctionWrapper(target, ...args) {
          if (args.length < metadata.minArgs) {
            throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
          }

          if (args.length > metadata.maxArgs) {
            throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
          }

          return new Promise((resolve, reject) => {
            if (metadata.fallbackToNoCallback) {
              // This API method has currently no callback on Chrome, but it return a promise on Firefox,
              // and so the polyfill will try to call it with a callback first, and it will fallback
              // to not passing the callback if the first call fails.
              try {
                target[name](...args, makeCallback({
                  resolve,
                  reject
                }, metadata));
              } catch (cbError) {
                console.warn(`${name} API method doesn't seem to support the callback parameter, ` + "falling back to call it without a callback: ", cbError);
                target[name](...args); // Update the API method metadata, so that the next API calls will not try to
                // use the unsupported callback anymore.

                metadata.fallbackToNoCallback = false;
                metadata.noCallback = true;
                resolve();
              }
            } else if (metadata.noCallback) {
              target[name](...args);
              resolve();
            } else {
              target[name](...args, makeCallback({
                resolve,
                reject
              }, metadata));
            }
          });
        };
      };
      /**
       * Wraps an existing method of the target object, so that calls to it are
       * intercepted by the given wrapper function. The wrapper function receives,
       * as its first argument, the original `target` object, followed by each of
       * the arguments passed to the original method.
       *
       * @param {object} target
       *        The original target object that the wrapped method belongs to.
       * @param {function} method
       *        The method being wrapped. This is used as the target of the Proxy
       *        object which is created to wrap the method.
       * @param {function} wrapper
       *        The wrapper function which is called in place of a direct invocation
       *        of the wrapped method.
       *
       * @returns {Proxy<function>}
       *        A Proxy object for the given method, which invokes the given wrapper
       *        method in its place.
       */


      const wrapMethod = (target, method, wrapper) => {
        return new Proxy(method, {
          apply(targetMethod, thisObj, args) {
            return wrapper.call(thisObj, target, ...args);
          }

        });
      };

      let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
      /**
       * Wraps an object in a Proxy which intercepts and wraps certain methods
       * based on the given `wrappers` and `metadata` objects.
       *
       * @param {object} target
       *        The target object to wrap.
       *
       * @param {object} [wrappers = {}]
       *        An object tree containing wrapper functions for special cases. Any
       *        function present in this object tree is called in place of the
       *        method in the same location in the `target` object tree. These
       *        wrapper methods are invoked as described in {@see wrapMethod}.
       *
       * @param {object} [metadata = {}]
       *        An object tree containing metadata used to automatically generate
       *        Promise-based wrapper functions for asynchronous. Any function in
       *        the `target` object tree which has a corresponding metadata object
       *        in the same location in the `metadata` tree is replaced with an
       *        automatically-generated wrapper function, as described in
       *        {@see wrapAsyncFunction}
       *
       * @returns {Proxy<object>}
       */

      const wrapObject = (target, wrappers = {}, metadata = {}) => {
        let cache = Object.create(null);
        let handlers = {
          has(proxyTarget, prop) {
            return prop in target || prop in cache;
          },

          get(proxyTarget, prop, receiver) {
            if (prop in cache) {
              return cache[prop];
            }

            if (!(prop in target)) {
              return undefined;
            }

            let value = target[prop];

            if (typeof value === "function") {
              // This is a method on the underlying object. Check if we need to do
              // any wrapping.
              if (typeof wrappers[prop] === "function") {
                // We have a special-case wrapper for this method.
                value = wrapMethod(target, target[prop], wrappers[prop]);
              } else if (hasOwnProperty(metadata, prop)) {
                // This is an async method that we have metadata for. Create a
                // Promise wrapper for it.
                let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                value = wrapMethod(target, target[prop], wrapper);
              } else {
                // This is a method that we don't know or care about. Return the
                // original method, bound to the underlying object.
                value = value.bind(target);
              }
            } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
              // This is an object that we need to do some wrapping for the children
              // of. Create a sub-object wrapper for it with the appropriate child
              // metadata.
              value = wrapObject(value, wrappers[prop], metadata[prop]);
            } else if (hasOwnProperty(metadata, "*")) {
              // Wrap all properties in * namespace.
              value = wrapObject(value, wrappers[prop], metadata["*"]);
            } else {
              // We don't need to do any wrapping for this property,
              // so just forward all access to the underlying object.
              Object.defineProperty(cache, prop, {
                configurable: true,
                enumerable: true,

                get() {
                  return target[prop];
                },

                set(value) {
                  target[prop] = value;
                }

              });
              return value;
            }

            cache[prop] = value;
            return value;
          },

          set(proxyTarget, prop, value, receiver) {
            if (prop in cache) {
              cache[prop] = value;
            } else {
              target[prop] = value;
            }

            return true;
          },

          defineProperty(proxyTarget, prop, desc) {
            return Reflect.defineProperty(cache, prop, desc);
          },

          deleteProperty(proxyTarget, prop) {
            return Reflect.deleteProperty(cache, prop);
          }

        }; // Per contract of the Proxy API, the "get" proxy handler must return the
        // original value of the target if that value is declared read-only and
        // non-configurable. For this reason, we create an object with the
        // prototype set to `target` instead of using `target` directly.
        // Otherwise we cannot return a custom object for APIs that
        // are declared read-only and non-configurable, such as `chrome.devtools`.
        //
        // The proxy handlers themselves will still use the original `target`
        // instead of the `proxyTarget`, so that the methods and properties are
        // dereferenced via the original targets.

        let proxyTarget = Object.create(target);
        return new Proxy(proxyTarget, handlers);
      };
      /**
       * Creates a set of wrapper functions for an event object, which handles
       * wrapping of listener functions that those messages are passed.
       *
       * A single wrapper is created for each listener function, and stored in a
       * map. Subsequent calls to `addListener`, `hasListener`, or `removeListener`
       * retrieve the original wrapper, so that  attempts to remove a
       * previously-added listener work as expected.
       *
       * @param {DefaultWeakMap<function, function>} wrapperMap
       *        A DefaultWeakMap object which will create the appropriate wrapper
       *        for a given listener function when one does not exist, and retrieve
       *        an existing one when it does.
       *
       * @returns {object}
       */


      const wrapEvent = wrapperMap => ({
        addListener(target, listener, ...args) {
          target.addListener(wrapperMap.get(listener), ...args);
        },

        hasListener(target, listener) {
          return target.hasListener(wrapperMap.get(listener));
        },

        removeListener(target, listener) {
          target.removeListener(wrapperMap.get(listener));
        }

      });

      const onRequestFinishedWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }
        /**
         * Wraps an onRequestFinished listener function so that it will return a
         * `getContent()` property which returns a `Promise` rather than using a
         * callback API.
         *
         * @param {object} req
         *        The HAR entry object representing the network request.
         */


        return function onRequestFinished(req) {
          const wrappedReq = wrapObject(req, {}
          /* wrappers */
          , {
            getContent: {
              minArgs: 0,
              maxArgs: 0
            }
          });
          listener(wrappedReq);
        };
      });
      const onMessageWrappers = new DefaultWeakMap(listener => {
        if (typeof listener !== "function") {
          return listener;
        }
        /**
         * Wraps a message listener function so that it may send responses based on
         * its return value, rather than by returning a sentinel value and calling a
         * callback. If the listener function returns a Promise, the response is
         * sent when the promise either resolves or rejects.
         *
         * @param {*} message
         *        The message sent by the other end of the channel.
         * @param {object} sender
         *        Details about the sender of the message.
         * @param {function(*)} sendResponse
         *        A callback which, when called with an arbitrary argument, sends
         *        that value as a response.
         * @returns {boolean}
         *        True if the wrapped listener returned a Promise, which will later
         *        yield a response. False otherwise.
         */


        return function onMessage(message, sender, sendResponse) {
          let didCallSendResponse = false;
          let wrappedSendResponse;
          let sendResponsePromise = new Promise(resolve => {
            wrappedSendResponse = function (response) {
              didCallSendResponse = true;
              resolve(response);
            };
          });
          let result;

          try {
            result = listener(message, sender, wrappedSendResponse);
          } catch (err) {
            result = Promise.reject(err);
          }

          const isResultThenable = result !== true && isThenable(result); // If the listener didn't returned true or a Promise, or called
          // wrappedSendResponse synchronously, we can exit earlier
          // because there will be no response sent from this listener.

          if (result !== true && !isResultThenable && !didCallSendResponse) {
            return false;
          } // A small helper to send the message if the promise resolves
          // and an error if the promise rejects (a wrapped sendMessage has
          // to translate the message into a resolved promise or a rejected
          // promise).


          const sendPromisedResult = promise => {
            promise.then(msg => {
              // send the message value.
              sendResponse(msg);
            }, error => {
              // Send a JSON representation of the error if the rejected value
              // is an instance of error, or the object itself otherwise.
              let message;

              if (error && (error instanceof Error || typeof error.message === "string")) {
                message = error.message;
              } else {
                message = "An unexpected error occurred";
              }

              sendResponse({
                __mozWebExtensionPolyfillReject__: true,
                message
              });
            }).catch(err => {
              // Print an error on the console if unable to send the response.
              console.error("Failed to send onMessage rejected reply", err);
            });
          }; // If the listener returned a Promise, send the resolved value as a
          // result, otherwise wait the promise related to the wrappedSendResponse
          // callback to resolve and send it as a response.


          if (isResultThenable) {
            sendPromisedResult(result);
          } else {
            sendPromisedResult(sendResponsePromise);
          } // Let Chrome know that the listener is replying.


          return true;
        };
      });

      const wrappedSendMessageCallback = ({
        reject,
        resolve
      }, reply) => {
        if (extensionAPIs.runtime.lastError) {
          // Detect when none of the listeners replied to the sendMessage call and resolve
          // the promise to undefined as in Firefox.
          // See https://github.com/mozilla/webextension-polyfill/issues/130
          if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
            resolve();
          } else {
            reject(new Error(extensionAPIs.runtime.lastError.message));
          }
        } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
          // Convert back the JSON representation of the error into
          // an Error instance.
          reject(new Error(reply.message));
        } else {
          resolve(reply);
        }
      };

      const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
        if (args.length < metadata.minArgs) {
          throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
        }

        if (args.length > metadata.maxArgs) {
          throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
        }

        return new Promise((resolve, reject) => {
          const wrappedCb = wrappedSendMessageCallback.bind(null, {
            resolve,
            reject
          });
          args.push(wrappedCb);
          apiNamespaceObj.sendMessage(...args);
        });
      };

      const staticWrappers = {
        devtools: {
          network: {
            onRequestFinished: wrapEvent(onRequestFinishedWrappers)
          }
        },
        runtime: {
          onMessage: wrapEvent(onMessageWrappers),
          onMessageExternal: wrapEvent(onMessageWrappers),
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 1,
            maxArgs: 3
          })
        },
        tabs: {
          sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
            minArgs: 2,
            maxArgs: 3
          })
        }
      };
      const settingMetadata = {
        clear: {
          minArgs: 1,
          maxArgs: 1
        },
        get: {
          minArgs: 1,
          maxArgs: 1
        },
        set: {
          minArgs: 1,
          maxArgs: 1
        }
      };
      apiMetadata.privacy = {
        network: {
          "*": settingMetadata
        },
        services: {
          "*": settingMetadata
        },
        websites: {
          "*": settingMetadata
        }
      };
      return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
    }; // The build process adds a UMD wrapper around this file, which makes the
    // `module` variable available.


    module.exports = wrapAPIs(chrome);
  } else {
    module.exports = globalThis.browser;
  }
});
//# sourceMappingURL=browser-polyfill.js.map


/***/ }),

/***/ "./node_modules/@siteimprove/alfa-array/dist/array.js":
/*!************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-array/dist/array.js ***!
  \************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Array: () => (/* binding */ Array)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_clone__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-clone */ "./node_modules/@siteimprove/alfa-clone/dist/index.js");
/* harmony import */ var _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @siteimprove/alfa-comparable */ "./node_modules/@siteimprove/alfa-comparable/dist/index.js");
/* harmony import */ var _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @siteimprove/alfa-equatable */ "./node_modules/@siteimprove/alfa-equatable/dist/index.js");
/* harmony import */ var _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @siteimprove/alfa-iterable */ "./node_modules/@siteimprove/alfa-iterable/dist/index.js");
/* harmony import */ var _siteimprove_alfa_json__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @siteimprove/alfa-json */ "./node_modules/@siteimprove/alfa-json/dist/index.js");
/* harmony import */ var _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @siteimprove/alfa-option */ "./node_modules/@siteimprove/alfa-option/dist/index.js");
/* harmony import */ var _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! @siteimprove/alfa-predicate */ "./node_modules/@siteimprove/alfa-predicate/dist/index.js");
/* harmony import */ var _builtin_js__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(/*! ./builtin.js */ "./node_modules/@siteimprove/alfa-array/dist/builtin.js");








const { not } = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_6__.Predicate;
const { compareComparable } = _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_1__.Comparable;
/**
 * @public
 */
var Array;
(function (Array) {
    function isArray(value) {
        return _builtin_js__WEBPACK_IMPORTED_MODULE_7__.Array.isArray(value);
    }
    Array.isArray = isArray;
    function of(...values) {
        return values;
    }
    Array.of = of;
    function empty() {
        return [];
    }
    Array.empty = empty;
    function allocate(capacity) {
        return new _builtin_js__WEBPACK_IMPORTED_MODULE_7__.Array(capacity);
    }
    Array.allocate = allocate;
    /**
     * @remarks
     * Unlike the built-in function of the same name, this function will pass
     * along existing arrays as-is instead of returning a copy.
     */
    function from(iterable) {
        if (isArray(iterable)) {
            return iterable;
        }
        return [...iterable];
    }
    Array.from = from;
    function size(array) {
        return array.length;
    }
    Array.size = size;
    function isEmpty(array) {
        return array.length === 0;
    }
    Array.isEmpty = isEmpty;
    function copy(array) {
        return array.slice(0);
    }
    Array.copy = copy;
    function clone(array) {
        return array.map(_siteimprove_alfa_clone__WEBPACK_IMPORTED_MODULE_0__.Clone.clone);
    }
    Array.clone = clone;
    function forEach(array, callback) {
        for (let i = 0, n = array.length; i < n; i++) {
            callback(array[i], i);
        }
    }
    Array.forEach = forEach;
    function map(array, mapper) {
        const result = new _builtin_js__WEBPACK_IMPORTED_MODULE_7__.Array(array.length);
        for (let i = 0, n = array.length; i < n; i++) {
            result[i] = mapper(array[i], i);
        }
        return result;
    }
    Array.map = map;
    function flatMap(array, mapper) {
        const result = empty();
        for (let i = 0, n = array.length; i < n; i++) {
            result.push(...mapper(array[i], i));
        }
        return result;
    }
    Array.flatMap = flatMap;
    function flatten(array) {
        return flatMap(array, (array) => array);
    }
    Array.flatten = flatten;
    function reduce(array, reducer, accumulator) {
        for (let i = 0, n = array.length; i < n; i++) {
            accumulator = reducer(accumulator, array[i], i);
        }
        return accumulator;
    }
    Array.reduce = reduce;
    function reduceWhile(array, predicate, reducer, accumulator) {
        for (let i = 0, n = array.length; i < n; i++) {
            const value = array[i];
            if (predicate(value, i)) {
                accumulator = reducer(accumulator, value, i);
            }
            else {
                break;
            }
        }
        return accumulator;
    }
    Array.reduceWhile = reduceWhile;
    function reduceUntil(array, predicate, reducer, accumulator) {
        return reduceWhile(array, not(predicate), reducer, accumulator);
    }
    Array.reduceUntil = reduceUntil;
    function apply(array, mapper) {
        return flatMap(mapper, (mapper) => map(array, mapper));
    }
    Array.apply = apply;
    function filter(array, predicate) {
        const result = empty();
        for (let i = 0, n = array.length; i < n; i++) {
            const value = array[i];
            if (predicate(value, i)) {
                result.push(value);
            }
        }
        return result;
    }
    Array.filter = filter;
    function reject(array, predicate) {
        return filter(array, not(predicate));
    }
    Array.reject = reject;
    function find(array, predicate) {
        for (let i = 0, n = array.length; i < n; i++) {
            const value = array[i];
            if (predicate(value, i)) {
                return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__.Option.of(value);
            }
        }
        return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__.None;
    }
    Array.find = find;
    function findLast(array, predicate) {
        for (let i = array.length - 1; i >= 0; i--) {
            const value = array[i];
            if (predicate(value, i)) {
                return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__.Option.of(value);
            }
        }
        return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__.None;
    }
    Array.findLast = findLast;
    function includes(array, value) {
        return some(array, _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_6__.Predicate.equals(value));
    }
    Array.includes = includes;
    function collect(array, mapper) {
        const result = empty();
        for (let i = 0, n = array.length; i < n; i++) {
            for (const value of mapper(array[i], i)) {
                result.push(value);
            }
        }
        return result;
    }
    Array.collect = collect;
    function collectFirst(array, mapper) {
        for (let i = 0, n = array.length; i < n; i++) {
            const value = mapper(array[i], i);
            if (value.isSome()) {
                return value;
            }
        }
        return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__.None;
    }
    Array.collectFirst = collectFirst;
    function some(array, predicate) {
        for (let i = 0, n = array.length; i < n; i++) {
            if (predicate(array[i], i)) {
                return true;
            }
        }
        return false;
    }
    Array.some = some;
    function none(array, predicate) {
        return every(array, not(predicate));
    }
    Array.none = none;
    function every(array, predicate) {
        for (let i = 0, n = array.length; i < n; i++) {
            if (!predicate(array[i], i)) {
                return false;
            }
        }
        return true;
    }
    Array.every = every;
    function count(array, predicate) {
        return reduce(array, (count, value, index) => (predicate(value, index) ? count + 1 : count), 0);
    }
    Array.count = count;
    function distinct(array) {
        const result = empty();
        for (let i = 0, n = array.length; i < n; i++) {
            const value = array[i];
            if (result.some(_siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_6__.Predicate.equals(value))) {
                continue;
            }
            result.push(value);
        }
        return result;
    }
    Array.distinct = distinct;
    function get(array, index) {
        return index < array.length ? _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__.Option.of(array[index]) : _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__.None;
    }
    Array.get = get;
    function has(array, index) {
        return index < array.length;
    }
    Array.has = has;
    function set(array, index, value) {
        if (index < array.length) {
            array[index] = value;
        }
        return array;
    }
    Array.set = set;
    function insert(array, index, value) {
        if (index <= array.length) {
            array.splice(index, 0, value);
        }
        return array;
    }
    Array.insert = insert;
    function append(array, value) {
        array.push(value);
        return array;
    }
    Array.append = append;
    function prepend(array, value) {
        array.unshift(value);
        return array;
    }
    Array.prepend = prepend;
    function concat(array, ...iterables) {
        return [..._siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_3__.Iterable.concat(array, ...iterables)];
    }
    Array.concat = concat;
    function subtract(array, ...iterables) {
        return [..._siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_3__.Iterable.subtract(array, ...iterables)];
    }
    Array.subtract = subtract;
    function intersect(array, ...iterables) {
        return [..._siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_3__.Iterable.intersect(array, ...iterables)];
    }
    Array.intersect = intersect;
    function zip(array, iterable) {
        const result = empty();
        const it = _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_3__.Iterable.iterator(iterable);
        for (let i = 0, n = array.length; i < n; i++) {
            const next = it.next();
            if (next.done === true) {
                break;
            }
            result.push([array[i], next.value]);
        }
        return result;
    }
    Array.zip = zip;
    function first(array) {
        return array.length > 0 ? _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__.Option.of(array[0]) : _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__.None;
    }
    Array.first = first;
    function last(array) {
        return array.length > 0 ? _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__.Option.of(array[array.length - 1]) : _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_5__.None;
    }
    Array.last = last;
    function sort(array) {
        return sortWith(array, compareComparable);
    }
    Array.sort = sort;
    function sortWith(array, comparer) {
        return array.sort(comparer);
    }
    Array.sortWith = sortWith;
    function compare(a, b) {
        return compareWith(a, b, compareComparable);
    }
    Array.compare = compare;
    function compareWith(a, b, comparer) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_3__.Iterable.compareWith(a, b, comparer);
    }
    Array.compareWith = compareWith;
    function search(array, value, comparer) {
        let lower = 0;
        let upper = array.length - 1;
        while (lower <= upper) {
            const middle = (lower + (upper - lower) / 2) >>> 0;
            switch (comparer(value, array[middle])) {
                case _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_1__.Comparison.Greater:
                    lower = middle + 1;
                    break;
                case _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_1__.Comparison.Less:
                    upper = middle - 1;
                    break;
                case _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_1__.Comparison.Equal:
                    return middle;
            }
        }
        return lower;
    }
    Array.search = search;
    function equals(a, b) {
        if (a.length !== b.length) {
            return false;
        }
        for (let i = 0, n = a.length; i < n; i++) {
            if (!_siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_2__.Equatable.equals(a[i], b[i])) {
                return false;
            }
        }
        return true;
    }
    Array.equals = equals;
    function hash(array, hash) {
        for (let i = 0, n = array.length; i < n; i++) {
            hash.writeUnknown(array[i]);
        }
        hash.writeUint32(array.length);
    }
    Array.hash = hash;
    function iterator(array) {
        return array[Symbol.iterator]();
    }
    Array.iterator = iterator;
    function toJSON(array, options) {
        return array.map((value) => _siteimprove_alfa_json__WEBPACK_IMPORTED_MODULE_4__.Serializable.toJSON(value, options));
    }
    Array.toJSON = toJSON;
})(Array || (Array = {}));
//# sourceMappingURL=array.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-array/dist/builtin.js":
/*!**************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-array/dist/builtin.js ***!
  \**************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Array: () => (/* binding */ Builtin)
/* harmony export */ });
// This file defines exports from the builtin `Array` constructor for internal
// use only.
/**
 * @internal
 */
const Builtin = Array;

//# sourceMappingURL=builtin.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-array/dist/index.js":
/*!************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-array/dist/index.js ***!
  \************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Array: () => (/* reexport safe */ _array_js__WEBPACK_IMPORTED_MODULE_0__.Array)
/* harmony export */ });
/* harmony import */ var _array_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./array.js */ "./node_modules/@siteimprove/alfa-array/dist/array.js");
/**
 * This package provides functionality for working with arrays.
 *
 * @packageDocumentation
 */

//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-bits/dist/bits.js":
/*!**********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-bits/dist/bits.js ***!
  \**********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Bits: () => (/* binding */ Bits)
/* harmony export */ });
/**
 * @public
 */
var Bits;
(function (Bits) {
    function bit(i) {
        return 1 << i;
    }
    Bits.bit = bit;
    function set(bits, i) {
        return bits | bit(i);
    }
    Bits.set = set;
    function clear(bits, i) {
        return bits & ~bit(i);
    }
    Bits.clear = clear;
    function test(bits, i) {
        return (bits & bit(i)) !== 0;
    }
    Bits.test = test;
    function take(bits, n) {
        return bits & ((1 << n) - 1);
    }
    Bits.take = take;
    function skip(bits, n) {
        return bits >>> n;
    }
    Bits.skip = skip;
    /**
     * @remarks
     * This is a 32-bit variant of the 64-bit population count algorithm outlined
     * on Wikipedia. Until ECMAScript natively provides an efficient population
     * count algorithm, this is the best we can do.
     *
     * {@link https://en.wikipedia.org/wiki/Hamming_weight}
     */
    function popCount(bits) {
        bits -= (bits >> 1) & 0x55555555;
        bits = (bits & 0x33333333) + ((bits >> 2) & 0x33333333);
        bits = (bits + (bits >> 4)) & 0x0f0f0f0f;
        bits += bits >> 8;
        bits += bits >> 16;
        return bits & 0x7f;
    }
    Bits.popCount = popCount;
})(Bits || (Bits = {}));
//# sourceMappingURL=bits.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-bits/dist/index.js":
/*!***********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-bits/dist/index.js ***!
  \***********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Bits: () => (/* reexport safe */ _bits_js__WEBPACK_IMPORTED_MODULE_0__.Bits)
/* harmony export */ });
/* harmony import */ var _bits_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./bits.js */ "./node_modules/@siteimprove/alfa-bits/dist/bits.js");

//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-clone/dist/clone.js":
/*!************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-clone/dist/clone.js ***!
  \************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Clone: () => (/* binding */ Clone)
/* harmony export */ });
/**
 * @public
 */
var Clone;
(function (Clone) {
    function clone(value) {
        return value.clone();
    }
    Clone.clone = clone;
})(Clone || (Clone = {}));
//# sourceMappingURL=clone.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-clone/dist/index.js":
/*!************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-clone/dist/index.js ***!
  \************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Clone: () => (/* reexport safe */ _clone_js__WEBPACK_IMPORTED_MODULE_0__.Clone)
/* harmony export */ });
/* harmony import */ var _clone_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./clone.js */ "./node_modules/@siteimprove/alfa-clone/dist/clone.js");

//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-comparable/dist/comparable.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-comparable/dist/comparable.js ***!
  \**********************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Comparable: () => (/* binding */ Comparable)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_refinement__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-refinement */ "./node_modules/@siteimprove/alfa-refinement/dist/index.js");
/* harmony import */ var _comparison_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./comparison.js */ "./node_modules/@siteimprove/alfa-comparable/dist/comparison.js");


const { isString, isNumber, isBigInt, isBoolean, isFunction, isObject } = _siteimprove_alfa_refinement__WEBPACK_IMPORTED_MODULE_0__.Refinement;
/**
 * This namespace provides additional functions for the
 * {@link (Comparable:interface)} interface.
 *
 * @public
 */
var Comparable;
(function (Comparable) {
    /**
     * Check if an unknown value implements the {@link (Comparable:interface)}
     * interface.
     */
    function isComparable(value) {
        return isObject(value) && isFunction(value.compare);
    }
    Comparable.isComparable = isComparable;
    function compare(a, b) {
        if (isString(a)) {
            return compareString(a, b);
        }
        if (isNumber(a)) {
            return compareNumber(a, b);
        }
        if (isBigInt(a)) {
            return compareBigInt(a, b);
        }
        if (isBoolean(a)) {
            return compareBoolean(a, b);
        }
        return compareComparable(a, b);
    }
    Comparable.compare = compare;
    /**
     * @remarks
     * This should only be used in cases where branch mispredictions caused by the
     * more general {@link (Comparable:namespace).(compare:1)} are undesired.
     */
    function compareString(a, b) {
        return comparePrimitive(a, b);
    }
    Comparable.compareString = compareString;
    /**
     * @remarks
     * This should only be used in cases where branch mispredictions caused by the
     * more general {@link (Comparable:namespace).(compare:2)} are undesired.
     */
    function compareNumber(a, b) {
        return comparePrimitive(a, b);
    }
    Comparable.compareNumber = compareNumber;
    /**
     * @remarks
     * This should only be used in cases where branch mispredictions caused by the
     * more general {@link (Comparable:namespace).(compare:3)} are undesired.
     */
    function compareBigInt(a, b) {
        return comparePrimitive(a, b);
    }
    Comparable.compareBigInt = compareBigInt;
    /**
     * @remarks
     * This should only be used in cases where branch mispredictions caused by the
     * more general {@link (Comparable:namespace).(compare:4)} are undesired.
     */
    function compareBoolean(a, b) {
        return comparePrimitive(a, b);
    }
    Comparable.compareBoolean = compareBoolean;
    /**
     * @remarks
     * This should only be used in cases where branch mispredictions caused by the
     * more general {@link (Comparable:namespace).(compare:5)} are undesired.
     */
    function compareComparable(a, b) {
        return a.compare(b);
    }
    Comparable.compareComparable = compareComparable;
    /**
     * Compare two primitive values.
     */
    function comparePrimitive(a, b) {
        if (a < b) {
            return _comparison_js__WEBPACK_IMPORTED_MODULE_1__.Comparison.Less;
        }
        if (a > b) {
            return _comparison_js__WEBPACK_IMPORTED_MODULE_1__.Comparison.Greater;
        }
        return _comparison_js__WEBPACK_IMPORTED_MODULE_1__.Comparison.Equal;
    }
    /**
     * Compare tuples lexicographically
     *
     * {@link https://en.wikipedia.org/wiki/Lexicographic_order}
     */
    function compareLexicographically(a, b, comparer) {
        for (let i = 0; i < a.length; i++) {
            const comparison = comparer[i](a[i], b[i]);
            if (comparison === _comparison_js__WEBPACK_IMPORTED_MODULE_1__.Comparison.Equal) {
                continue;
            }
            return comparison;
        }
        return _comparison_js__WEBPACK_IMPORTED_MODULE_1__.Comparison.Equal;
    }
    Comparable.compareLexicographically = compareLexicographically;
    /**
     * Check if one value is less than another.
     */
    function isLessThan(a, b) {
        return a.compare(b) < 0;
    }
    Comparable.isLessThan = isLessThan;
    /**
     * Check if one value is less than or equal to another.
     */
    function isLessThanOrEqual(a, b) {
        return a.compare(b) <= 0;
    }
    Comparable.isLessThanOrEqual = isLessThanOrEqual;
    /**
     * Check if one value is equal to another
     */
    function isEqual(a, b) {
        return a.compare(b) === 0;
    }
    Comparable.isEqual = isEqual;
    /**
     * Check if one value is greater than another.
     */
    function isGreaterThan(a, b) {
        return a.compare(b) > 0;
    }
    Comparable.isGreaterThan = isGreaterThan;
    /**
     * Check if one value is greater than or equal to another.
     */
    function isGreaterThanOrEqual(a, b) {
        return a.compare(b) >= 0;
    }
    Comparable.isGreaterThanOrEqual = isGreaterThanOrEqual;
})(Comparable || (Comparable = {}));
//# sourceMappingURL=comparable.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-comparable/dist/comparer.js":
/*!********************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-comparable/dist/comparer.js ***!
  \********************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);

//# sourceMappingURL=comparer.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-comparable/dist/comparison.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-comparable/dist/comparison.js ***!
  \**********************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Comparison: () => (/* binding */ Comparison)
/* harmony export */ });
/**
 * @remarks
 * Comparisons are limited to the range [-1, 1] in order to avoid the potential
 * of over-/underflows when comparisons are implemented naively using
 * subtractions, such `a - b`; this would not be allowed.
 *
 * @public
 */
var Comparison;
(function (Comparison) {
    Comparison[Comparison["Less"] = -1] = "Less";
    Comparison[Comparison["Equal"] = 0] = "Equal";
    Comparison[Comparison["Greater"] = 1] = "Greater";
})(Comparison || (Comparison = {}));
//# sourceMappingURL=comparison.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-comparable/dist/index.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-comparable/dist/index.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Comparable: () => (/* reexport safe */ _comparable_js__WEBPACK_IMPORTED_MODULE_0__.Comparable),
/* harmony export */   Comparison: () => (/* reexport safe */ _comparison_js__WEBPACK_IMPORTED_MODULE_2__.Comparison)
/* harmony export */ });
/* harmony import */ var _comparable_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./comparable.js */ "./node_modules/@siteimprove/alfa-comparable/dist/comparable.js");
/* harmony import */ var _comparer_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./comparer.js */ "./node_modules/@siteimprove/alfa-comparable/dist/comparer.js");
/* harmony import */ var _comparison_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./comparison.js */ "./node_modules/@siteimprove/alfa-comparable/dist/comparison.js");



//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-encoding/dist/decoder.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-encoding/dist/decoder.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Decoder: () => (/* binding */ Decoder)
/* harmony export */ });
/**
 * {@link https://encoding.spec.whatwg.org/#textdecoder}
 *
 * @public
 */
var Decoder;
(function (Decoder) {
    /**
     * {@link https://encoding.spec.whatwg.org/#dom-textdecoder-decode}
     * {@link https://encoding.spec.whatwg.org/#utf-8-decoder}
     */
    function decode(input) {
        let output = "";
        let i = 0;
        while (i < input.length) {
            let byte = input[i];
            let bytesNeeded = 0;
            let codePoint = 0;
            if (byte <= 0x7f) {
                bytesNeeded = 0;
                codePoint = byte & 0xff;
            }
            else if (byte <= 0xdf) {
                bytesNeeded = 1;
                codePoint = byte & 0x1f;
            }
            else if (byte <= 0xef) {
                bytesNeeded = 2;
                codePoint = byte & 0x0f;
            }
            else if (byte <= 0xf4) {
                bytesNeeded = 3;
                codePoint = byte & 0x07;
            }
            if (input.length - i - bytesNeeded > 0) {
                let k = 0;
                while (k < bytesNeeded) {
                    byte = input[i + k + 1];
                    codePoint = (codePoint << 6) | (byte & 0x3f);
                    k += 1;
                }
            }
            else {
                codePoint = 0xfffd;
                bytesNeeded = input.length - i;
            }
            output += String.fromCodePoint(codePoint);
            i += bytesNeeded + 1;
        }
        return output;
    }
    Decoder.decode = decode;
})(Decoder || (Decoder = {}));
//# sourceMappingURL=decoder.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-encoding/dist/encoder.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-encoding/dist/encoder.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Encoder: () => (/* binding */ Encoder)
/* harmony export */ });
/**
 * {@link https://encoding.spec.whatwg.org/#textencoder}
 *
 * @public
 */
var Encoder;
(function (Encoder) {
    /**
     * {@link https://encoding.spec.whatwg.org/#dom-textencoder-encode}
     * {@link https://encoding.spec.whatwg.org/#utf-8-encoder}
     */
    function encode(input) {
        const output = [];
        const length = input.length;
        let i = 0;
        while (i < length) {
            const codePoint = input.codePointAt(i);
            let count = 0;
            let bits = 0;
            if (codePoint <= 0x7f) {
                count = 0;
                bits = 0x00;
            }
            else if (codePoint <= 0x7ff) {
                count = 6;
                bits = 0xc0;
            }
            else if (codePoint <= 0xffff) {
                count = 12;
                bits = 0xe0;
            }
            else if (codePoint <= 0x1fffff) {
                count = 18;
                bits = 0xf0;
            }
            output.push(bits | (codePoint >> count));
            count -= 6;
            while (count >= 0) {
                output.push(0x80 | ((codePoint >> count) & 0x3f));
                count -= 6;
            }
            i += codePoint >= 0x10000 ? 2 : 1;
        }
        return new Uint8Array(output);
    }
    Encoder.encode = encode;
})(Encoder || (Encoder = {}));
//# sourceMappingURL=encoder.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-encoding/dist/index.js":
/*!***************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-encoding/dist/index.js ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Decoder: () => (/* reexport safe */ _decoder_js__WEBPACK_IMPORTED_MODULE_0__.Decoder),
/* harmony export */   Encoder: () => (/* reexport safe */ _encoder_js__WEBPACK_IMPORTED_MODULE_1__.Encoder)
/* harmony export */ });
/* harmony import */ var _decoder_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./decoder.js */ "./node_modules/@siteimprove/alfa-encoding/dist/decoder.js");
/* harmony import */ var _encoder_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./encoder.js */ "./node_modules/@siteimprove/alfa-encoding/dist/encoder.js");


//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-equatable/dist/equatable.js":
/*!********************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-equatable/dist/equatable.js ***!
  \********************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Equatable: () => (/* binding */ Equatable)
/* harmony export */ });
/**
 * This namespace provides additional types and functions for the
 * {@link (Equatable:interface)} interface.
 *
 * @public
 */
var Equatable;
(function (Equatable) {
    // The following two type guards have been inlined from the
    // @siteimprove/alfa-refinement package to avoid creating a circular
    // dependency.
    function isFunction(value) {
        return typeof value === "function";
    }
    function isObject(value) {
        return typeof value === "object" && value !== null;
    }
    /**
     * Check if an unknown value implements the {@link (Equatable:interface)}
     * interface.
     */
    function isEquatable(value) {
        return isObject(value) && isFunction(value.equals);
    }
    Equatable.isEquatable = isEquatable;
    /**
     * Check if two unknown values are equal.
     *
     * @remarks
     * If either of the given values implement the {@link (Equatable:interface)}
     * interface, the equivalence constraints of the value will be used. If not,
     * strict equality will be used with the additional constraint that `NaN` is
     * equal to itself.
     */
    function equals(a, b) {
        if (a === b ||
            // `NaN` is the only value in JavaScript that is not equal to itself.
            (a !== a && b !== b)) {
            return true;
        }
        if (isEquatable(a)) {
            return a.equals(b);
        }
        if (isEquatable(b)) {
            return b.equals(a);
        }
        return false;
    }
    Equatable.equals = equals;
})(Equatable || (Equatable = {}));
//# sourceMappingURL=equatable.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-equatable/dist/index.js":
/*!****************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-equatable/dist/index.js ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Equatable: () => (/* reexport safe */ _equatable_js__WEBPACK_IMPORTED_MODULE_0__.Equatable)
/* harmony export */ });
/* harmony import */ var _equatable_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./equatable.js */ "./node_modules/@siteimprove/alfa-equatable/dist/equatable.js");

//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-fnv/dist/fnv.js":
/*!********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-fnv/dist/fnv.js ***!
  \********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FNV: () => (/* binding */ FNV)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_hash__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-hash */ "./node_modules/@siteimprove/alfa-hash/dist/index.js");

/**
 * @public
 */
class FNV extends _siteimprove_alfa_hash__WEBPACK_IMPORTED_MODULE_0__.Hash {
    static empty() {
        return new FNV();
    }
    _hash = 2166136261;
    constructor() {
        super();
    }
    finish() {
        return this._hash >>> 0; // Convert to unsigned 32-bit integer
    }
    write(data) {
        let hash = this._hash;
        for (const octet of data) {
            hash ^= octet;
            hash +=
                (hash << 1) + (hash << 4) + (hash << 7) + (hash << 8) + (hash << 24);
        }
        this._hash = hash;
        return this;
    }
    equals(value) {
        return value instanceof FNV && value._hash === this._hash;
    }
}
//# sourceMappingURL=fnv.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-fnv/dist/index.js":
/*!**********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-fnv/dist/index.js ***!
  \**********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   FNV: () => (/* reexport safe */ _fnv_js__WEBPACK_IMPORTED_MODULE_0__.FNV)
/* harmony export */ });
/* harmony import */ var _fnv_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./fnv.js */ "./node_modules/@siteimprove/alfa-fnv/dist/fnv.js");

//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-hash/dist/hash.js":
/*!**********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-hash/dist/hash.js ***!
  \**********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Hash: () => (/* binding */ Hash)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_encoding__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-encoding */ "./node_modules/@siteimprove/alfa-encoding/dist/index.js");
/* harmony import */ var _hashable_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./hashable.js */ "./node_modules/@siteimprove/alfa-hash/dist/hashable.js");


const { keys } = Object;
/**
 * A special offset used for the builtin types `true`, `false`, `undefined`, and
 * `null`. The offset is designed to minimize the chance of collisions for data
 * structures that rely on 5-bit partitioning. We use the first 30 bits for 6 of
 * these partitions, leaving us 2 bits to encode the 4 builtin types.
 */
const builtinOffset = 0b10000_10000_10000_10000_10000_10000_00;
/**
 * @public
 */
class Hash {
    /**
     * A map from objects to their hash values. Objects are weakly referenced as
     * to not prevent them from being garbage collected.
     */
    static _objectHashes = new WeakMap();
    /**
     * A map from symbols to their hash values. As there's not currently a way to
     * weakly reference symbols, we have to instead use strong references.
     *
     * {@link https://github.com/tc39/proposal-symbols-as-weakmap-keys}
     */
    static _symbolHashes = new Map();
    /**
     * The next available hash value. This is used for symbols and objects that
     * don't implement the {@link (Hashable:interface)} interface.
     */
    static _nextHash = 0;
    constructor() { }
    writeString(data) {
        return this.write(_siteimprove_alfa_encoding__WEBPACK_IMPORTED_MODULE_0__.Encoder.encode(data));
    }
    /**
     * @remarks
     * As JavaScript represents numbers in double-precision floating-point format,
     * numbers in general will be written as such.
     *
     * {@link https://en.wikipedia.org/wiki/Double-precision_floating-point_format}
     */
    writeNumber(data) {
        return this.writeFloat64(data);
    }
    writeInt(data, size = 32, signed = true) {
        const buffer = new ArrayBuffer(size / 8);
        const view = new DataView(buffer);
        switch (size) {
            case 8:
                signed ? view.setInt8(0, data) : view.setUint8(0, data);
                break;
            case 16:
                signed ? view.setInt16(0, data) : view.setUint16(0, data);
                break;
            case 32:
                signed ? view.setInt32(0, data) : view.setUint32(0, data);
        }
        return this.write(new Uint8Array(buffer));
    }
    writeInt8(data) {
        return this.writeInt(data, 8, true);
    }
    writeUint8(data) {
        return this.writeInt(data, 8, false);
    }
    writeInt16(data) {
        return this.writeInt(data, 16, true);
    }
    writeUint16(data) {
        return this.writeInt(data, 16, false);
    }
    writeInt32(data) {
        return this.writeInt(data, 32, true);
    }
    writeUint32(data) {
        return this.writeInt(data, 32, false);
    }
    writeBigInt(data, size = 64, signed = true) {
        const buffer = new ArrayBuffer(size / 8);
        const view = new DataView(buffer);
        switch (size) {
            case 64:
                signed ? view.setBigInt64(0, data) : view.setBigUint64(0, data);
        }
        return this.write(new Uint8Array(buffer));
    }
    writeBigInt64(data) {
        return this.writeBigInt(data, 64, true);
    }
    writeBigUint64(data) {
        return this.writeBigInt(data, 64, false);
    }
    writeFloat(data, size = 32) {
        const buffer = new ArrayBuffer(size / 8);
        const view = new DataView(buffer);
        switch (size) {
            case 32:
                view.setFloat32(0, data);
                break;
            case 64:
                view.setFloat64(0, data);
        }
        return this.write(new Uint8Array(buffer));
    }
    writeFloat32(data) {
        return this.writeFloat(data, 32);
    }
    writeFloat64(data) {
        return this.writeFloat(data, 64);
    }
    writeBoolean(data) {
        return this.writeUint8(builtinOffset + (data ? 1 : 0));
    }
    writeUndefined() {
        return this.writeUint32(builtinOffset + 2);
    }
    writeNull() {
        return this.writeUint32(builtinOffset + 3);
    }
    writeObject(data) {
        let hash = Hash._objectHashes.get(data);
        if (hash === undefined) {
            hash = Hash._getNextHash();
            Hash._objectHashes.set(data, hash);
        }
        return this.writeUint32(hash);
    }
    writeSymbol(data) {
        let hash = Hash._symbolHashes.get(data);
        if (hash === undefined) {
            hash = Hash._getNextHash();
            Hash._symbolHashes.set(data, hash);
        }
        return this.writeUint32(hash);
    }
    writeHashable(data) {
        data.hash(this);
        return this;
    }
    writeUnknown(data) {
        switch (typeof data) {
            case "string":
                return this.writeString(data);
            case "number":
                return this.writeNumber(data);
            case "bigint":
                return this.writeBigInt(data);
            case "boolean":
                return this.writeBoolean(data);
            case "symbol":
                return this.writeSymbol(data);
            case "undefined":
                return this.writeUndefined();
            case "object":
                if (data === null) {
                    return this.writeNull();
                }
                if (_hashable_js__WEBPACK_IMPORTED_MODULE_1__.Hashable.isHashable(data)) {
                    return this.writeHashable(data);
                }
                return this.writeObject(data);
            case "function":
                return this.writeObject(data);
        }
    }
    writeJSON(data) {
        switch (typeof data) {
            case "string":
                return this.writeString(data);
            case "number":
                return this.writeNumber(data);
            case "boolean":
                return this.writeBoolean(data);
            case "object":
                if (Array.isArray(data)) {
                    for (let i = 0, n = data.length; i < n; i++) {
                        this.writeJSON(data[i]);
                    }
                    this.writeUint32(data.length);
                }
                else if (data !== null) {
                    for (const key of keys(data).sort()) {
                        const value = data[key];
                        this.writeString(key);
                        if (value !== undefined) {
                            this.writeJSON(value);
                        }
                        // Write a null byte as a separator between key/value pairs.
                        this.writeUint8(0);
                    }
                }
                return this;
        }
    }
    equals(value) {
        return value instanceof Hash && value.finish() === this.finish();
    }
    hash(hash) {
        hash.writeUint32(this.finish());
    }
    static _getNextHash() {
        const nextHash = Hash._nextHash;
        // Increase the hash, wrapping around when it reaches the limit of 32 bits.
        Hash._nextHash = (Hash._nextHash + 1) >>> 0;
        return nextHash;
    }
}
//# sourceMappingURL=hash.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-hash/dist/hashable.js":
/*!**************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-hash/dist/hashable.js ***!
  \**************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Hashable: () => (/* binding */ Hashable)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_refinement__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-refinement */ "./node_modules/@siteimprove/alfa-refinement/dist/index.js");

const { isFunction, isObject } = _siteimprove_alfa_refinement__WEBPACK_IMPORTED_MODULE_0__.Refinement;
/**
 * @public
 */
var Hashable;
(function (Hashable) {
    function isHashable(value) {
        return isObject(value) && isFunction(value.hash);
    }
    Hashable.isHashable = isHashable;
})(Hashable || (Hashable = {}));
//# sourceMappingURL=hashable.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-hash/dist/index.js":
/*!***********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-hash/dist/index.js ***!
  \***********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Hash: () => (/* reexport safe */ _hash_js__WEBPACK_IMPORTED_MODULE_0__.Hash),
/* harmony export */   Hashable: () => (/* reexport safe */ _hashable_js__WEBPACK_IMPORTED_MODULE_1__.Hashable)
/* harmony export */ });
/* harmony import */ var _hash_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./hash.js */ "./node_modules/@siteimprove/alfa-hash/dist/hash.js");
/* harmony import */ var _hashable_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./hashable.js */ "./node_modules/@siteimprove/alfa-hash/dist/hashable.js");


//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-iterable/dist/index.js":
/*!***************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-iterable/dist/index.js ***!
  \***************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Iterable: () => (/* reexport safe */ _iterable_js__WEBPACK_IMPORTED_MODULE_0__.Iterable)
/* harmony export */ });
/* harmony import */ var _iterable_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./iterable.js */ "./node_modules/@siteimprove/alfa-iterable/dist/iterable.js");

//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-iterable/dist/iterable.js":
/*!******************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-iterable/dist/iterable.js ***!
  \******************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Iterable: () => (/* binding */ Iterable)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-comparable */ "./node_modules/@siteimprove/alfa-comparable/dist/index.js");
/* harmony import */ var _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @siteimprove/alfa-equatable */ "./node_modules/@siteimprove/alfa-equatable/dist/index.js");
/* harmony import */ var _siteimprove_alfa_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @siteimprove/alfa-json */ "./node_modules/@siteimprove/alfa-json/dist/index.js");
/* harmony import */ var _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @siteimprove/alfa-option */ "./node_modules/@siteimprove/alfa-option/dist/index.js");
/* harmony import */ var _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @siteimprove/alfa-predicate */ "./node_modules/@siteimprove/alfa-predicate/dist/index.js");
/* harmony import */ var _siteimprove_alfa_refinement__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @siteimprove/alfa-refinement */ "./node_modules/@siteimprove/alfa-refinement/dist/index.js");






const { not } = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_4__.Predicate;
const { isObject } = _siteimprove_alfa_refinement__WEBPACK_IMPORTED_MODULE_5__.Refinement;
const { compareComparable } = _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__.Comparable;
/**
 * @public
 */
var Iterable;
(function (Iterable) {
    function isIterable(value) {
        return isObject(value) && Symbol.iterator in value;
    }
    Iterable.isIterable = isIterable;
    function* empty() { }
    Iterable.empty = empty;
    function* from(arrayLike) {
        for (let i = 0, n = arrayLike.length; i < n; i++) {
            yield arrayLike[i];
        }
    }
    Iterable.from = from;
    function size(iterable) {
        return reduce(iterable, (size) => size + 1, 0);
    }
    Iterable.size = size;
    function isEmpty(iterable) {
        for (const _ of iterable) {
            return false;
        }
        return true;
    }
    Iterable.isEmpty = isEmpty;
    function forEach(iterable, callback) {
        let index = 0;
        for (const value of iterable) {
            callback(value, index++);
        }
    }
    Iterable.forEach = forEach;
    function* map(iterable, mapper) {
        let index = 0;
        for (const value of iterable) {
            yield mapper(value, index++);
        }
    }
    Iterable.map = map;
    function* flatMap(iterable, mapper) {
        let index = 0;
        for (const value of iterable) {
            yield* mapper(value, index++);
        }
    }
    Iterable.flatMap = flatMap;
    function* flatten(iterable) {
        for (const value of iterable) {
            yield* value;
        }
    }
    Iterable.flatten = flatten;
    function reduce(iterable, reducer, accumulator) {
        let index = 0;
        for (const value of iterable) {
            accumulator = reducer(accumulator, value, index++);
        }
        return accumulator;
    }
    Iterable.reduce = reduce;
    function reduceWhile(iterable, predicate, reducer, accumulator) {
        let index = 0;
        for (const value of iterable) {
            if (predicate(value, index)) {
                accumulator = reducer(accumulator, value, index++);
            }
            else {
                break;
            }
        }
        return accumulator;
    }
    Iterable.reduceWhile = reduceWhile;
    function reduceUntil(iterable, predicate, reducer, accumulator) {
        return reduceWhile(iterable, not(predicate), reducer, accumulator);
    }
    Iterable.reduceUntil = reduceUntil;
    function apply(iterable, mapper) {
        return flatMap(mapper, (mapper) => map(iterable, mapper));
    }
    Iterable.apply = apply;
    function* filter(iterable, predicate) {
        let index = 0;
        for (const value of iterable) {
            if (predicate(value, index++)) {
                yield value;
            }
        }
    }
    Iterable.filter = filter;
    function reject(iterable, predicate) {
        return filter(iterable, not(predicate));
    }
    Iterable.reject = reject;
    function find(iterable, predicate) {
        let index = 0;
        for (const value of iterable) {
            if (predicate(value, index++)) {
                return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_3__.Option.of(value);
            }
        }
        return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_3__.None;
    }
    Iterable.find = find;
    function findLast(iterable, predicate) {
        let index = 0;
        let result = _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_3__.None;
        for (const value of iterable) {
            if (predicate(value, index++)) {
                result = _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_3__.Option.of(value);
            }
        }
        return result;
    }
    Iterable.findLast = findLast;
    function includes(iterable, value) {
        return some(iterable, _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_4__.Predicate.equals(value));
    }
    Iterable.includes = includes;
    function collect(iterable, mapper) {
        return flatMap(iterable, mapper);
    }
    Iterable.collect = collect;
    function collectFirst(iterable, mapper) {
        return first(collect(iterable, mapper));
    }
    Iterable.collectFirst = collectFirst;
    function some(iterable, predicate) {
        let index = 0;
        for (const value of iterable) {
            if (predicate(value, index++)) {
                return true;
            }
        }
        return false;
    }
    Iterable.some = some;
    function none(iterable, predicate) {
        return every(iterable, not(predicate));
    }
    Iterable.none = none;
    function every(iterable, predicate) {
        let index = 0;
        for (const value of iterable) {
            if (!predicate(value, index++)) {
                return false;
            }
        }
        return true;
    }
    Iterable.every = every;
    function count(iterable, predicate) {
        return reduce(iterable, (count, value, index) => (predicate(value, index) ? count + 1 : count), 0);
    }
    Iterable.count = count;
    function* distinct(iterable) {
        const seen = [];
        for (const value of iterable) {
            if (seen.some(_siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_4__.Predicate.equals(value))) {
                continue;
            }
            seen.push(value);
            yield value;
        }
    }
    Iterable.distinct = distinct;
    function get(iterable, index) {
        return index < 0 ? _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_3__.None : first(skip(iterable, index));
    }
    Iterable.get = get;
    function has(iterable, index) {
        return index < 0 ? false : !isEmpty(skip(iterable, index));
    }
    Iterable.has = has;
    function* set(iterable, index, value) {
        const it = iterator(iterable);
        while (index-- > 0) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            yield next.value;
        }
        const next = it.next();
        if (next.done === true) {
            return;
        }
        yield value;
        while (true) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            yield next.value;
        }
    }
    Iterable.set = set;
    function* insert(iterable, index, value) {
        const it = iterator(iterable);
        while (index-- > 0) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            yield next.value;
        }
        yield value;
        while (true) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            yield next.value;
        }
    }
    Iterable.insert = insert;
    function* append(iterable, value) {
        yield* iterable;
        yield value;
    }
    Iterable.append = append;
    function* prepend(iterable, value) {
        yield value;
        yield* iterable;
    }
    Iterable.prepend = prepend;
    function* concat(iterable, ...iterables) {
        yield* iterable;
        for (const iterable of iterables) {
            yield* iterable;
        }
    }
    Iterable.concat = concat;
    function subtract(iterable, ...iterables) {
        return reject(iterable, (value) => includes(flatten(iterables), value));
    }
    Iterable.subtract = subtract;
    function intersect(iterable, ...iterables) {
        return filter(iterable, (value) => includes(flatten(iterables), value));
    }
    Iterable.intersect = intersect;
    function* zip(a, b) {
        const itA = iterator(a);
        const itB = iterator(b);
        while (true) {
            const a = itA.next();
            const b = itB.next();
            if (a.done === true || b.done === true) {
                return;
            }
            yield [a.value, b.value];
        }
    }
    Iterable.zip = zip;
    function first(iterable) {
        for (const value of iterable) {
            return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_3__.Option.of(value);
        }
        return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_3__.None;
    }
    Iterable.first = first;
    function last(iterable) {
        let last = null;
        for (const value of iterable) {
            last = value;
        }
        return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_3__.Option.from(last);
    }
    Iterable.last = last;
    function* take(iterable, count) {
        const it = iterator(iterable);
        while (count-- > 0) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            yield next.value;
        }
    }
    Iterable.take = take;
    function* takeWhile(iterable, predicate) {
        let index = 0;
        for (const value of iterable) {
            if (predicate(value, index++)) {
                yield value;
            }
            else {
                break;
            }
        }
    }
    Iterable.takeWhile = takeWhile;
    function takeUntil(iterable, predicate) {
        return takeWhile(iterable, not(predicate));
    }
    Iterable.takeUntil = takeUntil;
    function* takeLast(iterable, count = 1) {
        if (count <= 0) {
            return;
        }
        const last = [];
        for (const value of iterable) {
            last.push(value);
            if (last.length > count) {
                last.shift();
            }
        }
        yield* last;
    }
    Iterable.takeLast = takeLast;
    function* takeLastWhile(iterable, predicate) {
        const values = [...iterable];
        let last = values.length - 1;
        while (last >= 0) {
            if (predicate(values[last], last)) {
                last--;
            }
            else {
                break;
            }
        }
        for (let i = last, n = values.length - 1; i < n; i++) {
            yield values[i];
        }
    }
    Iterable.takeLastWhile = takeLastWhile;
    function takeLastUntil(iterable, predicate) {
        return takeLastWhile(iterable, not(predicate));
    }
    Iterable.takeLastUntil = takeLastUntil;
    function* skip(iterable, count) {
        const it = iterator(iterable);
        while (count-- > 0) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
        }
        while (true) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            yield next.value;
        }
    }
    Iterable.skip = skip;
    function* skipWhile(iterable, predicate) {
        let index = 0;
        let skipped = false;
        for (const value of iterable) {
            if (!skipped && predicate(value, index++)) {
                continue;
            }
            else {
                skipped = true;
                yield value;
            }
        }
    }
    Iterable.skipWhile = skipWhile;
    function skipUntil(iterable, predicate) {
        return skipWhile(iterable, not(predicate));
    }
    Iterable.skipUntil = skipUntil;
    function* skipLast(iterable, count = 1) {
        const it = iterator(iterable);
        const first = [];
        while (count-- > 0) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            first.push(next.value);
        }
        while (true) {
            const next = it.next();
            if (next.done === true) {
                return;
            }
            first.push(next.value);
            yield first.shift();
        }
    }
    Iterable.skipLast = skipLast;
    function* skipLastWhile(iterable, predicate) {
        const values = [...iterable];
        let last = values.length - 1;
        while (last >= 0) {
            if (predicate(values[last], last)) {
                last--;
            }
            else {
                break;
            }
        }
        for (let i = 0, n = last; i < n; i++) {
            yield values[i];
        }
    }
    Iterable.skipLastWhile = skipLastWhile;
    function skipLastUntil(iterable, predicate) {
        return skipLastWhile(iterable, not(predicate));
    }
    Iterable.skipLastUntil = skipLastUntil;
    function trim(iterable, predicate) {
        return trimTrailing(trimLeading(iterable, predicate), predicate);
    }
    Iterable.trim = trim;
    function trimLeading(iterable, predicate) {
        return skipWhile(iterable, predicate);
    }
    Iterable.trimLeading = trimLeading;
    function trimTrailing(iterable, predicate) {
        return skipLastWhile(iterable, predicate);
    }
    Iterable.trimTrailing = trimTrailing;
    function rest(iterable) {
        return skip(iterable, 1);
    }
    Iterable.rest = rest;
    function slice(iterable, start, end) {
        iterable = skip(iterable, start);
        if (end !== undefined) {
            iterable = take(iterable, end - start);
        }
        return iterable;
    }
    Iterable.slice = slice;
    function* reverse(iterable) {
        const array = Array.from(iterable);
        for (let i = array.length - 1; i >= 0; i--) {
            yield array[i];
        }
    }
    Iterable.reverse = reverse;
    function join(iterable, separator) {
        const it = iterator(iterable);
        let next = it.next();
        if (next.done === true) {
            return "";
        }
        let result = `${next.value}`;
        next = it.next();
        while (next.done !== true) {
            result += `${separator}${next.value}`;
            next = it.next();
        }
        return result;
    }
    Iterable.join = join;
    function sort(iterable) {
        return sortWith(iterable, compareComparable);
    }
    Iterable.sort = sort;
    function* sortWith(iterable, comparer) {
        yield* [...iterable].sort(comparer);
    }
    Iterable.sortWith = sortWith;
    function compare(a, b) {
        return compareWith(a, b, compareComparable);
    }
    Iterable.compare = compare;
    function compareWith(a, b, comparer) {
        const itA = iterator(a);
        const itB = iterator(b);
        let index = 0;
        while (true) {
            const a = itA.next();
            const b = itB.next();
            if (a.done === true) {
                return b.done === true ? _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__.Comparison.Equal : _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__.Comparison.Less;
            }
            if (b.done === true) {
                return _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__.Comparison.Greater;
            }
            const result = comparer(a.value, b.value, index++);
            if (result !== 0) {
                return result;
            }
        }
    }
    Iterable.compareWith = compareWith;
    function equals(a, b) {
        const itA = iterator(a);
        const itB = iterator(b);
        while (true) {
            const a = itA.next();
            const b = itB.next();
            if (a.done === true) {
                return b.done === true;
            }
            if (b.done === true || !_siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(a.value, b.value)) {
                return false;
            }
        }
    }
    Iterable.equals = equals;
    function hash(iterable, hash) {
        let size = 0;
        for (const value of iterable) {
            hash.writeUnknown(value);
            size++;
        }
        hash.writeUint32(size);
    }
    Iterable.hash = hash;
    function iterator(iterable) {
        return iterable[Symbol.iterator]();
    }
    Iterable.iterator = iterator;
    function groupBy(iterable, grouper) {
        const groups = [];
        let index = 0;
        for (const value of iterable) {
            const group = grouper(value, index++);
            const existing = groups.find(([existing]) => _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(group, existing));
            if (existing === undefined) {
                groups.push([group, [value]]);
            }
            else {
                existing[1].push(value);
            }
        }
        return groups;
    }
    Iterable.groupBy = groupBy;
    function toJSON(iterable, options) {
        return [...map(iterable, (value) => _siteimprove_alfa_json__WEBPACK_IMPORTED_MODULE_2__.Serializable.toJSON(value, options))];
    }
    Iterable.toJSON = toJSON;
})(Iterable || (Iterable = {}));
//# sourceMappingURL=iterable.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-json/dist/builtin.js":
/*!*************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-json/dist/builtin.js ***!
  \*************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   JSON: () => (/* binding */ Builtin)
/* harmony export */ });
// This file defines exports from the builtin `JSON` constructor for internal
// use only.
/**
 * @internal
 */
const Builtin = JSON;

//# sourceMappingURL=builtin.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-json/dist/index.js":
/*!***********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-json/dist/index.js ***!
  \***********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   JSON: () => (/* reexport safe */ _json_js__WEBPACK_IMPORTED_MODULE_0__.JSON),
/* harmony export */   Serializable: () => (/* reexport safe */ _serializable_js__WEBPACK_IMPORTED_MODULE_1__.Serializable)
/* harmony export */ });
/* harmony import */ var _json_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./json.js */ "./node_modules/@siteimprove/alfa-json/dist/json.js");
/* harmony import */ var _serializable_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./serializable.js */ "./node_modules/@siteimprove/alfa-json/dist/serializable.js");


//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-json/dist/json.js":
/*!**********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-json/dist/json.js ***!
  \**********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   JSON: () => (/* binding */ JSON)
/* harmony export */ });
/* harmony import */ var _builtin_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./builtin.js */ "./node_modules/@siteimprove/alfa-json/dist/builtin.js");

/**
 * @public
 */
var JSON;
(function (JSON) {
    function parse(value) {
        return _builtin_js__WEBPACK_IMPORTED_MODULE_0__.JSON.parse(value);
    }
    JSON.parse = parse;
    function stringify(value) {
        return _builtin_js__WEBPACK_IMPORTED_MODULE_0__.JSON.stringify(value);
    }
    JSON.stringify = stringify;
})(JSON || (JSON = {}));
//# sourceMappingURL=json.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-json/dist/serializable.js":
/*!******************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-json/dist/serializable.js ***!
  \******************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Serializable: () => (/* binding */ Serializable)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_refinement__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-refinement */ "./node_modules/@siteimprove/alfa-refinement/dist/index.js");

const { keys } = Object;
const { isArray } = Array;
const { isFunction, isObject, isString, isNumber, isBoolean, isNull } = _siteimprove_alfa_refinement__WEBPACK_IMPORTED_MODULE_0__.Refinement;
/**
 * @public
 */
var Serializable;
(function (Serializable) {
    function isSerializable(value) {
        return isObject(value) && isFunction(value.toJSON);
    }
    Serializable.isSerializable = isSerializable;
    function toJSON(value, options) {
        if (isSerializable(value)) {
            return value.toJSON(options);
        }
        if (isString(value) ||
            isNumber(value) ||
            isBoolean(value) ||
            isNull(value)) {
            return value;
        }
        if (isArray(value)) {
            return value.map((item) => toJSON(item, options));
        }
        if (isObject(value)) {
            const json = {};
            for (const key of keys(value)) {
                if (value[key] !== undefined) {
                    json[key] = toJSON(value[key], options);
                }
            }
            return json;
        }
        return null;
    }
    Serializable.toJSON = toJSON;
    let Verbosity;
    (function (Verbosity) {
        Verbosity[Verbosity["Minimal"] = 0] = "Minimal";
        Verbosity[Verbosity["Low"] = 100] = "Low";
        Verbosity[Verbosity["Medium"] = 200] = "Medium";
        Verbosity[Verbosity["High"] = 300] = "High";
    })(Verbosity = Serializable.Verbosity || (Serializable.Verbosity = {}));
})(Serializable || (Serializable = {}));
//# sourceMappingURL=serializable.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-map/dist/index.js":
/*!**********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-map/dist/index.js ***!
  \**********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Collision: () => (/* reexport safe */ _node_js__WEBPACK_IMPORTED_MODULE_1__.Collision),
/* harmony export */   Empty: () => (/* reexport safe */ _node_js__WEBPACK_IMPORTED_MODULE_1__.Empty),
/* harmony export */   Leaf: () => (/* reexport safe */ _node_js__WEBPACK_IMPORTED_MODULE_1__.Leaf),
/* harmony export */   Map: () => (/* reexport safe */ _map_js__WEBPACK_IMPORTED_MODULE_0__.Map),
/* harmony export */   Node: () => (/* reexport safe */ _node_js__WEBPACK_IMPORTED_MODULE_1__.Node),
/* harmony export */   Sparse: () => (/* reexport safe */ _node_js__WEBPACK_IMPORTED_MODULE_1__.Sparse)
/* harmony export */ });
/* harmony import */ var _map_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./map.js */ "./node_modules/@siteimprove/alfa-map/dist/map.js");
/* harmony import */ var _node_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./node.js */ "./node_modules/@siteimprove/alfa-map/dist/node.js");


//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-map/dist/map.js":
/*!********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-map/dist/map.js ***!
  \********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Map: () => (/* binding */ Map)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_array__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-array */ "./node_modules/@siteimprove/alfa-array/dist/index.js");
/* harmony import */ var _siteimprove_alfa_fnv__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @siteimprove/alfa-fnv */ "./node_modules/@siteimprove/alfa-fnv/dist/index.js");
/* harmony import */ var _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @siteimprove/alfa-iterable */ "./node_modules/@siteimprove/alfa-iterable/dist/index.js");
/* harmony import */ var _siteimprove_alfa_json__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @siteimprove/alfa-json */ "./node_modules/@siteimprove/alfa-json/dist/index.js");
/* harmony import */ var _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @siteimprove/alfa-predicate */ "./node_modules/@siteimprove/alfa-predicate/dist/index.js");
/* harmony import */ var _node_js__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./node.js */ "./node_modules/@siteimprove/alfa-map/dist/node.js");






const { not } = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_4__.Predicate;
/**
 * @public
 */
class Map {
    static of(...entries) {
        return entries.reduce((map, [key, value]) => map.set(key, value), Map.empty());
    }
    static _empty = new Map(_node_js__WEBPACK_IMPORTED_MODULE_5__.Empty, 0);
    static empty() {
        return this._empty;
    }
    _root;
    _size;
    constructor(root, size) {
        this._root = root;
        this._size = size;
    }
    get size() {
        return this._size;
    }
    isEmpty() {
        return this._size === 0;
    }
    forEach(callback) {
        _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.forEach(this, ([key, value]) => callback(value, key));
    }
    map(mapper) {
        return new Map(this._root.map(mapper), this._size);
    }
    /**
     * Apply a map of functions to each corresponding value of this map.
     *
     * @remarks
     * Keys without a corresponding function or value are dropped from the
     * resulting map.
     *
     * @example
     * ```ts
     * Map.of(["a", 1], ["b", 2])
     *   .apply(Map.of(["a", (x) => x + 1], ["b", (x) => x * 2]))
     *   .toArray();
     * // => [["a", 2], ["b", 4]]
     * ```
     */
    apply(mapper) {
        return this.collect((value, key) => mapper.get(key).map((mapper) => mapper(value)));
    }
    /**
     * @remarks
     * As the order of maps is undefined, it is also undefined which keys are
     * kept when duplicate keys are encountered.
     */
    flatMap(mapper) {
        return this.reduce((map, value, key) => map.concat(mapper(value, key)), Map.empty());
    }
    /**
     * @remarks
     * As the order of maps is undefined, it is also undefined which keys are
     * kept when duplicate keys are encountered.
     */
    flatten() {
        return this.flatMap((map) => map);
    }
    reduce(reducer, accumulator) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.reduce(this, (accumulator, [key, value]) => reducer(accumulator, value, key), accumulator);
    }
    filter(predicate) {
        return this.reduce((map, value, key) => (predicate(value, key) ? map.set(key, value) : map), Map.empty());
    }
    reject(predicate) {
        return this.filter(not(predicate));
    }
    find(predicate) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.find(this, ([key, value]) => predicate(value, key)).map(([, value]) => value);
    }
    includes(value) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.includes(this.values(), value);
    }
    collect(mapper) {
        return Map.from(_siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.collect(this, ([key, value]) => mapper(value, key).map((value) => [key, value])));
    }
    collectFirst(mapper) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.collectFirst(this, ([key, value]) => mapper(value, key));
    }
    some(predicate) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.some(this, ([key, value]) => predicate(value, key));
    }
    none(predicate) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.none(this, ([key, value]) => predicate(value, key));
    }
    every(predicate) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.every(this, ([key, value]) => predicate(value, key));
    }
    count(predicate) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.count(this, ([key, value]) => predicate(value, key));
    }
    /**
     * @remarks
     * As the order of maps is undefined, it is also undefined which keys are
     * kept when duplicate values are encountered.
     */
    distinct() {
        let seen = Map.empty();
        // We optimize for the case where there are more distinct values than there
        // are duplicate values by starting with the current map and removing
        // duplicates as we find them.
        let map = this;
        for (const [key, value] of map) {
            if (seen.has(value)) {
                map = map.delete(key);
            }
            else {
                seen = seen.set(value, value);
            }
        }
        return map;
    }
    get(key) {
        return this._root.get(key, hash(key), 0);
    }
    has(key) {
        return this.get(key).isSome();
    }
    set(key, value) {
        const { result: root, status } = this._root.set(key, value, hash(key), 0);
        if (status === "unchanged") {
            return this;
        }
        return new Map(root, this._size + (status === "updated" ? 0 : 1));
    }
    delete(key) {
        const { result: root, status } = this._root.delete(key, hash(key), 0);
        if (status === "unchanged") {
            return this;
        }
        return new Map(root, this._size - 1);
    }
    concat(iterable) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.reduce(iterable, (map, [key, value]) => map.set(key, value), this);
    }
    subtract(iterable) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.reduce(iterable, (map, [key]) => map.delete(key), this);
    }
    intersect(iterable) {
        return Map.fromIterable(_siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.filter(iterable, ([key]) => this.has(key)));
    }
    tee(callback, ...args) {
        callback(this, ...args);
        return this;
    }
    equals(value) {
        return (value instanceof Map &&
            value._size === this._size &&
            value._root.equals(this._root));
    }
    hash(hash) {
        for (const [key, value] of this) {
            hash.writeUnknown(key).writeUnknown(value);
        }
        hash.writeUint32(this._size);
    }
    keys() {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.map(this._root, (entry) => entry[0]);
    }
    values() {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.map(this._root, (entry) => entry[1]);
    }
    *iterator() {
        yield* this._root;
    }
    [Symbol.iterator]() {
        return this.iterator();
    }
    toArray() {
        return [...this];
    }
    toJSON(options) {
        return this.toArray().map(([key, value]) => [
            _siteimprove_alfa_json__WEBPACK_IMPORTED_MODULE_3__.Serializable.toJSON(key, options),
            _siteimprove_alfa_json__WEBPACK_IMPORTED_MODULE_3__.Serializable.toJSON(value, options),
        ]);
    }
    toString() {
        const entries = this.toArray()
            .map(([key, value]) => `${key} => ${value}`)
            .join(", ");
        return `Map {${entries === "" ? "" : ` ${entries} `}}`;
    }
}
/**
 * @public
 */
(function (Map) {
    function isMap(value) {
        return value instanceof Map;
    }
    Map.isMap = isMap;
    function from(iterable) {
        if (isMap(iterable)) {
            return iterable;
        }
        if (_siteimprove_alfa_array__WEBPACK_IMPORTED_MODULE_0__.Array.isArray(iterable)) {
            return fromArray(iterable);
        }
        return fromIterable(iterable);
    }
    Map.from = from;
    function fromArray(array) {
        return _siteimprove_alfa_array__WEBPACK_IMPORTED_MODULE_0__.Array.reduce(array, (map, [key, value]) => map.set(key, value), Map.empty());
    }
    Map.fromArray = fromArray;
    function fromIterable(iterable) {
        return _siteimprove_alfa_iterable__WEBPACK_IMPORTED_MODULE_2__.Iterable.reduce(iterable, (map, [key, value]) => map.set(key, value), Map.empty());
    }
    Map.fromIterable = fromIterable;
})(Map || (Map = {}));
function hash(key) {
    return _siteimprove_alfa_fnv__WEBPACK_IMPORTED_MODULE_1__.FNV.empty().writeUnknown(key).finish();
}
//# sourceMappingURL=map.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-map/dist/node.js":
/*!*********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-map/dist/node.js ***!
  \*********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Collision: () => (/* binding */ Collision),
/* harmony export */   Empty: () => (/* binding */ Empty),
/* harmony export */   Leaf: () => (/* binding */ Leaf),
/* harmony export */   Node: () => (/* binding */ Node),
/* harmony export */   Sparse: () => (/* binding */ Sparse)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_bits__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-bits */ "./node_modules/@siteimprove/alfa-bits/dist/index.js");
/* harmony import */ var _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @siteimprove/alfa-equatable */ "./node_modules/@siteimprove/alfa-equatable/dist/index.js");
/* harmony import */ var _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @siteimprove/alfa-option */ "./node_modules/@siteimprove/alfa-option/dist/index.js");
/* harmony import */ var _status_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./status.js */ "./node_modules/@siteimprove/alfa-map/dist/status.js");




const { bit, take, skip, test, set, clear, popCount } = _siteimprove_alfa_bits__WEBPACK_IMPORTED_MODULE_0__.Bits;
/**
 * @internal
 */
var Node;
(function (Node) {
    Node.Bits = 5;
    function fragment(hash, shift) {
        return take(skip(hash, shift), Node.Bits);
    }
    Node.fragment = fragment;
    function index(fragment, mask) {
        return popCount(take(mask, fragment));
    }
    Node.index = index;
})(Node || (Node = {}));
/**
 * @internal
 */
const Empty = new (class Empty {
    isEmpty() {
        return true;
    }
    isLeaf() {
        return false;
    }
    get() {
        return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_2__.None;
    }
    set(key, value, hash) {
        return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.created(Leaf.of(hash, key, value));
    }
    delete() {
        return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.unchanged(this);
    }
    map() {
        return this;
    }
    equals(value) {
        return value instanceof Empty;
    }
    *[Symbol.iterator]() { }
})();
/**
 * @internal
 */
class Leaf {
    static of(hash, key, value) {
        return new Leaf(hash, key, value);
    }
    _hash;
    _key;
    _value;
    constructor(hash, key, value) {
        this._hash = hash;
        this._key = key;
        this._value = value;
    }
    get key() {
        return this._key;
    }
    get value() {
        return this._value;
    }
    isEmpty() {
        return false;
    }
    isLeaf() {
        return true;
    }
    get(key, hash, shift) {
        return hash === this._hash && _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(key, this._key)
            ? _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_2__.Option.of(this._value)
            : _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_2__.None;
    }
    set(key, value, hash, shift) {
        if (hash === this._hash) {
            if (_siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(key, this._key)) {
                if (_siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(value, this._value)) {
                    return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.unchanged(this);
                }
                return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.updated(Leaf.of(hash, key, value));
            }
            return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.created(Collision.of(hash, [this, Leaf.of(hash, key, value)]));
        }
        const fragment = Node.fragment(this._hash, shift);
        return Sparse.of(bit(fragment), [this]).set(key, value, hash, shift);
    }
    delete(key, hash) {
        return hash === this._hash && _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(key, this._key)
            ? _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.deleted(Empty)
            : _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.unchanged(this);
    }
    map(mapper) {
        return Leaf.of(this._hash, this._key, mapper(this._value, this._key));
    }
    equals(value) {
        return (value instanceof Leaf &&
            value._hash === this._hash &&
            _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(value._key, this._key) &&
            _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(value._value, this._value));
    }
    *[Symbol.iterator]() {
        yield [this._key, this._value];
    }
}
/**
 * @internal
 */
class Collision {
    static of(hash, nodes) {
        return new Collision(hash, nodes);
    }
    _hash;
    _nodes;
    constructor(hash, nodes) {
        this._hash = hash;
        this._nodes = nodes;
    }
    isEmpty() {
        return false;
    }
    isLeaf() {
        return false;
    }
    get(key, hash, shift) {
        if (hash === this._hash) {
            for (const node of this._nodes) {
                const value = node.get(key, hash, shift);
                if (value.isSome()) {
                    return value;
                }
            }
        }
        return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_2__.None;
    }
    set(key, value, hash, shift) {
        if (hash === this._hash) {
            for (let i = 0, n = this._nodes.length; i < n; i++) {
                const node = this._nodes[i];
                if (_siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(key, node.key)) {
                    if (_siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(value, node.value)) {
                        return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.unchanged(this);
                    }
                    return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.updated(Collision.of(this._hash, replace(this._nodes, i, Leaf.of(hash, key, value))));
                }
            }
            return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.created(Collision.of(this._hash, this._nodes.concat(Leaf.of(hash, key, value))));
        }
        const fragment = Node.fragment(this._hash, shift);
        return Sparse.of(bit(fragment), [this]).set(key, value, hash, shift);
    }
    delete(key, hash) {
        if (hash === this._hash) {
            for (let i = 0, n = this._nodes.length; i < n; i++) {
                const node = this._nodes[i];
                if (_siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(key, node.key)) {
                    const nodes = remove(this._nodes, i);
                    if (nodes.length === 1) {
                        // We just deleted the penultimate Leaf of the Collision, so we can
                        // remove the Collision and only keep the remaining Leaf.
                        return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.deleted(nodes[0]);
                    }
                    return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.deleted(Collision.of(this._hash, nodes));
                }
            }
        }
        return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.unchanged(this);
    }
    map(mapper) {
        return Collision.of(this._hash, this._nodes.map((node) => node.map(mapper)));
    }
    equals(value) {
        return (value instanceof Collision &&
            value._hash === this._hash &&
            value._nodes.length === this._nodes.length &&
            value._nodes.every((node, i) => node.equals(this._nodes[i])));
    }
    *[Symbol.iterator]() {
        for (const node of this._nodes) {
            yield* node;
        }
    }
}
/**
 * @internal
 */
class Sparse {
    static of(mask, nodes) {
        return new Sparse(mask, nodes);
    }
    _mask;
    _nodes;
    constructor(mask, nodes) {
        this._mask = mask;
        this._nodes = nodes;
    }
    isEmpty() {
        return false;
    }
    isLeaf() {
        return false;
    }
    get(key, hash, shift) {
        const fragment = Node.fragment(hash, shift);
        if (test(this._mask, fragment)) {
            const index = Node.index(fragment, this._mask);
            return this._nodes[index].get(key, hash, shift + Node.Bits);
        }
        return _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_2__.None;
    }
    set(key, value, hash, shift) {
        const fragment = Node.fragment(hash, shift);
        const index = Node.index(fragment, this._mask);
        if (test(this._mask, fragment)) {
            const { result: node, status } = this._nodes[index].set(key, value, hash, shift + Node.Bits);
            if (status === "unchanged") {
                return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.unchanged(this);
            }
            const sparse = Sparse.of(this._mask, replace(this._nodes, index, node));
            switch (status) {
                case "created":
                    return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.created(sparse);
                case "updated":
                default:
                    return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.updated(sparse);
            }
        }
        return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.created(Sparse.of(set(this._mask, fragment), insert(this._nodes, index, Leaf.of(hash, key, value))));
    }
    delete(key, hash, shift) {
        const fragment = Node.fragment(hash, shift);
        if (test(this._mask, fragment)) {
            const index = Node.index(fragment, this._mask);
            const { result: node, status } = this._nodes[index].delete(key, hash, shift + Node.Bits);
            if (status === "unchanged") {
                return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.unchanged(this);
            }
            if (node.isEmpty()) {
                const nodes = remove(this._nodes, index);
                if (nodes.length === 1) {
                    // We deleted the penultimate child of the Sparse, we may be able to
                    // simplify the tree.
                    if (nodes[0].isLeaf() || nodes[0] instanceof Collision) {
                        // The last child is leaf-like, hence hashes will be fully matched
                        // against its key(s) and we can remove the current Sparse
                        return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.deleted(nodes[0]);
                    }
                    // Otherwise, the last child is a Sparse. We can't simply collapse the
                    // tree by removing the current Sparse, since it will cause the child
                    // mask to be tested with the wrong shift (its depth in the tree would
                    // be different).
                    // We could do some further optimisations (e.g., if the child's
                    // children are all leaf-like, we could instead delete the lone child
                    // and connect directly to the grandchildren). This is, however,
                    // getting hairy to make all cases working fine, and we assume this
                    // kind of situation is not too frequent. So we pay the price of
                    // keeping a non-branching Sparse until we need to optimise that.
                }
                return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.deleted(Sparse.of(clear(this._mask, fragment), nodes));
            }
            return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.deleted(Sparse.of(this._mask, replace(this._nodes, index, node)));
        }
        return _status_js__WEBPACK_IMPORTED_MODULE_3__.Status.unchanged(this);
    }
    map(mapper) {
        return Sparse.of(this._mask, this._nodes.map((node) => node.map(mapper)));
    }
    equals(value) {
        return (value instanceof Sparse &&
            value._mask === this._mask &&
            value._nodes.length === this._nodes.length &&
            value._nodes.every((node, i) => node.equals(this._nodes[i])));
    }
    *[Symbol.iterator]() {
        for (const node of this._nodes) {
            yield* node;
        }
    }
}
function insert(array, index, value) {
    const result = new Array(array.length + 1);
    result[index] = value;
    for (let i = 0, n = index; i < n; i++) {
        result[i] = array[i];
    }
    for (let i = index, n = array.length; i < n; i++) {
        result[i + 1] = array[i];
    }
    return result;
}
function remove(array, index) {
    const result = new Array(array.length - 1);
    for (let i = 0, n = index; i < n; i++) {
        result[i] = array[i];
    }
    for (let i = index, n = result.length; i < n; i++) {
        result[i] = array[i + 1];
    }
    return result;
}
function replace(array, index, value) {
    const result = array.slice(0);
    result[index] = value;
    return result;
}
//# sourceMappingURL=node.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-map/dist/status.js":
/*!***********************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-map/dist/status.js ***!
  \***********************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Status: () => (/* binding */ Status)
/* harmony export */ });
/**
 * @internal
 */
var Status;
(function (Status_1) {
    class Status {
        _result;
        constructor(result) {
            this._result = result;
        }
        get result() {
            return this._result;
        }
    }
    class Created extends Status {
        static of(result) {
            return new Created(result);
        }
        constructor(result) {
            super(result);
        }
        get status() {
            return "created";
        }
    }
    Status_1.Created = Created;
    Status_1.created = Created.of;
    class Updated extends Status {
        static of(result) {
            return new Updated(result);
        }
        constructor(result) {
            super(result);
        }
        get status() {
            return "updated";
        }
    }
    Status_1.Updated = Updated;
    Status_1.updated = Updated.of;
    class Deleted extends Status {
        static of(result) {
            return new Deleted(result);
        }
        constructor(result) {
            super(result);
        }
        get status() {
            return "deleted";
        }
    }
    Status_1.Deleted = Deleted;
    Status_1.deleted = Deleted.of;
    class Unchanged extends Status {
        static of(result) {
            return new Unchanged(result);
        }
        constructor(result) {
            super(result);
        }
        get status() {
            return "unchanged";
        }
    }
    Status_1.Unchanged = Unchanged;
    Status_1.unchanged = Unchanged.of;
})(Status || (Status = {}));
//# sourceMappingURL=status.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-option/dist/index.js":
/*!*************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-option/dist/index.js ***!
  \*************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Maybe: () => (/* reexport safe */ _maybe_js__WEBPACK_IMPORTED_MODULE_0__.Maybe),
/* harmony export */   None: () => (/* reexport safe */ _none_js__WEBPACK_IMPORTED_MODULE_1__.None),
/* harmony export */   Option: () => (/* reexport safe */ _option_js__WEBPACK_IMPORTED_MODULE_2__.Option),
/* harmony export */   Some: () => (/* reexport safe */ _some_js__WEBPACK_IMPORTED_MODULE_3__.Some)
/* harmony export */ });
/* harmony import */ var _maybe_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./maybe.js */ "./node_modules/@siteimprove/alfa-option/dist/maybe.js");
/* harmony import */ var _none_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./none.js */ "./node_modules/@siteimprove/alfa-option/dist/none.js");
/* harmony import */ var _option_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./option.js */ "./node_modules/@siteimprove/alfa-option/dist/option.js");
/* harmony import */ var _some_js__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./some.js */ "./node_modules/@siteimprove/alfa-option/dist/some.js");




//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-option/dist/maybe.js":
/*!*************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-option/dist/maybe.js ***!
  \*************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Maybe: () => (/* binding */ Maybe)
/* harmony export */ });
/* harmony import */ var _option_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./option.js */ "./node_modules/@siteimprove/alfa-option/dist/option.js");

/**
 * @internal
 */
var Maybe;
(function (Maybe) {
    function toOption(maybe) {
        return _option_js__WEBPACK_IMPORTED_MODULE_0__.Option.isOption(maybe) ? maybe : _option_js__WEBPACK_IMPORTED_MODULE_0__.Option.of(maybe);
    }
    Maybe.toOption = toOption;
})(Maybe || (Maybe = {}));
//# sourceMappingURL=maybe.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-option/dist/none.js":
/*!************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-option/dist/none.js ***!
  \************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   None: () => (/* binding */ None)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-comparable */ "./node_modules/@siteimprove/alfa-comparable/dist/index.js");

const { compareComparable } = _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__.Comparable;
/**
 * @public
 */
const None = new (class None {
    isSome() {
        return false;
    }
    isNone() {
        return true;
    }
    map() {
        return this;
    }
    forEach() {
        return;
    }
    apply() {
        return this;
    }
    flatMap() {
        return this;
    }
    flatten() {
        return this;
    }
    reduce(reducer, accumulator) {
        return accumulator;
    }
    filter() {
        return this;
    }
    reject() {
        return this;
    }
    includes() {
        return false;
    }
    some() {
        return false;
    }
    none() {
        return true;
    }
    every() {
        return true;
    }
    and() {
        return this;
    }
    andThen() {
        return this;
    }
    or(option) {
        return option;
    }
    orElse(option) {
        return option();
    }
    /**
     * @internal
     */
    getUnsafe(message = "Attempted to .getUnsafe() from None") {
        throw new Error(message);
    }
    getOr(value) {
        return value;
    }
    getOrElse(value) {
        return value();
    }
    tee() {
        return this;
    }
    compare(option) {
        return this.compareWith(option, compareComparable);
    }
    compareWith(option) {
        return option.isNone() ? _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__.Comparison.Equal : _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__.Comparison.Less;
    }
    equals(value) {
        return value instanceof None;
    }
    hash(hash) {
        hash.writeBoolean(false);
    }
    *[Symbol.iterator]() { }
    toArray() {
        return [];
    }
    toJSON() {
        return {
            type: "none",
        };
    }
    toString() {
        return "None";
    }
})();
//# sourceMappingURL=none.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-option/dist/option.js":
/*!**************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-option/dist/option.js ***!
  \**************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Option: () => (/* binding */ Option)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-comparable */ "./node_modules/@siteimprove/alfa-comparable/dist/index.js");
/* harmony import */ var _none_js__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./none.js */ "./node_modules/@siteimprove/alfa-option/dist/none.js");
/* harmony import */ var _some_js__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./some.js */ "./node_modules/@siteimprove/alfa-option/dist/some.js");



/**
 * @public
 */
var Option;
(function (Option) {
    function isOption(value) {
        return isSome(value) || isNone(value);
    }
    Option.isOption = isOption;
    function isSome(value) {
        return _some_js__WEBPACK_IMPORTED_MODULE_2__.Some.isSome(value);
    }
    Option.isSome = isSome;
    function isNone(value) {
        return value === _none_js__WEBPACK_IMPORTED_MODULE_1__.None;
    }
    Option.isNone = isNone;
    function of(value) {
        return _some_js__WEBPACK_IMPORTED_MODULE_2__.Some.of(value);
    }
    Option.of = of;
    function empty() {
        return _none_js__WEBPACK_IMPORTED_MODULE_1__.None;
    }
    Option.empty = empty;
    function from(value) {
        return value === null || value === undefined ? _none_js__WEBPACK_IMPORTED_MODULE_1__.None : _some_js__WEBPACK_IMPORTED_MODULE_2__.Some.of(value);
    }
    Option.from = from;
})(Option || (Option = {}));
//# sourceMappingURL=option.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-option/dist/some.js":
/*!************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-option/dist/some.js ***!
  \************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Some: () => (/* binding */ Some)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-comparable */ "./node_modules/@siteimprove/alfa-comparable/dist/index.js");
/* harmony import */ var _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @siteimprove/alfa-equatable */ "./node_modules/@siteimprove/alfa-equatable/dist/index.js");
/* harmony import */ var _siteimprove_alfa_json__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @siteimprove/alfa-json */ "./node_modules/@siteimprove/alfa-json/dist/index.js");
/* harmony import */ var _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! @siteimprove/alfa-predicate */ "./node_modules/@siteimprove/alfa-predicate/dist/index.js");
/* harmony import */ var _none_js__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./none.js */ "./node_modules/@siteimprove/alfa-option/dist/none.js");





const { not, test } = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_3__.Predicate;
const { compareComparable } = _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__.Comparable;
/**
 * @public
 */
class Some {
    static of(value) {
        return new Some(value);
    }
    _value;
    constructor(value) {
        this._value = value;
    }
    isSome() {
        return true;
    }
    isNone() {
        return false;
    }
    map(mapper) {
        return new Some(mapper(this._value));
    }
    forEach(mapper) {
        mapper(this._value);
    }
    apply(mapper) {
        return mapper.map((mapper) => mapper(this._value));
    }
    flatMap(mapper) {
        return mapper(this._value);
    }
    flatten() {
        return this._value;
    }
    reduce(reducer, accumulator) {
        return reducer(accumulator, this._value);
    }
    filter(predicate) {
        return test(predicate, this._value) ? this : _none_js__WEBPACK_IMPORTED_MODULE_4__.None;
    }
    reject(predicate) {
        return this.filter(not(predicate));
    }
    includes(value) {
        return _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(value, this._value);
    }
    some(predicate) {
        return test(predicate, this._value);
    }
    none(predicate) {
        return test(not(predicate), this._value);
    }
    every(predicate) {
        return test(predicate, this._value);
    }
    and(option) {
        return option;
    }
    andThen(option) {
        return option(this._value);
    }
    or() {
        return this;
    }
    orElse() {
        return this;
    }
    get() {
        return this._value;
    }
    /**
     * @internal
     */
    getUnsafe() {
        return this._value;
    }
    getOr() {
        return this._value;
    }
    getOrElse() {
        return this._value;
    }
    tee(callback) {
        callback(this._value);
        return this;
    }
    compare(option) {
        return this.compareWith(option, compareComparable);
    }
    compareWith(option, comparer) {
        return option.isSome()
            ? comparer(this._value, option._value)
            : _siteimprove_alfa_comparable__WEBPACK_IMPORTED_MODULE_0__.Comparison.Greater;
    }
    equals(value) {
        return value instanceof Some && _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_1__.Equatable.equals(value._value, this._value);
    }
    hash(hash) {
        hash.writeBoolean(true).writeUnknown(this._value);
    }
    *[Symbol.iterator]() {
        yield this._value;
    }
    toArray() {
        return [this._value];
    }
    toJSON(options) {
        return {
            type: "some",
            value: _siteimprove_alfa_json__WEBPACK_IMPORTED_MODULE_2__.Serializable.toJSON(this._value, options),
        };
    }
    toString() {
        return `Some { ${this._value} }`;
    }
}
/**
 * @public
 */
(function (Some) {
    function isSome(value) {
        return value instanceof Some;
    }
    Some.isSome = isSome;
})(Some || (Some = {}));
//# sourceMappingURL=some.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-predicate/dist/index.js":
/*!****************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-predicate/dist/index.js ***!
  \****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Predicate: () => (/* reexport safe */ _predicate_js__WEBPACK_IMPORTED_MODULE_0__.Predicate)
/* harmony export */ });
/* harmony import */ var _predicate_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./predicate.js */ "./node_modules/@siteimprove/alfa-predicate/dist/predicate.js");

//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-predicate/dist/predicate.js":
/*!********************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-predicate/dist/predicate.js ***!
  \********************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Predicate: () => (/* binding */ Predicate)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-equatable */ "./node_modules/@siteimprove/alfa-equatable/dist/index.js");

/**
 * @public
 */
var Predicate;
(function (Predicate) {
    function test(predicate, value, ...args) {
        return predicate(value, ...args);
    }
    Predicate.test = test;
    function fold(predicate, ifTrue, ifFalse, value, ...args) {
        return predicate(value, ...args) ? ifTrue(value) : ifFalse(value);
    }
    Predicate.fold = fold;
    function not(predicate) {
        return (value, ...args) => !predicate(value, ...args);
    }
    Predicate.not = not;
    function and(...predicates) {
        return (value, ...args) => {
            for (let i = 0, n = predicates.length; i < n; i++) {
                if (!predicates[i](value, ...args)) {
                    return false;
                }
            }
            return true;
        };
    }
    Predicate.and = and;
    function or(...predicates) {
        return (value, ...args) => {
            for (let i = 0, n = predicates.length; i < n; i++) {
                if (predicates[i](value, ...args)) {
                    return true;
                }
            }
            return false;
        };
    }
    Predicate.or = or;
    function xor(...predicates) {
        return and(or(...predicates), not(and(...predicates)));
    }
    Predicate.xor = xor;
    function nor(...predicates) {
        return not(or(...predicates));
    }
    Predicate.nor = nor;
    function nand(...predicates) {
        return not(and(...predicates));
    }
    Predicate.nand = nand;
    function equals(...values) {
        return (other) => values.some((value) => _siteimprove_alfa_equatable__WEBPACK_IMPORTED_MODULE_0__.Equatable.equals(other, value));
    }
    Predicate.equals = equals;
    function property(property, predicate) {
        return (value, ...args) => predicate(value[property], ...args);
    }
    Predicate.property = property;
    function tee(predicate, callback) {
        return (value, ...args) => {
            const result = predicate(value, ...args);
            callback(value, result, ...args);
            return result;
        };
    }
    Predicate.tee = tee;
})(Predicate || (Predicate = {}));
//# sourceMappingURL=predicate.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-refinement/dist/index.js":
/*!*****************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-refinement/dist/index.js ***!
  \*****************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Refinement: () => (/* reexport safe */ _refinement_js__WEBPACK_IMPORTED_MODULE_0__.Refinement)
/* harmony export */ });
/* harmony import */ var _refinement_js__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./refinement.js */ "./node_modules/@siteimprove/alfa-refinement/dist/refinement.js");

//# sourceMappingURL=index.js.map

/***/ }),

/***/ "./node_modules/@siteimprove/alfa-refinement/dist/refinement.js":
/*!**********************************************************************!*\
  !*** ./node_modules/@siteimprove/alfa-refinement/dist/refinement.js ***!
  \**********************************************************************/
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   Refinement: () => (/* binding */ Refinement)
/* harmony export */ });
/* harmony import */ var _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-predicate */ "./node_modules/@siteimprove/alfa-predicate/dist/index.js");

/**
 * @public
 */
var Refinement;
(function (Refinement) {
    Refinement.test = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_0__.Predicate.test;
    Refinement.fold = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_0__.Predicate.fold;
    Refinement.not = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_0__.Predicate.not;
    Refinement.and = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_0__.Predicate.and;
    Refinement.or = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_0__.Predicate.or;
    Refinement.xor = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_0__.Predicate.xor;
    Refinement.nor = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_0__.Predicate.nor;
    Refinement.nand = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_0__.Predicate.nand;
    Refinement.equals = _siteimprove_alfa_predicate__WEBPACK_IMPORTED_MODULE_0__.Predicate.equals;
    function isString(value) {
        return typeof value === "string";
    }
    Refinement.isString = isString;
    function isNumber(value) {
        return typeof value === "number";
    }
    Refinement.isNumber = isNumber;
    function isBigInt(value) {
        return typeof value === "bigint";
    }
    Refinement.isBigInt = isBigInt;
    function isBoolean(value) {
        return typeof value === "boolean";
    }
    Refinement.isBoolean = isBoolean;
    function isNull(value) {
        return value === null;
    }
    Refinement.isNull = isNull;
    function isUndefined(value) {
        return value === undefined;
    }
    Refinement.isUndefined = isUndefined;
    function isSymbol(value) {
        return typeof value === "symbol";
    }
    Refinement.isSymbol = isSymbol;
    function isFunction(value) {
        return typeof value === "function";
    }
    Refinement.isFunction = isFunction;
    function isObject(value) {
        return typeof value === "object" && value !== null;
    }
    Refinement.isObject = isObject;
    Refinement.isPrimitive = Refinement.or(isString, Refinement.or(isNumber, Refinement.or(isBigInt, Refinement.or(isBoolean, Refinement.or(isNull, Refinement.or(isUndefined, isSymbol))))));
})(Refinement || (Refinement = {}));
//# sourceMappingURL=refinement.js.map

/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/compat get default export */
/******/ 	(() => {
/******/ 		// getDefaultExport function for compatibility with non-harmony modules
/******/ 		__webpack_require__.n = (module) => {
/******/ 			var getter = module && module.__esModule ?
/******/ 				() => (module['default']) :
/******/ 				() => (module);
/******/ 			__webpack_require__.d(getter, { a: getter });
/******/ 			return getter;
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be in strict mode.
(() => {
"use strict";
/*!************************!*\
  !*** ./src/api/api.ts ***!
  \************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _siteimprove_alfa_map__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @siteimprove/alfa-map */ "./node_modules/@siteimprove/alfa-map/dist/index.js");
/* harmony import */ var _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @siteimprove/alfa-option */ "./node_modules/@siteimprove/alfa-option/dist/index.js");
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! webextension-polyfill */ "./node_modules/webextension-polyfill/dist/browser-polyfill.js");
/* harmony import */ var webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(webextension_polyfill__WEBPACK_IMPORTED_MODULE_2__);
/**
 * This is the main entry point to what we refer to as the API of the extension.
 * The API handles most interactions with Alfa, the browser, and the page being
 * tested and exposes an interface for the application code to call through
 * messaging.
 *
 * The API is run as a possibly non-persistent background script (or service
 * worker, depending on browsers) in the browser.
 * It must therefore not depend on any global state as such state will be lost
 * when the background script is unloaded.
 *
 * Notably, this forces the popup to connect directly to the devtools instance
 * of the inspected page; and this forces the popup map to be stored in local
 * storage.
 */





/**
 * Storage keys
 */
const POPUP_KEY = "popupsMap";

/**
 * Map from tabId to open popup.
 *
 * @remarks
 * Every listener will reload the popups map, to make sure it is up-to-date.
 * Listeners that update it also save it.
 * When clicking the extension button, we also take time to clean it, in case
 * anything bad happened at some point.
 */

let myPopups = _siteimprove_alfa_map__WEBPACK_IMPORTED_MODULE_0__.Map.empty();
async function loadPopupsMap() {
  const popups = await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().storage.local.get(POPUP_KEY);
  myPopups = _siteimprove_alfa_map__WEBPACK_IMPORTED_MODULE_0__.Map.from(popups?.[POPUP_KEY] ?? []);
}
async function savePopupsMap() {
  await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().storage.local.set({
    [POPUP_KEY]: myPopups.toArray()
  });
}
async function windowExists(windowId) {
  if (windowId === undefined) {
    return false;
  }
  try {
    await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().windows.get(windowId);
    return true;
  } catch (e) {
    // We assume errors mostly occur due to non-existent window.
    return false;
  }
}

/**
 * Remove entries with no corresponding opened window
 *
 * @remarks
 * This should not happen since the service worker should restart and clean
 * the map on window removed. This is however not expensive because we assume
 * the map will be small; and this prevents a possible vector of memory leak
 * since this is persistent storage and we have requested unlimited storage
 * permission.
 */
async function cleanPopupsMap() {
  let existing = _siteimprove_alfa_map__WEBPACK_IMPORTED_MODULE_0__.Map.empty();
  for (const [tabId, popup] of myPopups) {
    if (await windowExists(popup.windowId)) {
      existing = existing.set(tabId, popup);
    }
  }
  myPopups = existing;
}

/**
 * Cleanup popup-map when a popup window is closed.
 *
 * @remarks
 * This is triggered by the other listeners closing popup windows.
 */
webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().windows.onRemoved.addListener(async windowId => {
  await loadPopupsMap();
  let key = _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_1__.None;
  myPopups.find((popup, tabId) => {
    if (popup.windowId === windowId) {
      key = _siteimprove_alfa_option__WEBPACK_IMPORTED_MODULE_1__.Option.of(tabId);
      return true;
    }
    return false;
  });
  key.forEach(key => myPopups = myPopups.delete(key));
  await savePopupsMap();
});

/**
 * Close popup if user navigate to another page.
 */
webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().tabs.onUpdated.addListener(async tabId => {
  await loadPopupsMap();
  const currentPopup = myPopups.get(tabId).getOr(undefined);
  if (currentPopup?.windowId) {
    // Close the popup if the url changes
    const tab = await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().tabs.get(tabId);
    if (currentPopup?.url !== tab.url && navigator.userAgent.indexOf("Firefox") === -1) {
      await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().windows.remove(currentPopup.windowId);
    }
  }
});

/**
 * Close popup if the audited tab is closed.
 */
webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().tabs.onRemoved.addListener(async tabId => {
  await loadPopupsMap();
  const currentPopup = myPopups.get(tabId).getOr(undefined);
  if (currentPopup?.windowId) {
    // Close the popup if the tab is closed
    await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().windows.remove(currentPopup.windowId);
  }
});

/**
 * Open popup when icon is clicked.
 * If the popup is open, close it.
 */
webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().action.onClicked.addListener(async tab => {
  // Bail out immediately if we cannot get a tabId
  if (!tab.id) {
    return;
  }
  await loadPopupsMap();
  await cleanPopupsMap();

  // If the current tab already has an extension popup, close the popup.
  const currentPopup = myPopups.get(tab.id).getOr(undefined);
  if (currentPopup?.windowId) {
    await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().windows.remove(currentPopup.windowId);
    return;
  }

  // Otherwise, open a new popup.
  const popupUrl = new URL(webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().runtime.getURL("app.html"));

  /**
   * Pass along the tab ID as a query parameter. The application code uses this
   * when making API calls.
   */
  popupUrl.searchParams.set("tabId", tab.id?.toString(10) || "");
  const popup = await webextension_polyfill__WEBPACK_IMPORTED_MODULE_2___default().windows.create({
    url: popupUrl.toString(),
    type: "panel",
    height: 600,
    width: 800
  });
  myPopups = myPopups.set(tab.id, {
    windowId: popup.id,
    url: tab.url
  });
  await savePopupsMap();
});
})();

/******/ 	return __webpack_exports__;
/******/ })()
;
});
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXBpLmpzIiwibWFwcGluZ3MiOiJBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7OztBQ1ZBO0FBQ0E7QUFDQTtBQUFBO0FBQUE7QUFBQTtBQUNBO0FBU0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwdkNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7O0FDbFZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUNQQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7O0FDTkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDL0NBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7OztBQ0RBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUNWQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7OztBQ0RBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7QUNoSkE7QUFDQTs7Ozs7Ozs7Ozs7Ozs7O0FDREE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDZEE7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7OztBQ0hBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7O0FDckRBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDL0NBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7O0FDRkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDbERBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUM3QkE7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDaE5BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNaQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUNGQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7QUNoaUJBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ1BBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7OztBQ0ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDZkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQzlDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQ0ZBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbE9BO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7OztBQ3RUQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDbkVBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUNKQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUNYQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUNwR0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FDakNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUNsSUE7QUFDQTs7Ozs7Ozs7Ozs7Ozs7OztBQ0RBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDckVBO0FBQ0E7Ozs7Ozs7Ozs7Ozs7Ozs7QUNEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7OztBQ3JEQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7Ozs7QUN2QkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7Ozs7QUNQQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7OztBQ1BBOzs7OztBQ0FBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOzs7Ozs7Ozs7Ozs7Ozs7O0FDTkE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQSIsInNvdXJjZXMiOlsid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vd2VicGFjay91bml2ZXJzYWxNb2R1bGVEZWZpbml0aW9uIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvd2ViZXh0ZW5zaW9uLXBvbHlmaWxsL2Rpc3QvYnJvd3Nlci1wb2x5ZmlsbC5qcyIsIndlYnBhY2s6Ly9Ac2l0ZWltcHJvdmUvYWxmYS13ZWItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLWFycmF5L2Rpc3QvYXJyYXkuanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1hcnJheS9kaXN0L2J1aWx0aW4uanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1hcnJheS9kaXN0L2luZGV4LmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtYml0cy9kaXN0L2JpdHMuanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1iaXRzL2Rpc3QvaW5kZXguanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1jbG9uZS9kaXN0L2Nsb25lLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtY2xvbmUvZGlzdC9pbmRleC5qcyIsIndlYnBhY2s6Ly9Ac2l0ZWltcHJvdmUvYWxmYS13ZWItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLWNvbXBhcmFibGUvZGlzdC9jb21wYXJhYmxlLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtY29tcGFyYWJsZS9kaXN0L2NvbXBhcmVyLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtY29tcGFyYWJsZS9kaXN0L2NvbXBhcmlzb24uanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1jb21wYXJhYmxlL2Rpc3QvaW5kZXguanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1lbmNvZGluZy9kaXN0L2RlY29kZXIuanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1lbmNvZGluZy9kaXN0L2VuY29kZXIuanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1lbmNvZGluZy9kaXN0L2luZGV4LmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtZXF1YXRhYmxlL2Rpc3QvZXF1YXRhYmxlLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtZXF1YXRhYmxlL2Rpc3QvaW5kZXguanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1mbnYvZGlzdC9mbnYuanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1mbnYvZGlzdC9pbmRleC5qcyIsIndlYnBhY2s6Ly9Ac2l0ZWltcHJvdmUvYWxmYS13ZWItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLWhhc2gvZGlzdC9oYXNoLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtaGFzaC9kaXN0L2hhc2hhYmxlLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtaGFzaC9kaXN0L2luZGV4LmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtaXRlcmFibGUvZGlzdC9pbmRleC5qcyIsIndlYnBhY2s6Ly9Ac2l0ZWltcHJvdmUvYWxmYS13ZWItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLWl0ZXJhYmxlL2Rpc3QvaXRlcmFibGUuanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1qc29uL2Rpc3QvYnVpbHRpbi5qcyIsIndlYnBhY2s6Ly9Ac2l0ZWltcHJvdmUvYWxmYS13ZWItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLWpzb24vZGlzdC9pbmRleC5qcyIsIndlYnBhY2s6Ly9Ac2l0ZWltcHJvdmUvYWxmYS13ZWItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLWpzb24vZGlzdC9qc29uLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtanNvbi9kaXN0L3NlcmlhbGl6YWJsZS5qcyIsIndlYnBhY2s6Ly9Ac2l0ZWltcHJvdmUvYWxmYS13ZWItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLW1hcC9kaXN0L2luZGV4LmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtbWFwL2Rpc3QvbWFwLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtbWFwL2Rpc3Qvbm9kZS5qcyIsIndlYnBhY2s6Ly9Ac2l0ZWltcHJvdmUvYWxmYS13ZWItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLW1hcC9kaXN0L3N0YXR1cy5qcyIsIndlYnBhY2s6Ly9Ac2l0ZWltcHJvdmUvYWxmYS13ZWItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLW9wdGlvbi9kaXN0L2luZGV4LmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtb3B0aW9uL2Rpc3QvbWF5YmUuanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL25vZGVfbW9kdWxlcy9Ac2l0ZWltcHJvdmUvYWxmYS1vcHRpb24vZGlzdC9ub25lLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtb3B0aW9uL2Rpc3Qvb3B0aW9uLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtb3B0aW9uL2Rpc3Qvc29tZS5qcyIsIndlYnBhY2s6Ly9Ac2l0ZWltcHJvdmUvYWxmYS13ZWItZXh0ZW5zaW9uLy4vbm9kZV9tb2R1bGVzL0BzaXRlaW1wcm92ZS9hbGZhLXByZWRpY2F0ZS9kaXN0L2luZGV4LmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtcHJlZGljYXRlL2Rpc3QvcHJlZGljYXRlLmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtcmVmaW5lbWVudC9kaXN0L2luZGV4LmpzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vLi9ub2RlX21vZHVsZXMvQHNpdGVpbXByb3ZlL2FsZmEtcmVmaW5lbWVudC9kaXN0L3JlZmluZW1lbnQuanMiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi93ZWJwYWNrL2Jvb3RzdHJhcCIsIndlYnBhY2s6Ly9Ac2l0ZWltcHJvdmUvYWxmYS13ZWItZXh0ZW5zaW9uL3dlYnBhY2svcnVudGltZS9jb21wYXQgZ2V0IGRlZmF1bHQgZXhwb3J0Iiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vd2VicGFjay9ydW50aW1lL2RlZmluZSBwcm9wZXJ0eSBnZXR0ZXJzIiwid2VicGFjazovL0BzaXRlaW1wcm92ZS9hbGZhLXdlYi1leHRlbnNpb24vd2VicGFjay9ydW50aW1lL2hhc093blByb3BlcnR5IHNob3J0aGFuZCIsIndlYnBhY2s6Ly9Ac2l0ZWltcHJvdmUvYWxmYS13ZWItZXh0ZW5zaW9uL3dlYnBhY2svcnVudGltZS9tYWtlIG5hbWVzcGFjZSBvYmplY3QiLCJ3ZWJwYWNrOi8vQHNpdGVpbXByb3ZlL2FsZmEtd2ViLWV4dGVuc2lvbi8uL3NyYy9hcGkvYXBpLnRzIl0sInNvdXJjZXNDb250ZW50IjpbIihmdW5jdGlvbiB3ZWJwYWNrVW5pdmVyc2FsTW9kdWxlRGVmaW5pdGlvbihyb290LCBmYWN0b3J5KSB7XG5cdGlmKHR5cGVvZiBleHBvcnRzID09PSAnb2JqZWN0JyAmJiB0eXBlb2YgbW9kdWxlID09PSAnb2JqZWN0Jylcblx0XHRtb2R1bGUuZXhwb3J0cyA9IGZhY3RvcnkoKTtcblx0ZWxzZSBpZih0eXBlb2YgZGVmaW5lID09PSAnZnVuY3Rpb24nICYmIGRlZmluZS5hbWQpXG5cdFx0ZGVmaW5lKFtdLCBmYWN0b3J5KTtcblx0ZWxzZSB7XG5cdFx0dmFyIGEgPSBmYWN0b3J5KCk7XG5cdFx0Zm9yKHZhciBpIGluIGEpICh0eXBlb2YgZXhwb3J0cyA9PT0gJ29iamVjdCcgPyBleHBvcnRzIDogcm9vdClbaV0gPSBhW2ldO1xuXHR9XG59KShzZWxmLCAoKSA9PiB7XG5yZXR1cm4gIiwiKGZ1bmN0aW9uIChnbG9iYWwsIGZhY3RvcnkpIHtcbiAgaWYgKHR5cGVvZiBkZWZpbmUgPT09IFwiZnVuY3Rpb25cIiAmJiBkZWZpbmUuYW1kKSB7XG4gICAgZGVmaW5lKFwid2ViZXh0ZW5zaW9uLXBvbHlmaWxsXCIsIFtcIm1vZHVsZVwiXSwgZmFjdG9yeSk7XG4gIH0gZWxzZSBpZiAodHlwZW9mIGV4cG9ydHMgIT09IFwidW5kZWZpbmVkXCIpIHtcbiAgICBmYWN0b3J5KG1vZHVsZSk7XG4gIH0gZWxzZSB7XG4gICAgdmFyIG1vZCA9IHtcbiAgICAgIGV4cG9ydHM6IHt9XG4gICAgfTtcbiAgICBmYWN0b3J5KG1vZCk7XG4gICAgZ2xvYmFsLmJyb3dzZXIgPSBtb2QuZXhwb3J0cztcbiAgfVxufSkodHlwZW9mIGdsb2JhbFRoaXMgIT09IFwidW5kZWZpbmVkXCIgPyBnbG9iYWxUaGlzIDogdHlwZW9mIHNlbGYgIT09IFwidW5kZWZpbmVkXCIgPyBzZWxmIDogdGhpcywgZnVuY3Rpb24gKG1vZHVsZSkge1xuICAvKiB3ZWJleHRlbnNpb24tcG9seWZpbGwgLSB2MC4xMC4wIC0gRnJpIEF1ZyAxMiAyMDIyIDE5OjQyOjQ0ICovXG5cbiAgLyogLSotIE1vZGU6IGluZGVudC10YWJzLW1vZGU6IG5pbDsganMtaW5kZW50LWxldmVsOiAyIC0qLSAqL1xuXG4gIC8qIHZpbTogc2V0IHN0cz0yIHN3PTIgZXQgdHc9ODA6ICovXG5cbiAgLyogVGhpcyBTb3VyY2UgQ29kZSBGb3JtIGlzIHN1YmplY3QgdG8gdGhlIHRlcm1zIG9mIHRoZSBNb3ppbGxhIFB1YmxpY1xuICAgKiBMaWNlbnNlLCB2LiAyLjAuIElmIGEgY29weSBvZiB0aGUgTVBMIHdhcyBub3QgZGlzdHJpYnV0ZWQgd2l0aCB0aGlzXG4gICAqIGZpbGUsIFlvdSBjYW4gb2J0YWluIG9uZSBhdCBodHRwOi8vbW96aWxsYS5vcmcvTVBMLzIuMC8uICovXG4gIFwidXNlIHN0cmljdFwiO1xuXG4gIGlmICghZ2xvYmFsVGhpcy5jaHJvbWU/LnJ1bnRpbWU/LmlkKSB7XG4gICAgdGhyb3cgbmV3IEVycm9yKFwiVGhpcyBzY3JpcHQgc2hvdWxkIG9ubHkgYmUgbG9hZGVkIGluIGEgYnJvd3NlciBleHRlbnNpb24uXCIpO1xuICB9XG5cbiAgaWYgKHR5cGVvZiBnbG9iYWxUaGlzLmJyb3dzZXIgPT09IFwidW5kZWZpbmVkXCIgfHwgT2JqZWN0LmdldFByb3RvdHlwZU9mKGdsb2JhbFRoaXMuYnJvd3NlcikgIT09IE9iamVjdC5wcm90b3R5cGUpIHtcbiAgICBjb25zdCBDSFJPTUVfU0VORF9NRVNTQUdFX0NBTExCQUNLX05PX1JFU1BPTlNFX01FU1NBR0UgPSBcIlRoZSBtZXNzYWdlIHBvcnQgY2xvc2VkIGJlZm9yZSBhIHJlc3BvbnNlIHdhcyByZWNlaXZlZC5cIjsgLy8gV3JhcHBpbmcgdGhlIGJ1bGsgb2YgdGhpcyBwb2x5ZmlsbCBpbiBhIG9uZS10aW1lLXVzZSBmdW5jdGlvbiBpcyBhIG1pbm9yXG4gICAgLy8gb3B0aW1pemF0aW9uIGZvciBGaXJlZm94LiBTaW5jZSBTcGlkZXJtb25rZXkgZG9lcyBub3QgZnVsbHkgcGFyc2UgdGhlXG4gICAgLy8gY29udGVudHMgb2YgYSBmdW5jdGlvbiB1bnRpbCB0aGUgZmlyc3QgdGltZSBpdCdzIGNhbGxlZCwgYW5kIHNpbmNlIGl0IHdpbGxcbiAgICAvLyBuZXZlciBhY3R1YWxseSBuZWVkIHRvIGJlIGNhbGxlZCwgdGhpcyBhbGxvd3MgdGhlIHBvbHlmaWxsIHRvIGJlIGluY2x1ZGVkXG4gICAgLy8gaW4gRmlyZWZveCBuZWFybHkgZm9yIGZyZWUuXG5cbiAgICBjb25zdCB3cmFwQVBJcyA9IGV4dGVuc2lvbkFQSXMgPT4ge1xuICAgICAgLy8gTk9URTogYXBpTWV0YWRhdGEgaXMgYXNzb2NpYXRlZCB0byB0aGUgY29udGVudCBvZiB0aGUgYXBpLW1ldGFkYXRhLmpzb24gZmlsZVxuICAgICAgLy8gYXQgYnVpbGQgdGltZSBieSByZXBsYWNpbmcgdGhlIGZvbGxvd2luZyBcImluY2x1ZGVcIiB3aXRoIHRoZSBjb250ZW50IG9mIHRoZVxuICAgICAgLy8gSlNPTiBmaWxlLlxuICAgICAgY29uc3QgYXBpTWV0YWRhdGEgPSB7XG4gICAgICAgIFwiYWxhcm1zXCI6IHtcbiAgICAgICAgICBcImNsZWFyXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiY2xlYXJBbGxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRBbGxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJib29rbWFya3NcIjoge1xuICAgICAgICAgIFwiY3JlYXRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0Q2hpbGRyZW5cIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRSZWNlbnRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRTdWJUcmVlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0VHJlZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcIm1vdmVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVUcmVlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2VhcmNoXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwidXBkYXRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiYnJvd3NlckFjdGlvblwiOiB7XG4gICAgICAgICAgXCJkaXNhYmxlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZW5hYmxlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0QmFkZ2VCYWNrZ3JvdW5kQ29sb3JcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRCYWRnZVRleHRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRQb3B1cFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFRpdGxlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwib3BlblBvcHVwXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0QmFkZ2VCYWNrZ3JvdW5kQ29sb3JcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRCYWRnZVRleHRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRJY29uXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0UG9wdXBcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRUaXRsZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImJyb3dzaW5nRGF0YVwiOiB7XG4gICAgICAgICAgXCJyZW1vdmVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMlxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVDYWNoZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZUNvb2tpZXNcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVEb3dubG9hZHNcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVGb3JtRGF0YVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZUhpc3RvcnlcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVMb2NhbFN0b3JhZ2VcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVQYXNzd29yZHNcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVQbHVnaW5EYXRhXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0dGluZ3NcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJjb21tYW5kc1wiOiB7XG4gICAgICAgICAgXCJnZXRBbGxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJjb250ZXh0TWVudXNcIjoge1xuICAgICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlQWxsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwidXBkYXRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiY29va2llc1wiOiB7XG4gICAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRBbGxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRBbGxDb29raWVTdG9yZXNcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZW1vdmVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJkZXZ0b29sc1wiOiB7XG4gICAgICAgICAgXCJpbnNwZWN0ZWRXaW5kb3dcIjoge1xuICAgICAgICAgICAgXCJldmFsXCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyLFxuICAgICAgICAgICAgICBcInNpbmdsZUNhbGxiYWNrQXJnXCI6IGZhbHNlXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInBhbmVsc1wiOiB7XG4gICAgICAgICAgICBcImNyZWF0ZVwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAzLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMyxcbiAgICAgICAgICAgICAgXCJzaW5nbGVDYWxsYmFja0FyZ1wiOiB0cnVlXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJlbGVtZW50c1wiOiB7XG4gICAgICAgICAgICAgIFwiY3JlYXRlU2lkZWJhclBhbmVcIjoge1xuICAgICAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiZG93bmxvYWRzXCI6IHtcbiAgICAgICAgICBcImNhbmNlbFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImRvd25sb2FkXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZXJhc2VcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRGaWxlSWNvblwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcIm9wZW5cIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwiZmFsbGJhY2tUb05vQ2FsbGJhY2tcIjogdHJ1ZVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJwYXVzZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInJlbW92ZUZpbGVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZXN1bWVcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZWFyY2hcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzaG93XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiZXh0ZW5zaW9uXCI6IHtcbiAgICAgICAgICBcImlzQWxsb3dlZEZpbGVTY2hlbWVBY2Nlc3NcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJpc0FsbG93ZWRJbmNvZ25pdG9BY2Nlc3NcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJoaXN0b3J5XCI6IHtcbiAgICAgICAgICBcImFkZFVybFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImRlbGV0ZUFsbFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImRlbGV0ZVJhbmdlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZGVsZXRlVXJsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0VmlzaXRzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2VhcmNoXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiaTE4blwiOiB7XG4gICAgICAgICAgXCJkZXRlY3RMYW5ndWFnZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEFjY2VwdExhbmd1YWdlc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcImlkZW50aXR5XCI6IHtcbiAgICAgICAgICBcImxhdW5jaFdlYkF1dGhGbG93XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwiaWRsZVwiOiB7XG4gICAgICAgICAgXCJxdWVyeVN0YXRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwibWFuYWdlbWVudFwiOiB7XG4gICAgICAgICAgXCJnZXRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRBbGxcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRTZWxmXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0RW5hYmxlZFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInVuaW5zdGFsbFNlbGZcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJub3RpZmljYXRpb25zXCI6IHtcbiAgICAgICAgICBcImNsZWFyXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiY3JlYXRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0QWxsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0UGVybWlzc2lvbkxldmVsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwidXBkYXRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwicGFnZUFjdGlvblwiOiB7XG4gICAgICAgICAgXCJnZXRQb3B1cFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFRpdGxlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiaGlkZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldEljb25cIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRQb3B1cFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNldFRpdGxlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDEsXG4gICAgICAgICAgICBcImZhbGxiYWNrVG9Ob0NhbGxiYWNrXCI6IHRydWVcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2hvd1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJmYWxsYmFja1RvTm9DYWxsYmFja1wiOiB0cnVlXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcInBlcm1pc3Npb25zXCI6IHtcbiAgICAgICAgICBcImNvbnRhaW5zXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0QWxsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVxdWVzdFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcInJ1bnRpbWVcIjoge1xuICAgICAgICAgIFwiZ2V0QmFja2dyb3VuZFBhZ2VcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRQbGF0Zm9ybUluZm9cIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJvcGVuT3B0aW9uc1BhZ2VcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJyZXF1ZXN0VXBkYXRlQ2hlY2tcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZW5kTWVzc2FnZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAzXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInNlbmROYXRpdmVNZXNzYWdlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0VW5pbnN0YWxsVVJMXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwic2Vzc2lvbnNcIjoge1xuICAgICAgICAgIFwiZ2V0RGV2aWNlc1wiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFJlY2VudGx5Q2xvc2VkXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVzdG9yZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcInN0b3JhZ2VcIjoge1xuICAgICAgICAgIFwibG9jYWxcIjoge1xuICAgICAgICAgICAgXCJjbGVhclwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJnZXRCeXRlc0luVXNlXCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJyZW1vdmVcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBcInNldFwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJtYW5hZ2VkXCI6IHtcbiAgICAgICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJnZXRCeXRlc0luVXNlXCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInN5bmNcIjoge1xuICAgICAgICAgICAgXCJjbGVhclwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJnZXRCeXRlc0luVXNlXCI6IHtcbiAgICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgICB9LFxuICAgICAgICAgICAgXCJyZW1vdmVcIjoge1xuICAgICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgICBcInNldFwiOiB7XG4gICAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgXCJ0YWJzXCI6IHtcbiAgICAgICAgICBcImNhcHR1cmVWaXNpYmxlVGFiXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiY3JlYXRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZGV0ZWN0TGFuZ3VhZ2VcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJkaXNjYXJkXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZHVwbGljYXRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZXhlY3V0ZVNjcmlwdFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldEN1cnJlbnRcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDAsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRab29tXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0Wm9vbVNldHRpbmdzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ29CYWNrXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ29Gb3J3YXJkXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiaGlnaGxpZ2h0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiaW5zZXJ0Q1NTXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwibW92ZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMixcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAyXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcInF1ZXJ5XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVsb2FkXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlQ1NTXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2VuZE1lc3NhZ2VcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDIsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogM1xuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJzZXRab29tXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwic2V0Wm9vbVNldHRpbmdzXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwidXBkYXRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwidG9wU2l0ZXNcIjoge1xuICAgICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDBcbiAgICAgICAgICB9XG4gICAgICAgIH0sXG4gICAgICAgIFwid2ViTmF2aWdhdGlvblwiOiB7XG4gICAgICAgICAgXCJnZXRBbGxGcmFtZXNcIjoge1xuICAgICAgICAgICAgXCJtaW5BcmdzXCI6IDEsXG4gICAgICAgICAgICBcIm1heEFyZ3NcIjogMVxuICAgICAgICAgIH0sXG4gICAgICAgICAgXCJnZXRGcmFtZVwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMSxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcIndlYlJlcXVlc3RcIjoge1xuICAgICAgICAgIFwiaGFuZGxlckJlaGF2aW9yQ2hhbmdlZFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAwXG4gICAgICAgICAgfVxuICAgICAgICB9LFxuICAgICAgICBcIndpbmRvd3NcIjoge1xuICAgICAgICAgIFwiY3JlYXRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0XCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0QWxsXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwiZ2V0Q3VycmVudFwiOiB7XG4gICAgICAgICAgICBcIm1pbkFyZ3NcIjogMCxcbiAgICAgICAgICAgIFwibWF4QXJnc1wiOiAxXG4gICAgICAgICAgfSxcbiAgICAgICAgICBcImdldExhc3RGb2N1c2VkXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAwLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwicmVtb3ZlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAxLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDFcbiAgICAgICAgICB9LFxuICAgICAgICAgIFwidXBkYXRlXCI6IHtcbiAgICAgICAgICAgIFwibWluQXJnc1wiOiAyLFxuICAgICAgICAgICAgXCJtYXhBcmdzXCI6IDJcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH07XG5cbiAgICAgIGlmIChPYmplY3Qua2V5cyhhcGlNZXRhZGF0YSkubGVuZ3RoID09PSAwKSB7XG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcImFwaS1tZXRhZGF0YS5qc29uIGhhcyBub3QgYmVlbiBpbmNsdWRlZCBpbiBicm93c2VyLXBvbHlmaWxsXCIpO1xuICAgICAgfVxuICAgICAgLyoqXG4gICAgICAgKiBBIFdlYWtNYXAgc3ViY2xhc3Mgd2hpY2ggY3JlYXRlcyBhbmQgc3RvcmVzIGEgdmFsdWUgZm9yIGFueSBrZXkgd2hpY2ggZG9lc1xuICAgICAgICogbm90IGV4aXN0IHdoZW4gYWNjZXNzZWQsIGJ1dCBiZWhhdmVzIGV4YWN0bHkgYXMgYW4gb3JkaW5hcnkgV2Vha01hcFxuICAgICAgICogb3RoZXJ3aXNlLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7ZnVuY3Rpb259IGNyZWF0ZUl0ZW1cbiAgICAgICAqICAgICAgICBBIGZ1bmN0aW9uIHdoaWNoIHdpbGwgYmUgY2FsbGVkIGluIG9yZGVyIHRvIGNyZWF0ZSB0aGUgdmFsdWUgZm9yIGFueVxuICAgICAgICogICAgICAgIGtleSB3aGljaCBkb2VzIG5vdCBleGlzdCwgdGhlIGZpcnN0IHRpbWUgaXQgaXMgYWNjZXNzZWQuIFRoZVxuICAgICAgICogICAgICAgIGZ1bmN0aW9uIHJlY2VpdmVzLCBhcyBpdHMgb25seSBhcmd1bWVudCwgdGhlIGtleSBiZWluZyBjcmVhdGVkLlxuICAgICAgICovXG5cblxuICAgICAgY2xhc3MgRGVmYXVsdFdlYWtNYXAgZXh0ZW5kcyBXZWFrTWFwIHtcbiAgICAgICAgY29uc3RydWN0b3IoY3JlYXRlSXRlbSwgaXRlbXMgPSB1bmRlZmluZWQpIHtcbiAgICAgICAgICBzdXBlcihpdGVtcyk7XG4gICAgICAgICAgdGhpcy5jcmVhdGVJdGVtID0gY3JlYXRlSXRlbTtcbiAgICAgICAgfVxuXG4gICAgICAgIGdldChrZXkpIHtcbiAgICAgICAgICBpZiAoIXRoaXMuaGFzKGtleSkpIHtcbiAgICAgICAgICAgIHRoaXMuc2V0KGtleSwgdGhpcy5jcmVhdGVJdGVtKGtleSkpO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHJldHVybiBzdXBlci5nZXQoa2V5KTtcbiAgICAgICAgfVxuXG4gICAgICB9XG4gICAgICAvKipcbiAgICAgICAqIFJldHVybnMgdHJ1ZSBpZiB0aGUgZ2l2ZW4gb2JqZWN0IGlzIGFuIG9iamVjdCB3aXRoIGEgYHRoZW5gIG1ldGhvZCwgYW5kIGNhblxuICAgICAgICogdGhlcmVmb3JlIGJlIGFzc3VtZWQgdG8gYmVoYXZlIGFzIGEgUHJvbWlzZS5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0geyp9IHZhbHVlIFRoZSB2YWx1ZSB0byB0ZXN0LlxuICAgICAgICogQHJldHVybnMge2Jvb2xlYW59IFRydWUgaWYgdGhlIHZhbHVlIGlzIHRoZW5hYmxlLlxuICAgICAgICovXG5cblxuICAgICAgY29uc3QgaXNUaGVuYWJsZSA9IHZhbHVlID0+IHtcbiAgICAgICAgcmV0dXJuIHZhbHVlICYmIHR5cGVvZiB2YWx1ZSA9PT0gXCJvYmplY3RcIiAmJiB0eXBlb2YgdmFsdWUudGhlbiA9PT0gXCJmdW5jdGlvblwiO1xuICAgICAgfTtcbiAgICAgIC8qKlxuICAgICAgICogQ3JlYXRlcyBhbmQgcmV0dXJucyBhIGZ1bmN0aW9uIHdoaWNoLCB3aGVuIGNhbGxlZCwgd2lsbCByZXNvbHZlIG9yIHJlamVjdFxuICAgICAgICogdGhlIGdpdmVuIHByb21pc2UgYmFzZWQgb24gaG93IGl0IGlzIGNhbGxlZDpcbiAgICAgICAqXG4gICAgICAgKiAtIElmLCB3aGVuIGNhbGxlZCwgYGNocm9tZS5ydW50aW1lLmxhc3RFcnJvcmAgY29udGFpbnMgYSBub24tbnVsbCBvYmplY3QsXG4gICAgICAgKiAgIHRoZSBwcm9taXNlIGlzIHJlamVjdGVkIHdpdGggdGhhdCB2YWx1ZS5cbiAgICAgICAqIC0gSWYgdGhlIGZ1bmN0aW9uIGlzIGNhbGxlZCB3aXRoIGV4YWN0bHkgb25lIGFyZ3VtZW50LCB0aGUgcHJvbWlzZSBpc1xuICAgICAgICogICByZXNvbHZlZCB0byB0aGF0IHZhbHVlLlxuICAgICAgICogLSBPdGhlcndpc2UsIHRoZSBwcm9taXNlIGlzIHJlc29sdmVkIHRvIGFuIGFycmF5IGNvbnRhaW5pbmcgYWxsIG9mIHRoZVxuICAgICAgICogICBmdW5jdGlvbidzIGFyZ3VtZW50cy5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge29iamVjdH0gcHJvbWlzZVxuICAgICAgICogICAgICAgIEFuIG9iamVjdCBjb250YWluaW5nIHRoZSByZXNvbHV0aW9uIGFuZCByZWplY3Rpb24gZnVuY3Rpb25zIG9mIGFcbiAgICAgICAqICAgICAgICBwcm9taXNlLlxuICAgICAgICogQHBhcmFtIHtmdW5jdGlvbn0gcHJvbWlzZS5yZXNvbHZlXG4gICAgICAgKiAgICAgICAgVGhlIHByb21pc2UncyByZXNvbHV0aW9uIGZ1bmN0aW9uLlxuICAgICAgICogQHBhcmFtIHtmdW5jdGlvbn0gcHJvbWlzZS5yZWplY3RcbiAgICAgICAqICAgICAgICBUaGUgcHJvbWlzZSdzIHJlamVjdGlvbiBmdW5jdGlvbi5cbiAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSBtZXRhZGF0YVxuICAgICAgICogICAgICAgIE1ldGFkYXRhIGFib3V0IHRoZSB3cmFwcGVkIG1ldGhvZCB3aGljaCBoYXMgY3JlYXRlZCB0aGUgY2FsbGJhY2suXG4gICAgICAgKiBAcGFyYW0ge2Jvb2xlYW59IG1ldGFkYXRhLnNpbmdsZUNhbGxiYWNrQXJnXG4gICAgICAgKiAgICAgICAgV2hldGhlciBvciBub3QgdGhlIHByb21pc2UgaXMgcmVzb2x2ZWQgd2l0aCBvbmx5IHRoZSBmaXJzdFxuICAgICAgICogICAgICAgIGFyZ3VtZW50IG9mIHRoZSBjYWxsYmFjaywgYWx0ZXJuYXRpdmVseSBhbiBhcnJheSBvZiBhbGwgdGhlXG4gICAgICAgKiAgICAgICAgY2FsbGJhY2sgYXJndW1lbnRzIGlzIHJlc29sdmVkLiBCeSBkZWZhdWx0LCBpZiB0aGUgY2FsbGJhY2tcbiAgICAgICAqICAgICAgICBmdW5jdGlvbiBpcyBpbnZva2VkIHdpdGggb25seSBhIHNpbmdsZSBhcmd1bWVudCwgdGhhdCB3aWxsIGJlXG4gICAgICAgKiAgICAgICAgcmVzb2x2ZWQgdG8gdGhlIHByb21pc2UsIHdoaWxlIGFsbCBhcmd1bWVudHMgd2lsbCBiZSByZXNvbHZlZCBhc1xuICAgICAgICogICAgICAgIGFuIGFycmF5IGlmIG11bHRpcGxlIGFyZSBnaXZlbi5cbiAgICAgICAqXG4gICAgICAgKiBAcmV0dXJucyB7ZnVuY3Rpb259XG4gICAgICAgKiAgICAgICAgVGhlIGdlbmVyYXRlZCBjYWxsYmFjayBmdW5jdGlvbi5cbiAgICAgICAqL1xuXG5cbiAgICAgIGNvbnN0IG1ha2VDYWxsYmFjayA9IChwcm9taXNlLCBtZXRhZGF0YSkgPT4ge1xuICAgICAgICByZXR1cm4gKC4uLmNhbGxiYWNrQXJncykgPT4ge1xuICAgICAgICAgIGlmIChleHRlbnNpb25BUElzLnJ1bnRpbWUubGFzdEVycm9yKSB7XG4gICAgICAgICAgICBwcm9taXNlLnJlamVjdChuZXcgRXJyb3IoZXh0ZW5zaW9uQVBJcy5ydW50aW1lLmxhc3RFcnJvci5tZXNzYWdlKSk7XG4gICAgICAgICAgfSBlbHNlIGlmIChtZXRhZGF0YS5zaW5nbGVDYWxsYmFja0FyZyB8fCBjYWxsYmFja0FyZ3MubGVuZ3RoIDw9IDEgJiYgbWV0YWRhdGEuc2luZ2xlQ2FsbGJhY2tBcmcgIT09IGZhbHNlKSB7XG4gICAgICAgICAgICBwcm9taXNlLnJlc29sdmUoY2FsbGJhY2tBcmdzWzBdKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcHJvbWlzZS5yZXNvbHZlKGNhbGxiYWNrQXJncyk7XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuICAgICAgfTtcblxuICAgICAgY29uc3QgcGx1cmFsaXplQXJndW1lbnRzID0gbnVtQXJncyA9PiBudW1BcmdzID09IDEgPyBcImFyZ3VtZW50XCIgOiBcImFyZ3VtZW50c1wiO1xuICAgICAgLyoqXG4gICAgICAgKiBDcmVhdGVzIGEgd3JhcHBlciBmdW5jdGlvbiBmb3IgYSBtZXRob2Qgd2l0aCB0aGUgZ2l2ZW4gbmFtZSBhbmQgbWV0YWRhdGEuXG4gICAgICAgKlxuICAgICAgICogQHBhcmFtIHtzdHJpbmd9IG5hbWVcbiAgICAgICAqICAgICAgICBUaGUgbmFtZSBvZiB0aGUgbWV0aG9kIHdoaWNoIGlzIGJlaW5nIHdyYXBwZWQuXG4gICAgICAgKiBAcGFyYW0ge29iamVjdH0gbWV0YWRhdGFcbiAgICAgICAqICAgICAgICBNZXRhZGF0YSBhYm91dCB0aGUgbWV0aG9kIGJlaW5nIHdyYXBwZWQuXG4gICAgICAgKiBAcGFyYW0ge2ludGVnZXJ9IG1ldGFkYXRhLm1pbkFyZ3NcbiAgICAgICAqICAgICAgICBUaGUgbWluaW11bSBudW1iZXIgb2YgYXJndW1lbnRzIHdoaWNoIG11c3QgYmUgcGFzc2VkIHRvIHRoZVxuICAgICAgICogICAgICAgIGZ1bmN0aW9uLiBJZiBjYWxsZWQgd2l0aCBmZXdlciB0aGFuIHRoaXMgbnVtYmVyIG9mIGFyZ3VtZW50cywgdGhlXG4gICAgICAgKiAgICAgICAgd3JhcHBlciB3aWxsIHJhaXNlIGFuIGV4Y2VwdGlvbi5cbiAgICAgICAqIEBwYXJhbSB7aW50ZWdlcn0gbWV0YWRhdGEubWF4QXJnc1xuICAgICAgICogICAgICAgIFRoZSBtYXhpbXVtIG51bWJlciBvZiBhcmd1bWVudHMgd2hpY2ggbWF5IGJlIHBhc3NlZCB0byB0aGVcbiAgICAgICAqICAgICAgICBmdW5jdGlvbi4gSWYgY2FsbGVkIHdpdGggbW9yZSB0aGFuIHRoaXMgbnVtYmVyIG9mIGFyZ3VtZW50cywgdGhlXG4gICAgICAgKiAgICAgICAgd3JhcHBlciB3aWxsIHJhaXNlIGFuIGV4Y2VwdGlvbi5cbiAgICAgICAqIEBwYXJhbSB7Ym9vbGVhbn0gbWV0YWRhdGEuc2luZ2xlQ2FsbGJhY2tBcmdcbiAgICAgICAqICAgICAgICBXaGV0aGVyIG9yIG5vdCB0aGUgcHJvbWlzZSBpcyByZXNvbHZlZCB3aXRoIG9ubHkgdGhlIGZpcnN0XG4gICAgICAgKiAgICAgICAgYXJndW1lbnQgb2YgdGhlIGNhbGxiYWNrLCBhbHRlcm5hdGl2ZWx5IGFuIGFycmF5IG9mIGFsbCB0aGVcbiAgICAgICAqICAgICAgICBjYWxsYmFjayBhcmd1bWVudHMgaXMgcmVzb2x2ZWQuIEJ5IGRlZmF1bHQsIGlmIHRoZSBjYWxsYmFja1xuICAgICAgICogICAgICAgIGZ1bmN0aW9uIGlzIGludm9rZWQgd2l0aCBvbmx5IGEgc2luZ2xlIGFyZ3VtZW50LCB0aGF0IHdpbGwgYmVcbiAgICAgICAqICAgICAgICByZXNvbHZlZCB0byB0aGUgcHJvbWlzZSwgd2hpbGUgYWxsIGFyZ3VtZW50cyB3aWxsIGJlIHJlc29sdmVkIGFzXG4gICAgICAgKiAgICAgICAgYW4gYXJyYXkgaWYgbXVsdGlwbGUgYXJlIGdpdmVuLlxuICAgICAgICpcbiAgICAgICAqIEByZXR1cm5zIHtmdW5jdGlvbihvYmplY3QsIC4uLiopfVxuICAgICAgICogICAgICAgVGhlIGdlbmVyYXRlZCB3cmFwcGVyIGZ1bmN0aW9uLlxuICAgICAgICovXG5cblxuICAgICAgY29uc3Qgd3JhcEFzeW5jRnVuY3Rpb24gPSAobmFtZSwgbWV0YWRhdGEpID0+IHtcbiAgICAgICAgcmV0dXJuIGZ1bmN0aW9uIGFzeW5jRnVuY3Rpb25XcmFwcGVyKHRhcmdldCwgLi4uYXJncykge1xuICAgICAgICAgIGlmIChhcmdzLmxlbmd0aCA8IG1ldGFkYXRhLm1pbkFyZ3MpIHtcbiAgICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRXhwZWN0ZWQgYXQgbGVhc3QgJHttZXRhZGF0YS5taW5BcmdzfSAke3BsdXJhbGl6ZUFyZ3VtZW50cyhtZXRhZGF0YS5taW5BcmdzKX0gZm9yICR7bmFtZX0oKSwgZ290ICR7YXJncy5sZW5ndGh9YCk7XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKGFyZ3MubGVuZ3RoID4gbWV0YWRhdGEubWF4QXJncykge1xuICAgICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBFeHBlY3RlZCBhdCBtb3N0ICR7bWV0YWRhdGEubWF4QXJnc30gJHtwbHVyYWxpemVBcmd1bWVudHMobWV0YWRhdGEubWF4QXJncyl9IGZvciAke25hbWV9KCksIGdvdCAke2FyZ3MubGVuZ3RofWApO1xuICAgICAgICAgIH1cblxuICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgICBpZiAobWV0YWRhdGEuZmFsbGJhY2tUb05vQ2FsbGJhY2spIHtcbiAgICAgICAgICAgICAgLy8gVGhpcyBBUEkgbWV0aG9kIGhhcyBjdXJyZW50bHkgbm8gY2FsbGJhY2sgb24gQ2hyb21lLCBidXQgaXQgcmV0dXJuIGEgcHJvbWlzZSBvbiBGaXJlZm94LFxuICAgICAgICAgICAgICAvLyBhbmQgc28gdGhlIHBvbHlmaWxsIHdpbGwgdHJ5IHRvIGNhbGwgaXQgd2l0aCBhIGNhbGxiYWNrIGZpcnN0LCBhbmQgaXQgd2lsbCBmYWxsYmFja1xuICAgICAgICAgICAgICAvLyB0byBub3QgcGFzc2luZyB0aGUgY2FsbGJhY2sgaWYgdGhlIGZpcnN0IGNhbGwgZmFpbHMuXG4gICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgdGFyZ2V0W25hbWVdKC4uLmFyZ3MsIG1ha2VDYWxsYmFjayh7XG4gICAgICAgICAgICAgICAgICByZXNvbHZlLFxuICAgICAgICAgICAgICAgICAgcmVqZWN0XG4gICAgICAgICAgICAgICAgfSwgbWV0YWRhdGEpKTtcbiAgICAgICAgICAgICAgfSBjYXRjaCAoY2JFcnJvcikge1xuICAgICAgICAgICAgICAgIGNvbnNvbGUud2FybihgJHtuYW1lfSBBUEkgbWV0aG9kIGRvZXNuJ3Qgc2VlbSB0byBzdXBwb3J0IHRoZSBjYWxsYmFjayBwYXJhbWV0ZXIsIGAgKyBcImZhbGxpbmcgYmFjayB0byBjYWxsIGl0IHdpdGhvdXQgYSBjYWxsYmFjazogXCIsIGNiRXJyb3IpO1xuICAgICAgICAgICAgICAgIHRhcmdldFtuYW1lXSguLi5hcmdzKTsgLy8gVXBkYXRlIHRoZSBBUEkgbWV0aG9kIG1ldGFkYXRhLCBzbyB0aGF0IHRoZSBuZXh0IEFQSSBjYWxscyB3aWxsIG5vdCB0cnkgdG9cbiAgICAgICAgICAgICAgICAvLyB1c2UgdGhlIHVuc3VwcG9ydGVkIGNhbGxiYWNrIGFueW1vcmUuXG5cbiAgICAgICAgICAgICAgICBtZXRhZGF0YS5mYWxsYmFja1RvTm9DYWxsYmFjayA9IGZhbHNlO1xuICAgICAgICAgICAgICAgIG1ldGFkYXRhLm5vQ2FsbGJhY2sgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHJlc29sdmUoKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfSBlbHNlIGlmIChtZXRhZGF0YS5ub0NhbGxiYWNrKSB7XG4gICAgICAgICAgICAgIHRhcmdldFtuYW1lXSguLi5hcmdzKTtcbiAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgdGFyZ2V0W25hbWVdKC4uLmFyZ3MsIG1ha2VDYWxsYmFjayh7XG4gICAgICAgICAgICAgICAgcmVzb2x2ZSxcbiAgICAgICAgICAgICAgICByZWplY3RcbiAgICAgICAgICAgICAgfSwgbWV0YWRhdGEpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9KTtcbiAgICAgICAgfTtcbiAgICAgIH07XG4gICAgICAvKipcbiAgICAgICAqIFdyYXBzIGFuIGV4aXN0aW5nIG1ldGhvZCBvZiB0aGUgdGFyZ2V0IG9iamVjdCwgc28gdGhhdCBjYWxscyB0byBpdCBhcmVcbiAgICAgICAqIGludGVyY2VwdGVkIGJ5IHRoZSBnaXZlbiB3cmFwcGVyIGZ1bmN0aW9uLiBUaGUgd3JhcHBlciBmdW5jdGlvbiByZWNlaXZlcyxcbiAgICAgICAqIGFzIGl0cyBmaXJzdCBhcmd1bWVudCwgdGhlIG9yaWdpbmFsIGB0YXJnZXRgIG9iamVjdCwgZm9sbG93ZWQgYnkgZWFjaCBvZlxuICAgICAgICogdGhlIGFyZ3VtZW50cyBwYXNzZWQgdG8gdGhlIG9yaWdpbmFsIG1ldGhvZC5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge29iamVjdH0gdGFyZ2V0XG4gICAgICAgKiAgICAgICAgVGhlIG9yaWdpbmFsIHRhcmdldCBvYmplY3QgdGhhdCB0aGUgd3JhcHBlZCBtZXRob2QgYmVsb25ncyB0by5cbiAgICAgICAqIEBwYXJhbSB7ZnVuY3Rpb259IG1ldGhvZFxuICAgICAgICogICAgICAgIFRoZSBtZXRob2QgYmVpbmcgd3JhcHBlZC4gVGhpcyBpcyB1c2VkIGFzIHRoZSB0YXJnZXQgb2YgdGhlIFByb3h5XG4gICAgICAgKiAgICAgICAgb2JqZWN0IHdoaWNoIGlzIGNyZWF0ZWQgdG8gd3JhcCB0aGUgbWV0aG9kLlxuICAgICAgICogQHBhcmFtIHtmdW5jdGlvbn0gd3JhcHBlclxuICAgICAgICogICAgICAgIFRoZSB3cmFwcGVyIGZ1bmN0aW9uIHdoaWNoIGlzIGNhbGxlZCBpbiBwbGFjZSBvZiBhIGRpcmVjdCBpbnZvY2F0aW9uXG4gICAgICAgKiAgICAgICAgb2YgdGhlIHdyYXBwZWQgbWV0aG9kLlxuICAgICAgICpcbiAgICAgICAqIEByZXR1cm5zIHtQcm94eTxmdW5jdGlvbj59XG4gICAgICAgKiAgICAgICAgQSBQcm94eSBvYmplY3QgZm9yIHRoZSBnaXZlbiBtZXRob2QsIHdoaWNoIGludm9rZXMgdGhlIGdpdmVuIHdyYXBwZXJcbiAgICAgICAqICAgICAgICBtZXRob2QgaW4gaXRzIHBsYWNlLlxuICAgICAgICovXG5cblxuICAgICAgY29uc3Qgd3JhcE1ldGhvZCA9ICh0YXJnZXQsIG1ldGhvZCwgd3JhcHBlcikgPT4ge1xuICAgICAgICByZXR1cm4gbmV3IFByb3h5KG1ldGhvZCwge1xuICAgICAgICAgIGFwcGx5KHRhcmdldE1ldGhvZCwgdGhpc09iaiwgYXJncykge1xuICAgICAgICAgICAgcmV0dXJuIHdyYXBwZXIuY2FsbCh0aGlzT2JqLCB0YXJnZXQsIC4uLmFyZ3MpO1xuICAgICAgICAgIH1cblxuICAgICAgICB9KTtcbiAgICAgIH07XG5cbiAgICAgIGxldCBoYXNPd25Qcm9wZXJ0eSA9IEZ1bmN0aW9uLmNhbGwuYmluZChPYmplY3QucHJvdG90eXBlLmhhc093blByb3BlcnR5KTtcbiAgICAgIC8qKlxuICAgICAgICogV3JhcHMgYW4gb2JqZWN0IGluIGEgUHJveHkgd2hpY2ggaW50ZXJjZXB0cyBhbmQgd3JhcHMgY2VydGFpbiBtZXRob2RzXG4gICAgICAgKiBiYXNlZCBvbiB0aGUgZ2l2ZW4gYHdyYXBwZXJzYCBhbmQgYG1ldGFkYXRhYCBvYmplY3RzLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSB0YXJnZXRcbiAgICAgICAqICAgICAgICBUaGUgdGFyZ2V0IG9iamVjdCB0byB3cmFwLlxuICAgICAgICpcbiAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSBbd3JhcHBlcnMgPSB7fV1cbiAgICAgICAqICAgICAgICBBbiBvYmplY3QgdHJlZSBjb250YWluaW5nIHdyYXBwZXIgZnVuY3Rpb25zIGZvciBzcGVjaWFsIGNhc2VzLiBBbnlcbiAgICAgICAqICAgICAgICBmdW5jdGlvbiBwcmVzZW50IGluIHRoaXMgb2JqZWN0IHRyZWUgaXMgY2FsbGVkIGluIHBsYWNlIG9mIHRoZVxuICAgICAgICogICAgICAgIG1ldGhvZCBpbiB0aGUgc2FtZSBsb2NhdGlvbiBpbiB0aGUgYHRhcmdldGAgb2JqZWN0IHRyZWUuIFRoZXNlXG4gICAgICAgKiAgICAgICAgd3JhcHBlciBtZXRob2RzIGFyZSBpbnZva2VkIGFzIGRlc2NyaWJlZCBpbiB7QHNlZSB3cmFwTWV0aG9kfS5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge29iamVjdH0gW21ldGFkYXRhID0ge31dXG4gICAgICAgKiAgICAgICAgQW4gb2JqZWN0IHRyZWUgY29udGFpbmluZyBtZXRhZGF0YSB1c2VkIHRvIGF1dG9tYXRpY2FsbHkgZ2VuZXJhdGVcbiAgICAgICAqICAgICAgICBQcm9taXNlLWJhc2VkIHdyYXBwZXIgZnVuY3Rpb25zIGZvciBhc3luY2hyb25vdXMuIEFueSBmdW5jdGlvbiBpblxuICAgICAgICogICAgICAgIHRoZSBgdGFyZ2V0YCBvYmplY3QgdHJlZSB3aGljaCBoYXMgYSBjb3JyZXNwb25kaW5nIG1ldGFkYXRhIG9iamVjdFxuICAgICAgICogICAgICAgIGluIHRoZSBzYW1lIGxvY2F0aW9uIGluIHRoZSBgbWV0YWRhdGFgIHRyZWUgaXMgcmVwbGFjZWQgd2l0aCBhblxuICAgICAgICogICAgICAgIGF1dG9tYXRpY2FsbHktZ2VuZXJhdGVkIHdyYXBwZXIgZnVuY3Rpb24sIGFzIGRlc2NyaWJlZCBpblxuICAgICAgICogICAgICAgIHtAc2VlIHdyYXBBc3luY0Z1bmN0aW9ufVxuICAgICAgICpcbiAgICAgICAqIEByZXR1cm5zIHtQcm94eTxvYmplY3Q+fVxuICAgICAgICovXG5cbiAgICAgIGNvbnN0IHdyYXBPYmplY3QgPSAodGFyZ2V0LCB3cmFwcGVycyA9IHt9LCBtZXRhZGF0YSA9IHt9KSA9PiB7XG4gICAgICAgIGxldCBjYWNoZSA9IE9iamVjdC5jcmVhdGUobnVsbCk7XG4gICAgICAgIGxldCBoYW5kbGVycyA9IHtcbiAgICAgICAgICBoYXMocHJveHlUYXJnZXQsIHByb3ApIHtcbiAgICAgICAgICAgIHJldHVybiBwcm9wIGluIHRhcmdldCB8fCBwcm9wIGluIGNhY2hlO1xuICAgICAgICAgIH0sXG5cbiAgICAgICAgICBnZXQocHJveHlUYXJnZXQsIHByb3AsIHJlY2VpdmVyKSB7XG4gICAgICAgICAgICBpZiAocHJvcCBpbiBjYWNoZSkge1xuICAgICAgICAgICAgICByZXR1cm4gY2FjaGVbcHJvcF07XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGlmICghKHByb3AgaW4gdGFyZ2V0KSkge1xuICAgICAgICAgICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICBsZXQgdmFsdWUgPSB0YXJnZXRbcHJvcF07XG5cbiAgICAgICAgICAgIGlmICh0eXBlb2YgdmFsdWUgPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgICAgICAvLyBUaGlzIGlzIGEgbWV0aG9kIG9uIHRoZSB1bmRlcmx5aW5nIG9iamVjdC4gQ2hlY2sgaWYgd2UgbmVlZCB0byBkb1xuICAgICAgICAgICAgICAvLyBhbnkgd3JhcHBpbmcuXG4gICAgICAgICAgICAgIGlmICh0eXBlb2Ygd3JhcHBlcnNbcHJvcF0gPT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgICAgICAgIC8vIFdlIGhhdmUgYSBzcGVjaWFsLWNhc2Ugd3JhcHBlciBmb3IgdGhpcyBtZXRob2QuXG4gICAgICAgICAgICAgICAgdmFsdWUgPSB3cmFwTWV0aG9kKHRhcmdldCwgdGFyZ2V0W3Byb3BdLCB3cmFwcGVyc1twcm9wXSk7XG4gICAgICAgICAgICAgIH0gZWxzZSBpZiAoaGFzT3duUHJvcGVydHkobWV0YWRhdGEsIHByb3ApKSB7XG4gICAgICAgICAgICAgICAgLy8gVGhpcyBpcyBhbiBhc3luYyBtZXRob2QgdGhhdCB3ZSBoYXZlIG1ldGFkYXRhIGZvci4gQ3JlYXRlIGFcbiAgICAgICAgICAgICAgICAvLyBQcm9taXNlIHdyYXBwZXIgZm9yIGl0LlxuICAgICAgICAgICAgICAgIGxldCB3cmFwcGVyID0gd3JhcEFzeW5jRnVuY3Rpb24ocHJvcCwgbWV0YWRhdGFbcHJvcF0pO1xuICAgICAgICAgICAgICAgIHZhbHVlID0gd3JhcE1ldGhvZCh0YXJnZXQsIHRhcmdldFtwcm9wXSwgd3JhcHBlcik7XG4gICAgICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICAgICAgLy8gVGhpcyBpcyBhIG1ldGhvZCB0aGF0IHdlIGRvbid0IGtub3cgb3IgY2FyZSBhYm91dC4gUmV0dXJuIHRoZVxuICAgICAgICAgICAgICAgIC8vIG9yaWdpbmFsIG1ldGhvZCwgYm91bmQgdG8gdGhlIHVuZGVybHlpbmcgb2JqZWN0LlxuICAgICAgICAgICAgICAgIHZhbHVlID0gdmFsdWUuYmluZCh0YXJnZXQpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9IGVsc2UgaWYgKHR5cGVvZiB2YWx1ZSA9PT0gXCJvYmplY3RcIiAmJiB2YWx1ZSAhPT0gbnVsbCAmJiAoaGFzT3duUHJvcGVydHkod3JhcHBlcnMsIHByb3ApIHx8IGhhc093blByb3BlcnR5KG1ldGFkYXRhLCBwcm9wKSkpIHtcbiAgICAgICAgICAgICAgLy8gVGhpcyBpcyBhbiBvYmplY3QgdGhhdCB3ZSBuZWVkIHRvIGRvIHNvbWUgd3JhcHBpbmcgZm9yIHRoZSBjaGlsZHJlblxuICAgICAgICAgICAgICAvLyBvZi4gQ3JlYXRlIGEgc3ViLW9iamVjdCB3cmFwcGVyIGZvciBpdCB3aXRoIHRoZSBhcHByb3ByaWF0ZSBjaGlsZFxuICAgICAgICAgICAgICAvLyBtZXRhZGF0YS5cbiAgICAgICAgICAgICAgdmFsdWUgPSB3cmFwT2JqZWN0KHZhbHVlLCB3cmFwcGVyc1twcm9wXSwgbWV0YWRhdGFbcHJvcF0pO1xuICAgICAgICAgICAgfSBlbHNlIGlmIChoYXNPd25Qcm9wZXJ0eShtZXRhZGF0YSwgXCIqXCIpKSB7XG4gICAgICAgICAgICAgIC8vIFdyYXAgYWxsIHByb3BlcnRpZXMgaW4gKiBuYW1lc3BhY2UuXG4gICAgICAgICAgICAgIHZhbHVlID0gd3JhcE9iamVjdCh2YWx1ZSwgd3JhcHBlcnNbcHJvcF0sIG1ldGFkYXRhW1wiKlwiXSk7XG4gICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAvLyBXZSBkb24ndCBuZWVkIHRvIGRvIGFueSB3cmFwcGluZyBmb3IgdGhpcyBwcm9wZXJ0eSxcbiAgICAgICAgICAgICAgLy8gc28ganVzdCBmb3J3YXJkIGFsbCBhY2Nlc3MgdG8gdGhlIHVuZGVybHlpbmcgb2JqZWN0LlxuICAgICAgICAgICAgICBPYmplY3QuZGVmaW5lUHJvcGVydHkoY2FjaGUsIHByb3AsIHtcbiAgICAgICAgICAgICAgICBjb25maWd1cmFibGU6IHRydWUsXG4gICAgICAgICAgICAgICAgZW51bWVyYWJsZTogdHJ1ZSxcblxuICAgICAgICAgICAgICAgIGdldCgpIHtcbiAgICAgICAgICAgICAgICAgIHJldHVybiB0YXJnZXRbcHJvcF07XG4gICAgICAgICAgICAgICAgfSxcblxuICAgICAgICAgICAgICAgIHNldCh2YWx1ZSkge1xuICAgICAgICAgICAgICAgICAgdGFyZ2V0W3Byb3BdID0gdmFsdWU7XG4gICAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIH0pO1xuICAgICAgICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIGNhY2hlW3Byb3BdID0gdmFsdWU7XG4gICAgICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgICAgICAgfSxcblxuICAgICAgICAgIHNldChwcm94eVRhcmdldCwgcHJvcCwgdmFsdWUsIHJlY2VpdmVyKSB7XG4gICAgICAgICAgICBpZiAocHJvcCBpbiBjYWNoZSkge1xuICAgICAgICAgICAgICBjYWNoZVtwcm9wXSA9IHZhbHVlO1xuICAgICAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAgICAgdGFyZ2V0W3Byb3BdID0gdmFsdWU7XG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgIH0sXG5cbiAgICAgICAgICBkZWZpbmVQcm9wZXJ0eShwcm94eVRhcmdldCwgcHJvcCwgZGVzYykge1xuICAgICAgICAgICAgcmV0dXJuIFJlZmxlY3QuZGVmaW5lUHJvcGVydHkoY2FjaGUsIHByb3AsIGRlc2MpO1xuICAgICAgICAgIH0sXG5cbiAgICAgICAgICBkZWxldGVQcm9wZXJ0eShwcm94eVRhcmdldCwgcHJvcCkge1xuICAgICAgICAgICAgcmV0dXJuIFJlZmxlY3QuZGVsZXRlUHJvcGVydHkoY2FjaGUsIHByb3ApO1xuICAgICAgICAgIH1cblxuICAgICAgICB9OyAvLyBQZXIgY29udHJhY3Qgb2YgdGhlIFByb3h5IEFQSSwgdGhlIFwiZ2V0XCIgcHJveHkgaGFuZGxlciBtdXN0IHJldHVybiB0aGVcbiAgICAgICAgLy8gb3JpZ2luYWwgdmFsdWUgb2YgdGhlIHRhcmdldCBpZiB0aGF0IHZhbHVlIGlzIGRlY2xhcmVkIHJlYWQtb25seSBhbmRcbiAgICAgICAgLy8gbm9uLWNvbmZpZ3VyYWJsZS4gRm9yIHRoaXMgcmVhc29uLCB3ZSBjcmVhdGUgYW4gb2JqZWN0IHdpdGggdGhlXG4gICAgICAgIC8vIHByb3RvdHlwZSBzZXQgdG8gYHRhcmdldGAgaW5zdGVhZCBvZiB1c2luZyBgdGFyZ2V0YCBkaXJlY3RseS5cbiAgICAgICAgLy8gT3RoZXJ3aXNlIHdlIGNhbm5vdCByZXR1cm4gYSBjdXN0b20gb2JqZWN0IGZvciBBUElzIHRoYXRcbiAgICAgICAgLy8gYXJlIGRlY2xhcmVkIHJlYWQtb25seSBhbmQgbm9uLWNvbmZpZ3VyYWJsZSwgc3VjaCBhcyBgY2hyb21lLmRldnRvb2xzYC5cbiAgICAgICAgLy9cbiAgICAgICAgLy8gVGhlIHByb3h5IGhhbmRsZXJzIHRoZW1zZWx2ZXMgd2lsbCBzdGlsbCB1c2UgdGhlIG9yaWdpbmFsIGB0YXJnZXRgXG4gICAgICAgIC8vIGluc3RlYWQgb2YgdGhlIGBwcm94eVRhcmdldGAsIHNvIHRoYXQgdGhlIG1ldGhvZHMgYW5kIHByb3BlcnRpZXMgYXJlXG4gICAgICAgIC8vIGRlcmVmZXJlbmNlZCB2aWEgdGhlIG9yaWdpbmFsIHRhcmdldHMuXG5cbiAgICAgICAgbGV0IHByb3h5VGFyZ2V0ID0gT2JqZWN0LmNyZWF0ZSh0YXJnZXQpO1xuICAgICAgICByZXR1cm4gbmV3IFByb3h5KHByb3h5VGFyZ2V0LCBoYW5kbGVycyk7XG4gICAgICB9O1xuICAgICAgLyoqXG4gICAgICAgKiBDcmVhdGVzIGEgc2V0IG9mIHdyYXBwZXIgZnVuY3Rpb25zIGZvciBhbiBldmVudCBvYmplY3QsIHdoaWNoIGhhbmRsZXNcbiAgICAgICAqIHdyYXBwaW5nIG9mIGxpc3RlbmVyIGZ1bmN0aW9ucyB0aGF0IHRob3NlIG1lc3NhZ2VzIGFyZSBwYXNzZWQuXG4gICAgICAgKlxuICAgICAgICogQSBzaW5nbGUgd3JhcHBlciBpcyBjcmVhdGVkIGZvciBlYWNoIGxpc3RlbmVyIGZ1bmN0aW9uLCBhbmQgc3RvcmVkIGluIGFcbiAgICAgICAqIG1hcC4gU3Vic2VxdWVudCBjYWxscyB0byBgYWRkTGlzdGVuZXJgLCBgaGFzTGlzdGVuZXJgLCBvciBgcmVtb3ZlTGlzdGVuZXJgXG4gICAgICAgKiByZXRyaWV2ZSB0aGUgb3JpZ2luYWwgd3JhcHBlciwgc28gdGhhdCAgYXR0ZW1wdHMgdG8gcmVtb3ZlIGFcbiAgICAgICAqIHByZXZpb3VzbHktYWRkZWQgbGlzdGVuZXIgd29yayBhcyBleHBlY3RlZC5cbiAgICAgICAqXG4gICAgICAgKiBAcGFyYW0ge0RlZmF1bHRXZWFrTWFwPGZ1bmN0aW9uLCBmdW5jdGlvbj59IHdyYXBwZXJNYXBcbiAgICAgICAqICAgICAgICBBIERlZmF1bHRXZWFrTWFwIG9iamVjdCB3aGljaCB3aWxsIGNyZWF0ZSB0aGUgYXBwcm9wcmlhdGUgd3JhcHBlclxuICAgICAgICogICAgICAgIGZvciBhIGdpdmVuIGxpc3RlbmVyIGZ1bmN0aW9uIHdoZW4gb25lIGRvZXMgbm90IGV4aXN0LCBhbmQgcmV0cmlldmVcbiAgICAgICAqICAgICAgICBhbiBleGlzdGluZyBvbmUgd2hlbiBpdCBkb2VzLlxuICAgICAgICpcbiAgICAgICAqIEByZXR1cm5zIHtvYmplY3R9XG4gICAgICAgKi9cblxuXG4gICAgICBjb25zdCB3cmFwRXZlbnQgPSB3cmFwcGVyTWFwID0+ICh7XG4gICAgICAgIGFkZExpc3RlbmVyKHRhcmdldCwgbGlzdGVuZXIsIC4uLmFyZ3MpIHtcbiAgICAgICAgICB0YXJnZXQuYWRkTGlzdGVuZXIod3JhcHBlck1hcC5nZXQobGlzdGVuZXIpLCAuLi5hcmdzKTtcbiAgICAgICAgfSxcblxuICAgICAgICBoYXNMaXN0ZW5lcih0YXJnZXQsIGxpc3RlbmVyKSB7XG4gICAgICAgICAgcmV0dXJuIHRhcmdldC5oYXNMaXN0ZW5lcih3cmFwcGVyTWFwLmdldChsaXN0ZW5lcikpO1xuICAgICAgICB9LFxuXG4gICAgICAgIHJlbW92ZUxpc3RlbmVyKHRhcmdldCwgbGlzdGVuZXIpIHtcbiAgICAgICAgICB0YXJnZXQucmVtb3ZlTGlzdGVuZXIod3JhcHBlck1hcC5nZXQobGlzdGVuZXIpKTtcbiAgICAgICAgfVxuXG4gICAgICB9KTtcblxuICAgICAgY29uc3Qgb25SZXF1ZXN0RmluaXNoZWRXcmFwcGVycyA9IG5ldyBEZWZhdWx0V2Vha01hcChsaXN0ZW5lciA9PiB7XG4gICAgICAgIGlmICh0eXBlb2YgbGlzdGVuZXIgIT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgIHJldHVybiBsaXN0ZW5lcjtcbiAgICAgICAgfVxuICAgICAgICAvKipcbiAgICAgICAgICogV3JhcHMgYW4gb25SZXF1ZXN0RmluaXNoZWQgbGlzdGVuZXIgZnVuY3Rpb24gc28gdGhhdCBpdCB3aWxsIHJldHVybiBhXG4gICAgICAgICAqIGBnZXRDb250ZW50KClgIHByb3BlcnR5IHdoaWNoIHJldHVybnMgYSBgUHJvbWlzZWAgcmF0aGVyIHRoYW4gdXNpbmcgYVxuICAgICAgICAgKiBjYWxsYmFjayBBUEkuXG4gICAgICAgICAqXG4gICAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSByZXFcbiAgICAgICAgICogICAgICAgIFRoZSBIQVIgZW50cnkgb2JqZWN0IHJlcHJlc2VudGluZyB0aGUgbmV0d29yayByZXF1ZXN0LlxuICAgICAgICAgKi9cblxuXG4gICAgICAgIHJldHVybiBmdW5jdGlvbiBvblJlcXVlc3RGaW5pc2hlZChyZXEpIHtcbiAgICAgICAgICBjb25zdCB3cmFwcGVkUmVxID0gd3JhcE9iamVjdChyZXEsIHt9XG4gICAgICAgICAgLyogd3JhcHBlcnMgKi9cbiAgICAgICAgICAsIHtcbiAgICAgICAgICAgIGdldENvbnRlbnQ6IHtcbiAgICAgICAgICAgICAgbWluQXJnczogMCxcbiAgICAgICAgICAgICAgbWF4QXJnczogMFxuICAgICAgICAgICAgfVxuICAgICAgICAgIH0pO1xuICAgICAgICAgIGxpc3RlbmVyKHdyYXBwZWRSZXEpO1xuICAgICAgICB9O1xuICAgICAgfSk7XG4gICAgICBjb25zdCBvbk1lc3NhZ2VXcmFwcGVycyA9IG5ldyBEZWZhdWx0V2Vha01hcChsaXN0ZW5lciA9PiB7XG4gICAgICAgIGlmICh0eXBlb2YgbGlzdGVuZXIgIT09IFwiZnVuY3Rpb25cIikge1xuICAgICAgICAgIHJldHVybiBsaXN0ZW5lcjtcbiAgICAgICAgfVxuICAgICAgICAvKipcbiAgICAgICAgICogV3JhcHMgYSBtZXNzYWdlIGxpc3RlbmVyIGZ1bmN0aW9uIHNvIHRoYXQgaXQgbWF5IHNlbmQgcmVzcG9uc2VzIGJhc2VkIG9uXG4gICAgICAgICAqIGl0cyByZXR1cm4gdmFsdWUsIHJhdGhlciB0aGFuIGJ5IHJldHVybmluZyBhIHNlbnRpbmVsIHZhbHVlIGFuZCBjYWxsaW5nIGFcbiAgICAgICAgICogY2FsbGJhY2suIElmIHRoZSBsaXN0ZW5lciBmdW5jdGlvbiByZXR1cm5zIGEgUHJvbWlzZSwgdGhlIHJlc3BvbnNlIGlzXG4gICAgICAgICAqIHNlbnQgd2hlbiB0aGUgcHJvbWlzZSBlaXRoZXIgcmVzb2x2ZXMgb3IgcmVqZWN0cy5cbiAgICAgICAgICpcbiAgICAgICAgICogQHBhcmFtIHsqfSBtZXNzYWdlXG4gICAgICAgICAqICAgICAgICBUaGUgbWVzc2FnZSBzZW50IGJ5IHRoZSBvdGhlciBlbmQgb2YgdGhlIGNoYW5uZWwuXG4gICAgICAgICAqIEBwYXJhbSB7b2JqZWN0fSBzZW5kZXJcbiAgICAgICAgICogICAgICAgIERldGFpbHMgYWJvdXQgdGhlIHNlbmRlciBvZiB0aGUgbWVzc2FnZS5cbiAgICAgICAgICogQHBhcmFtIHtmdW5jdGlvbigqKX0gc2VuZFJlc3BvbnNlXG4gICAgICAgICAqICAgICAgICBBIGNhbGxiYWNrIHdoaWNoLCB3aGVuIGNhbGxlZCB3aXRoIGFuIGFyYml0cmFyeSBhcmd1bWVudCwgc2VuZHNcbiAgICAgICAgICogICAgICAgIHRoYXQgdmFsdWUgYXMgYSByZXNwb25zZS5cbiAgICAgICAgICogQHJldHVybnMge2Jvb2xlYW59XG4gICAgICAgICAqICAgICAgICBUcnVlIGlmIHRoZSB3cmFwcGVkIGxpc3RlbmVyIHJldHVybmVkIGEgUHJvbWlzZSwgd2hpY2ggd2lsbCBsYXRlclxuICAgICAgICAgKiAgICAgICAgeWllbGQgYSByZXNwb25zZS4gRmFsc2Ugb3RoZXJ3aXNlLlxuICAgICAgICAgKi9cblxuXG4gICAgICAgIHJldHVybiBmdW5jdGlvbiBvbk1lc3NhZ2UobWVzc2FnZSwgc2VuZGVyLCBzZW5kUmVzcG9uc2UpIHtcbiAgICAgICAgICBsZXQgZGlkQ2FsbFNlbmRSZXNwb25zZSA9IGZhbHNlO1xuICAgICAgICAgIGxldCB3cmFwcGVkU2VuZFJlc3BvbnNlO1xuICAgICAgICAgIGxldCBzZW5kUmVzcG9uc2VQcm9taXNlID0gbmV3IFByb21pc2UocmVzb2x2ZSA9PiB7XG4gICAgICAgICAgICB3cmFwcGVkU2VuZFJlc3BvbnNlID0gZnVuY3Rpb24gKHJlc3BvbnNlKSB7XG4gICAgICAgICAgICAgIGRpZENhbGxTZW5kUmVzcG9uc2UgPSB0cnVlO1xuICAgICAgICAgICAgICByZXNvbHZlKHJlc3BvbnNlKTtcbiAgICAgICAgICAgIH07XG4gICAgICAgICAgfSk7XG4gICAgICAgICAgbGV0IHJlc3VsdDtcblxuICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICByZXN1bHQgPSBsaXN0ZW5lcihtZXNzYWdlLCBzZW5kZXIsIHdyYXBwZWRTZW5kUmVzcG9uc2UpO1xuICAgICAgICAgIH0gY2F0Y2ggKGVycikge1xuICAgICAgICAgICAgcmVzdWx0ID0gUHJvbWlzZS5yZWplY3QoZXJyKTtcbiAgICAgICAgICB9XG5cbiAgICAgICAgICBjb25zdCBpc1Jlc3VsdFRoZW5hYmxlID0gcmVzdWx0ICE9PSB0cnVlICYmIGlzVGhlbmFibGUocmVzdWx0KTsgLy8gSWYgdGhlIGxpc3RlbmVyIGRpZG4ndCByZXR1cm5lZCB0cnVlIG9yIGEgUHJvbWlzZSwgb3IgY2FsbGVkXG4gICAgICAgICAgLy8gd3JhcHBlZFNlbmRSZXNwb25zZSBzeW5jaHJvbm91c2x5LCB3ZSBjYW4gZXhpdCBlYXJsaWVyXG4gICAgICAgICAgLy8gYmVjYXVzZSB0aGVyZSB3aWxsIGJlIG5vIHJlc3BvbnNlIHNlbnQgZnJvbSB0aGlzIGxpc3RlbmVyLlxuXG4gICAgICAgICAgaWYgKHJlc3VsdCAhPT0gdHJ1ZSAmJiAhaXNSZXN1bHRUaGVuYWJsZSAmJiAhZGlkQ2FsbFNlbmRSZXNwb25zZSkge1xuICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgIH0gLy8gQSBzbWFsbCBoZWxwZXIgdG8gc2VuZCB0aGUgbWVzc2FnZSBpZiB0aGUgcHJvbWlzZSByZXNvbHZlc1xuICAgICAgICAgIC8vIGFuZCBhbiBlcnJvciBpZiB0aGUgcHJvbWlzZSByZWplY3RzIChhIHdyYXBwZWQgc2VuZE1lc3NhZ2UgaGFzXG4gICAgICAgICAgLy8gdG8gdHJhbnNsYXRlIHRoZSBtZXNzYWdlIGludG8gYSByZXNvbHZlZCBwcm9taXNlIG9yIGEgcmVqZWN0ZWRcbiAgICAgICAgICAvLyBwcm9taXNlKS5cblxuXG4gICAgICAgICAgY29uc3Qgc2VuZFByb21pc2VkUmVzdWx0ID0gcHJvbWlzZSA9PiB7XG4gICAgICAgICAgICBwcm9taXNlLnRoZW4obXNnID0+IHtcbiAgICAgICAgICAgICAgLy8gc2VuZCB0aGUgbWVzc2FnZSB2YWx1ZS5cbiAgICAgICAgICAgICAgc2VuZFJlc3BvbnNlKG1zZyk7XG4gICAgICAgICAgICB9LCBlcnJvciA9PiB7XG4gICAgICAgICAgICAgIC8vIFNlbmQgYSBKU09OIHJlcHJlc2VudGF0aW9uIG9mIHRoZSBlcnJvciBpZiB0aGUgcmVqZWN0ZWQgdmFsdWVcbiAgICAgICAgICAgICAgLy8gaXMgYW4gaW5zdGFuY2Ugb2YgZXJyb3IsIG9yIHRoZSBvYmplY3QgaXRzZWxmIG90aGVyd2lzZS5cbiAgICAgICAgICAgICAgbGV0IG1lc3NhZ2U7XG5cbiAgICAgICAgICAgICAgaWYgKGVycm9yICYmIChlcnJvciBpbnN0YW5jZW9mIEVycm9yIHx8IHR5cGVvZiBlcnJvci5tZXNzYWdlID09PSBcInN0cmluZ1wiKSkge1xuICAgICAgICAgICAgICAgIG1lc3NhZ2UgPSBlcnJvci5tZXNzYWdlO1xuICAgICAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgICAgIG1lc3NhZ2UgPSBcIkFuIHVuZXhwZWN0ZWQgZXJyb3Igb2NjdXJyZWRcIjtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICAgIHNlbmRSZXNwb25zZSh7XG4gICAgICAgICAgICAgICAgX19tb3pXZWJFeHRlbnNpb25Qb2x5ZmlsbFJlamVjdF9fOiB0cnVlLFxuICAgICAgICAgICAgICAgIG1lc3NhZ2VcbiAgICAgICAgICAgICAgfSk7XG4gICAgICAgICAgICB9KS5jYXRjaChlcnIgPT4ge1xuICAgICAgICAgICAgICAvLyBQcmludCBhbiBlcnJvciBvbiB0aGUgY29uc29sZSBpZiB1bmFibGUgdG8gc2VuZCB0aGUgcmVzcG9uc2UuXG4gICAgICAgICAgICAgIGNvbnNvbGUuZXJyb3IoXCJGYWlsZWQgdG8gc2VuZCBvbk1lc3NhZ2UgcmVqZWN0ZWQgcmVwbHlcIiwgZXJyKTtcbiAgICAgICAgICAgIH0pO1xuICAgICAgICAgIH07IC8vIElmIHRoZSBsaXN0ZW5lciByZXR1cm5lZCBhIFByb21pc2UsIHNlbmQgdGhlIHJlc29sdmVkIHZhbHVlIGFzIGFcbiAgICAgICAgICAvLyByZXN1bHQsIG90aGVyd2lzZSB3YWl0IHRoZSBwcm9taXNlIHJlbGF0ZWQgdG8gdGhlIHdyYXBwZWRTZW5kUmVzcG9uc2VcbiAgICAgICAgICAvLyBjYWxsYmFjayB0byByZXNvbHZlIGFuZCBzZW5kIGl0IGFzIGEgcmVzcG9uc2UuXG5cblxuICAgICAgICAgIGlmIChpc1Jlc3VsdFRoZW5hYmxlKSB7XG4gICAgICAgICAgICBzZW5kUHJvbWlzZWRSZXN1bHQocmVzdWx0KTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgc2VuZFByb21pc2VkUmVzdWx0KHNlbmRSZXNwb25zZVByb21pc2UpO1xuICAgICAgICAgIH0gLy8gTGV0IENocm9tZSBrbm93IHRoYXQgdGhlIGxpc3RlbmVyIGlzIHJlcGx5aW5nLlxuXG5cbiAgICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICAgICAgfTtcbiAgICAgIH0pO1xuXG4gICAgICBjb25zdCB3cmFwcGVkU2VuZE1lc3NhZ2VDYWxsYmFjayA9ICh7XG4gICAgICAgIHJlamVjdCxcbiAgICAgICAgcmVzb2x2ZVxuICAgICAgfSwgcmVwbHkpID0+IHtcbiAgICAgICAgaWYgKGV4dGVuc2lvbkFQSXMucnVudGltZS5sYXN0RXJyb3IpIHtcbiAgICAgICAgICAvLyBEZXRlY3Qgd2hlbiBub25lIG9mIHRoZSBsaXN0ZW5lcnMgcmVwbGllZCB0byB0aGUgc2VuZE1lc3NhZ2UgY2FsbCBhbmQgcmVzb2x2ZVxuICAgICAgICAgIC8vIHRoZSBwcm9taXNlIHRvIHVuZGVmaW5lZCBhcyBpbiBGaXJlZm94LlxuICAgICAgICAgIC8vIFNlZSBodHRwczovL2dpdGh1Yi5jb20vbW96aWxsYS93ZWJleHRlbnNpb24tcG9seWZpbGwvaXNzdWVzLzEzMFxuICAgICAgICAgIGlmIChleHRlbnNpb25BUElzLnJ1bnRpbWUubGFzdEVycm9yLm1lc3NhZ2UgPT09IENIUk9NRV9TRU5EX01FU1NBR0VfQ0FMTEJBQ0tfTk9fUkVTUE9OU0VfTUVTU0FHRSkge1xuICAgICAgICAgICAgcmVzb2x2ZSgpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZWplY3QobmV3IEVycm9yKGV4dGVuc2lvbkFQSXMucnVudGltZS5sYXN0RXJyb3IubWVzc2FnZSkpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIGlmIChyZXBseSAmJiByZXBseS5fX21veldlYkV4dGVuc2lvblBvbHlmaWxsUmVqZWN0X18pIHtcbiAgICAgICAgICAvLyBDb252ZXJ0IGJhY2sgdGhlIEpTT04gcmVwcmVzZW50YXRpb24gb2YgdGhlIGVycm9yIGludG9cbiAgICAgICAgICAvLyBhbiBFcnJvciBpbnN0YW5jZS5cbiAgICAgICAgICByZWplY3QobmV3IEVycm9yKHJlcGx5Lm1lc3NhZ2UpKTtcbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICByZXNvbHZlKHJlcGx5KTtcbiAgICAgICAgfVxuICAgICAgfTtcblxuICAgICAgY29uc3Qgd3JhcHBlZFNlbmRNZXNzYWdlID0gKG5hbWUsIG1ldGFkYXRhLCBhcGlOYW1lc3BhY2VPYmosIC4uLmFyZ3MpID0+IHtcbiAgICAgICAgaWYgKGFyZ3MubGVuZ3RoIDwgbWV0YWRhdGEubWluQXJncykge1xuICAgICAgICAgIHRocm93IG5ldyBFcnJvcihgRXhwZWN0ZWQgYXQgbGVhc3QgJHttZXRhZGF0YS5taW5BcmdzfSAke3BsdXJhbGl6ZUFyZ3VtZW50cyhtZXRhZGF0YS5taW5BcmdzKX0gZm9yICR7bmFtZX0oKSwgZ290ICR7YXJncy5sZW5ndGh9YCk7XG4gICAgICAgIH1cblxuICAgICAgICBpZiAoYXJncy5sZW5ndGggPiBtZXRhZGF0YS5tYXhBcmdzKSB7XG4gICAgICAgICAgdGhyb3cgbmV3IEVycm9yKGBFeHBlY3RlZCBhdCBtb3N0ICR7bWV0YWRhdGEubWF4QXJnc30gJHtwbHVyYWxpemVBcmd1bWVudHMobWV0YWRhdGEubWF4QXJncyl9IGZvciAke25hbWV9KCksIGdvdCAke2FyZ3MubGVuZ3RofWApO1xuICAgICAgICB9XG5cbiAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICBjb25zdCB3cmFwcGVkQ2IgPSB3cmFwcGVkU2VuZE1lc3NhZ2VDYWxsYmFjay5iaW5kKG51bGwsIHtcbiAgICAgICAgICAgIHJlc29sdmUsXG4gICAgICAgICAgICByZWplY3RcbiAgICAgICAgICB9KTtcbiAgICAgICAgICBhcmdzLnB1c2god3JhcHBlZENiKTtcbiAgICAgICAgICBhcGlOYW1lc3BhY2VPYmouc2VuZE1lc3NhZ2UoLi4uYXJncyk7XG4gICAgICAgIH0pO1xuICAgICAgfTtcblxuICAgICAgY29uc3Qgc3RhdGljV3JhcHBlcnMgPSB7XG4gICAgICAgIGRldnRvb2xzOiB7XG4gICAgICAgICAgbmV0d29yazoge1xuICAgICAgICAgICAgb25SZXF1ZXN0RmluaXNoZWQ6IHdyYXBFdmVudChvblJlcXVlc3RGaW5pc2hlZFdyYXBwZXJzKVxuICAgICAgICAgIH1cbiAgICAgICAgfSxcbiAgICAgICAgcnVudGltZToge1xuICAgICAgICAgIG9uTWVzc2FnZTogd3JhcEV2ZW50KG9uTWVzc2FnZVdyYXBwZXJzKSxcbiAgICAgICAgICBvbk1lc3NhZ2VFeHRlcm5hbDogd3JhcEV2ZW50KG9uTWVzc2FnZVdyYXBwZXJzKSxcbiAgICAgICAgICBzZW5kTWVzc2FnZTogd3JhcHBlZFNlbmRNZXNzYWdlLmJpbmQobnVsbCwgXCJzZW5kTWVzc2FnZVwiLCB7XG4gICAgICAgICAgICBtaW5BcmdzOiAxLFxuICAgICAgICAgICAgbWF4QXJnczogM1xuICAgICAgICAgIH0pXG4gICAgICAgIH0sXG4gICAgICAgIHRhYnM6IHtcbiAgICAgICAgICBzZW5kTWVzc2FnZTogd3JhcHBlZFNlbmRNZXNzYWdlLmJpbmQobnVsbCwgXCJzZW5kTWVzc2FnZVwiLCB7XG4gICAgICAgICAgICBtaW5BcmdzOiAyLFxuICAgICAgICAgICAgbWF4QXJnczogM1xuICAgICAgICAgIH0pXG4gICAgICAgIH1cbiAgICAgIH07XG4gICAgICBjb25zdCBzZXR0aW5nTWV0YWRhdGEgPSB7XG4gICAgICAgIGNsZWFyOiB7XG4gICAgICAgICAgbWluQXJnczogMSxcbiAgICAgICAgICBtYXhBcmdzOiAxXG4gICAgICAgIH0sXG4gICAgICAgIGdldDoge1xuICAgICAgICAgIG1pbkFyZ3M6IDEsXG4gICAgICAgICAgbWF4QXJnczogMVxuICAgICAgICB9LFxuICAgICAgICBzZXQ6IHtcbiAgICAgICAgICBtaW5BcmdzOiAxLFxuICAgICAgICAgIG1heEFyZ3M6IDFcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIGFwaU1ldGFkYXRhLnByaXZhY3kgPSB7XG4gICAgICAgIG5ldHdvcms6IHtcbiAgICAgICAgICBcIipcIjogc2V0dGluZ01ldGFkYXRhXG4gICAgICAgIH0sXG4gICAgICAgIHNlcnZpY2VzOiB7XG4gICAgICAgICAgXCIqXCI6IHNldHRpbmdNZXRhZGF0YVxuICAgICAgICB9LFxuICAgICAgICB3ZWJzaXRlczoge1xuICAgICAgICAgIFwiKlwiOiBzZXR0aW5nTWV0YWRhdGFcbiAgICAgICAgfVxuICAgICAgfTtcbiAgICAgIHJldHVybiB3cmFwT2JqZWN0KGV4dGVuc2lvbkFQSXMsIHN0YXRpY1dyYXBwZXJzLCBhcGlNZXRhZGF0YSk7XG4gICAgfTsgLy8gVGhlIGJ1aWxkIHByb2Nlc3MgYWRkcyBhIFVNRCB3cmFwcGVyIGFyb3VuZCB0aGlzIGZpbGUsIHdoaWNoIG1ha2VzIHRoZVxuICAgIC8vIGBtb2R1bGVgIHZhcmlhYmxlIGF2YWlsYWJsZS5cblxuXG4gICAgbW9kdWxlLmV4cG9ydHMgPSB3cmFwQVBJcyhjaHJvbWUpO1xuICB9IGVsc2Uge1xuICAgIG1vZHVsZS5leHBvcnRzID0gZ2xvYmFsVGhpcy5icm93c2VyO1xuICB9XG59KTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWJyb3dzZXItcG9seWZpbGwuanMubWFwXG4iLCJpbXBvcnQgeyBDbG9uZSB9IGZyb20gXCJAc2l0ZWltcHJvdmUvYWxmYS1jbG9uZVwiO1xuaW1wb3J0IHsgQ29tcGFyYWJsZSwgQ29tcGFyaXNvbiwgfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtY29tcGFyYWJsZVwiO1xuaW1wb3J0IHsgRXF1YXRhYmxlIH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLWVxdWF0YWJsZVwiO1xuaW1wb3J0IHsgSXRlcmFibGUgfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtaXRlcmFibGVcIjtcbmltcG9ydCB7IFNlcmlhbGl6YWJsZSB9IGZyb20gXCJAc2l0ZWltcHJvdmUvYWxmYS1qc29uXCI7XG5pbXBvcnQgeyBOb25lLCBPcHRpb24gfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtb3B0aW9uXCI7XG5pbXBvcnQgeyBQcmVkaWNhdGUgfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtcHJlZGljYXRlXCI7XG5pbXBvcnQgKiBhcyBidWlsdGluIGZyb20gXCIuL2J1aWx0aW4uanNcIjtcbmNvbnN0IHsgbm90IH0gPSBQcmVkaWNhdGU7XG5jb25zdCB7IGNvbXBhcmVDb21wYXJhYmxlIH0gPSBDb21wYXJhYmxlO1xuLyoqXG4gKiBAcHVibGljXG4gKi9cbmV4cG9ydCB2YXIgQXJyYXk7XG4oZnVuY3Rpb24gKEFycmF5KSB7XG4gICAgZnVuY3Rpb24gaXNBcnJheSh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gYnVpbHRpbi5BcnJheS5pc0FycmF5KHZhbHVlKTtcbiAgICB9XG4gICAgQXJyYXkuaXNBcnJheSA9IGlzQXJyYXk7XG4gICAgZnVuY3Rpb24gb2YoLi4udmFsdWVzKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZXM7XG4gICAgfVxuICAgIEFycmF5Lm9mID0gb2Y7XG4gICAgZnVuY3Rpb24gZW1wdHkoKSB7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG4gICAgQXJyYXkuZW1wdHkgPSBlbXB0eTtcbiAgICBmdW5jdGlvbiBhbGxvY2F0ZShjYXBhY2l0eSkge1xuICAgICAgICByZXR1cm4gbmV3IGJ1aWx0aW4uQXJyYXkoY2FwYWNpdHkpO1xuICAgIH1cbiAgICBBcnJheS5hbGxvY2F0ZSA9IGFsbG9jYXRlO1xuICAgIC8qKlxuICAgICAqIEByZW1hcmtzXG4gICAgICogVW5saWtlIHRoZSBidWlsdC1pbiBmdW5jdGlvbiBvZiB0aGUgc2FtZSBuYW1lLCB0aGlzIGZ1bmN0aW9uIHdpbGwgcGFzc1xuICAgICAqIGFsb25nIGV4aXN0aW5nIGFycmF5cyBhcy1pcyBpbnN0ZWFkIG9mIHJldHVybmluZyBhIGNvcHkuXG4gICAgICovXG4gICAgZnVuY3Rpb24gZnJvbShpdGVyYWJsZSkge1xuICAgICAgICBpZiAoaXNBcnJheShpdGVyYWJsZSkpIHtcbiAgICAgICAgICAgIHJldHVybiBpdGVyYWJsZTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gWy4uLml0ZXJhYmxlXTtcbiAgICB9XG4gICAgQXJyYXkuZnJvbSA9IGZyb207XG4gICAgZnVuY3Rpb24gc2l6ZShhcnJheSkge1xuICAgICAgICByZXR1cm4gYXJyYXkubGVuZ3RoO1xuICAgIH1cbiAgICBBcnJheS5zaXplID0gc2l6ZTtcbiAgICBmdW5jdGlvbiBpc0VtcHR5KGFycmF5KSB7XG4gICAgICAgIHJldHVybiBhcnJheS5sZW5ndGggPT09IDA7XG4gICAgfVxuICAgIEFycmF5LmlzRW1wdHkgPSBpc0VtcHR5O1xuICAgIGZ1bmN0aW9uIGNvcHkoYXJyYXkpIHtcbiAgICAgICAgcmV0dXJuIGFycmF5LnNsaWNlKDApO1xuICAgIH1cbiAgICBBcnJheS5jb3B5ID0gY29weTtcbiAgICBmdW5jdGlvbiBjbG9uZShhcnJheSkge1xuICAgICAgICByZXR1cm4gYXJyYXkubWFwKENsb25lLmNsb25lKTtcbiAgICB9XG4gICAgQXJyYXkuY2xvbmUgPSBjbG9uZTtcbiAgICBmdW5jdGlvbiBmb3JFYWNoKGFycmF5LCBjYWxsYmFjaykge1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IGFycmF5Lmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgY2FsbGJhY2soYXJyYXlbaV0sIGkpO1xuICAgICAgICB9XG4gICAgfVxuICAgIEFycmF5LmZvckVhY2ggPSBmb3JFYWNoO1xuICAgIGZ1bmN0aW9uIG1hcChhcnJheSwgbWFwcGVyKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IG5ldyBidWlsdGluLkFycmF5KGFycmF5Lmxlbmd0aCk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBuID0gYXJyYXkubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICByZXN1bHRbaV0gPSBtYXBwZXIoYXJyYXlbaV0sIGkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIEFycmF5Lm1hcCA9IG1hcDtcbiAgICBmdW5jdGlvbiBmbGF0TWFwKGFycmF5LCBtYXBwZXIpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gZW1wdHkoKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG4gPSBhcnJheS5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKC4uLm1hcHBlcihhcnJheVtpXSwgaSkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIEFycmF5LmZsYXRNYXAgPSBmbGF0TWFwO1xuICAgIGZ1bmN0aW9uIGZsYXR0ZW4oYXJyYXkpIHtcbiAgICAgICAgcmV0dXJuIGZsYXRNYXAoYXJyYXksIChhcnJheSkgPT4gYXJyYXkpO1xuICAgIH1cbiAgICBBcnJheS5mbGF0dGVuID0gZmxhdHRlbjtcbiAgICBmdW5jdGlvbiByZWR1Y2UoYXJyYXksIHJlZHVjZXIsIGFjY3VtdWxhdG9yKSB7XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBuID0gYXJyYXkubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICBhY2N1bXVsYXRvciA9IHJlZHVjZXIoYWNjdW11bGF0b3IsIGFycmF5W2ldLCBpKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYWNjdW11bGF0b3I7XG4gICAgfVxuICAgIEFycmF5LnJlZHVjZSA9IHJlZHVjZTtcbiAgICBmdW5jdGlvbiByZWR1Y2VXaGlsZShhcnJheSwgcHJlZGljYXRlLCByZWR1Y2VyLCBhY2N1bXVsYXRvcikge1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IGFycmF5Lmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBhcnJheVtpXTtcbiAgICAgICAgICAgIGlmIChwcmVkaWNhdGUodmFsdWUsIGkpKSB7XG4gICAgICAgICAgICAgICAgYWNjdW11bGF0b3IgPSByZWR1Y2VyKGFjY3VtdWxhdG9yLCB2YWx1ZSwgaSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIHtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYWNjdW11bGF0b3I7XG4gICAgfVxuICAgIEFycmF5LnJlZHVjZVdoaWxlID0gcmVkdWNlV2hpbGU7XG4gICAgZnVuY3Rpb24gcmVkdWNlVW50aWwoYXJyYXksIHByZWRpY2F0ZSwgcmVkdWNlciwgYWNjdW11bGF0b3IpIHtcbiAgICAgICAgcmV0dXJuIHJlZHVjZVdoaWxlKGFycmF5LCBub3QocHJlZGljYXRlKSwgcmVkdWNlciwgYWNjdW11bGF0b3IpO1xuICAgIH1cbiAgICBBcnJheS5yZWR1Y2VVbnRpbCA9IHJlZHVjZVVudGlsO1xuICAgIGZ1bmN0aW9uIGFwcGx5KGFycmF5LCBtYXBwZXIpIHtcbiAgICAgICAgcmV0dXJuIGZsYXRNYXAobWFwcGVyLCAobWFwcGVyKSA9PiBtYXAoYXJyYXksIG1hcHBlcikpO1xuICAgIH1cbiAgICBBcnJheS5hcHBseSA9IGFwcGx5O1xuICAgIGZ1bmN0aW9uIGZpbHRlcihhcnJheSwgcHJlZGljYXRlKSB7XG4gICAgICAgIGNvbnN0IHJlc3VsdCA9IGVtcHR5KCk7XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBuID0gYXJyYXkubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICBjb25zdCB2YWx1ZSA9IGFycmF5W2ldO1xuICAgICAgICAgICAgaWYgKHByZWRpY2F0ZSh2YWx1ZSwgaSkpIHtcbiAgICAgICAgICAgICAgICByZXN1bHQucHVzaCh2YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgQXJyYXkuZmlsdGVyID0gZmlsdGVyO1xuICAgIGZ1bmN0aW9uIHJlamVjdChhcnJheSwgcHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiBmaWx0ZXIoYXJyYXksIG5vdChwcmVkaWNhdGUpKTtcbiAgICB9XG4gICAgQXJyYXkucmVqZWN0ID0gcmVqZWN0O1xuICAgIGZ1bmN0aW9uIGZpbmQoYXJyYXksIHByZWRpY2F0ZSkge1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IGFycmF5Lmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBhcnJheVtpXTtcbiAgICAgICAgICAgIGlmIChwcmVkaWNhdGUodmFsdWUsIGkpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIE9wdGlvbi5vZih2YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIE5vbmU7XG4gICAgfVxuICAgIEFycmF5LmZpbmQgPSBmaW5kO1xuICAgIGZ1bmN0aW9uIGZpbmRMYXN0KGFycmF5LCBwcmVkaWNhdGUpIHtcbiAgICAgICAgZm9yIChsZXQgaSA9IGFycmF5Lmxlbmd0aCAtIDE7IGkgPj0gMDsgaS0tKSB7XG4gICAgICAgICAgICBjb25zdCB2YWx1ZSA9IGFycmF5W2ldO1xuICAgICAgICAgICAgaWYgKHByZWRpY2F0ZSh2YWx1ZSwgaSkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gT3B0aW9uLm9mKHZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gTm9uZTtcbiAgICB9XG4gICAgQXJyYXkuZmluZExhc3QgPSBmaW5kTGFzdDtcbiAgICBmdW5jdGlvbiBpbmNsdWRlcyhhcnJheSwgdmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHNvbWUoYXJyYXksIFByZWRpY2F0ZS5lcXVhbHModmFsdWUpKTtcbiAgICB9XG4gICAgQXJyYXkuaW5jbHVkZXMgPSBpbmNsdWRlcztcbiAgICBmdW5jdGlvbiBjb2xsZWN0KGFycmF5LCBtYXBwZXIpIHtcbiAgICAgICAgY29uc3QgcmVzdWx0ID0gZW1wdHkoKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG4gPSBhcnJheS5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIGZvciAoY29uc3QgdmFsdWUgb2YgbWFwcGVyKGFycmF5W2ldLCBpKSkge1xuICAgICAgICAgICAgICAgIHJlc3VsdC5wdXNoKHZhbHVlKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBBcnJheS5jb2xsZWN0ID0gY29sbGVjdDtcbiAgICBmdW5jdGlvbiBjb2xsZWN0Rmlyc3QoYXJyYXksIG1hcHBlcikge1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IGFycmF5Lmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBtYXBwZXIoYXJyYXlbaV0sIGkpO1xuICAgICAgICAgICAgaWYgKHZhbHVlLmlzU29tZSgpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIHZhbHVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBOb25lO1xuICAgIH1cbiAgICBBcnJheS5jb2xsZWN0Rmlyc3QgPSBjb2xsZWN0Rmlyc3Q7XG4gICAgZnVuY3Rpb24gc29tZShhcnJheSwgcHJlZGljYXRlKSB7XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBuID0gYXJyYXkubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICBpZiAocHJlZGljYXRlKGFycmF5W2ldLCBpKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgQXJyYXkuc29tZSA9IHNvbWU7XG4gICAgZnVuY3Rpb24gbm9uZShhcnJheSwgcHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiBldmVyeShhcnJheSwgbm90KHByZWRpY2F0ZSkpO1xuICAgIH1cbiAgICBBcnJheS5ub25lID0gbm9uZTtcbiAgICBmdW5jdGlvbiBldmVyeShhcnJheSwgcHJlZGljYXRlKSB7XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBuID0gYXJyYXkubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICBpZiAoIXByZWRpY2F0ZShhcnJheVtpXSwgaSkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIEFycmF5LmV2ZXJ5ID0gZXZlcnk7XG4gICAgZnVuY3Rpb24gY291bnQoYXJyYXksIHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gcmVkdWNlKGFycmF5LCAoY291bnQsIHZhbHVlLCBpbmRleCkgPT4gKHByZWRpY2F0ZSh2YWx1ZSwgaW5kZXgpID8gY291bnQgKyAxIDogY291bnQpLCAwKTtcbiAgICB9XG4gICAgQXJyYXkuY291bnQgPSBjb3VudDtcbiAgICBmdW5jdGlvbiBkaXN0aW5jdChhcnJheSkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBlbXB0eSgpO1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IGFycmF5Lmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgY29uc3QgdmFsdWUgPSBhcnJheVtpXTtcbiAgICAgICAgICAgIGlmIChyZXN1bHQuc29tZShQcmVkaWNhdGUuZXF1YWxzKHZhbHVlKSkpIHtcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJlc3VsdC5wdXNoKHZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBBcnJheS5kaXN0aW5jdCA9IGRpc3RpbmN0O1xuICAgIGZ1bmN0aW9uIGdldChhcnJheSwgaW5kZXgpIHtcbiAgICAgICAgcmV0dXJuIGluZGV4IDwgYXJyYXkubGVuZ3RoID8gT3B0aW9uLm9mKGFycmF5W2luZGV4XSkgOiBOb25lO1xuICAgIH1cbiAgICBBcnJheS5nZXQgPSBnZXQ7XG4gICAgZnVuY3Rpb24gaGFzKGFycmF5LCBpbmRleCkge1xuICAgICAgICByZXR1cm4gaW5kZXggPCBhcnJheS5sZW5ndGg7XG4gICAgfVxuICAgIEFycmF5LmhhcyA9IGhhcztcbiAgICBmdW5jdGlvbiBzZXQoYXJyYXksIGluZGV4LCB2YWx1ZSkge1xuICAgICAgICBpZiAoaW5kZXggPCBhcnJheS5sZW5ndGgpIHtcbiAgICAgICAgICAgIGFycmF5W2luZGV4XSA9IHZhbHVlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBhcnJheTtcbiAgICB9XG4gICAgQXJyYXkuc2V0ID0gc2V0O1xuICAgIGZ1bmN0aW9uIGluc2VydChhcnJheSwgaW5kZXgsIHZhbHVlKSB7XG4gICAgICAgIGlmIChpbmRleCA8PSBhcnJheS5sZW5ndGgpIHtcbiAgICAgICAgICAgIGFycmF5LnNwbGljZShpbmRleCwgMCwgdmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBhcnJheTtcbiAgICB9XG4gICAgQXJyYXkuaW5zZXJ0ID0gaW5zZXJ0O1xuICAgIGZ1bmN0aW9uIGFwcGVuZChhcnJheSwgdmFsdWUpIHtcbiAgICAgICAgYXJyYXkucHVzaCh2YWx1ZSk7XG4gICAgICAgIHJldHVybiBhcnJheTtcbiAgICB9XG4gICAgQXJyYXkuYXBwZW5kID0gYXBwZW5kO1xuICAgIGZ1bmN0aW9uIHByZXBlbmQoYXJyYXksIHZhbHVlKSB7XG4gICAgICAgIGFycmF5LnVuc2hpZnQodmFsdWUpO1xuICAgICAgICByZXR1cm4gYXJyYXk7XG4gICAgfVxuICAgIEFycmF5LnByZXBlbmQgPSBwcmVwZW5kO1xuICAgIGZ1bmN0aW9uIGNvbmNhdChhcnJheSwgLi4uaXRlcmFibGVzKSB7XG4gICAgICAgIHJldHVybiBbLi4uSXRlcmFibGUuY29uY2F0KGFycmF5LCAuLi5pdGVyYWJsZXMpXTtcbiAgICB9XG4gICAgQXJyYXkuY29uY2F0ID0gY29uY2F0O1xuICAgIGZ1bmN0aW9uIHN1YnRyYWN0KGFycmF5LCAuLi5pdGVyYWJsZXMpIHtcbiAgICAgICAgcmV0dXJuIFsuLi5JdGVyYWJsZS5zdWJ0cmFjdChhcnJheSwgLi4uaXRlcmFibGVzKV07XG4gICAgfVxuICAgIEFycmF5LnN1YnRyYWN0ID0gc3VidHJhY3Q7XG4gICAgZnVuY3Rpb24gaW50ZXJzZWN0KGFycmF5LCAuLi5pdGVyYWJsZXMpIHtcbiAgICAgICAgcmV0dXJuIFsuLi5JdGVyYWJsZS5pbnRlcnNlY3QoYXJyYXksIC4uLml0ZXJhYmxlcyldO1xuICAgIH1cbiAgICBBcnJheS5pbnRlcnNlY3QgPSBpbnRlcnNlY3Q7XG4gICAgZnVuY3Rpb24gemlwKGFycmF5LCBpdGVyYWJsZSkge1xuICAgICAgICBjb25zdCByZXN1bHQgPSBlbXB0eSgpO1xuICAgICAgICBjb25zdCBpdCA9IEl0ZXJhYmxlLml0ZXJhdG9yKGl0ZXJhYmxlKTtcbiAgICAgICAgZm9yIChsZXQgaSA9IDAsIG4gPSBhcnJheS5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIGNvbnN0IG5leHQgPSBpdC5uZXh0KCk7XG4gICAgICAgICAgICBpZiAobmV4dC5kb25lID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXN1bHQucHVzaChbYXJyYXlbaV0sIG5leHQudmFsdWVdKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgIH1cbiAgICBBcnJheS56aXAgPSB6aXA7XG4gICAgZnVuY3Rpb24gZmlyc3QoYXJyYXkpIHtcbiAgICAgICAgcmV0dXJuIGFycmF5Lmxlbmd0aCA+IDAgPyBPcHRpb24ub2YoYXJyYXlbMF0pIDogTm9uZTtcbiAgICB9XG4gICAgQXJyYXkuZmlyc3QgPSBmaXJzdDtcbiAgICBmdW5jdGlvbiBsYXN0KGFycmF5KSB7XG4gICAgICAgIHJldHVybiBhcnJheS5sZW5ndGggPiAwID8gT3B0aW9uLm9mKGFycmF5W2FycmF5Lmxlbmd0aCAtIDFdKSA6IE5vbmU7XG4gICAgfVxuICAgIEFycmF5Lmxhc3QgPSBsYXN0O1xuICAgIGZ1bmN0aW9uIHNvcnQoYXJyYXkpIHtcbiAgICAgICAgcmV0dXJuIHNvcnRXaXRoKGFycmF5LCBjb21wYXJlQ29tcGFyYWJsZSk7XG4gICAgfVxuICAgIEFycmF5LnNvcnQgPSBzb3J0O1xuICAgIGZ1bmN0aW9uIHNvcnRXaXRoKGFycmF5LCBjb21wYXJlcikge1xuICAgICAgICByZXR1cm4gYXJyYXkuc29ydChjb21wYXJlcik7XG4gICAgfVxuICAgIEFycmF5LnNvcnRXaXRoID0gc29ydFdpdGg7XG4gICAgZnVuY3Rpb24gY29tcGFyZShhLCBiKSB7XG4gICAgICAgIHJldHVybiBjb21wYXJlV2l0aChhLCBiLCBjb21wYXJlQ29tcGFyYWJsZSk7XG4gICAgfVxuICAgIEFycmF5LmNvbXBhcmUgPSBjb21wYXJlO1xuICAgIGZ1bmN0aW9uIGNvbXBhcmVXaXRoKGEsIGIsIGNvbXBhcmVyKSB7XG4gICAgICAgIHJldHVybiBJdGVyYWJsZS5jb21wYXJlV2l0aChhLCBiLCBjb21wYXJlcik7XG4gICAgfVxuICAgIEFycmF5LmNvbXBhcmVXaXRoID0gY29tcGFyZVdpdGg7XG4gICAgZnVuY3Rpb24gc2VhcmNoKGFycmF5LCB2YWx1ZSwgY29tcGFyZXIpIHtcbiAgICAgICAgbGV0IGxvd2VyID0gMDtcbiAgICAgICAgbGV0IHVwcGVyID0gYXJyYXkubGVuZ3RoIC0gMTtcbiAgICAgICAgd2hpbGUgKGxvd2VyIDw9IHVwcGVyKSB7XG4gICAgICAgICAgICBjb25zdCBtaWRkbGUgPSAobG93ZXIgKyAodXBwZXIgLSBsb3dlcikgLyAyKSA+Pj4gMDtcbiAgICAgICAgICAgIHN3aXRjaCAoY29tcGFyZXIodmFsdWUsIGFycmF5W21pZGRsZV0pKSB7XG4gICAgICAgICAgICAgICAgY2FzZSBDb21wYXJpc29uLkdyZWF0ZXI6XG4gICAgICAgICAgICAgICAgICAgIGxvd2VyID0gbWlkZGxlICsgMTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSBDb21wYXJpc29uLkxlc3M6XG4gICAgICAgICAgICAgICAgICAgIHVwcGVyID0gbWlkZGxlIC0gMTtcbiAgICAgICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICAgICAgY2FzZSBDb21wYXJpc29uLkVxdWFsOlxuICAgICAgICAgICAgICAgICAgICByZXR1cm4gbWlkZGxlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBsb3dlcjtcbiAgICB9XG4gICAgQXJyYXkuc2VhcmNoID0gc2VhcmNoO1xuICAgIGZ1bmN0aW9uIGVxdWFscyhhLCBiKSB7XG4gICAgICAgIGlmIChhLmxlbmd0aCAhPT0gYi5sZW5ndGgpIHtcbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfVxuICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IGEubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICBpZiAoIUVxdWF0YWJsZS5lcXVhbHMoYVtpXSwgYltpXSkpIHtcbiAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIEFycmF5LmVxdWFscyA9IGVxdWFscztcbiAgICBmdW5jdGlvbiBoYXNoKGFycmF5LCBoYXNoKSB7XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBuID0gYXJyYXkubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICBoYXNoLndyaXRlVW5rbm93bihhcnJheVtpXSk7XG4gICAgICAgIH1cbiAgICAgICAgaGFzaC53cml0ZVVpbnQzMihhcnJheS5sZW5ndGgpO1xuICAgIH1cbiAgICBBcnJheS5oYXNoID0gaGFzaDtcbiAgICBmdW5jdGlvbiBpdGVyYXRvcihhcnJheSkge1xuICAgICAgICByZXR1cm4gYXJyYXlbU3ltYm9sLml0ZXJhdG9yXSgpO1xuICAgIH1cbiAgICBBcnJheS5pdGVyYXRvciA9IGl0ZXJhdG9yO1xuICAgIGZ1bmN0aW9uIHRvSlNPTihhcnJheSwgb3B0aW9ucykge1xuICAgICAgICByZXR1cm4gYXJyYXkubWFwKCh2YWx1ZSkgPT4gU2VyaWFsaXphYmxlLnRvSlNPTih2YWx1ZSwgb3B0aW9ucykpO1xuICAgIH1cbiAgICBBcnJheS50b0pTT04gPSB0b0pTT047XG59KShBcnJheSB8fCAoQXJyYXkgPSB7fSkpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YXJyYXkuanMubWFwIiwiLy8gVGhpcyBmaWxlIGRlZmluZXMgZXhwb3J0cyBmcm9tIHRoZSBidWlsdGluIGBBcnJheWAgY29uc3RydWN0b3IgZm9yIGludGVybmFsXG4vLyB1c2Ugb25seS5cbi8qKlxuICogQGludGVybmFsXG4gKi9cbmNvbnN0IEJ1aWx0aW4gPSBBcnJheTtcbmV4cG9ydCB7IEJ1aWx0aW4gYXMgQXJyYXkgfTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWJ1aWx0aW4uanMubWFwIiwiLyoqXG4gKiBUaGlzIHBhY2thZ2UgcHJvdmlkZXMgZnVuY3Rpb25hbGl0eSBmb3Igd29ya2luZyB3aXRoIGFycmF5cy5cbiAqXG4gKiBAcGFja2FnZURvY3VtZW50YXRpb25cbiAqL1xuZXhwb3J0ICogZnJvbSBcIi4vYXJyYXkuanNcIjtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsIi8qKlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgdmFyIEJpdHM7XG4oZnVuY3Rpb24gKEJpdHMpIHtcbiAgICBmdW5jdGlvbiBiaXQoaSkge1xuICAgICAgICByZXR1cm4gMSA8PCBpO1xuICAgIH1cbiAgICBCaXRzLmJpdCA9IGJpdDtcbiAgICBmdW5jdGlvbiBzZXQoYml0cywgaSkge1xuICAgICAgICByZXR1cm4gYml0cyB8IGJpdChpKTtcbiAgICB9XG4gICAgQml0cy5zZXQgPSBzZXQ7XG4gICAgZnVuY3Rpb24gY2xlYXIoYml0cywgaSkge1xuICAgICAgICByZXR1cm4gYml0cyAmIH5iaXQoaSk7XG4gICAgfVxuICAgIEJpdHMuY2xlYXIgPSBjbGVhcjtcbiAgICBmdW5jdGlvbiB0ZXN0KGJpdHMsIGkpIHtcbiAgICAgICAgcmV0dXJuIChiaXRzICYgYml0KGkpKSAhPT0gMDtcbiAgICB9XG4gICAgQml0cy50ZXN0ID0gdGVzdDtcbiAgICBmdW5jdGlvbiB0YWtlKGJpdHMsIG4pIHtcbiAgICAgICAgcmV0dXJuIGJpdHMgJiAoKDEgPDwgbikgLSAxKTtcbiAgICB9XG4gICAgQml0cy50YWtlID0gdGFrZTtcbiAgICBmdW5jdGlvbiBza2lwKGJpdHMsIG4pIHtcbiAgICAgICAgcmV0dXJuIGJpdHMgPj4+IG47XG4gICAgfVxuICAgIEJpdHMuc2tpcCA9IHNraXA7XG4gICAgLyoqXG4gICAgICogQHJlbWFya3NcbiAgICAgKiBUaGlzIGlzIGEgMzItYml0IHZhcmlhbnQgb2YgdGhlIDY0LWJpdCBwb3B1bGF0aW9uIGNvdW50IGFsZ29yaXRobSBvdXRsaW5lZFxuICAgICAqIG9uIFdpa2lwZWRpYS4gVW50aWwgRUNNQVNjcmlwdCBuYXRpdmVseSBwcm92aWRlcyBhbiBlZmZpY2llbnQgcG9wdWxhdGlvblxuICAgICAqIGNvdW50IGFsZ29yaXRobSwgdGhpcyBpcyB0aGUgYmVzdCB3ZSBjYW4gZG8uXG4gICAgICpcbiAgICAgKiB7QGxpbmsgaHR0cHM6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvSGFtbWluZ193ZWlnaHR9XG4gICAgICovXG4gICAgZnVuY3Rpb24gcG9wQ291bnQoYml0cykge1xuICAgICAgICBiaXRzIC09IChiaXRzID4+IDEpICYgMHg1NTU1NTU1NTtcbiAgICAgICAgYml0cyA9IChiaXRzICYgMHgzMzMzMzMzMykgKyAoKGJpdHMgPj4gMikgJiAweDMzMzMzMzMzKTtcbiAgICAgICAgYml0cyA9IChiaXRzICsgKGJpdHMgPj4gNCkpICYgMHgwZjBmMGYwZjtcbiAgICAgICAgYml0cyArPSBiaXRzID4+IDg7XG4gICAgICAgIGJpdHMgKz0gYml0cyA+PiAxNjtcbiAgICAgICAgcmV0dXJuIGJpdHMgJiAweDdmO1xuICAgIH1cbiAgICBCaXRzLnBvcENvdW50ID0gcG9wQ291bnQ7XG59KShCaXRzIHx8IChCaXRzID0ge30pKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWJpdHMuanMubWFwIiwiZXhwb3J0ICogZnJvbSBcIi4vYml0cy5qc1wiO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXguanMubWFwIiwiLyoqXG4gKiBAcHVibGljXG4gKi9cbmV4cG9ydCB2YXIgQ2xvbmU7XG4oZnVuY3Rpb24gKENsb25lKSB7XG4gICAgZnVuY3Rpb24gY2xvbmUodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlLmNsb25lKCk7XG4gICAgfVxuICAgIENsb25lLmNsb25lID0gY2xvbmU7XG59KShDbG9uZSB8fCAoQ2xvbmUgPSB7fSkpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y2xvbmUuanMubWFwIiwiZXhwb3J0ICogZnJvbSBcIi4vY2xvbmUuanNcIjtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsImltcG9ydCB7IFJlZmluZW1lbnQgfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtcmVmaW5lbWVudFwiO1xuaW1wb3J0IHsgQ29tcGFyaXNvbiB9IGZyb20gXCIuL2NvbXBhcmlzb24uanNcIjtcbmNvbnN0IHsgaXNTdHJpbmcsIGlzTnVtYmVyLCBpc0JpZ0ludCwgaXNCb29sZWFuLCBpc0Z1bmN0aW9uLCBpc09iamVjdCB9ID0gUmVmaW5lbWVudDtcbi8qKlxuICogVGhpcyBuYW1lc3BhY2UgcHJvdmlkZXMgYWRkaXRpb25hbCBmdW5jdGlvbnMgZm9yIHRoZVxuICoge0BsaW5rIChDb21wYXJhYmxlOmludGVyZmFjZSl9IGludGVyZmFjZS5cbiAqXG4gKiBAcHVibGljXG4gKi9cbmV4cG9ydCB2YXIgQ29tcGFyYWJsZTtcbihmdW5jdGlvbiAoQ29tcGFyYWJsZSkge1xuICAgIC8qKlxuICAgICAqIENoZWNrIGlmIGFuIHVua25vd24gdmFsdWUgaW1wbGVtZW50cyB0aGUge0BsaW5rIChDb21wYXJhYmxlOmludGVyZmFjZSl9XG4gICAgICogaW50ZXJmYWNlLlxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGlzQ29tcGFyYWJsZSh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gaXNPYmplY3QodmFsdWUpICYmIGlzRnVuY3Rpb24odmFsdWUuY29tcGFyZSk7XG4gICAgfVxuICAgIENvbXBhcmFibGUuaXNDb21wYXJhYmxlID0gaXNDb21wYXJhYmxlO1xuICAgIGZ1bmN0aW9uIGNvbXBhcmUoYSwgYikge1xuICAgICAgICBpZiAoaXNTdHJpbmcoYSkpIHtcbiAgICAgICAgICAgIHJldHVybiBjb21wYXJlU3RyaW5nKGEsIGIpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc051bWJlcihhKSkge1xuICAgICAgICAgICAgcmV0dXJuIGNvbXBhcmVOdW1iZXIoYSwgYik7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzQmlnSW50KGEpKSB7XG4gICAgICAgICAgICByZXR1cm4gY29tcGFyZUJpZ0ludChhLCBiKTtcbiAgICAgICAgfVxuICAgICAgICBpZiAoaXNCb29sZWFuKGEpKSB7XG4gICAgICAgICAgICByZXR1cm4gY29tcGFyZUJvb2xlYW4oYSwgYik7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGNvbXBhcmVDb21wYXJhYmxlKGEsIGIpO1xuICAgIH1cbiAgICBDb21wYXJhYmxlLmNvbXBhcmUgPSBjb21wYXJlO1xuICAgIC8qKlxuICAgICAqIEByZW1hcmtzXG4gICAgICogVGhpcyBzaG91bGQgb25seSBiZSB1c2VkIGluIGNhc2VzIHdoZXJlIGJyYW5jaCBtaXNwcmVkaWN0aW9ucyBjYXVzZWQgYnkgdGhlXG4gICAgICogbW9yZSBnZW5lcmFsIHtAbGluayAoQ29tcGFyYWJsZTpuYW1lc3BhY2UpLihjb21wYXJlOjEpfSBhcmUgdW5kZXNpcmVkLlxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGNvbXBhcmVTdHJpbmcoYSwgYikge1xuICAgICAgICByZXR1cm4gY29tcGFyZVByaW1pdGl2ZShhLCBiKTtcbiAgICB9XG4gICAgQ29tcGFyYWJsZS5jb21wYXJlU3RyaW5nID0gY29tcGFyZVN0cmluZztcbiAgICAvKipcbiAgICAgKiBAcmVtYXJrc1xuICAgICAqIFRoaXMgc2hvdWxkIG9ubHkgYmUgdXNlZCBpbiBjYXNlcyB3aGVyZSBicmFuY2ggbWlzcHJlZGljdGlvbnMgY2F1c2VkIGJ5IHRoZVxuICAgICAqIG1vcmUgZ2VuZXJhbCB7QGxpbmsgKENvbXBhcmFibGU6bmFtZXNwYWNlKS4oY29tcGFyZToyKX0gYXJlIHVuZGVzaXJlZC5cbiAgICAgKi9cbiAgICBmdW5jdGlvbiBjb21wYXJlTnVtYmVyKGEsIGIpIHtcbiAgICAgICAgcmV0dXJuIGNvbXBhcmVQcmltaXRpdmUoYSwgYik7XG4gICAgfVxuICAgIENvbXBhcmFibGUuY29tcGFyZU51bWJlciA9IGNvbXBhcmVOdW1iZXI7XG4gICAgLyoqXG4gICAgICogQHJlbWFya3NcbiAgICAgKiBUaGlzIHNob3VsZCBvbmx5IGJlIHVzZWQgaW4gY2FzZXMgd2hlcmUgYnJhbmNoIG1pc3ByZWRpY3Rpb25zIGNhdXNlZCBieSB0aGVcbiAgICAgKiBtb3JlIGdlbmVyYWwge0BsaW5rIChDb21wYXJhYmxlOm5hbWVzcGFjZSkuKGNvbXBhcmU6Myl9IGFyZSB1bmRlc2lyZWQuXG4gICAgICovXG4gICAgZnVuY3Rpb24gY29tcGFyZUJpZ0ludChhLCBiKSB7XG4gICAgICAgIHJldHVybiBjb21wYXJlUHJpbWl0aXZlKGEsIGIpO1xuICAgIH1cbiAgICBDb21wYXJhYmxlLmNvbXBhcmVCaWdJbnQgPSBjb21wYXJlQmlnSW50O1xuICAgIC8qKlxuICAgICAqIEByZW1hcmtzXG4gICAgICogVGhpcyBzaG91bGQgb25seSBiZSB1c2VkIGluIGNhc2VzIHdoZXJlIGJyYW5jaCBtaXNwcmVkaWN0aW9ucyBjYXVzZWQgYnkgdGhlXG4gICAgICogbW9yZSBnZW5lcmFsIHtAbGluayAoQ29tcGFyYWJsZTpuYW1lc3BhY2UpLihjb21wYXJlOjQpfSBhcmUgdW5kZXNpcmVkLlxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGNvbXBhcmVCb29sZWFuKGEsIGIpIHtcbiAgICAgICAgcmV0dXJuIGNvbXBhcmVQcmltaXRpdmUoYSwgYik7XG4gICAgfVxuICAgIENvbXBhcmFibGUuY29tcGFyZUJvb2xlYW4gPSBjb21wYXJlQm9vbGVhbjtcbiAgICAvKipcbiAgICAgKiBAcmVtYXJrc1xuICAgICAqIFRoaXMgc2hvdWxkIG9ubHkgYmUgdXNlZCBpbiBjYXNlcyB3aGVyZSBicmFuY2ggbWlzcHJlZGljdGlvbnMgY2F1c2VkIGJ5IHRoZVxuICAgICAqIG1vcmUgZ2VuZXJhbCB7QGxpbmsgKENvbXBhcmFibGU6bmFtZXNwYWNlKS4oY29tcGFyZTo1KX0gYXJlIHVuZGVzaXJlZC5cbiAgICAgKi9cbiAgICBmdW5jdGlvbiBjb21wYXJlQ29tcGFyYWJsZShhLCBiKSB7XG4gICAgICAgIHJldHVybiBhLmNvbXBhcmUoYik7XG4gICAgfVxuICAgIENvbXBhcmFibGUuY29tcGFyZUNvbXBhcmFibGUgPSBjb21wYXJlQ29tcGFyYWJsZTtcbiAgICAvKipcbiAgICAgKiBDb21wYXJlIHR3byBwcmltaXRpdmUgdmFsdWVzLlxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGNvbXBhcmVQcmltaXRpdmUoYSwgYikge1xuICAgICAgICBpZiAoYSA8IGIpIHtcbiAgICAgICAgICAgIHJldHVybiBDb21wYXJpc29uLkxlc3M7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGEgPiBiKSB7XG4gICAgICAgICAgICByZXR1cm4gQ29tcGFyaXNvbi5HcmVhdGVyO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBDb21wYXJpc29uLkVxdWFsO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBDb21wYXJlIHR1cGxlcyBsZXhpY29ncmFwaGljYWxseVxuICAgICAqXG4gICAgICoge0BsaW5rIGh0dHBzOi8vZW4ud2lraXBlZGlhLm9yZy93aWtpL0xleGljb2dyYXBoaWNfb3JkZXJ9XG4gICAgICovXG4gICAgZnVuY3Rpb24gY29tcGFyZUxleGljb2dyYXBoaWNhbGx5KGEsIGIsIGNvbXBhcmVyKSB7XG4gICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgYS5sZW5ndGg7IGkrKykge1xuICAgICAgICAgICAgY29uc3QgY29tcGFyaXNvbiA9IGNvbXBhcmVyW2ldKGFbaV0sIGJbaV0pO1xuICAgICAgICAgICAgaWYgKGNvbXBhcmlzb24gPT09IENvbXBhcmlzb24uRXF1YWwpIHtcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBjb21wYXJpc29uO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBDb21wYXJpc29uLkVxdWFsO1xuICAgIH1cbiAgICBDb21wYXJhYmxlLmNvbXBhcmVMZXhpY29ncmFwaGljYWxseSA9IGNvbXBhcmVMZXhpY29ncmFwaGljYWxseTtcbiAgICAvKipcbiAgICAgKiBDaGVjayBpZiBvbmUgdmFsdWUgaXMgbGVzcyB0aGFuIGFub3RoZXIuXG4gICAgICovXG4gICAgZnVuY3Rpb24gaXNMZXNzVGhhbihhLCBiKSB7XG4gICAgICAgIHJldHVybiBhLmNvbXBhcmUoYikgPCAwO1xuICAgIH1cbiAgICBDb21wYXJhYmxlLmlzTGVzc1RoYW4gPSBpc0xlc3NUaGFuO1xuICAgIC8qKlxuICAgICAqIENoZWNrIGlmIG9uZSB2YWx1ZSBpcyBsZXNzIHRoYW4gb3IgZXF1YWwgdG8gYW5vdGhlci5cbiAgICAgKi9cbiAgICBmdW5jdGlvbiBpc0xlc3NUaGFuT3JFcXVhbChhLCBiKSB7XG4gICAgICAgIHJldHVybiBhLmNvbXBhcmUoYikgPD0gMDtcbiAgICB9XG4gICAgQ29tcGFyYWJsZS5pc0xlc3NUaGFuT3JFcXVhbCA9IGlzTGVzc1RoYW5PckVxdWFsO1xuICAgIC8qKlxuICAgICAqIENoZWNrIGlmIG9uZSB2YWx1ZSBpcyBlcXVhbCB0byBhbm90aGVyXG4gICAgICovXG4gICAgZnVuY3Rpb24gaXNFcXVhbChhLCBiKSB7XG4gICAgICAgIHJldHVybiBhLmNvbXBhcmUoYikgPT09IDA7XG4gICAgfVxuICAgIENvbXBhcmFibGUuaXNFcXVhbCA9IGlzRXF1YWw7XG4gICAgLyoqXG4gICAgICogQ2hlY2sgaWYgb25lIHZhbHVlIGlzIGdyZWF0ZXIgdGhhbiBhbm90aGVyLlxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGlzR3JlYXRlclRoYW4oYSwgYikge1xuICAgICAgICByZXR1cm4gYS5jb21wYXJlKGIpID4gMDtcbiAgICB9XG4gICAgQ29tcGFyYWJsZS5pc0dyZWF0ZXJUaGFuID0gaXNHcmVhdGVyVGhhbjtcbiAgICAvKipcbiAgICAgKiBDaGVjayBpZiBvbmUgdmFsdWUgaXMgZ3JlYXRlciB0aGFuIG9yIGVxdWFsIHRvIGFub3RoZXIuXG4gICAgICovXG4gICAgZnVuY3Rpb24gaXNHcmVhdGVyVGhhbk9yRXF1YWwoYSwgYikge1xuICAgICAgICByZXR1cm4gYS5jb21wYXJlKGIpID49IDA7XG4gICAgfVxuICAgIENvbXBhcmFibGUuaXNHcmVhdGVyVGhhbk9yRXF1YWwgPSBpc0dyZWF0ZXJUaGFuT3JFcXVhbDtcbn0pKENvbXBhcmFibGUgfHwgKENvbXBhcmFibGUgPSB7fSkpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9Y29tcGFyYWJsZS5qcy5tYXAiLCJleHBvcnQge307XG4vLyMgc291cmNlTWFwcGluZ1VSTD1jb21wYXJlci5qcy5tYXAiLCIvKipcbiAqIEByZW1hcmtzXG4gKiBDb21wYXJpc29ucyBhcmUgbGltaXRlZCB0byB0aGUgcmFuZ2UgWy0xLCAxXSBpbiBvcmRlciB0byBhdm9pZCB0aGUgcG90ZW50aWFsXG4gKiBvZiBvdmVyLS91bmRlcmZsb3dzIHdoZW4gY29tcGFyaXNvbnMgYXJlIGltcGxlbWVudGVkIG5haXZlbHkgdXNpbmdcbiAqIHN1YnRyYWN0aW9ucywgc3VjaCBgYSAtIGJgOyB0aGlzIHdvdWxkIG5vdCBiZSBhbGxvd2VkLlxuICpcbiAqIEBwdWJsaWNcbiAqL1xuZXhwb3J0IHZhciBDb21wYXJpc29uO1xuKGZ1bmN0aW9uIChDb21wYXJpc29uKSB7XG4gICAgQ29tcGFyaXNvbltDb21wYXJpc29uW1wiTGVzc1wiXSA9IC0xXSA9IFwiTGVzc1wiO1xuICAgIENvbXBhcmlzb25bQ29tcGFyaXNvbltcIkVxdWFsXCJdID0gMF0gPSBcIkVxdWFsXCI7XG4gICAgQ29tcGFyaXNvbltDb21wYXJpc29uW1wiR3JlYXRlclwiXSA9IDFdID0gXCJHcmVhdGVyXCI7XG59KShDb21wYXJpc29uIHx8IChDb21wYXJpc29uID0ge30pKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWNvbXBhcmlzb24uanMubWFwIiwiZXhwb3J0ICogZnJvbSBcIi4vY29tcGFyYWJsZS5qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vY29tcGFyZXIuanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL2NvbXBhcmlzb24uanNcIjtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsIi8qKlxuICoge0BsaW5rIGh0dHBzOi8vZW5jb2Rpbmcuc3BlYy53aGF0d2cub3JnLyN0ZXh0ZGVjb2Rlcn1cbiAqXG4gKiBAcHVibGljXG4gKi9cbmV4cG9ydCB2YXIgRGVjb2RlcjtcbihmdW5jdGlvbiAoRGVjb2Rlcikge1xuICAgIC8qKlxuICAgICAqIHtAbGluayBodHRwczovL2VuY29kaW5nLnNwZWMud2hhdHdnLm9yZy8jZG9tLXRleHRkZWNvZGVyLWRlY29kZX1cbiAgICAgKiB7QGxpbmsgaHR0cHM6Ly9lbmNvZGluZy5zcGVjLndoYXR3Zy5vcmcvI3V0Zi04LWRlY29kZXJ9XG4gICAgICovXG4gICAgZnVuY3Rpb24gZGVjb2RlKGlucHV0KSB7XG4gICAgICAgIGxldCBvdXRwdXQgPSBcIlwiO1xuICAgICAgICBsZXQgaSA9IDA7XG4gICAgICAgIHdoaWxlIChpIDwgaW5wdXQubGVuZ3RoKSB7XG4gICAgICAgICAgICBsZXQgYnl0ZSA9IGlucHV0W2ldO1xuICAgICAgICAgICAgbGV0IGJ5dGVzTmVlZGVkID0gMDtcbiAgICAgICAgICAgIGxldCBjb2RlUG9pbnQgPSAwO1xuICAgICAgICAgICAgaWYgKGJ5dGUgPD0gMHg3Zikge1xuICAgICAgICAgICAgICAgIGJ5dGVzTmVlZGVkID0gMDtcbiAgICAgICAgICAgICAgICBjb2RlUG9pbnQgPSBieXRlICYgMHhmZjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGJ5dGUgPD0gMHhkZikge1xuICAgICAgICAgICAgICAgIGJ5dGVzTmVlZGVkID0gMTtcbiAgICAgICAgICAgICAgICBjb2RlUG9pbnQgPSBieXRlICYgMHgxZjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGJ5dGUgPD0gMHhlZikge1xuICAgICAgICAgICAgICAgIGJ5dGVzTmVlZGVkID0gMjtcbiAgICAgICAgICAgICAgICBjb2RlUG9pbnQgPSBieXRlICYgMHgwZjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2UgaWYgKGJ5dGUgPD0gMHhmNCkge1xuICAgICAgICAgICAgICAgIGJ5dGVzTmVlZGVkID0gMztcbiAgICAgICAgICAgICAgICBjb2RlUG9pbnQgPSBieXRlICYgMHgwNztcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGlmIChpbnB1dC5sZW5ndGggLSBpIC0gYnl0ZXNOZWVkZWQgPiAwKSB7XG4gICAgICAgICAgICAgICAgbGV0IGsgPSAwO1xuICAgICAgICAgICAgICAgIHdoaWxlIChrIDwgYnl0ZXNOZWVkZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgYnl0ZSA9IGlucHV0W2kgKyBrICsgMV07XG4gICAgICAgICAgICAgICAgICAgIGNvZGVQb2ludCA9IChjb2RlUG9pbnQgPDwgNikgfCAoYnl0ZSAmIDB4M2YpO1xuICAgICAgICAgICAgICAgICAgICBrICs9IDE7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgY29kZVBvaW50ID0gMHhmZmZkO1xuICAgICAgICAgICAgICAgIGJ5dGVzTmVlZGVkID0gaW5wdXQubGVuZ3RoIC0gaTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIG91dHB1dCArPSBTdHJpbmcuZnJvbUNvZGVQb2ludChjb2RlUG9pbnQpO1xuICAgICAgICAgICAgaSArPSBieXRlc05lZWRlZCArIDE7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG91dHB1dDtcbiAgICB9XG4gICAgRGVjb2Rlci5kZWNvZGUgPSBkZWNvZGU7XG59KShEZWNvZGVyIHx8IChEZWNvZGVyID0ge30pKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWRlY29kZXIuanMubWFwIiwiLyoqXG4gKiB7QGxpbmsgaHR0cHM6Ly9lbmNvZGluZy5zcGVjLndoYXR3Zy5vcmcvI3RleHRlbmNvZGVyfVxuICpcbiAqIEBwdWJsaWNcbiAqL1xuZXhwb3J0IHZhciBFbmNvZGVyO1xuKGZ1bmN0aW9uIChFbmNvZGVyKSB7XG4gICAgLyoqXG4gICAgICoge0BsaW5rIGh0dHBzOi8vZW5jb2Rpbmcuc3BlYy53aGF0d2cub3JnLyNkb20tdGV4dGVuY29kZXItZW5jb2RlfVxuICAgICAqIHtAbGluayBodHRwczovL2VuY29kaW5nLnNwZWMud2hhdHdnLm9yZy8jdXRmLTgtZW5jb2Rlcn1cbiAgICAgKi9cbiAgICBmdW5jdGlvbiBlbmNvZGUoaW5wdXQpIHtcbiAgICAgICAgY29uc3Qgb3V0cHV0ID0gW107XG4gICAgICAgIGNvbnN0IGxlbmd0aCA9IGlucHV0Lmxlbmd0aDtcbiAgICAgICAgbGV0IGkgPSAwO1xuICAgICAgICB3aGlsZSAoaSA8IGxlbmd0aCkge1xuICAgICAgICAgICAgY29uc3QgY29kZVBvaW50ID0gaW5wdXQuY29kZVBvaW50QXQoaSk7XG4gICAgICAgICAgICBsZXQgY291bnQgPSAwO1xuICAgICAgICAgICAgbGV0IGJpdHMgPSAwO1xuICAgICAgICAgICAgaWYgKGNvZGVQb2ludCA8PSAweDdmKSB7XG4gICAgICAgICAgICAgICAgY291bnQgPSAwO1xuICAgICAgICAgICAgICAgIGJpdHMgPSAweDAwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoY29kZVBvaW50IDw9IDB4N2ZmKSB7XG4gICAgICAgICAgICAgICAgY291bnQgPSA2O1xuICAgICAgICAgICAgICAgIGJpdHMgPSAweGMwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSBpZiAoY29kZVBvaW50IDw9IDB4ZmZmZikge1xuICAgICAgICAgICAgICAgIGNvdW50ID0gMTI7XG4gICAgICAgICAgICAgICAgYml0cyA9IDB4ZTA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBlbHNlIGlmIChjb2RlUG9pbnQgPD0gMHgxZmZmZmYpIHtcbiAgICAgICAgICAgICAgICBjb3VudCA9IDE4O1xuICAgICAgICAgICAgICAgIGJpdHMgPSAweGYwO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgb3V0cHV0LnB1c2goYml0cyB8IChjb2RlUG9pbnQgPj4gY291bnQpKTtcbiAgICAgICAgICAgIGNvdW50IC09IDY7XG4gICAgICAgICAgICB3aGlsZSAoY291bnQgPj0gMCkge1xuICAgICAgICAgICAgICAgIG91dHB1dC5wdXNoKDB4ODAgfCAoKGNvZGVQb2ludCA+PiBjb3VudCkgJiAweDNmKSk7XG4gICAgICAgICAgICAgICAgY291bnQgLT0gNjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGkgKz0gY29kZVBvaW50ID49IDB4MTAwMDAgPyAyIDogMTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gbmV3IFVpbnQ4QXJyYXkob3V0cHV0KTtcbiAgICB9XG4gICAgRW5jb2Rlci5lbmNvZGUgPSBlbmNvZGU7XG59KShFbmNvZGVyIHx8IChFbmNvZGVyID0ge30pKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWVuY29kZXIuanMubWFwIiwiZXhwb3J0ICogZnJvbSBcIi4vZGVjb2Rlci5qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vZW5jb2Rlci5qc1wiO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXguanMubWFwIiwiLyoqXG4gKiBUaGlzIG5hbWVzcGFjZSBwcm92aWRlcyBhZGRpdGlvbmFsIHR5cGVzIGFuZCBmdW5jdGlvbnMgZm9yIHRoZVxuICoge0BsaW5rIChFcXVhdGFibGU6aW50ZXJmYWNlKX0gaW50ZXJmYWNlLlxuICpcbiAqIEBwdWJsaWNcbiAqL1xuZXhwb3J0IHZhciBFcXVhdGFibGU7XG4oZnVuY3Rpb24gKEVxdWF0YWJsZSkge1xuICAgIC8vIFRoZSBmb2xsb3dpbmcgdHdvIHR5cGUgZ3VhcmRzIGhhdmUgYmVlbiBpbmxpbmVkIGZyb20gdGhlXG4gICAgLy8gQHNpdGVpbXByb3ZlL2FsZmEtcmVmaW5lbWVudCBwYWNrYWdlIHRvIGF2b2lkIGNyZWF0aW5nIGEgY2lyY3VsYXJcbiAgICAvLyBkZXBlbmRlbmN5LlxuICAgIGZ1bmN0aW9uIGlzRnVuY3Rpb24odmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJmdW5jdGlvblwiO1xuICAgIH1cbiAgICBmdW5jdGlvbiBpc09iamVjdCh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIHZhbHVlICE9PSBudWxsO1xuICAgIH1cbiAgICAvKipcbiAgICAgKiBDaGVjayBpZiBhbiB1bmtub3duIHZhbHVlIGltcGxlbWVudHMgdGhlIHtAbGluayAoRXF1YXRhYmxlOmludGVyZmFjZSl9XG4gICAgICogaW50ZXJmYWNlLlxuICAgICAqL1xuICAgIGZ1bmN0aW9uIGlzRXF1YXRhYmxlKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiBpc09iamVjdCh2YWx1ZSkgJiYgaXNGdW5jdGlvbih2YWx1ZS5lcXVhbHMpO1xuICAgIH1cbiAgICBFcXVhdGFibGUuaXNFcXVhdGFibGUgPSBpc0VxdWF0YWJsZTtcbiAgICAvKipcbiAgICAgKiBDaGVjayBpZiB0d28gdW5rbm93biB2YWx1ZXMgYXJlIGVxdWFsLlxuICAgICAqXG4gICAgICogQHJlbWFya3NcbiAgICAgKiBJZiBlaXRoZXIgb2YgdGhlIGdpdmVuIHZhbHVlcyBpbXBsZW1lbnQgdGhlIHtAbGluayAoRXF1YXRhYmxlOmludGVyZmFjZSl9XG4gICAgICogaW50ZXJmYWNlLCB0aGUgZXF1aXZhbGVuY2UgY29uc3RyYWludHMgb2YgdGhlIHZhbHVlIHdpbGwgYmUgdXNlZC4gSWYgbm90LFxuICAgICAqIHN0cmljdCBlcXVhbGl0eSB3aWxsIGJlIHVzZWQgd2l0aCB0aGUgYWRkaXRpb25hbCBjb25zdHJhaW50IHRoYXQgYE5hTmAgaXNcbiAgICAgKiBlcXVhbCB0byBpdHNlbGYuXG4gICAgICovXG4gICAgZnVuY3Rpb24gZXF1YWxzKGEsIGIpIHtcbiAgICAgICAgaWYgKGEgPT09IGIgfHxcbiAgICAgICAgICAgIC8vIGBOYU5gIGlzIHRoZSBvbmx5IHZhbHVlIGluIEphdmFTY3JpcHQgdGhhdCBpcyBub3QgZXF1YWwgdG8gaXRzZWxmLlxuICAgICAgICAgICAgKGEgIT09IGEgJiYgYiAhPT0gYikpIHtcbiAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0VxdWF0YWJsZShhKSkge1xuICAgICAgICAgICAgcmV0dXJuIGEuZXF1YWxzKGIpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc0VxdWF0YWJsZShiKSkge1xuICAgICAgICAgICAgcmV0dXJuIGIuZXF1YWxzKGEpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgRXF1YXRhYmxlLmVxdWFscyA9IGVxdWFscztcbn0pKEVxdWF0YWJsZSB8fCAoRXF1YXRhYmxlID0ge30pKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWVxdWF0YWJsZS5qcy5tYXAiLCJleHBvcnQgKiBmcm9tIFwiLi9lcXVhdGFibGUuanNcIjtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsImltcG9ydCB7IEhhc2ggfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtaGFzaFwiO1xuLyoqXG4gKiBAcHVibGljXG4gKi9cbmV4cG9ydCBjbGFzcyBGTlYgZXh0ZW5kcyBIYXNoIHtcbiAgICBzdGF0aWMgZW1wdHkoKSB7XG4gICAgICAgIHJldHVybiBuZXcgRk5WKCk7XG4gICAgfVxuICAgIF9oYXNoID0gMjE2NjEzNjI2MTtcbiAgICBjb25zdHJ1Y3RvcigpIHtcbiAgICAgICAgc3VwZXIoKTtcbiAgICB9XG4gICAgZmluaXNoKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5faGFzaCA+Pj4gMDsgLy8gQ29udmVydCB0byB1bnNpZ25lZCAzMi1iaXQgaW50ZWdlclxuICAgIH1cbiAgICB3cml0ZShkYXRhKSB7XG4gICAgICAgIGxldCBoYXNoID0gdGhpcy5faGFzaDtcbiAgICAgICAgZm9yIChjb25zdCBvY3RldCBvZiBkYXRhKSB7XG4gICAgICAgICAgICBoYXNoIF49IG9jdGV0O1xuICAgICAgICAgICAgaGFzaCArPVxuICAgICAgICAgICAgICAgIChoYXNoIDw8IDEpICsgKGhhc2ggPDwgNCkgKyAoaGFzaCA8PCA3KSArIChoYXNoIDw8IDgpICsgKGhhc2ggPDwgMjQpO1xuICAgICAgICB9XG4gICAgICAgIHRoaXMuX2hhc2ggPSBoYXNoO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgZXF1YWxzKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIEZOViAmJiB2YWx1ZS5faGFzaCA9PT0gdGhpcy5faGFzaDtcbiAgICB9XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1mbnYuanMubWFwIiwiZXhwb3J0ICogZnJvbSBcIi4vZm52LmpzXCI7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCJpbXBvcnQgeyBFbmNvZGVyIH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLWVuY29kaW5nXCI7XG5pbXBvcnQgeyBIYXNoYWJsZSB9IGZyb20gXCIuL2hhc2hhYmxlLmpzXCI7XG5jb25zdCB7IGtleXMgfSA9IE9iamVjdDtcbi8qKlxuICogQSBzcGVjaWFsIG9mZnNldCB1c2VkIGZvciB0aGUgYnVpbHRpbiB0eXBlcyBgdHJ1ZWAsIGBmYWxzZWAsIGB1bmRlZmluZWRgLCBhbmRcbiAqIGBudWxsYC4gVGhlIG9mZnNldCBpcyBkZXNpZ25lZCB0byBtaW5pbWl6ZSB0aGUgY2hhbmNlIG9mIGNvbGxpc2lvbnMgZm9yIGRhdGFcbiAqIHN0cnVjdHVyZXMgdGhhdCByZWx5IG9uIDUtYml0IHBhcnRpdGlvbmluZy4gV2UgdXNlIHRoZSBmaXJzdCAzMCBiaXRzIGZvciA2IG9mXG4gKiB0aGVzZSBwYXJ0aXRpb25zLCBsZWF2aW5nIHVzIDIgYml0cyB0byBlbmNvZGUgdGhlIDQgYnVpbHRpbiB0eXBlcy5cbiAqL1xuY29uc3QgYnVpbHRpbk9mZnNldCA9IDBiMTAwMDBfMTAwMDBfMTAwMDBfMTAwMDBfMTAwMDBfMTAwMDBfMDA7XG4vKipcbiAqIEBwdWJsaWNcbiAqL1xuZXhwb3J0IGNsYXNzIEhhc2gge1xuICAgIC8qKlxuICAgICAqIEEgbWFwIGZyb20gb2JqZWN0cyB0byB0aGVpciBoYXNoIHZhbHVlcy4gT2JqZWN0cyBhcmUgd2Vha2x5IHJlZmVyZW5jZWQgYXNcbiAgICAgKiB0byBub3QgcHJldmVudCB0aGVtIGZyb20gYmVpbmcgZ2FyYmFnZSBjb2xsZWN0ZWQuXG4gICAgICovXG4gICAgc3RhdGljIF9vYmplY3RIYXNoZXMgPSBuZXcgV2Vha01hcCgpO1xuICAgIC8qKlxuICAgICAqIEEgbWFwIGZyb20gc3ltYm9scyB0byB0aGVpciBoYXNoIHZhbHVlcy4gQXMgdGhlcmUncyBub3QgY3VycmVudGx5IGEgd2F5IHRvXG4gICAgICogd2Vha2x5IHJlZmVyZW5jZSBzeW1ib2xzLCB3ZSBoYXZlIHRvIGluc3RlYWQgdXNlIHN0cm9uZyByZWZlcmVuY2VzLlxuICAgICAqXG4gICAgICoge0BsaW5rIGh0dHBzOi8vZ2l0aHViLmNvbS90YzM5L3Byb3Bvc2FsLXN5bWJvbHMtYXMtd2Vha21hcC1rZXlzfVxuICAgICAqL1xuICAgIHN0YXRpYyBfc3ltYm9sSGFzaGVzID0gbmV3IE1hcCgpO1xuICAgIC8qKlxuICAgICAqIFRoZSBuZXh0IGF2YWlsYWJsZSBoYXNoIHZhbHVlLiBUaGlzIGlzIHVzZWQgZm9yIHN5bWJvbHMgYW5kIG9iamVjdHMgdGhhdFxuICAgICAqIGRvbid0IGltcGxlbWVudCB0aGUge0BsaW5rIChIYXNoYWJsZTppbnRlcmZhY2UpfSBpbnRlcmZhY2UuXG4gICAgICovXG4gICAgc3RhdGljIF9uZXh0SGFzaCA9IDA7XG4gICAgY29uc3RydWN0b3IoKSB7IH1cbiAgICB3cml0ZVN0cmluZyhkYXRhKSB7XG4gICAgICAgIHJldHVybiB0aGlzLndyaXRlKEVuY29kZXIuZW5jb2RlKGRhdGEpKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQHJlbWFya3NcbiAgICAgKiBBcyBKYXZhU2NyaXB0IHJlcHJlc2VudHMgbnVtYmVycyBpbiBkb3VibGUtcHJlY2lzaW9uIGZsb2F0aW5nLXBvaW50IGZvcm1hdCxcbiAgICAgKiBudW1iZXJzIGluIGdlbmVyYWwgd2lsbCBiZSB3cml0dGVuIGFzIHN1Y2guXG4gICAgICpcbiAgICAgKiB7QGxpbmsgaHR0cHM6Ly9lbi53aWtpcGVkaWEub3JnL3dpa2kvRG91YmxlLXByZWNpc2lvbl9mbG9hdGluZy1wb2ludF9mb3JtYXR9XG4gICAgICovXG4gICAgd3JpdGVOdW1iZXIoZGF0YSkge1xuICAgICAgICByZXR1cm4gdGhpcy53cml0ZUZsb2F0NjQoZGF0YSk7XG4gICAgfVxuICAgIHdyaXRlSW50KGRhdGEsIHNpemUgPSAzMiwgc2lnbmVkID0gdHJ1ZSkge1xuICAgICAgICBjb25zdCBidWZmZXIgPSBuZXcgQXJyYXlCdWZmZXIoc2l6ZSAvIDgpO1xuICAgICAgICBjb25zdCB2aWV3ID0gbmV3IERhdGFWaWV3KGJ1ZmZlcik7XG4gICAgICAgIHN3aXRjaCAoc2l6ZSkge1xuICAgICAgICAgICAgY2FzZSA4OlxuICAgICAgICAgICAgICAgIHNpZ25lZCA/IHZpZXcuc2V0SW50OCgwLCBkYXRhKSA6IHZpZXcuc2V0VWludDgoMCwgZGF0YSk7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICBjYXNlIDE2OlxuICAgICAgICAgICAgICAgIHNpZ25lZCA/IHZpZXcuc2V0SW50MTYoMCwgZGF0YSkgOiB2aWV3LnNldFVpbnQxNigwLCBkYXRhKTtcbiAgICAgICAgICAgICAgICBicmVhaztcbiAgICAgICAgICAgIGNhc2UgMzI6XG4gICAgICAgICAgICAgICAgc2lnbmVkID8gdmlldy5zZXRJbnQzMigwLCBkYXRhKSA6IHZpZXcuc2V0VWludDMyKDAsIGRhdGEpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiB0aGlzLndyaXRlKG5ldyBVaW50OEFycmF5KGJ1ZmZlcikpO1xuICAgIH1cbiAgICB3cml0ZUludDgoZGF0YSkge1xuICAgICAgICByZXR1cm4gdGhpcy53cml0ZUludChkYXRhLCA4LCB0cnVlKTtcbiAgICB9XG4gICAgd3JpdGVVaW50OChkYXRhKSB7XG4gICAgICAgIHJldHVybiB0aGlzLndyaXRlSW50KGRhdGEsIDgsIGZhbHNlKTtcbiAgICB9XG4gICAgd3JpdGVJbnQxNihkYXRhKSB7XG4gICAgICAgIHJldHVybiB0aGlzLndyaXRlSW50KGRhdGEsIDE2LCB0cnVlKTtcbiAgICB9XG4gICAgd3JpdGVVaW50MTYoZGF0YSkge1xuICAgICAgICByZXR1cm4gdGhpcy53cml0ZUludChkYXRhLCAxNiwgZmFsc2UpO1xuICAgIH1cbiAgICB3cml0ZUludDMyKGRhdGEpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVJbnQoZGF0YSwgMzIsIHRydWUpO1xuICAgIH1cbiAgICB3cml0ZVVpbnQzMihkYXRhKSB7XG4gICAgICAgIHJldHVybiB0aGlzLndyaXRlSW50KGRhdGEsIDMyLCBmYWxzZSk7XG4gICAgfVxuICAgIHdyaXRlQmlnSW50KGRhdGEsIHNpemUgPSA2NCwgc2lnbmVkID0gdHJ1ZSkge1xuICAgICAgICBjb25zdCBidWZmZXIgPSBuZXcgQXJyYXlCdWZmZXIoc2l6ZSAvIDgpO1xuICAgICAgICBjb25zdCB2aWV3ID0gbmV3IERhdGFWaWV3KGJ1ZmZlcik7XG4gICAgICAgIHN3aXRjaCAoc2l6ZSkge1xuICAgICAgICAgICAgY2FzZSA2NDpcbiAgICAgICAgICAgICAgICBzaWduZWQgPyB2aWV3LnNldEJpZ0ludDY0KDAsIGRhdGEpIDogdmlldy5zZXRCaWdVaW50NjQoMCwgZGF0YSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMud3JpdGUobmV3IFVpbnQ4QXJyYXkoYnVmZmVyKSk7XG4gICAgfVxuICAgIHdyaXRlQmlnSW50NjQoZGF0YSkge1xuICAgICAgICByZXR1cm4gdGhpcy53cml0ZUJpZ0ludChkYXRhLCA2NCwgdHJ1ZSk7XG4gICAgfVxuICAgIHdyaXRlQmlnVWludDY0KGRhdGEpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVCaWdJbnQoZGF0YSwgNjQsIGZhbHNlKTtcbiAgICB9XG4gICAgd3JpdGVGbG9hdChkYXRhLCBzaXplID0gMzIpIHtcbiAgICAgICAgY29uc3QgYnVmZmVyID0gbmV3IEFycmF5QnVmZmVyKHNpemUgLyA4KTtcbiAgICAgICAgY29uc3QgdmlldyA9IG5ldyBEYXRhVmlldyhidWZmZXIpO1xuICAgICAgICBzd2l0Y2ggKHNpemUpIHtcbiAgICAgICAgICAgIGNhc2UgMzI6XG4gICAgICAgICAgICAgICAgdmlldy5zZXRGbG9hdDMyKDAsIGRhdGEpO1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgY2FzZSA2NDpcbiAgICAgICAgICAgICAgICB2aWV3LnNldEZsb2F0NjQoMCwgZGF0YSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRoaXMud3JpdGUobmV3IFVpbnQ4QXJyYXkoYnVmZmVyKSk7XG4gICAgfVxuICAgIHdyaXRlRmxvYXQzMihkYXRhKSB7XG4gICAgICAgIHJldHVybiB0aGlzLndyaXRlRmxvYXQoZGF0YSwgMzIpO1xuICAgIH1cbiAgICB3cml0ZUZsb2F0NjQoZGF0YSkge1xuICAgICAgICByZXR1cm4gdGhpcy53cml0ZUZsb2F0KGRhdGEsIDY0KTtcbiAgICB9XG4gICAgd3JpdGVCb29sZWFuKGRhdGEpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVVaW50OChidWlsdGluT2Zmc2V0ICsgKGRhdGEgPyAxIDogMCkpO1xuICAgIH1cbiAgICB3cml0ZVVuZGVmaW5lZCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVVaW50MzIoYnVpbHRpbk9mZnNldCArIDIpO1xuICAgIH1cbiAgICB3cml0ZU51bGwoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLndyaXRlVWludDMyKGJ1aWx0aW5PZmZzZXQgKyAzKTtcbiAgICB9XG4gICAgd3JpdGVPYmplY3QoZGF0YSkge1xuICAgICAgICBsZXQgaGFzaCA9IEhhc2guX29iamVjdEhhc2hlcy5nZXQoZGF0YSk7XG4gICAgICAgIGlmIChoYXNoID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIGhhc2ggPSBIYXNoLl9nZXROZXh0SGFzaCgpO1xuICAgICAgICAgICAgSGFzaC5fb2JqZWN0SGFzaGVzLnNldChkYXRhLCBoYXNoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy53cml0ZVVpbnQzMihoYXNoKTtcbiAgICB9XG4gICAgd3JpdGVTeW1ib2woZGF0YSkge1xuICAgICAgICBsZXQgaGFzaCA9IEhhc2guX3N5bWJvbEhhc2hlcy5nZXQoZGF0YSk7XG4gICAgICAgIGlmIChoYXNoID09PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIGhhc2ggPSBIYXNoLl9nZXROZXh0SGFzaCgpO1xuICAgICAgICAgICAgSGFzaC5fc3ltYm9sSGFzaGVzLnNldChkYXRhLCBoYXNoKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdGhpcy53cml0ZVVpbnQzMihoYXNoKTtcbiAgICB9XG4gICAgd3JpdGVIYXNoYWJsZShkYXRhKSB7XG4gICAgICAgIGRhdGEuaGFzaCh0aGlzKTtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIHdyaXRlVW5rbm93bihkYXRhKSB7XG4gICAgICAgIHN3aXRjaCAodHlwZW9mIGRhdGEpIHtcbiAgICAgICAgICAgIGNhc2UgXCJzdHJpbmdcIjpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy53cml0ZVN0cmluZyhkYXRhKTtcbiAgICAgICAgICAgIGNhc2UgXCJudW1iZXJcIjpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy53cml0ZU51bWJlcihkYXRhKTtcbiAgICAgICAgICAgIGNhc2UgXCJiaWdpbnRcIjpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy53cml0ZUJpZ0ludChkYXRhKTtcbiAgICAgICAgICAgIGNhc2UgXCJib29sZWFuXCI6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVCb29sZWFuKGRhdGEpO1xuICAgICAgICAgICAgY2FzZSBcInN5bWJvbFwiOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLndyaXRlU3ltYm9sKGRhdGEpO1xuICAgICAgICAgICAgY2FzZSBcInVuZGVmaW5lZFwiOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLndyaXRlVW5kZWZpbmVkKCk7XG4gICAgICAgICAgICBjYXNlIFwib2JqZWN0XCI6XG4gICAgICAgICAgICAgICAgaWYgKGRhdGEgPT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVOdWxsKCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGlmIChIYXNoYWJsZS5pc0hhc2hhYmxlKGRhdGEpKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLndyaXRlSGFzaGFibGUoZGF0YSk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLndyaXRlT2JqZWN0KGRhdGEpO1xuICAgICAgICAgICAgY2FzZSBcImZ1bmN0aW9uXCI6XG4gICAgICAgICAgICAgICAgcmV0dXJuIHRoaXMud3JpdGVPYmplY3QoZGF0YSk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgd3JpdGVKU09OKGRhdGEpIHtcbiAgICAgICAgc3dpdGNoICh0eXBlb2YgZGF0YSkge1xuICAgICAgICAgICAgY2FzZSBcInN0cmluZ1wiOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLndyaXRlU3RyaW5nKGRhdGEpO1xuICAgICAgICAgICAgY2FzZSBcIm51bWJlclwiOlxuICAgICAgICAgICAgICAgIHJldHVybiB0aGlzLndyaXRlTnVtYmVyKGRhdGEpO1xuICAgICAgICAgICAgY2FzZSBcImJvb2xlYW5cIjpcbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcy53cml0ZUJvb2xlYW4oZGF0YSk7XG4gICAgICAgICAgICBjYXNlIFwib2JqZWN0XCI6XG4gICAgICAgICAgICAgICAgaWYgKEFycmF5LmlzQXJyYXkoZGF0YSkpIHtcbiAgICAgICAgICAgICAgICAgICAgZm9yIChsZXQgaSA9IDAsIG4gPSBkYXRhLmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy53cml0ZUpTT04oZGF0YVtpXSk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgdGhpcy53cml0ZVVpbnQzMihkYXRhLmxlbmd0aCk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIGVsc2UgaWYgKGRhdGEgIT09IG51bGwpIHtcbiAgICAgICAgICAgICAgICAgICAgZm9yIChjb25zdCBrZXkgb2Yga2V5cyhkYXRhKS5zb3J0KCkpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIGNvbnN0IHZhbHVlID0gZGF0YVtrZXldO1xuICAgICAgICAgICAgICAgICAgICAgICAgdGhpcy53cml0ZVN0cmluZyhrZXkpO1xuICAgICAgICAgICAgICAgICAgICAgICAgaWYgKHZhbHVlICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgICAgICAgICAgICAgICAgICB0aGlzLndyaXRlSlNPTih2YWx1ZSk7XG4gICAgICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgICAgICAvLyBXcml0ZSBhIG51bGwgYnl0ZSBhcyBhIHNlcGFyYXRvciBiZXR3ZWVuIGtleS92YWx1ZSBwYWlycy5cbiAgICAgICAgICAgICAgICAgICAgICAgIHRoaXMud3JpdGVVaW50OCgwKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICByZXR1cm4gdGhpcztcbiAgICAgICAgfVxuICAgIH1cbiAgICBlcXVhbHModmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgSGFzaCAmJiB2YWx1ZS5maW5pc2goKSA9PT0gdGhpcy5maW5pc2goKTtcbiAgICB9XG4gICAgaGFzaChoYXNoKSB7XG4gICAgICAgIGhhc2gud3JpdGVVaW50MzIodGhpcy5maW5pc2goKSk7XG4gICAgfVxuICAgIHN0YXRpYyBfZ2V0TmV4dEhhc2goKSB7XG4gICAgICAgIGNvbnN0IG5leHRIYXNoID0gSGFzaC5fbmV4dEhhc2g7XG4gICAgICAgIC8vIEluY3JlYXNlIHRoZSBoYXNoLCB3cmFwcGluZyBhcm91bmQgd2hlbiBpdCByZWFjaGVzIHRoZSBsaW1pdCBvZiAzMiBiaXRzLlxuICAgICAgICBIYXNoLl9uZXh0SGFzaCA9IChIYXNoLl9uZXh0SGFzaCArIDEpID4+PiAwO1xuICAgICAgICByZXR1cm4gbmV4dEhhc2g7XG4gICAgfVxufVxuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aGFzaC5qcy5tYXAiLCJpbXBvcnQgeyBSZWZpbmVtZW50IH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLXJlZmluZW1lbnRcIjtcbmNvbnN0IHsgaXNGdW5jdGlvbiwgaXNPYmplY3QgfSA9IFJlZmluZW1lbnQ7XG4vKipcbiAqIEBwdWJsaWNcbiAqL1xuZXhwb3J0IHZhciBIYXNoYWJsZTtcbihmdW5jdGlvbiAoSGFzaGFibGUpIHtcbiAgICBmdW5jdGlvbiBpc0hhc2hhYmxlKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiBpc09iamVjdCh2YWx1ZSkgJiYgaXNGdW5jdGlvbih2YWx1ZS5oYXNoKTtcbiAgICB9XG4gICAgSGFzaGFibGUuaXNIYXNoYWJsZSA9IGlzSGFzaGFibGU7XG59KShIYXNoYWJsZSB8fCAoSGFzaGFibGUgPSB7fSkpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aGFzaGFibGUuanMubWFwIiwiZXhwb3J0ICogZnJvbSBcIi4vaGFzaC5qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vaGFzaGFibGUuanNcIjtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsImV4cG9ydCAqIGZyb20gXCIuL2l0ZXJhYmxlLmpzXCI7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCJpbXBvcnQgeyBDb21wYXJhYmxlLCBDb21wYXJpc29uLCB9IGZyb20gXCJAc2l0ZWltcHJvdmUvYWxmYS1jb21wYXJhYmxlXCI7XG5pbXBvcnQgeyBFcXVhdGFibGUgfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtZXF1YXRhYmxlXCI7XG5pbXBvcnQgeyBTZXJpYWxpemFibGUgfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtanNvblwiO1xuaW1wb3J0IHsgT3B0aW9uLCBOb25lIH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLW9wdGlvblwiO1xuaW1wb3J0IHsgUHJlZGljYXRlIH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLXByZWRpY2F0ZVwiO1xuaW1wb3J0IHsgUmVmaW5lbWVudCB9IGZyb20gXCJAc2l0ZWltcHJvdmUvYWxmYS1yZWZpbmVtZW50XCI7XG5jb25zdCB7IG5vdCB9ID0gUHJlZGljYXRlO1xuY29uc3QgeyBpc09iamVjdCB9ID0gUmVmaW5lbWVudDtcbmNvbnN0IHsgY29tcGFyZUNvbXBhcmFibGUgfSA9IENvbXBhcmFibGU7XG4vKipcbiAqIEBwdWJsaWNcbiAqL1xuZXhwb3J0IHZhciBJdGVyYWJsZTtcbihmdW5jdGlvbiAoSXRlcmFibGUpIHtcbiAgICBmdW5jdGlvbiBpc0l0ZXJhYmxlKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiBpc09iamVjdCh2YWx1ZSkgJiYgU3ltYm9sLml0ZXJhdG9yIGluIHZhbHVlO1xuICAgIH1cbiAgICBJdGVyYWJsZS5pc0l0ZXJhYmxlID0gaXNJdGVyYWJsZTtcbiAgICBmdW5jdGlvbiogZW1wdHkoKSB7IH1cbiAgICBJdGVyYWJsZS5lbXB0eSA9IGVtcHR5O1xuICAgIGZ1bmN0aW9uKiBmcm9tKGFycmF5TGlrZSkge1xuICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IGFycmF5TGlrZS5sZW5ndGg7IGkgPCBuOyBpKyspIHtcbiAgICAgICAgICAgIHlpZWxkIGFycmF5TGlrZVtpXTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBJdGVyYWJsZS5mcm9tID0gZnJvbTtcbiAgICBmdW5jdGlvbiBzaXplKGl0ZXJhYmxlKSB7XG4gICAgICAgIHJldHVybiByZWR1Y2UoaXRlcmFibGUsIChzaXplKSA9PiBzaXplICsgMSwgMCk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnNpemUgPSBzaXplO1xuICAgIGZ1bmN0aW9uIGlzRW1wdHkoaXRlcmFibGUpIHtcbiAgICAgICAgZm9yIChjb25zdCBfIG9mIGl0ZXJhYmxlKSB7XG4gICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIEl0ZXJhYmxlLmlzRW1wdHkgPSBpc0VtcHR5O1xuICAgIGZ1bmN0aW9uIGZvckVhY2goaXRlcmFibGUsIGNhbGxiYWNrKSB7XG4gICAgICAgIGxldCBpbmRleCA9IDA7XG4gICAgICAgIGZvciAoY29uc3QgdmFsdWUgb2YgaXRlcmFibGUpIHtcbiAgICAgICAgICAgIGNhbGxiYWNrKHZhbHVlLCBpbmRleCsrKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBJdGVyYWJsZS5mb3JFYWNoID0gZm9yRWFjaDtcbiAgICBmdW5jdGlvbiogbWFwKGl0ZXJhYmxlLCBtYXBwZXIpIHtcbiAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgeWllbGQgbWFwcGVyKHZhbHVlLCBpbmRleCsrKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBJdGVyYWJsZS5tYXAgPSBtYXA7XG4gICAgZnVuY3Rpb24qIGZsYXRNYXAoaXRlcmFibGUsIG1hcHBlcikge1xuICAgICAgICBsZXQgaW5kZXggPSAwO1xuICAgICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIGl0ZXJhYmxlKSB7XG4gICAgICAgICAgICB5aWVsZCogbWFwcGVyKHZhbHVlLCBpbmRleCsrKTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBJdGVyYWJsZS5mbGF0TWFwID0gZmxhdE1hcDtcbiAgICBmdW5jdGlvbiogZmxhdHRlbihpdGVyYWJsZSkge1xuICAgICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIGl0ZXJhYmxlKSB7XG4gICAgICAgICAgICB5aWVsZCogdmFsdWU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgSXRlcmFibGUuZmxhdHRlbiA9IGZsYXR0ZW47XG4gICAgZnVuY3Rpb24gcmVkdWNlKGl0ZXJhYmxlLCByZWR1Y2VyLCBhY2N1bXVsYXRvcikge1xuICAgICAgICBsZXQgaW5kZXggPSAwO1xuICAgICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIGl0ZXJhYmxlKSB7XG4gICAgICAgICAgICBhY2N1bXVsYXRvciA9IHJlZHVjZXIoYWNjdW11bGF0b3IsIHZhbHVlLCBpbmRleCsrKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gYWNjdW11bGF0b3I7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnJlZHVjZSA9IHJlZHVjZTtcbiAgICBmdW5jdGlvbiByZWR1Y2VXaGlsZShpdGVyYWJsZSwgcHJlZGljYXRlLCByZWR1Y2VyLCBhY2N1bXVsYXRvcikge1xuICAgICAgICBsZXQgaW5kZXggPSAwO1xuICAgICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIGl0ZXJhYmxlKSB7XG4gICAgICAgICAgICBpZiAocHJlZGljYXRlKHZhbHVlLCBpbmRleCkpIHtcbiAgICAgICAgICAgICAgICBhY2N1bXVsYXRvciA9IHJlZHVjZXIoYWNjdW11bGF0b3IsIHZhbHVlLCBpbmRleCsrKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBhY2N1bXVsYXRvcjtcbiAgICB9XG4gICAgSXRlcmFibGUucmVkdWNlV2hpbGUgPSByZWR1Y2VXaGlsZTtcbiAgICBmdW5jdGlvbiByZWR1Y2VVbnRpbChpdGVyYWJsZSwgcHJlZGljYXRlLCByZWR1Y2VyLCBhY2N1bXVsYXRvcikge1xuICAgICAgICByZXR1cm4gcmVkdWNlV2hpbGUoaXRlcmFibGUsIG5vdChwcmVkaWNhdGUpLCByZWR1Y2VyLCBhY2N1bXVsYXRvcik7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnJlZHVjZVVudGlsID0gcmVkdWNlVW50aWw7XG4gICAgZnVuY3Rpb24gYXBwbHkoaXRlcmFibGUsIG1hcHBlcikge1xuICAgICAgICByZXR1cm4gZmxhdE1hcChtYXBwZXIsIChtYXBwZXIpID0+IG1hcChpdGVyYWJsZSwgbWFwcGVyKSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLmFwcGx5ID0gYXBwbHk7XG4gICAgZnVuY3Rpb24qIGZpbHRlcihpdGVyYWJsZSwgcHJlZGljYXRlKSB7XG4gICAgICAgIGxldCBpbmRleCA9IDA7XG4gICAgICAgIGZvciAoY29uc3QgdmFsdWUgb2YgaXRlcmFibGUpIHtcbiAgICAgICAgICAgIGlmIChwcmVkaWNhdGUodmFsdWUsIGluZGV4KyspKSB7XG4gICAgICAgICAgICAgICAgeWllbGQgdmFsdWU7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgSXRlcmFibGUuZmlsdGVyID0gZmlsdGVyO1xuICAgIGZ1bmN0aW9uIHJlamVjdChpdGVyYWJsZSwgcHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiBmaWx0ZXIoaXRlcmFibGUsIG5vdChwcmVkaWNhdGUpKTtcbiAgICB9XG4gICAgSXRlcmFibGUucmVqZWN0ID0gcmVqZWN0O1xuICAgIGZ1bmN0aW9uIGZpbmQoaXRlcmFibGUsIHByZWRpY2F0ZSkge1xuICAgICAgICBsZXQgaW5kZXggPSAwO1xuICAgICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIGl0ZXJhYmxlKSB7XG4gICAgICAgICAgICBpZiAocHJlZGljYXRlKHZhbHVlLCBpbmRleCsrKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBPcHRpb24ub2YodmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBOb25lO1xuICAgIH1cbiAgICBJdGVyYWJsZS5maW5kID0gZmluZDtcbiAgICBmdW5jdGlvbiBmaW5kTGFzdChpdGVyYWJsZSwgcHJlZGljYXRlKSB7XG4gICAgICAgIGxldCBpbmRleCA9IDA7XG4gICAgICAgIGxldCByZXN1bHQgPSBOb25lO1xuICAgICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIGl0ZXJhYmxlKSB7XG4gICAgICAgICAgICBpZiAocHJlZGljYXRlKHZhbHVlLCBpbmRleCsrKSkge1xuICAgICAgICAgICAgICAgIHJlc3VsdCA9IE9wdGlvbi5vZih2YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIHJlc3VsdDtcbiAgICB9XG4gICAgSXRlcmFibGUuZmluZExhc3QgPSBmaW5kTGFzdDtcbiAgICBmdW5jdGlvbiBpbmNsdWRlcyhpdGVyYWJsZSwgdmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHNvbWUoaXRlcmFibGUsIFByZWRpY2F0ZS5lcXVhbHModmFsdWUpKTtcbiAgICB9XG4gICAgSXRlcmFibGUuaW5jbHVkZXMgPSBpbmNsdWRlcztcbiAgICBmdW5jdGlvbiBjb2xsZWN0KGl0ZXJhYmxlLCBtYXBwZXIpIHtcbiAgICAgICAgcmV0dXJuIGZsYXRNYXAoaXRlcmFibGUsIG1hcHBlcik7XG4gICAgfVxuICAgIEl0ZXJhYmxlLmNvbGxlY3QgPSBjb2xsZWN0O1xuICAgIGZ1bmN0aW9uIGNvbGxlY3RGaXJzdChpdGVyYWJsZSwgbWFwcGVyKSB7XG4gICAgICAgIHJldHVybiBmaXJzdChjb2xsZWN0KGl0ZXJhYmxlLCBtYXBwZXIpKTtcbiAgICB9XG4gICAgSXRlcmFibGUuY29sbGVjdEZpcnN0ID0gY29sbGVjdEZpcnN0O1xuICAgIGZ1bmN0aW9uIHNvbWUoaXRlcmFibGUsIHByZWRpY2F0ZSkge1xuICAgICAgICBsZXQgaW5kZXggPSAwO1xuICAgICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIGl0ZXJhYmxlKSB7XG4gICAgICAgICAgICBpZiAocHJlZGljYXRlKHZhbHVlLCBpbmRleCsrKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgSXRlcmFibGUuc29tZSA9IHNvbWU7XG4gICAgZnVuY3Rpb24gbm9uZShpdGVyYWJsZSwgcHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiBldmVyeShpdGVyYWJsZSwgbm90KHByZWRpY2F0ZSkpO1xuICAgIH1cbiAgICBJdGVyYWJsZS5ub25lID0gbm9uZTtcbiAgICBmdW5jdGlvbiBldmVyeShpdGVyYWJsZSwgcHJlZGljYXRlKSB7XG4gICAgICAgIGxldCBpbmRleCA9IDA7XG4gICAgICAgIGZvciAoY29uc3QgdmFsdWUgb2YgaXRlcmFibGUpIHtcbiAgICAgICAgICAgIGlmICghcHJlZGljYXRlKHZhbHVlLCBpbmRleCsrKSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgSXRlcmFibGUuZXZlcnkgPSBldmVyeTtcbiAgICBmdW5jdGlvbiBjb3VudChpdGVyYWJsZSwgcHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiByZWR1Y2UoaXRlcmFibGUsIChjb3VudCwgdmFsdWUsIGluZGV4KSA9PiAocHJlZGljYXRlKHZhbHVlLCBpbmRleCkgPyBjb3VudCArIDEgOiBjb3VudCksIDApO1xuICAgIH1cbiAgICBJdGVyYWJsZS5jb3VudCA9IGNvdW50O1xuICAgIGZ1bmN0aW9uKiBkaXN0aW5jdChpdGVyYWJsZSkge1xuICAgICAgICBjb25zdCBzZWVuID0gW107XG4gICAgICAgIGZvciAoY29uc3QgdmFsdWUgb2YgaXRlcmFibGUpIHtcbiAgICAgICAgICAgIGlmIChzZWVuLnNvbWUoUHJlZGljYXRlLmVxdWFscyh2YWx1ZSkpKSB7XG4gICAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBzZWVuLnB1c2godmFsdWUpO1xuICAgICAgICAgICAgeWllbGQgdmFsdWU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgSXRlcmFibGUuZGlzdGluY3QgPSBkaXN0aW5jdDtcbiAgICBmdW5jdGlvbiBnZXQoaXRlcmFibGUsIGluZGV4KSB7XG4gICAgICAgIHJldHVybiBpbmRleCA8IDAgPyBOb25lIDogZmlyc3Qoc2tpcChpdGVyYWJsZSwgaW5kZXgpKTtcbiAgICB9XG4gICAgSXRlcmFibGUuZ2V0ID0gZ2V0O1xuICAgIGZ1bmN0aW9uIGhhcyhpdGVyYWJsZSwgaW5kZXgpIHtcbiAgICAgICAgcmV0dXJuIGluZGV4IDwgMCA/IGZhbHNlIDogIWlzRW1wdHkoc2tpcChpdGVyYWJsZSwgaW5kZXgpKTtcbiAgICB9XG4gICAgSXRlcmFibGUuaGFzID0gaGFzO1xuICAgIGZ1bmN0aW9uKiBzZXQoaXRlcmFibGUsIGluZGV4LCB2YWx1ZSkge1xuICAgICAgICBjb25zdCBpdCA9IGl0ZXJhdG9yKGl0ZXJhYmxlKTtcbiAgICAgICAgd2hpbGUgKGluZGV4LS0gPiAwKSB7XG4gICAgICAgICAgICBjb25zdCBuZXh0ID0gaXQubmV4dCgpO1xuICAgICAgICAgICAgaWYgKG5leHQuZG9uZSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHlpZWxkIG5leHQudmFsdWU7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgbmV4dCA9IGl0Lm5leHQoKTtcbiAgICAgICAgaWYgKG5leHQuZG9uZSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIHlpZWxkIHZhbHVlO1xuICAgICAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgICAgICAgY29uc3QgbmV4dCA9IGl0Lm5leHQoKTtcbiAgICAgICAgICAgIGlmIChuZXh0LmRvbmUgPT09IHRydWUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB5aWVsZCBuZXh0LnZhbHVlO1xuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLnNldCA9IHNldDtcbiAgICBmdW5jdGlvbiogaW5zZXJ0KGl0ZXJhYmxlLCBpbmRleCwgdmFsdWUpIHtcbiAgICAgICAgY29uc3QgaXQgPSBpdGVyYXRvcihpdGVyYWJsZSk7XG4gICAgICAgIHdoaWxlIChpbmRleC0tID4gMCkge1xuICAgICAgICAgICAgY29uc3QgbmV4dCA9IGl0Lm5leHQoKTtcbiAgICAgICAgICAgIGlmIChuZXh0LmRvbmUgPT09IHRydWUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB5aWVsZCBuZXh0LnZhbHVlO1xuICAgICAgICB9XG4gICAgICAgIHlpZWxkIHZhbHVlO1xuICAgICAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgICAgICAgY29uc3QgbmV4dCA9IGl0Lm5leHQoKTtcbiAgICAgICAgICAgIGlmIChuZXh0LmRvbmUgPT09IHRydWUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICB5aWVsZCBuZXh0LnZhbHVlO1xuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLmluc2VydCA9IGluc2VydDtcbiAgICBmdW5jdGlvbiogYXBwZW5kKGl0ZXJhYmxlLCB2YWx1ZSkge1xuICAgICAgICB5aWVsZCogaXRlcmFibGU7XG4gICAgICAgIHlpZWxkIHZhbHVlO1xuICAgIH1cbiAgICBJdGVyYWJsZS5hcHBlbmQgPSBhcHBlbmQ7XG4gICAgZnVuY3Rpb24qIHByZXBlbmQoaXRlcmFibGUsIHZhbHVlKSB7XG4gICAgICAgIHlpZWxkIHZhbHVlO1xuICAgICAgICB5aWVsZCogaXRlcmFibGU7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnByZXBlbmQgPSBwcmVwZW5kO1xuICAgIGZ1bmN0aW9uKiBjb25jYXQoaXRlcmFibGUsIC4uLml0ZXJhYmxlcykge1xuICAgICAgICB5aWVsZCogaXRlcmFibGU7XG4gICAgICAgIGZvciAoY29uc3QgaXRlcmFibGUgb2YgaXRlcmFibGVzKSB7XG4gICAgICAgICAgICB5aWVsZCogaXRlcmFibGU7XG4gICAgICAgIH1cbiAgICB9XG4gICAgSXRlcmFibGUuY29uY2F0ID0gY29uY2F0O1xuICAgIGZ1bmN0aW9uIHN1YnRyYWN0KGl0ZXJhYmxlLCAuLi5pdGVyYWJsZXMpIHtcbiAgICAgICAgcmV0dXJuIHJlamVjdChpdGVyYWJsZSwgKHZhbHVlKSA9PiBpbmNsdWRlcyhmbGF0dGVuKGl0ZXJhYmxlcyksIHZhbHVlKSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnN1YnRyYWN0ID0gc3VidHJhY3Q7XG4gICAgZnVuY3Rpb24gaW50ZXJzZWN0KGl0ZXJhYmxlLCAuLi5pdGVyYWJsZXMpIHtcbiAgICAgICAgcmV0dXJuIGZpbHRlcihpdGVyYWJsZSwgKHZhbHVlKSA9PiBpbmNsdWRlcyhmbGF0dGVuKGl0ZXJhYmxlcyksIHZhbHVlKSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLmludGVyc2VjdCA9IGludGVyc2VjdDtcbiAgICBmdW5jdGlvbiogemlwKGEsIGIpIHtcbiAgICAgICAgY29uc3QgaXRBID0gaXRlcmF0b3IoYSk7XG4gICAgICAgIGNvbnN0IGl0QiA9IGl0ZXJhdG9yKGIpO1xuICAgICAgICB3aGlsZSAodHJ1ZSkge1xuICAgICAgICAgICAgY29uc3QgYSA9IGl0QS5uZXh0KCk7XG4gICAgICAgICAgICBjb25zdCBiID0gaXRCLm5leHQoKTtcbiAgICAgICAgICAgIGlmIChhLmRvbmUgPT09IHRydWUgfHwgYi5kb25lID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgeWllbGQgW2EudmFsdWUsIGIudmFsdWVdO1xuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLnppcCA9IHppcDtcbiAgICBmdW5jdGlvbiBmaXJzdChpdGVyYWJsZSkge1xuICAgICAgICBmb3IgKGNvbnN0IHZhbHVlIG9mIGl0ZXJhYmxlKSB7XG4gICAgICAgICAgICByZXR1cm4gT3B0aW9uLm9mKHZhbHVlKTtcbiAgICAgICAgfVxuICAgICAgICByZXR1cm4gTm9uZTtcbiAgICB9XG4gICAgSXRlcmFibGUuZmlyc3QgPSBmaXJzdDtcbiAgICBmdW5jdGlvbiBsYXN0KGl0ZXJhYmxlKSB7XG4gICAgICAgIGxldCBsYXN0ID0gbnVsbDtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgbGFzdCA9IHZhbHVlO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBPcHRpb24uZnJvbShsYXN0KTtcbiAgICB9XG4gICAgSXRlcmFibGUubGFzdCA9IGxhc3Q7XG4gICAgZnVuY3Rpb24qIHRha2UoaXRlcmFibGUsIGNvdW50KSB7XG4gICAgICAgIGNvbnN0IGl0ID0gaXRlcmF0b3IoaXRlcmFibGUpO1xuICAgICAgICB3aGlsZSAoY291bnQtLSA+IDApIHtcbiAgICAgICAgICAgIGNvbnN0IG5leHQgPSBpdC5uZXh0KCk7XG4gICAgICAgICAgICBpZiAobmV4dC5kb25lID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgeWllbGQgbmV4dC52YWx1ZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBJdGVyYWJsZS50YWtlID0gdGFrZTtcbiAgICBmdW5jdGlvbiogdGFrZVdoaWxlKGl0ZXJhYmxlLCBwcmVkaWNhdGUpIHtcbiAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgaWYgKHByZWRpY2F0ZSh2YWx1ZSwgaW5kZXgrKykpIHtcbiAgICAgICAgICAgICAgICB5aWVsZCB2YWx1ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLnRha2VXaGlsZSA9IHRha2VXaGlsZTtcbiAgICBmdW5jdGlvbiB0YWtlVW50aWwoaXRlcmFibGUsIHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gdGFrZVdoaWxlKGl0ZXJhYmxlLCBub3QocHJlZGljYXRlKSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnRha2VVbnRpbCA9IHRha2VVbnRpbDtcbiAgICBmdW5jdGlvbiogdGFrZUxhc3QoaXRlcmFibGUsIGNvdW50ID0gMSkge1xuICAgICAgICBpZiAoY291bnQgPD0gMCkge1xuICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0IGxhc3QgPSBbXTtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgbGFzdC5wdXNoKHZhbHVlKTtcbiAgICAgICAgICAgIGlmIChsYXN0Lmxlbmd0aCA+IGNvdW50KSB7XG4gICAgICAgICAgICAgICAgbGFzdC5zaGlmdCgpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHlpZWxkKiBsYXN0O1xuICAgIH1cbiAgICBJdGVyYWJsZS50YWtlTGFzdCA9IHRha2VMYXN0O1xuICAgIGZ1bmN0aW9uKiB0YWtlTGFzdFdoaWxlKGl0ZXJhYmxlLCBwcmVkaWNhdGUpIHtcbiAgICAgICAgY29uc3QgdmFsdWVzID0gWy4uLml0ZXJhYmxlXTtcbiAgICAgICAgbGV0IGxhc3QgPSB2YWx1ZXMubGVuZ3RoIC0gMTtcbiAgICAgICAgd2hpbGUgKGxhc3QgPj0gMCkge1xuICAgICAgICAgICAgaWYgKHByZWRpY2F0ZSh2YWx1ZXNbbGFzdF0sIGxhc3QpKSB7XG4gICAgICAgICAgICAgICAgbGFzdC0tO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgZm9yIChsZXQgaSA9IGxhc3QsIG4gPSB2YWx1ZXMubGVuZ3RoIC0gMTsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgeWllbGQgdmFsdWVzW2ldO1xuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLnRha2VMYXN0V2hpbGUgPSB0YWtlTGFzdFdoaWxlO1xuICAgIGZ1bmN0aW9uIHRha2VMYXN0VW50aWwoaXRlcmFibGUsIHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gdGFrZUxhc3RXaGlsZShpdGVyYWJsZSwgbm90KHByZWRpY2F0ZSkpO1xuICAgIH1cbiAgICBJdGVyYWJsZS50YWtlTGFzdFVudGlsID0gdGFrZUxhc3RVbnRpbDtcbiAgICBmdW5jdGlvbiogc2tpcChpdGVyYWJsZSwgY291bnQpIHtcbiAgICAgICAgY29uc3QgaXQgPSBpdGVyYXRvcihpdGVyYWJsZSk7XG4gICAgICAgIHdoaWxlIChjb3VudC0tID4gMCkge1xuICAgICAgICAgICAgY29uc3QgbmV4dCA9IGl0Lm5leHQoKTtcbiAgICAgICAgICAgIGlmIChuZXh0LmRvbmUgPT09IHRydWUpIHtcbiAgICAgICAgICAgICAgICByZXR1cm47XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgICAgIGNvbnN0IG5leHQgPSBpdC5uZXh0KCk7XG4gICAgICAgICAgICBpZiAobmV4dC5kb25lID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgeWllbGQgbmV4dC52YWx1ZTtcbiAgICAgICAgfVxuICAgIH1cbiAgICBJdGVyYWJsZS5za2lwID0gc2tpcDtcbiAgICBmdW5jdGlvbiogc2tpcFdoaWxlKGl0ZXJhYmxlLCBwcmVkaWNhdGUpIHtcbiAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgbGV0IHNraXBwZWQgPSBmYWxzZTtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgaWYgKCFza2lwcGVkICYmIHByZWRpY2F0ZSh2YWx1ZSwgaW5kZXgrKykpIHtcbiAgICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHNraXBwZWQgPSB0cnVlO1xuICAgICAgICAgICAgICAgIHlpZWxkIHZhbHVlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLnNraXBXaGlsZSA9IHNraXBXaGlsZTtcbiAgICBmdW5jdGlvbiBza2lwVW50aWwoaXRlcmFibGUsIHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gc2tpcFdoaWxlKGl0ZXJhYmxlLCBub3QocHJlZGljYXRlKSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnNraXBVbnRpbCA9IHNraXBVbnRpbDtcbiAgICBmdW5jdGlvbiogc2tpcExhc3QoaXRlcmFibGUsIGNvdW50ID0gMSkge1xuICAgICAgICBjb25zdCBpdCA9IGl0ZXJhdG9yKGl0ZXJhYmxlKTtcbiAgICAgICAgY29uc3QgZmlyc3QgPSBbXTtcbiAgICAgICAgd2hpbGUgKGNvdW50LS0gPiAwKSB7XG4gICAgICAgICAgICBjb25zdCBuZXh0ID0gaXQubmV4dCgpO1xuICAgICAgICAgICAgaWYgKG5leHQuZG9uZSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgICAgIHJldHVybjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGZpcnN0LnB1c2gobmV4dC52YWx1ZSk7XG4gICAgICAgIH1cbiAgICAgICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgICAgIGNvbnN0IG5leHQgPSBpdC5uZXh0KCk7XG4gICAgICAgICAgICBpZiAobmV4dC5kb25lID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZmlyc3QucHVzaChuZXh0LnZhbHVlKTtcbiAgICAgICAgICAgIHlpZWxkIGZpcnN0LnNoaWZ0KCk7XG4gICAgICAgIH1cbiAgICB9XG4gICAgSXRlcmFibGUuc2tpcExhc3QgPSBza2lwTGFzdDtcbiAgICBmdW5jdGlvbiogc2tpcExhc3RXaGlsZShpdGVyYWJsZSwgcHJlZGljYXRlKSB7XG4gICAgICAgIGNvbnN0IHZhbHVlcyA9IFsuLi5pdGVyYWJsZV07XG4gICAgICAgIGxldCBsYXN0ID0gdmFsdWVzLmxlbmd0aCAtIDE7XG4gICAgICAgIHdoaWxlIChsYXN0ID49IDApIHtcbiAgICAgICAgICAgIGlmIChwcmVkaWNhdGUodmFsdWVzW2xhc3RdLCBsYXN0KSkge1xuICAgICAgICAgICAgICAgIGxhc3QtLTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIGZvciAobGV0IGkgPSAwLCBuID0gbGFzdDsgaSA8IG47IGkrKykge1xuICAgICAgICAgICAgeWllbGQgdmFsdWVzW2ldO1xuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLnNraXBMYXN0V2hpbGUgPSBza2lwTGFzdFdoaWxlO1xuICAgIGZ1bmN0aW9uIHNraXBMYXN0VW50aWwoaXRlcmFibGUsIHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gc2tpcExhc3RXaGlsZShpdGVyYWJsZSwgbm90KHByZWRpY2F0ZSkpO1xuICAgIH1cbiAgICBJdGVyYWJsZS5za2lwTGFzdFVudGlsID0gc2tpcExhc3RVbnRpbDtcbiAgICBmdW5jdGlvbiB0cmltKGl0ZXJhYmxlLCBwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIHRyaW1UcmFpbGluZyh0cmltTGVhZGluZyhpdGVyYWJsZSwgcHJlZGljYXRlKSwgcHJlZGljYXRlKTtcbiAgICB9XG4gICAgSXRlcmFibGUudHJpbSA9IHRyaW07XG4gICAgZnVuY3Rpb24gdHJpbUxlYWRpbmcoaXRlcmFibGUsIHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gc2tpcFdoaWxlKGl0ZXJhYmxlLCBwcmVkaWNhdGUpO1xuICAgIH1cbiAgICBJdGVyYWJsZS50cmltTGVhZGluZyA9IHRyaW1MZWFkaW5nO1xuICAgIGZ1bmN0aW9uIHRyaW1UcmFpbGluZyhpdGVyYWJsZSwgcHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiBza2lwTGFzdFdoaWxlKGl0ZXJhYmxlLCBwcmVkaWNhdGUpO1xuICAgIH1cbiAgICBJdGVyYWJsZS50cmltVHJhaWxpbmcgPSB0cmltVHJhaWxpbmc7XG4gICAgZnVuY3Rpb24gcmVzdChpdGVyYWJsZSkge1xuICAgICAgICByZXR1cm4gc2tpcChpdGVyYWJsZSwgMSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnJlc3QgPSByZXN0O1xuICAgIGZ1bmN0aW9uIHNsaWNlKGl0ZXJhYmxlLCBzdGFydCwgZW5kKSB7XG4gICAgICAgIGl0ZXJhYmxlID0gc2tpcChpdGVyYWJsZSwgc3RhcnQpO1xuICAgICAgICBpZiAoZW5kICE9PSB1bmRlZmluZWQpIHtcbiAgICAgICAgICAgIGl0ZXJhYmxlID0gdGFrZShpdGVyYWJsZSwgZW5kIC0gc3RhcnQpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBpdGVyYWJsZTtcbiAgICB9XG4gICAgSXRlcmFibGUuc2xpY2UgPSBzbGljZTtcbiAgICBmdW5jdGlvbiogcmV2ZXJzZShpdGVyYWJsZSkge1xuICAgICAgICBjb25zdCBhcnJheSA9IEFycmF5LmZyb20oaXRlcmFibGUpO1xuICAgICAgICBmb3IgKGxldCBpID0gYXJyYXkubGVuZ3RoIC0gMTsgaSA+PSAwOyBpLS0pIHtcbiAgICAgICAgICAgIHlpZWxkIGFycmF5W2ldO1xuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLnJldmVyc2UgPSByZXZlcnNlO1xuICAgIGZ1bmN0aW9uIGpvaW4oaXRlcmFibGUsIHNlcGFyYXRvcikge1xuICAgICAgICBjb25zdCBpdCA9IGl0ZXJhdG9yKGl0ZXJhYmxlKTtcbiAgICAgICAgbGV0IG5leHQgPSBpdC5uZXh0KCk7XG4gICAgICAgIGlmIChuZXh0LmRvbmUgPT09IHRydWUpIHtcbiAgICAgICAgICAgIHJldHVybiBcIlwiO1xuICAgICAgICB9XG4gICAgICAgIGxldCByZXN1bHQgPSBgJHtuZXh0LnZhbHVlfWA7XG4gICAgICAgIG5leHQgPSBpdC5uZXh0KCk7XG4gICAgICAgIHdoaWxlIChuZXh0LmRvbmUgIT09IHRydWUpIHtcbiAgICAgICAgICAgIHJlc3VsdCArPSBgJHtzZXBhcmF0b3J9JHtuZXh0LnZhbHVlfWA7XG4gICAgICAgICAgICBuZXh0ID0gaXQubmV4dCgpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgfVxuICAgIEl0ZXJhYmxlLmpvaW4gPSBqb2luO1xuICAgIGZ1bmN0aW9uIHNvcnQoaXRlcmFibGUpIHtcbiAgICAgICAgcmV0dXJuIHNvcnRXaXRoKGl0ZXJhYmxlLCBjb21wYXJlQ29tcGFyYWJsZSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnNvcnQgPSBzb3J0O1xuICAgIGZ1bmN0aW9uKiBzb3J0V2l0aChpdGVyYWJsZSwgY29tcGFyZXIpIHtcbiAgICAgICAgeWllbGQqIFsuLi5pdGVyYWJsZV0uc29ydChjb21wYXJlcik7XG4gICAgfVxuICAgIEl0ZXJhYmxlLnNvcnRXaXRoID0gc29ydFdpdGg7XG4gICAgZnVuY3Rpb24gY29tcGFyZShhLCBiKSB7XG4gICAgICAgIHJldHVybiBjb21wYXJlV2l0aChhLCBiLCBjb21wYXJlQ29tcGFyYWJsZSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLmNvbXBhcmUgPSBjb21wYXJlO1xuICAgIGZ1bmN0aW9uIGNvbXBhcmVXaXRoKGEsIGIsIGNvbXBhcmVyKSB7XG4gICAgICAgIGNvbnN0IGl0QSA9IGl0ZXJhdG9yKGEpO1xuICAgICAgICBjb25zdCBpdEIgPSBpdGVyYXRvcihiKTtcbiAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgd2hpbGUgKHRydWUpIHtcbiAgICAgICAgICAgIGNvbnN0IGEgPSBpdEEubmV4dCgpO1xuICAgICAgICAgICAgY29uc3QgYiA9IGl0Qi5uZXh0KCk7XG4gICAgICAgICAgICBpZiAoYS5kb25lID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGIuZG9uZSA9PT0gdHJ1ZSA/IENvbXBhcmlzb24uRXF1YWwgOiBDb21wYXJpc29uLkxlc3M7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoYi5kb25lID09PSB0cnVlKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIENvbXBhcmlzb24uR3JlYXRlcjtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGNvbnN0IHJlc3VsdCA9IGNvbXBhcmVyKGEudmFsdWUsIGIudmFsdWUsIGluZGV4KyspO1xuICAgICAgICAgICAgaWYgKHJlc3VsdCAhPT0gMCkge1xuICAgICAgICAgICAgICAgIHJldHVybiByZXN1bHQ7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICB9XG4gICAgSXRlcmFibGUuY29tcGFyZVdpdGggPSBjb21wYXJlV2l0aDtcbiAgICBmdW5jdGlvbiBlcXVhbHMoYSwgYikge1xuICAgICAgICBjb25zdCBpdEEgPSBpdGVyYXRvcihhKTtcbiAgICAgICAgY29uc3QgaXRCID0gaXRlcmF0b3IoYik7XG4gICAgICAgIHdoaWxlICh0cnVlKSB7XG4gICAgICAgICAgICBjb25zdCBhID0gaXRBLm5leHQoKTtcbiAgICAgICAgICAgIGNvbnN0IGIgPSBpdEIubmV4dCgpO1xuICAgICAgICAgICAgaWYgKGEuZG9uZSA9PT0gdHJ1ZSkge1xuICAgICAgICAgICAgICAgIHJldHVybiBiLmRvbmUgPT09IHRydWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBpZiAoYi5kb25lID09PSB0cnVlIHx8ICFFcXVhdGFibGUuZXF1YWxzKGEudmFsdWUsIGIudmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgfVxuICAgIEl0ZXJhYmxlLmVxdWFscyA9IGVxdWFscztcbiAgICBmdW5jdGlvbiBoYXNoKGl0ZXJhYmxlLCBoYXNoKSB7XG4gICAgICAgIGxldCBzaXplID0gMDtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgaGFzaC53cml0ZVVua25vd24odmFsdWUpO1xuICAgICAgICAgICAgc2l6ZSsrO1xuICAgICAgICB9XG4gICAgICAgIGhhc2gud3JpdGVVaW50MzIoc2l6ZSk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLmhhc2ggPSBoYXNoO1xuICAgIGZ1bmN0aW9uIGl0ZXJhdG9yKGl0ZXJhYmxlKSB7XG4gICAgICAgIHJldHVybiBpdGVyYWJsZVtTeW1ib2wuaXRlcmF0b3JdKCk7XG4gICAgfVxuICAgIEl0ZXJhYmxlLml0ZXJhdG9yID0gaXRlcmF0b3I7XG4gICAgZnVuY3Rpb24gZ3JvdXBCeShpdGVyYWJsZSwgZ3JvdXBlcikge1xuICAgICAgICBjb25zdCBncm91cHMgPSBbXTtcbiAgICAgICAgbGV0IGluZGV4ID0gMDtcbiAgICAgICAgZm9yIChjb25zdCB2YWx1ZSBvZiBpdGVyYWJsZSkge1xuICAgICAgICAgICAgY29uc3QgZ3JvdXAgPSBncm91cGVyKHZhbHVlLCBpbmRleCsrKTtcbiAgICAgICAgICAgIGNvbnN0IGV4aXN0aW5nID0gZ3JvdXBzLmZpbmQoKFtleGlzdGluZ10pID0+IEVxdWF0YWJsZS5lcXVhbHMoZ3JvdXAsIGV4aXN0aW5nKSk7XG4gICAgICAgICAgICBpZiAoZXhpc3RpbmcgPT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgIGdyb3Vwcy5wdXNoKFtncm91cCwgW3ZhbHVlXV0pO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgZWxzZSB7XG4gICAgICAgICAgICAgICAgZXhpc3RpbmdbMV0ucHVzaCh2YWx1ZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGdyb3VwcztcbiAgICB9XG4gICAgSXRlcmFibGUuZ3JvdXBCeSA9IGdyb3VwQnk7XG4gICAgZnVuY3Rpb24gdG9KU09OKGl0ZXJhYmxlLCBvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiBbLi4ubWFwKGl0ZXJhYmxlLCAodmFsdWUpID0+IFNlcmlhbGl6YWJsZS50b0pTT04odmFsdWUsIG9wdGlvbnMpKV07XG4gICAgfVxuICAgIEl0ZXJhYmxlLnRvSlNPTiA9IHRvSlNPTjtcbn0pKEl0ZXJhYmxlIHx8IChJdGVyYWJsZSA9IHt9KSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pdGVyYWJsZS5qcy5tYXAiLCIvLyBUaGlzIGZpbGUgZGVmaW5lcyBleHBvcnRzIGZyb20gdGhlIGJ1aWx0aW4gYEpTT05gIGNvbnN0cnVjdG9yIGZvciBpbnRlcm5hbFxuLy8gdXNlIG9ubHkuXG4vKipcbiAqIEBpbnRlcm5hbFxuICovXG5jb25zdCBCdWlsdGluID0gSlNPTjtcbmV4cG9ydCB7IEJ1aWx0aW4gYXMgSlNPTiB9O1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9YnVpbHRpbi5qcy5tYXAiLCJleHBvcnQgKiBmcm9tIFwiLi9qc29uLmpzXCI7XG5leHBvcnQgKiBmcm9tIFwiLi9zZXJpYWxpemFibGUuanNcIjtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsImltcG9ydCAqIGFzIGJ1aWx0aW4gZnJvbSBcIi4vYnVpbHRpbi5qc1wiO1xuLyoqXG4gKiBAcHVibGljXG4gKi9cbmV4cG9ydCB2YXIgSlNPTjtcbihmdW5jdGlvbiAoSlNPTikge1xuICAgIGZ1bmN0aW9uIHBhcnNlKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiBidWlsdGluLkpTT04ucGFyc2UodmFsdWUpO1xuICAgIH1cbiAgICBKU09OLnBhcnNlID0gcGFyc2U7XG4gICAgZnVuY3Rpb24gc3RyaW5naWZ5KHZhbHVlKSB7XG4gICAgICAgIHJldHVybiBidWlsdGluLkpTT04uc3RyaW5naWZ5KHZhbHVlKTtcbiAgICB9XG4gICAgSlNPTi5zdHJpbmdpZnkgPSBzdHJpbmdpZnk7XG59KShKU09OIHx8IChKU09OID0ge30pKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWpzb24uanMubWFwIiwiaW1wb3J0IHsgUmVmaW5lbWVudCB9IGZyb20gXCJAc2l0ZWltcHJvdmUvYWxmYS1yZWZpbmVtZW50XCI7XG5jb25zdCB7IGtleXMgfSA9IE9iamVjdDtcbmNvbnN0IHsgaXNBcnJheSB9ID0gQXJyYXk7XG5jb25zdCB7IGlzRnVuY3Rpb24sIGlzT2JqZWN0LCBpc1N0cmluZywgaXNOdW1iZXIsIGlzQm9vbGVhbiwgaXNOdWxsIH0gPSBSZWZpbmVtZW50O1xuLyoqXG4gKiBAcHVibGljXG4gKi9cbmV4cG9ydCB2YXIgU2VyaWFsaXphYmxlO1xuKGZ1bmN0aW9uIChTZXJpYWxpemFibGUpIHtcbiAgICBmdW5jdGlvbiBpc1NlcmlhbGl6YWJsZSh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gaXNPYmplY3QodmFsdWUpICYmIGlzRnVuY3Rpb24odmFsdWUudG9KU09OKTtcbiAgICB9XG4gICAgU2VyaWFsaXphYmxlLmlzU2VyaWFsaXphYmxlID0gaXNTZXJpYWxpemFibGU7XG4gICAgZnVuY3Rpb24gdG9KU09OKHZhbHVlLCBvcHRpb25zKSB7XG4gICAgICAgIGlmIChpc1NlcmlhbGl6YWJsZSh2YWx1ZSkpIHtcbiAgICAgICAgICAgIHJldHVybiB2YWx1ZS50b0pTT04ob3B0aW9ucyk7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzU3RyaW5nKHZhbHVlKSB8fFxuICAgICAgICAgICAgaXNOdW1iZXIodmFsdWUpIHx8XG4gICAgICAgICAgICBpc0Jvb2xlYW4odmFsdWUpIHx8XG4gICAgICAgICAgICBpc051bGwodmFsdWUpKSB7XG4gICAgICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgICAgIH1cbiAgICAgICAgaWYgKGlzQXJyYXkodmFsdWUpKSB7XG4gICAgICAgICAgICByZXR1cm4gdmFsdWUubWFwKChpdGVtKSA9PiB0b0pTT04oaXRlbSwgb3B0aW9ucykpO1xuICAgICAgICB9XG4gICAgICAgIGlmIChpc09iamVjdCh2YWx1ZSkpIHtcbiAgICAgICAgICAgIGNvbnN0IGpzb24gPSB7fTtcbiAgICAgICAgICAgIGZvciAoY29uc3Qga2V5IG9mIGtleXModmFsdWUpKSB7XG4gICAgICAgICAgICAgICAgaWYgKHZhbHVlW2tleV0gIT09IHVuZGVmaW5lZCkge1xuICAgICAgICAgICAgICAgICAgICBqc29uW2tleV0gPSB0b0pTT04odmFsdWVba2V5XSwgb3B0aW9ucyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIGpzb247XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG51bGw7XG4gICAgfVxuICAgIFNlcmlhbGl6YWJsZS50b0pTT04gPSB0b0pTT047XG4gICAgbGV0IFZlcmJvc2l0eTtcbiAgICAoZnVuY3Rpb24gKFZlcmJvc2l0eSkge1xuICAgICAgICBWZXJib3NpdHlbVmVyYm9zaXR5W1wiTWluaW1hbFwiXSA9IDBdID0gXCJNaW5pbWFsXCI7XG4gICAgICAgIFZlcmJvc2l0eVtWZXJib3NpdHlbXCJMb3dcIl0gPSAxMDBdID0gXCJMb3dcIjtcbiAgICAgICAgVmVyYm9zaXR5W1ZlcmJvc2l0eVtcIk1lZGl1bVwiXSA9IDIwMF0gPSBcIk1lZGl1bVwiO1xuICAgICAgICBWZXJib3NpdHlbVmVyYm9zaXR5W1wiSGlnaFwiXSA9IDMwMF0gPSBcIkhpZ2hcIjtcbiAgICB9KShWZXJib3NpdHkgPSBTZXJpYWxpemFibGUuVmVyYm9zaXR5IHx8IChTZXJpYWxpemFibGUuVmVyYm9zaXR5ID0ge30pKTtcbn0pKFNlcmlhbGl6YWJsZSB8fCAoU2VyaWFsaXphYmxlID0ge30pKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXNlcmlhbGl6YWJsZS5qcy5tYXAiLCJleHBvcnQgKiBmcm9tIFwiLi9tYXAuanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL25vZGUuanNcIjtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsImltcG9ydCB7IEFycmF5IH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLWFycmF5XCI7XG5pbXBvcnQgeyBGTlYgfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtZm52XCI7XG5pbXBvcnQgeyBJdGVyYWJsZSB9IGZyb20gXCJAc2l0ZWltcHJvdmUvYWxmYS1pdGVyYWJsZVwiO1xuaW1wb3J0IHsgU2VyaWFsaXphYmxlIH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLWpzb25cIjtcbmltcG9ydCB7IFByZWRpY2F0ZSB9IGZyb20gXCJAc2l0ZWltcHJvdmUvYWxmYS1wcmVkaWNhdGVcIjtcbmltcG9ydCB7IEVtcHR5IH0gZnJvbSBcIi4vbm9kZS5qc1wiO1xuY29uc3QgeyBub3QgfSA9IFByZWRpY2F0ZTtcbi8qKlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgY2xhc3MgTWFwIHtcbiAgICBzdGF0aWMgb2YoLi4uZW50cmllcykge1xuICAgICAgICByZXR1cm4gZW50cmllcy5yZWR1Y2UoKG1hcCwgW2tleSwgdmFsdWVdKSA9PiBtYXAuc2V0KGtleSwgdmFsdWUpLCBNYXAuZW1wdHkoKSk7XG4gICAgfVxuICAgIHN0YXRpYyBfZW1wdHkgPSBuZXcgTWFwKEVtcHR5LCAwKTtcbiAgICBzdGF0aWMgZW1wdHkoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl9lbXB0eTtcbiAgICB9XG4gICAgX3Jvb3Q7XG4gICAgX3NpemU7XG4gICAgY29uc3RydWN0b3Iocm9vdCwgc2l6ZSkge1xuICAgICAgICB0aGlzLl9yb290ID0gcm9vdDtcbiAgICAgICAgdGhpcy5fc2l6ZSA9IHNpemU7XG4gICAgfVxuICAgIGdldCBzaXplKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fc2l6ZTtcbiAgICB9XG4gICAgaXNFbXB0eSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3NpemUgPT09IDA7XG4gICAgfVxuICAgIGZvckVhY2goY2FsbGJhY2spIHtcbiAgICAgICAgSXRlcmFibGUuZm9yRWFjaCh0aGlzLCAoW2tleSwgdmFsdWVdKSA9PiBjYWxsYmFjayh2YWx1ZSwga2V5KSk7XG4gICAgfVxuICAgIG1hcChtYXBwZXIpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBNYXAodGhpcy5fcm9vdC5tYXAobWFwcGVyKSwgdGhpcy5fc2l6ZSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEFwcGx5IGEgbWFwIG9mIGZ1bmN0aW9ucyB0byBlYWNoIGNvcnJlc3BvbmRpbmcgdmFsdWUgb2YgdGhpcyBtYXAuXG4gICAgICpcbiAgICAgKiBAcmVtYXJrc1xuICAgICAqIEtleXMgd2l0aG91dCBhIGNvcnJlc3BvbmRpbmcgZnVuY3Rpb24gb3IgdmFsdWUgYXJlIGRyb3BwZWQgZnJvbSB0aGVcbiAgICAgKiByZXN1bHRpbmcgbWFwLlxuICAgICAqXG4gICAgICogQGV4YW1wbGVcbiAgICAgKiBgYGB0c1xuICAgICAqIE1hcC5vZihbXCJhXCIsIDFdLCBbXCJiXCIsIDJdKVxuICAgICAqICAgLmFwcGx5KE1hcC5vZihbXCJhXCIsICh4KSA9PiB4ICsgMV0sIFtcImJcIiwgKHgpID0+IHggKiAyXSkpXG4gICAgICogICAudG9BcnJheSgpO1xuICAgICAqIC8vID0+IFtbXCJhXCIsIDJdLCBbXCJiXCIsIDRdXVxuICAgICAqIGBgYFxuICAgICAqL1xuICAgIGFwcGx5KG1hcHBlcikge1xuICAgICAgICByZXR1cm4gdGhpcy5jb2xsZWN0KCh2YWx1ZSwga2V5KSA9PiBtYXBwZXIuZ2V0KGtleSkubWFwKChtYXBwZXIpID0+IG1hcHBlcih2YWx1ZSkpKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQHJlbWFya3NcbiAgICAgKiBBcyB0aGUgb3JkZXIgb2YgbWFwcyBpcyB1bmRlZmluZWQsIGl0IGlzIGFsc28gdW5kZWZpbmVkIHdoaWNoIGtleXMgYXJlXG4gICAgICoga2VwdCB3aGVuIGR1cGxpY2F0ZSBrZXlzIGFyZSBlbmNvdW50ZXJlZC5cbiAgICAgKi9cbiAgICBmbGF0TWFwKG1hcHBlcikge1xuICAgICAgICByZXR1cm4gdGhpcy5yZWR1Y2UoKG1hcCwgdmFsdWUsIGtleSkgPT4gbWFwLmNvbmNhdChtYXBwZXIodmFsdWUsIGtleSkpLCBNYXAuZW1wdHkoKSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEByZW1hcmtzXG4gICAgICogQXMgdGhlIG9yZGVyIG9mIG1hcHMgaXMgdW5kZWZpbmVkLCBpdCBpcyBhbHNvIHVuZGVmaW5lZCB3aGljaCBrZXlzIGFyZVxuICAgICAqIGtlcHQgd2hlbiBkdXBsaWNhdGUga2V5cyBhcmUgZW5jb3VudGVyZWQuXG4gICAgICovXG4gICAgZmxhdHRlbigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZmxhdE1hcCgobWFwKSA9PiBtYXApO1xuICAgIH1cbiAgICByZWR1Y2UocmVkdWNlciwgYWNjdW11bGF0b3IpIHtcbiAgICAgICAgcmV0dXJuIEl0ZXJhYmxlLnJlZHVjZSh0aGlzLCAoYWNjdW11bGF0b3IsIFtrZXksIHZhbHVlXSkgPT4gcmVkdWNlcihhY2N1bXVsYXRvciwgdmFsdWUsIGtleSksIGFjY3VtdWxhdG9yKTtcbiAgICB9XG4gICAgZmlsdGVyKHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gdGhpcy5yZWR1Y2UoKG1hcCwgdmFsdWUsIGtleSkgPT4gKHByZWRpY2F0ZSh2YWx1ZSwga2V5KSA/IG1hcC5zZXQoa2V5LCB2YWx1ZSkgOiBtYXApLCBNYXAuZW1wdHkoKSk7XG4gICAgfVxuICAgIHJlamVjdChwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZmlsdGVyKG5vdChwcmVkaWNhdGUpKTtcbiAgICB9XG4gICAgZmluZChwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIEl0ZXJhYmxlLmZpbmQodGhpcywgKFtrZXksIHZhbHVlXSkgPT4gcHJlZGljYXRlKHZhbHVlLCBrZXkpKS5tYXAoKFssIHZhbHVlXSkgPT4gdmFsdWUpO1xuICAgIH1cbiAgICBpbmNsdWRlcyh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gSXRlcmFibGUuaW5jbHVkZXModGhpcy52YWx1ZXMoKSwgdmFsdWUpO1xuICAgIH1cbiAgICBjb2xsZWN0KG1hcHBlcikge1xuICAgICAgICByZXR1cm4gTWFwLmZyb20oSXRlcmFibGUuY29sbGVjdCh0aGlzLCAoW2tleSwgdmFsdWVdKSA9PiBtYXBwZXIodmFsdWUsIGtleSkubWFwKCh2YWx1ZSkgPT4gW2tleSwgdmFsdWVdKSkpO1xuICAgIH1cbiAgICBjb2xsZWN0Rmlyc3QobWFwcGVyKSB7XG4gICAgICAgIHJldHVybiBJdGVyYWJsZS5jb2xsZWN0Rmlyc3QodGhpcywgKFtrZXksIHZhbHVlXSkgPT4gbWFwcGVyKHZhbHVlLCBrZXkpKTtcbiAgICB9XG4gICAgc29tZShwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIEl0ZXJhYmxlLnNvbWUodGhpcywgKFtrZXksIHZhbHVlXSkgPT4gcHJlZGljYXRlKHZhbHVlLCBrZXkpKTtcbiAgICB9XG4gICAgbm9uZShwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIEl0ZXJhYmxlLm5vbmUodGhpcywgKFtrZXksIHZhbHVlXSkgPT4gcHJlZGljYXRlKHZhbHVlLCBrZXkpKTtcbiAgICB9XG4gICAgZXZlcnkocHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiBJdGVyYWJsZS5ldmVyeSh0aGlzLCAoW2tleSwgdmFsdWVdKSA9PiBwcmVkaWNhdGUodmFsdWUsIGtleSkpO1xuICAgIH1cbiAgICBjb3VudChwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIEl0ZXJhYmxlLmNvdW50KHRoaXMsIChba2V5LCB2YWx1ZV0pID0+IHByZWRpY2F0ZSh2YWx1ZSwga2V5KSk7XG4gICAgfVxuICAgIC8qKlxuICAgICAqIEByZW1hcmtzXG4gICAgICogQXMgdGhlIG9yZGVyIG9mIG1hcHMgaXMgdW5kZWZpbmVkLCBpdCBpcyBhbHNvIHVuZGVmaW5lZCB3aGljaCBrZXlzIGFyZVxuICAgICAqIGtlcHQgd2hlbiBkdXBsaWNhdGUgdmFsdWVzIGFyZSBlbmNvdW50ZXJlZC5cbiAgICAgKi9cbiAgICBkaXN0aW5jdCgpIHtcbiAgICAgICAgbGV0IHNlZW4gPSBNYXAuZW1wdHkoKTtcbiAgICAgICAgLy8gV2Ugb3B0aW1pemUgZm9yIHRoZSBjYXNlIHdoZXJlIHRoZXJlIGFyZSBtb3JlIGRpc3RpbmN0IHZhbHVlcyB0aGFuIHRoZXJlXG4gICAgICAgIC8vIGFyZSBkdXBsaWNhdGUgdmFsdWVzIGJ5IHN0YXJ0aW5nIHdpdGggdGhlIGN1cnJlbnQgbWFwIGFuZCByZW1vdmluZ1xuICAgICAgICAvLyBkdXBsaWNhdGVzIGFzIHdlIGZpbmQgdGhlbS5cbiAgICAgICAgbGV0IG1hcCA9IHRoaXM7XG4gICAgICAgIGZvciAoY29uc3QgW2tleSwgdmFsdWVdIG9mIG1hcCkge1xuICAgICAgICAgICAgaWYgKHNlZW4uaGFzKHZhbHVlKSkge1xuICAgICAgICAgICAgICAgIG1hcCA9IG1hcC5kZWxldGUoa2V5KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGVsc2Uge1xuICAgICAgICAgICAgICAgIHNlZW4gPSBzZWVuLnNldCh2YWx1ZSwgdmFsdWUpO1xuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBtYXA7XG4gICAgfVxuICAgIGdldChrZXkpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3Jvb3QuZ2V0KGtleSwgaGFzaChrZXkpLCAwKTtcbiAgICB9XG4gICAgaGFzKGtleSkge1xuICAgICAgICByZXR1cm4gdGhpcy5nZXQoa2V5KS5pc1NvbWUoKTtcbiAgICB9XG4gICAgc2V0KGtleSwgdmFsdWUpIHtcbiAgICAgICAgY29uc3QgeyByZXN1bHQ6IHJvb3QsIHN0YXR1cyB9ID0gdGhpcy5fcm9vdC5zZXQoa2V5LCB2YWx1ZSwgaGFzaChrZXkpLCAwKTtcbiAgICAgICAgaWYgKHN0YXR1cyA9PT0gXCJ1bmNoYW5nZWRcIikge1xuICAgICAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIG5ldyBNYXAocm9vdCwgdGhpcy5fc2l6ZSArIChzdGF0dXMgPT09IFwidXBkYXRlZFwiID8gMCA6IDEpKTtcbiAgICB9XG4gICAgZGVsZXRlKGtleSkge1xuICAgICAgICBjb25zdCB7IHJlc3VsdDogcm9vdCwgc3RhdHVzIH0gPSB0aGlzLl9yb290LmRlbGV0ZShrZXksIGhhc2goa2V5KSwgMCk7XG4gICAgICAgIGlmIChzdGF0dXMgPT09IFwidW5jaGFuZ2VkXCIpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBuZXcgTWFwKHJvb3QsIHRoaXMuX3NpemUgLSAxKTtcbiAgICB9XG4gICAgY29uY2F0KGl0ZXJhYmxlKSB7XG4gICAgICAgIHJldHVybiBJdGVyYWJsZS5yZWR1Y2UoaXRlcmFibGUsIChtYXAsIFtrZXksIHZhbHVlXSkgPT4gbWFwLnNldChrZXksIHZhbHVlKSwgdGhpcyk7XG4gICAgfVxuICAgIHN1YnRyYWN0KGl0ZXJhYmxlKSB7XG4gICAgICAgIHJldHVybiBJdGVyYWJsZS5yZWR1Y2UoaXRlcmFibGUsIChtYXAsIFtrZXldKSA9PiBtYXAuZGVsZXRlKGtleSksIHRoaXMpO1xuICAgIH1cbiAgICBpbnRlcnNlY3QoaXRlcmFibGUpIHtcbiAgICAgICAgcmV0dXJuIE1hcC5mcm9tSXRlcmFibGUoSXRlcmFibGUuZmlsdGVyKGl0ZXJhYmxlLCAoW2tleV0pID0+IHRoaXMuaGFzKGtleSkpKTtcbiAgICB9XG4gICAgdGVlKGNhbGxiYWNrLCAuLi5hcmdzKSB7XG4gICAgICAgIGNhbGxiYWNrKHRoaXMsIC4uLmFyZ3MpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgZXF1YWxzKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiAodmFsdWUgaW5zdGFuY2VvZiBNYXAgJiZcbiAgICAgICAgICAgIHZhbHVlLl9zaXplID09PSB0aGlzLl9zaXplICYmXG4gICAgICAgICAgICB2YWx1ZS5fcm9vdC5lcXVhbHModGhpcy5fcm9vdCkpO1xuICAgIH1cbiAgICBoYXNoKGhhc2gpIHtcbiAgICAgICAgZm9yIChjb25zdCBba2V5LCB2YWx1ZV0gb2YgdGhpcykge1xuICAgICAgICAgICAgaGFzaC53cml0ZVVua25vd24oa2V5KS53cml0ZVVua25vd24odmFsdWUpO1xuICAgICAgICB9XG4gICAgICAgIGhhc2gud3JpdGVVaW50MzIodGhpcy5fc2l6ZSk7XG4gICAgfVxuICAgIGtleXMoKSB7XG4gICAgICAgIHJldHVybiBJdGVyYWJsZS5tYXAodGhpcy5fcm9vdCwgKGVudHJ5KSA9PiBlbnRyeVswXSk7XG4gICAgfVxuICAgIHZhbHVlcygpIHtcbiAgICAgICAgcmV0dXJuIEl0ZXJhYmxlLm1hcCh0aGlzLl9yb290LCAoZW50cnkpID0+IGVudHJ5WzFdKTtcbiAgICB9XG4gICAgKml0ZXJhdG9yKCkge1xuICAgICAgICB5aWVsZCogdGhpcy5fcm9vdDtcbiAgICB9XG4gICAgW1N5bWJvbC5pdGVyYXRvcl0oKSB7XG4gICAgICAgIHJldHVybiB0aGlzLml0ZXJhdG9yKCk7XG4gICAgfVxuICAgIHRvQXJyYXkoKSB7XG4gICAgICAgIHJldHVybiBbLi4udGhpc107XG4gICAgfVxuICAgIHRvSlNPTihvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB0aGlzLnRvQXJyYXkoKS5tYXAoKFtrZXksIHZhbHVlXSkgPT4gW1xuICAgICAgICAgICAgU2VyaWFsaXphYmxlLnRvSlNPTihrZXksIG9wdGlvbnMpLFxuICAgICAgICAgICAgU2VyaWFsaXphYmxlLnRvSlNPTih2YWx1ZSwgb3B0aW9ucyksXG4gICAgICAgIF0pO1xuICAgIH1cbiAgICB0b1N0cmluZygpIHtcbiAgICAgICAgY29uc3QgZW50cmllcyA9IHRoaXMudG9BcnJheSgpXG4gICAgICAgICAgICAubWFwKChba2V5LCB2YWx1ZV0pID0+IGAke2tleX0gPT4gJHt2YWx1ZX1gKVxuICAgICAgICAgICAgLmpvaW4oXCIsIFwiKTtcbiAgICAgICAgcmV0dXJuIGBNYXAgeyR7ZW50cmllcyA9PT0gXCJcIiA/IFwiXCIgOiBgICR7ZW50cmllc30gYH19YDtcbiAgICB9XG59XG4vKipcbiAqIEBwdWJsaWNcbiAqL1xuKGZ1bmN0aW9uIChNYXApIHtcbiAgICBmdW5jdGlvbiBpc01hcCh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdmFsdWUgaW5zdGFuY2VvZiBNYXA7XG4gICAgfVxuICAgIE1hcC5pc01hcCA9IGlzTWFwO1xuICAgIGZ1bmN0aW9uIGZyb20oaXRlcmFibGUpIHtcbiAgICAgICAgaWYgKGlzTWFwKGl0ZXJhYmxlKSkge1xuICAgICAgICAgICAgcmV0dXJuIGl0ZXJhYmxlO1xuICAgICAgICB9XG4gICAgICAgIGlmIChBcnJheS5pc0FycmF5KGl0ZXJhYmxlKSkge1xuICAgICAgICAgICAgcmV0dXJuIGZyb21BcnJheShpdGVyYWJsZSk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIGZyb21JdGVyYWJsZShpdGVyYWJsZSk7XG4gICAgfVxuICAgIE1hcC5mcm9tID0gZnJvbTtcbiAgICBmdW5jdGlvbiBmcm9tQXJyYXkoYXJyYXkpIHtcbiAgICAgICAgcmV0dXJuIEFycmF5LnJlZHVjZShhcnJheSwgKG1hcCwgW2tleSwgdmFsdWVdKSA9PiBtYXAuc2V0KGtleSwgdmFsdWUpLCBNYXAuZW1wdHkoKSk7XG4gICAgfVxuICAgIE1hcC5mcm9tQXJyYXkgPSBmcm9tQXJyYXk7XG4gICAgZnVuY3Rpb24gZnJvbUl0ZXJhYmxlKGl0ZXJhYmxlKSB7XG4gICAgICAgIHJldHVybiBJdGVyYWJsZS5yZWR1Y2UoaXRlcmFibGUsIChtYXAsIFtrZXksIHZhbHVlXSkgPT4gbWFwLnNldChrZXksIHZhbHVlKSwgTWFwLmVtcHR5KCkpO1xuICAgIH1cbiAgICBNYXAuZnJvbUl0ZXJhYmxlID0gZnJvbUl0ZXJhYmxlO1xufSkoTWFwIHx8IChNYXAgPSB7fSkpO1xuZnVuY3Rpb24gaGFzaChrZXkpIHtcbiAgICByZXR1cm4gRk5WLmVtcHR5KCkud3JpdGVVbmtub3duKGtleSkuZmluaXNoKCk7XG59XG4vLyMgc291cmNlTWFwcGluZ1VSTD1tYXAuanMubWFwIiwiaW1wb3J0IHsgQml0cyB9IGZyb20gXCJAc2l0ZWltcHJvdmUvYWxmYS1iaXRzXCI7XG5pbXBvcnQgeyBFcXVhdGFibGUgfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtZXF1YXRhYmxlXCI7XG5pbXBvcnQgeyBOb25lLCBPcHRpb24gfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtb3B0aW9uXCI7XG5pbXBvcnQgeyBTdGF0dXMgfSBmcm9tIFwiLi9zdGF0dXMuanNcIjtcbmNvbnN0IHsgYml0LCB0YWtlLCBza2lwLCB0ZXN0LCBzZXQsIGNsZWFyLCBwb3BDb3VudCB9ID0gQml0cztcbi8qKlxuICogQGludGVybmFsXG4gKi9cbmV4cG9ydCB2YXIgTm9kZTtcbihmdW5jdGlvbiAoTm9kZSkge1xuICAgIE5vZGUuQml0cyA9IDU7XG4gICAgZnVuY3Rpb24gZnJhZ21lbnQoaGFzaCwgc2hpZnQpIHtcbiAgICAgICAgcmV0dXJuIHRha2Uoc2tpcChoYXNoLCBzaGlmdCksIE5vZGUuQml0cyk7XG4gICAgfVxuICAgIE5vZGUuZnJhZ21lbnQgPSBmcmFnbWVudDtcbiAgICBmdW5jdGlvbiBpbmRleChmcmFnbWVudCwgbWFzaykge1xuICAgICAgICByZXR1cm4gcG9wQ291bnQodGFrZShtYXNrLCBmcmFnbWVudCkpO1xuICAgIH1cbiAgICBOb2RlLmluZGV4ID0gaW5kZXg7XG59KShOb2RlIHx8IChOb2RlID0ge30pKTtcbi8qKlxuICogQGludGVybmFsXG4gKi9cbmV4cG9ydCBjb25zdCBFbXB0eSA9IG5ldyAoY2xhc3MgRW1wdHkge1xuICAgIGlzRW1wdHkoKSB7XG4gICAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICBpc0xlYWYoKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgZ2V0KCkge1xuICAgICAgICByZXR1cm4gTm9uZTtcbiAgICB9XG4gICAgc2V0KGtleSwgdmFsdWUsIGhhc2gpIHtcbiAgICAgICAgcmV0dXJuIFN0YXR1cy5jcmVhdGVkKExlYWYub2YoaGFzaCwga2V5LCB2YWx1ZSkpO1xuICAgIH1cbiAgICBkZWxldGUoKSB7XG4gICAgICAgIHJldHVybiBTdGF0dXMudW5jaGFuZ2VkKHRoaXMpO1xuICAgIH1cbiAgICBtYXAoKSB7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBlcXVhbHModmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgRW1wdHk7XG4gICAgfVxuICAgICpbU3ltYm9sLml0ZXJhdG9yXSgpIHsgfVxufSkoKTtcbi8qKlxuICogQGludGVybmFsXG4gKi9cbmV4cG9ydCBjbGFzcyBMZWFmIHtcbiAgICBzdGF0aWMgb2YoaGFzaCwga2V5LCB2YWx1ZSkge1xuICAgICAgICByZXR1cm4gbmV3IExlYWYoaGFzaCwga2V5LCB2YWx1ZSk7XG4gICAgfVxuICAgIF9oYXNoO1xuICAgIF9rZXk7XG4gICAgX3ZhbHVlO1xuICAgIGNvbnN0cnVjdG9yKGhhc2gsIGtleSwgdmFsdWUpIHtcbiAgICAgICAgdGhpcy5faGFzaCA9IGhhc2g7XG4gICAgICAgIHRoaXMuX2tleSA9IGtleTtcbiAgICAgICAgdGhpcy5fdmFsdWUgPSB2YWx1ZTtcbiAgICB9XG4gICAgZ2V0IGtleSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX2tleTtcbiAgICB9XG4gICAgZ2V0IHZhbHVlKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fdmFsdWU7XG4gICAgfVxuICAgIGlzRW1wdHkoKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgaXNMZWFmKCkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgZ2V0KGtleSwgaGFzaCwgc2hpZnQpIHtcbiAgICAgICAgcmV0dXJuIGhhc2ggPT09IHRoaXMuX2hhc2ggJiYgRXF1YXRhYmxlLmVxdWFscyhrZXksIHRoaXMuX2tleSlcbiAgICAgICAgICAgID8gT3B0aW9uLm9mKHRoaXMuX3ZhbHVlKVxuICAgICAgICAgICAgOiBOb25lO1xuICAgIH1cbiAgICBzZXQoa2V5LCB2YWx1ZSwgaGFzaCwgc2hpZnQpIHtcbiAgICAgICAgaWYgKGhhc2ggPT09IHRoaXMuX2hhc2gpIHtcbiAgICAgICAgICAgIGlmIChFcXVhdGFibGUuZXF1YWxzKGtleSwgdGhpcy5fa2V5KSkge1xuICAgICAgICAgICAgICAgIGlmIChFcXVhdGFibGUuZXF1YWxzKHZhbHVlLCB0aGlzLl92YWx1ZSkpIHtcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFN0YXR1cy51bmNoYW5nZWQodGhpcyk7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgIHJldHVybiBTdGF0dXMudXBkYXRlZChMZWFmLm9mKGhhc2gsIGtleSwgdmFsdWUpKTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBTdGF0dXMuY3JlYXRlZChDb2xsaXNpb24ub2YoaGFzaCwgW3RoaXMsIExlYWYub2YoaGFzaCwga2V5LCB2YWx1ZSldKSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZnJhZ21lbnQgPSBOb2RlLmZyYWdtZW50KHRoaXMuX2hhc2gsIHNoaWZ0KTtcbiAgICAgICAgcmV0dXJuIFNwYXJzZS5vZihiaXQoZnJhZ21lbnQpLCBbdGhpc10pLnNldChrZXksIHZhbHVlLCBoYXNoLCBzaGlmdCk7XG4gICAgfVxuICAgIGRlbGV0ZShrZXksIGhhc2gpIHtcbiAgICAgICAgcmV0dXJuIGhhc2ggPT09IHRoaXMuX2hhc2ggJiYgRXF1YXRhYmxlLmVxdWFscyhrZXksIHRoaXMuX2tleSlcbiAgICAgICAgICAgID8gU3RhdHVzLmRlbGV0ZWQoRW1wdHkpXG4gICAgICAgICAgICA6IFN0YXR1cy51bmNoYW5nZWQodGhpcyk7XG4gICAgfVxuICAgIG1hcChtYXBwZXIpIHtcbiAgICAgICAgcmV0dXJuIExlYWYub2YodGhpcy5faGFzaCwgdGhpcy5fa2V5LCBtYXBwZXIodGhpcy5fdmFsdWUsIHRoaXMuX2tleSkpO1xuICAgIH1cbiAgICBlcXVhbHModmFsdWUpIHtcbiAgICAgICAgcmV0dXJuICh2YWx1ZSBpbnN0YW5jZW9mIExlYWYgJiZcbiAgICAgICAgICAgIHZhbHVlLl9oYXNoID09PSB0aGlzLl9oYXNoICYmXG4gICAgICAgICAgICBFcXVhdGFibGUuZXF1YWxzKHZhbHVlLl9rZXksIHRoaXMuX2tleSkgJiZcbiAgICAgICAgICAgIEVxdWF0YWJsZS5lcXVhbHModmFsdWUuX3ZhbHVlLCB0aGlzLl92YWx1ZSkpO1xuICAgIH1cbiAgICAqW1N5bWJvbC5pdGVyYXRvcl0oKSB7XG4gICAgICAgIHlpZWxkIFt0aGlzLl9rZXksIHRoaXMuX3ZhbHVlXTtcbiAgICB9XG59XG4vKipcbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgY2xhc3MgQ29sbGlzaW9uIHtcbiAgICBzdGF0aWMgb2YoaGFzaCwgbm9kZXMpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBDb2xsaXNpb24oaGFzaCwgbm9kZXMpO1xuICAgIH1cbiAgICBfaGFzaDtcbiAgICBfbm9kZXM7XG4gICAgY29uc3RydWN0b3IoaGFzaCwgbm9kZXMpIHtcbiAgICAgICAgdGhpcy5faGFzaCA9IGhhc2g7XG4gICAgICAgIHRoaXMuX25vZGVzID0gbm9kZXM7XG4gICAgfVxuICAgIGlzRW1wdHkoKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgaXNMZWFmKCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGdldChrZXksIGhhc2gsIHNoaWZ0KSB7XG4gICAgICAgIGlmIChoYXNoID09PSB0aGlzLl9oYXNoKSB7XG4gICAgICAgICAgICBmb3IgKGNvbnN0IG5vZGUgb2YgdGhpcy5fbm9kZXMpIHtcbiAgICAgICAgICAgICAgICBjb25zdCB2YWx1ZSA9IG5vZGUuZ2V0KGtleSwgaGFzaCwgc2hpZnQpO1xuICAgICAgICAgICAgICAgIGlmICh2YWx1ZS5pc1NvbWUoKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICAgIHJldHVybiBOb25lO1xuICAgIH1cbiAgICBzZXQoa2V5LCB2YWx1ZSwgaGFzaCwgc2hpZnQpIHtcbiAgICAgICAgaWYgKGhhc2ggPT09IHRoaXMuX2hhc2gpIHtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwLCBuID0gdGhpcy5fbm9kZXMubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgbm9kZSA9IHRoaXMuX25vZGVzW2ldO1xuICAgICAgICAgICAgICAgIGlmIChFcXVhdGFibGUuZXF1YWxzKGtleSwgbm9kZS5rZXkpKSB7XG4gICAgICAgICAgICAgICAgICAgIGlmIChFcXVhdGFibGUuZXF1YWxzKHZhbHVlLCBub2RlLnZhbHVlKSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFN0YXR1cy51bmNoYW5nZWQodGhpcyk7XG4gICAgICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFN0YXR1cy51cGRhdGVkKENvbGxpc2lvbi5vZih0aGlzLl9oYXNoLCByZXBsYWNlKHRoaXMuX25vZGVzLCBpLCBMZWFmLm9mKGhhc2gsIGtleSwgdmFsdWUpKSkpO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBTdGF0dXMuY3JlYXRlZChDb2xsaXNpb24ub2YodGhpcy5faGFzaCwgdGhpcy5fbm9kZXMuY29uY2F0KExlYWYub2YoaGFzaCwga2V5LCB2YWx1ZSkpKSk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3QgZnJhZ21lbnQgPSBOb2RlLmZyYWdtZW50KHRoaXMuX2hhc2gsIHNoaWZ0KTtcbiAgICAgICAgcmV0dXJuIFNwYXJzZS5vZihiaXQoZnJhZ21lbnQpLCBbdGhpc10pLnNldChrZXksIHZhbHVlLCBoYXNoLCBzaGlmdCk7XG4gICAgfVxuICAgIGRlbGV0ZShrZXksIGhhc2gpIHtcbiAgICAgICAgaWYgKGhhc2ggPT09IHRoaXMuX2hhc2gpIHtcbiAgICAgICAgICAgIGZvciAobGV0IGkgPSAwLCBuID0gdGhpcy5fbm9kZXMubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgbm9kZSA9IHRoaXMuX25vZGVzW2ldO1xuICAgICAgICAgICAgICAgIGlmIChFcXVhdGFibGUuZXF1YWxzKGtleSwgbm9kZS5rZXkpKSB7XG4gICAgICAgICAgICAgICAgICAgIGNvbnN0IG5vZGVzID0gcmVtb3ZlKHRoaXMuX25vZGVzLCBpKTtcbiAgICAgICAgICAgICAgICAgICAgaWYgKG5vZGVzLmxlbmd0aCA9PT0gMSkge1xuICAgICAgICAgICAgICAgICAgICAgICAgLy8gV2UganVzdCBkZWxldGVkIHRoZSBwZW51bHRpbWF0ZSBMZWFmIG9mIHRoZSBDb2xsaXNpb24sIHNvIHdlIGNhblxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gcmVtb3ZlIHRoZSBDb2xsaXNpb24gYW5kIG9ubHkga2VlcCB0aGUgcmVtYWluaW5nIExlYWYuXG4gICAgICAgICAgICAgICAgICAgICAgICByZXR1cm4gU3RhdHVzLmRlbGV0ZWQobm9kZXNbMF0pO1xuICAgICAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBTdGF0dXMuZGVsZXRlZChDb2xsaXNpb24ub2YodGhpcy5faGFzaCwgbm9kZXMpKTtcbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIFN0YXR1cy51bmNoYW5nZWQodGhpcyk7XG4gICAgfVxuICAgIG1hcChtYXBwZXIpIHtcbiAgICAgICAgcmV0dXJuIENvbGxpc2lvbi5vZih0aGlzLl9oYXNoLCB0aGlzLl9ub2Rlcy5tYXAoKG5vZGUpID0+IG5vZGUubWFwKG1hcHBlcikpKTtcbiAgICB9XG4gICAgZXF1YWxzKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiAodmFsdWUgaW5zdGFuY2VvZiBDb2xsaXNpb24gJiZcbiAgICAgICAgICAgIHZhbHVlLl9oYXNoID09PSB0aGlzLl9oYXNoICYmXG4gICAgICAgICAgICB2YWx1ZS5fbm9kZXMubGVuZ3RoID09PSB0aGlzLl9ub2Rlcy5sZW5ndGggJiZcbiAgICAgICAgICAgIHZhbHVlLl9ub2Rlcy5ldmVyeSgobm9kZSwgaSkgPT4gbm9kZS5lcXVhbHModGhpcy5fbm9kZXNbaV0pKSk7XG4gICAgfVxuICAgICpbU3ltYm9sLml0ZXJhdG9yXSgpIHtcbiAgICAgICAgZm9yIChjb25zdCBub2RlIG9mIHRoaXMuX25vZGVzKSB7XG4gICAgICAgICAgICB5aWVsZCogbm9kZTtcbiAgICAgICAgfVxuICAgIH1cbn1cbi8qKlxuICogQGludGVybmFsXG4gKi9cbmV4cG9ydCBjbGFzcyBTcGFyc2Uge1xuICAgIHN0YXRpYyBvZihtYXNrLCBub2Rlcykge1xuICAgICAgICByZXR1cm4gbmV3IFNwYXJzZShtYXNrLCBub2Rlcyk7XG4gICAgfVxuICAgIF9tYXNrO1xuICAgIF9ub2RlcztcbiAgICBjb25zdHJ1Y3RvcihtYXNrLCBub2Rlcykge1xuICAgICAgICB0aGlzLl9tYXNrID0gbWFzaztcbiAgICAgICAgdGhpcy5fbm9kZXMgPSBub2RlcztcbiAgICB9XG4gICAgaXNFbXB0eSgpIHtcbiAgICAgICAgcmV0dXJuIGZhbHNlO1xuICAgIH1cbiAgICBpc0xlYWYoKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgZ2V0KGtleSwgaGFzaCwgc2hpZnQpIHtcbiAgICAgICAgY29uc3QgZnJhZ21lbnQgPSBOb2RlLmZyYWdtZW50KGhhc2gsIHNoaWZ0KTtcbiAgICAgICAgaWYgKHRlc3QodGhpcy5fbWFzaywgZnJhZ21lbnQpKSB7XG4gICAgICAgICAgICBjb25zdCBpbmRleCA9IE5vZGUuaW5kZXgoZnJhZ21lbnQsIHRoaXMuX21hc2spO1xuICAgICAgICAgICAgcmV0dXJuIHRoaXMuX25vZGVzW2luZGV4XS5nZXQoa2V5LCBoYXNoLCBzaGlmdCArIE5vZGUuQml0cyk7XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIE5vbmU7XG4gICAgfVxuICAgIHNldChrZXksIHZhbHVlLCBoYXNoLCBzaGlmdCkge1xuICAgICAgICBjb25zdCBmcmFnbWVudCA9IE5vZGUuZnJhZ21lbnQoaGFzaCwgc2hpZnQpO1xuICAgICAgICBjb25zdCBpbmRleCA9IE5vZGUuaW5kZXgoZnJhZ21lbnQsIHRoaXMuX21hc2spO1xuICAgICAgICBpZiAodGVzdCh0aGlzLl9tYXNrLCBmcmFnbWVudCkpIHtcbiAgICAgICAgICAgIGNvbnN0IHsgcmVzdWx0OiBub2RlLCBzdGF0dXMgfSA9IHRoaXMuX25vZGVzW2luZGV4XS5zZXQoa2V5LCB2YWx1ZSwgaGFzaCwgc2hpZnQgKyBOb2RlLkJpdHMpO1xuICAgICAgICAgICAgaWYgKHN0YXR1cyA9PT0gXCJ1bmNoYW5nZWRcIikge1xuICAgICAgICAgICAgICAgIHJldHVybiBTdGF0dXMudW5jaGFuZ2VkKHRoaXMpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgY29uc3Qgc3BhcnNlID0gU3BhcnNlLm9mKHRoaXMuX21hc2ssIHJlcGxhY2UodGhpcy5fbm9kZXMsIGluZGV4LCBub2RlKSk7XG4gICAgICAgICAgICBzd2l0Y2ggKHN0YXR1cykge1xuICAgICAgICAgICAgICAgIGNhc2UgXCJjcmVhdGVkXCI6XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiBTdGF0dXMuY3JlYXRlZChzcGFyc2UpO1xuICAgICAgICAgICAgICAgIGNhc2UgXCJ1cGRhdGVkXCI6XG4gICAgICAgICAgICAgICAgZGVmYXVsdDpcbiAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFN0YXR1cy51cGRhdGVkKHNwYXJzZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgICAgcmV0dXJuIFN0YXR1cy5jcmVhdGVkKFNwYXJzZS5vZihzZXQodGhpcy5fbWFzaywgZnJhZ21lbnQpLCBpbnNlcnQodGhpcy5fbm9kZXMsIGluZGV4LCBMZWFmLm9mKGhhc2gsIGtleSwgdmFsdWUpKSkpO1xuICAgIH1cbiAgICBkZWxldGUoa2V5LCBoYXNoLCBzaGlmdCkge1xuICAgICAgICBjb25zdCBmcmFnbWVudCA9IE5vZGUuZnJhZ21lbnQoaGFzaCwgc2hpZnQpO1xuICAgICAgICBpZiAodGVzdCh0aGlzLl9tYXNrLCBmcmFnbWVudCkpIHtcbiAgICAgICAgICAgIGNvbnN0IGluZGV4ID0gTm9kZS5pbmRleChmcmFnbWVudCwgdGhpcy5fbWFzayk7XG4gICAgICAgICAgICBjb25zdCB7IHJlc3VsdDogbm9kZSwgc3RhdHVzIH0gPSB0aGlzLl9ub2Rlc1tpbmRleF0uZGVsZXRlKGtleSwgaGFzaCwgc2hpZnQgKyBOb2RlLkJpdHMpO1xuICAgICAgICAgICAgaWYgKHN0YXR1cyA9PT0gXCJ1bmNoYW5nZWRcIikge1xuICAgICAgICAgICAgICAgIHJldHVybiBTdGF0dXMudW5jaGFuZ2VkKHRoaXMpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgaWYgKG5vZGUuaXNFbXB0eSgpKSB7XG4gICAgICAgICAgICAgICAgY29uc3Qgbm9kZXMgPSByZW1vdmUodGhpcy5fbm9kZXMsIGluZGV4KTtcbiAgICAgICAgICAgICAgICBpZiAobm9kZXMubGVuZ3RoID09PSAxKSB7XG4gICAgICAgICAgICAgICAgICAgIC8vIFdlIGRlbGV0ZWQgdGhlIHBlbnVsdGltYXRlIGNoaWxkIG9mIHRoZSBTcGFyc2UsIHdlIG1heSBiZSBhYmxlIHRvXG4gICAgICAgICAgICAgICAgICAgIC8vIHNpbXBsaWZ5IHRoZSB0cmVlLlxuICAgICAgICAgICAgICAgICAgICBpZiAobm9kZXNbMF0uaXNMZWFmKCkgfHwgbm9kZXNbMF0gaW5zdGFuY2VvZiBDb2xsaXNpb24pIHtcbiAgICAgICAgICAgICAgICAgICAgICAgIC8vIFRoZSBsYXN0IGNoaWxkIGlzIGxlYWYtbGlrZSwgaGVuY2UgaGFzaGVzIHdpbGwgYmUgZnVsbHkgbWF0Y2hlZFxuICAgICAgICAgICAgICAgICAgICAgICAgLy8gYWdhaW5zdCBpdHMga2V5KHMpIGFuZCB3ZSBjYW4gcmVtb3ZlIHRoZSBjdXJyZW50IFNwYXJzZVxuICAgICAgICAgICAgICAgICAgICAgICAgcmV0dXJuIFN0YXR1cy5kZWxldGVkKG5vZGVzWzBdKTtcbiAgICAgICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICAgICAgICAvLyBPdGhlcndpc2UsIHRoZSBsYXN0IGNoaWxkIGlzIGEgU3BhcnNlLiBXZSBjYW4ndCBzaW1wbHkgY29sbGFwc2UgdGhlXG4gICAgICAgICAgICAgICAgICAgIC8vIHRyZWUgYnkgcmVtb3ZpbmcgdGhlIGN1cnJlbnQgU3BhcnNlLCBzaW5jZSBpdCB3aWxsIGNhdXNlIHRoZSBjaGlsZFxuICAgICAgICAgICAgICAgICAgICAvLyBtYXNrIHRvIGJlIHRlc3RlZCB3aXRoIHRoZSB3cm9uZyBzaGlmdCAoaXRzIGRlcHRoIGluIHRoZSB0cmVlIHdvdWxkXG4gICAgICAgICAgICAgICAgICAgIC8vIGJlIGRpZmZlcmVudCkuXG4gICAgICAgICAgICAgICAgICAgIC8vIFdlIGNvdWxkIGRvIHNvbWUgZnVydGhlciBvcHRpbWlzYXRpb25zIChlLmcuLCBpZiB0aGUgY2hpbGQnc1xuICAgICAgICAgICAgICAgICAgICAvLyBjaGlsZHJlbiBhcmUgYWxsIGxlYWYtbGlrZSwgd2UgY291bGQgaW5zdGVhZCBkZWxldGUgdGhlIGxvbmUgY2hpbGRcbiAgICAgICAgICAgICAgICAgICAgLy8gYW5kIGNvbm5lY3QgZGlyZWN0bHkgdG8gdGhlIGdyYW5kY2hpbGRyZW4pLiBUaGlzIGlzLCBob3dldmVyLFxuICAgICAgICAgICAgICAgICAgICAvLyBnZXR0aW5nIGhhaXJ5IHRvIG1ha2UgYWxsIGNhc2VzIHdvcmtpbmcgZmluZSwgYW5kIHdlIGFzc3VtZSB0aGlzXG4gICAgICAgICAgICAgICAgICAgIC8vIGtpbmQgb2Ygc2l0dWF0aW9uIGlzIG5vdCB0b28gZnJlcXVlbnQuIFNvIHdlIHBheSB0aGUgcHJpY2Ugb2ZcbiAgICAgICAgICAgICAgICAgICAgLy8ga2VlcGluZyBhIG5vbi1icmFuY2hpbmcgU3BhcnNlIHVudGlsIHdlIG5lZWQgdG8gb3B0aW1pc2UgdGhhdC5cbiAgICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgICAgcmV0dXJuIFN0YXR1cy5kZWxldGVkKFNwYXJzZS5vZihjbGVhcih0aGlzLl9tYXNrLCBmcmFnbWVudCksIG5vZGVzKSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICByZXR1cm4gU3RhdHVzLmRlbGV0ZWQoU3BhcnNlLm9mKHRoaXMuX21hc2ssIHJlcGxhY2UodGhpcy5fbm9kZXMsIGluZGV4LCBub2RlKSkpO1xuICAgICAgICB9XG4gICAgICAgIHJldHVybiBTdGF0dXMudW5jaGFuZ2VkKHRoaXMpO1xuICAgIH1cbiAgICBtYXAobWFwcGVyKSB7XG4gICAgICAgIHJldHVybiBTcGFyc2Uub2YodGhpcy5fbWFzaywgdGhpcy5fbm9kZXMubWFwKChub2RlKSA9PiBub2RlLm1hcChtYXBwZXIpKSk7XG4gICAgfVxuICAgIGVxdWFscyh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gKHZhbHVlIGluc3RhbmNlb2YgU3BhcnNlICYmXG4gICAgICAgICAgICB2YWx1ZS5fbWFzayA9PT0gdGhpcy5fbWFzayAmJlxuICAgICAgICAgICAgdmFsdWUuX25vZGVzLmxlbmd0aCA9PT0gdGhpcy5fbm9kZXMubGVuZ3RoICYmXG4gICAgICAgICAgICB2YWx1ZS5fbm9kZXMuZXZlcnkoKG5vZGUsIGkpID0+IG5vZGUuZXF1YWxzKHRoaXMuX25vZGVzW2ldKSkpO1xuICAgIH1cbiAgICAqW1N5bWJvbC5pdGVyYXRvcl0oKSB7XG4gICAgICAgIGZvciAoY29uc3Qgbm9kZSBvZiB0aGlzLl9ub2Rlcykge1xuICAgICAgICAgICAgeWllbGQqIG5vZGU7XG4gICAgICAgIH1cbiAgICB9XG59XG5mdW5jdGlvbiBpbnNlcnQoYXJyYXksIGluZGV4LCB2YWx1ZSkge1xuICAgIGNvbnN0IHJlc3VsdCA9IG5ldyBBcnJheShhcnJheS5sZW5ndGggKyAxKTtcbiAgICByZXN1bHRbaW5kZXhdID0gdmFsdWU7XG4gICAgZm9yIChsZXQgaSA9IDAsIG4gPSBpbmRleDsgaSA8IG47IGkrKykge1xuICAgICAgICByZXN1bHRbaV0gPSBhcnJheVtpXTtcbiAgICB9XG4gICAgZm9yIChsZXQgaSA9IGluZGV4LCBuID0gYXJyYXkubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgIHJlc3VsdFtpICsgMV0gPSBhcnJheVtpXTtcbiAgICB9XG4gICAgcmV0dXJuIHJlc3VsdDtcbn1cbmZ1bmN0aW9uIHJlbW92ZShhcnJheSwgaW5kZXgpIHtcbiAgICBjb25zdCByZXN1bHQgPSBuZXcgQXJyYXkoYXJyYXkubGVuZ3RoIC0gMSk7XG4gICAgZm9yIChsZXQgaSA9IDAsIG4gPSBpbmRleDsgaSA8IG47IGkrKykge1xuICAgICAgICByZXN1bHRbaV0gPSBhcnJheVtpXTtcbiAgICB9XG4gICAgZm9yIChsZXQgaSA9IGluZGV4LCBuID0gcmVzdWx0Lmxlbmd0aDsgaSA8IG47IGkrKykge1xuICAgICAgICByZXN1bHRbaV0gPSBhcnJheVtpICsgMV07XG4gICAgfVxuICAgIHJldHVybiByZXN1bHQ7XG59XG5mdW5jdGlvbiByZXBsYWNlKGFycmF5LCBpbmRleCwgdmFsdWUpIHtcbiAgICBjb25zdCByZXN1bHQgPSBhcnJheS5zbGljZSgwKTtcbiAgICByZXN1bHRbaW5kZXhdID0gdmFsdWU7XG4gICAgcmV0dXJuIHJlc3VsdDtcbn1cbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW5vZGUuanMubWFwIiwiLyoqXG4gKiBAaW50ZXJuYWxcbiAqL1xuZXhwb3J0IHZhciBTdGF0dXM7XG4oZnVuY3Rpb24gKFN0YXR1c18xKSB7XG4gICAgY2xhc3MgU3RhdHVzIHtcbiAgICAgICAgX3Jlc3VsdDtcbiAgICAgICAgY29uc3RydWN0b3IocmVzdWx0KSB7XG4gICAgICAgICAgICB0aGlzLl9yZXN1bHQgPSByZXN1bHQ7XG4gICAgICAgIH1cbiAgICAgICAgZ2V0IHJlc3VsdCgpIHtcbiAgICAgICAgICAgIHJldHVybiB0aGlzLl9yZXN1bHQ7XG4gICAgICAgIH1cbiAgICB9XG4gICAgY2xhc3MgQ3JlYXRlZCBleHRlbmRzIFN0YXR1cyB7XG4gICAgICAgIHN0YXRpYyBvZihyZXN1bHQpIHtcbiAgICAgICAgICAgIHJldHVybiBuZXcgQ3JlYXRlZChyZXN1bHQpO1xuICAgICAgICB9XG4gICAgICAgIGNvbnN0cnVjdG9yKHJlc3VsdCkge1xuICAgICAgICAgICAgc3VwZXIocmVzdWx0KTtcbiAgICAgICAgfVxuICAgICAgICBnZXQgc3RhdHVzKCkge1xuICAgICAgICAgICAgcmV0dXJuIFwiY3JlYXRlZFwiO1xuICAgICAgICB9XG4gICAgfVxuICAgIFN0YXR1c18xLkNyZWF0ZWQgPSBDcmVhdGVkO1xuICAgIFN0YXR1c18xLmNyZWF0ZWQgPSBDcmVhdGVkLm9mO1xuICAgIGNsYXNzIFVwZGF0ZWQgZXh0ZW5kcyBTdGF0dXMge1xuICAgICAgICBzdGF0aWMgb2YocmVzdWx0KSB7XG4gICAgICAgICAgICByZXR1cm4gbmV3IFVwZGF0ZWQocmVzdWx0KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdHJ1Y3RvcihyZXN1bHQpIHtcbiAgICAgICAgICAgIHN1cGVyKHJlc3VsdCk7XG4gICAgICAgIH1cbiAgICAgICAgZ2V0IHN0YXR1cygpIHtcbiAgICAgICAgICAgIHJldHVybiBcInVwZGF0ZWRcIjtcbiAgICAgICAgfVxuICAgIH1cbiAgICBTdGF0dXNfMS5VcGRhdGVkID0gVXBkYXRlZDtcbiAgICBTdGF0dXNfMS51cGRhdGVkID0gVXBkYXRlZC5vZjtcbiAgICBjbGFzcyBEZWxldGVkIGV4dGVuZHMgU3RhdHVzIHtcbiAgICAgICAgc3RhdGljIG9mKHJlc3VsdCkge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBEZWxldGVkKHJlc3VsdCk7XG4gICAgICAgIH1cbiAgICAgICAgY29uc3RydWN0b3IocmVzdWx0KSB7XG4gICAgICAgICAgICBzdXBlcihyZXN1bHQpO1xuICAgICAgICB9XG4gICAgICAgIGdldCBzdGF0dXMoKSB7XG4gICAgICAgICAgICByZXR1cm4gXCJkZWxldGVkXCI7XG4gICAgICAgIH1cbiAgICB9XG4gICAgU3RhdHVzXzEuRGVsZXRlZCA9IERlbGV0ZWQ7XG4gICAgU3RhdHVzXzEuZGVsZXRlZCA9IERlbGV0ZWQub2Y7XG4gICAgY2xhc3MgVW5jaGFuZ2VkIGV4dGVuZHMgU3RhdHVzIHtcbiAgICAgICAgc3RhdGljIG9mKHJlc3VsdCkge1xuICAgICAgICAgICAgcmV0dXJuIG5ldyBVbmNoYW5nZWQocmVzdWx0KTtcbiAgICAgICAgfVxuICAgICAgICBjb25zdHJ1Y3RvcihyZXN1bHQpIHtcbiAgICAgICAgICAgIHN1cGVyKHJlc3VsdCk7XG4gICAgICAgIH1cbiAgICAgICAgZ2V0IHN0YXR1cygpIHtcbiAgICAgICAgICAgIHJldHVybiBcInVuY2hhbmdlZFwiO1xuICAgICAgICB9XG4gICAgfVxuICAgIFN0YXR1c18xLlVuY2hhbmdlZCA9IFVuY2hhbmdlZDtcbiAgICBTdGF0dXNfMS51bmNoYW5nZWQgPSBVbmNoYW5nZWQub2Y7XG59KShTdGF0dXMgfHwgKFN0YXR1cyA9IHt9KSk7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1zdGF0dXMuanMubWFwIiwiZXhwb3J0ICogZnJvbSBcIi4vbWF5YmUuanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL25vbmUuanNcIjtcbmV4cG9ydCAqIGZyb20gXCIuL29wdGlvbi5qc1wiO1xuZXhwb3J0ICogZnJvbSBcIi4vc29tZS5qc1wiO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9aW5kZXguanMubWFwIiwiaW1wb3J0IHsgT3B0aW9uIH0gZnJvbSBcIi4vb3B0aW9uLmpzXCI7XG4vKipcbiAqIEBpbnRlcm5hbFxuICovXG5leHBvcnQgdmFyIE1heWJlO1xuKGZ1bmN0aW9uIChNYXliZSkge1xuICAgIGZ1bmN0aW9uIHRvT3B0aW9uKG1heWJlKSB7XG4gICAgICAgIHJldHVybiBPcHRpb24uaXNPcHRpb24obWF5YmUpID8gbWF5YmUgOiBPcHRpb24ub2YobWF5YmUpO1xuICAgIH1cbiAgICBNYXliZS50b09wdGlvbiA9IHRvT3B0aW9uO1xufSkoTWF5YmUgfHwgKE1heWJlID0ge30pKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW1heWJlLmpzLm1hcCIsImltcG9ydCB7IENvbXBhcmFibGUsIENvbXBhcmlzb24gfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtY29tcGFyYWJsZVwiO1xuY29uc3QgeyBjb21wYXJlQ29tcGFyYWJsZSB9ID0gQ29tcGFyYWJsZTtcbi8qKlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgY29uc3QgTm9uZSA9IG5ldyAoY2xhc3MgTm9uZSB7XG4gICAgaXNTb21lKCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIGlzTm9uZSgpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIG1hcCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGZvckVhY2goKSB7XG4gICAgICAgIHJldHVybjtcbiAgICB9XG4gICAgYXBwbHkoKSB7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBmbGF0TWFwKCkge1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgZmxhdHRlbigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIHJlZHVjZShyZWR1Y2VyLCBhY2N1bXVsYXRvcikge1xuICAgICAgICByZXR1cm4gYWNjdW11bGF0b3I7XG4gICAgfVxuICAgIGZpbHRlcigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIHJlamVjdCgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIGluY2x1ZGVzKCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIHNvbWUoKSB7XG4gICAgICAgIHJldHVybiBmYWxzZTtcbiAgICB9XG4gICAgbm9uZSgpIHtcbiAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgfVxuICAgIGV2ZXJ5KCkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgYW5kKCkge1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgYW5kVGhlbigpIHtcbiAgICAgICAgcmV0dXJuIHRoaXM7XG4gICAgfVxuICAgIG9yKG9wdGlvbikge1xuICAgICAgICByZXR1cm4gb3B0aW9uO1xuICAgIH1cbiAgICBvckVsc2Uob3B0aW9uKSB7XG4gICAgICAgIHJldHVybiBvcHRpb24oKTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgZ2V0VW5zYWZlKG1lc3NhZ2UgPSBcIkF0dGVtcHRlZCB0byAuZ2V0VW5zYWZlKCkgZnJvbSBOb25lXCIpIHtcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKG1lc3NhZ2UpO1xuICAgIH1cbiAgICBnZXRPcih2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdmFsdWU7XG4gICAgfVxuICAgIGdldE9yRWxzZSh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdmFsdWUoKTtcbiAgICB9XG4gICAgdGVlKCkge1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgY29tcGFyZShvcHRpb24pIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuY29tcGFyZVdpdGgob3B0aW9uLCBjb21wYXJlQ29tcGFyYWJsZSk7XG4gICAgfVxuICAgIGNvbXBhcmVXaXRoKG9wdGlvbikge1xuICAgICAgICByZXR1cm4gb3B0aW9uLmlzTm9uZSgpID8gQ29tcGFyaXNvbi5FcXVhbCA6IENvbXBhcmlzb24uTGVzcztcbiAgICB9XG4gICAgZXF1YWxzKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZSBpbnN0YW5jZW9mIE5vbmU7XG4gICAgfVxuICAgIGhhc2goaGFzaCkge1xuICAgICAgICBoYXNoLndyaXRlQm9vbGVhbihmYWxzZSk7XG4gICAgfVxuICAgICpbU3ltYm9sLml0ZXJhdG9yXSgpIHsgfVxuICAgIHRvQXJyYXkoKSB7XG4gICAgICAgIHJldHVybiBbXTtcbiAgICB9XG4gICAgdG9KU09OKCkge1xuICAgICAgICByZXR1cm4ge1xuICAgICAgICAgICAgdHlwZTogXCJub25lXCIsXG4gICAgICAgIH07XG4gICAgfVxuICAgIHRvU3RyaW5nKCkge1xuICAgICAgICByZXR1cm4gXCJOb25lXCI7XG4gICAgfVxufSkoKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPW5vbmUuanMubWFwIiwiaW1wb3J0IHt9IGZyb20gXCJAc2l0ZWltcHJvdmUvYWxmYS1jb21wYXJhYmxlXCI7XG5pbXBvcnQgeyBOb25lIH0gZnJvbSBcIi4vbm9uZS5qc1wiO1xuaW1wb3J0IHsgU29tZSB9IGZyb20gXCIuL3NvbWUuanNcIjtcbi8qKlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgdmFyIE9wdGlvbjtcbihmdW5jdGlvbiAoT3B0aW9uKSB7XG4gICAgZnVuY3Rpb24gaXNPcHRpb24odmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIGlzU29tZSh2YWx1ZSkgfHwgaXNOb25lKHZhbHVlKTtcbiAgICB9XG4gICAgT3B0aW9uLmlzT3B0aW9uID0gaXNPcHRpb247XG4gICAgZnVuY3Rpb24gaXNTb21lKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiBTb21lLmlzU29tZSh2YWx1ZSk7XG4gICAgfVxuICAgIE9wdGlvbi5pc1NvbWUgPSBpc1NvbWU7XG4gICAgZnVuY3Rpb24gaXNOb25lKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB2YWx1ZSA9PT0gTm9uZTtcbiAgICB9XG4gICAgT3B0aW9uLmlzTm9uZSA9IGlzTm9uZTtcbiAgICBmdW5jdGlvbiBvZih2YWx1ZSkge1xuICAgICAgICByZXR1cm4gU29tZS5vZih2YWx1ZSk7XG4gICAgfVxuICAgIE9wdGlvbi5vZiA9IG9mO1xuICAgIGZ1bmN0aW9uIGVtcHR5KCkge1xuICAgICAgICByZXR1cm4gTm9uZTtcbiAgICB9XG4gICAgT3B0aW9uLmVtcHR5ID0gZW1wdHk7XG4gICAgZnVuY3Rpb24gZnJvbSh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdmFsdWUgPT09IG51bGwgfHwgdmFsdWUgPT09IHVuZGVmaW5lZCA/IE5vbmUgOiBTb21lLm9mKHZhbHVlKTtcbiAgICB9XG4gICAgT3B0aW9uLmZyb20gPSBmcm9tO1xufSkoT3B0aW9uIHx8IChPcHRpb24gPSB7fSkpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9b3B0aW9uLmpzLm1hcCIsImltcG9ydCB7IENvbXBhcmFibGUsIENvbXBhcmlzb24sIH0gZnJvbSBcIkBzaXRlaW1wcm92ZS9hbGZhLWNvbXBhcmFibGVcIjtcbmltcG9ydCB7IEVxdWF0YWJsZSB9IGZyb20gXCJAc2l0ZWltcHJvdmUvYWxmYS1lcXVhdGFibGVcIjtcbmltcG9ydCB7IFNlcmlhbGl6YWJsZSB9IGZyb20gXCJAc2l0ZWltcHJvdmUvYWxmYS1qc29uXCI7XG5pbXBvcnQgeyBQcmVkaWNhdGUgfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtcHJlZGljYXRlXCI7XG5pbXBvcnQgeyBOb25lIH0gZnJvbSBcIi4vbm9uZS5qc1wiO1xuY29uc3QgeyBub3QsIHRlc3QgfSA9IFByZWRpY2F0ZTtcbmNvbnN0IHsgY29tcGFyZUNvbXBhcmFibGUgfSA9IENvbXBhcmFibGU7XG4vKipcbiAqIEBwdWJsaWNcbiAqL1xuZXhwb3J0IGNsYXNzIFNvbWUge1xuICAgIHN0YXRpYyBvZih2YWx1ZSkge1xuICAgICAgICByZXR1cm4gbmV3IFNvbWUodmFsdWUpO1xuICAgIH1cbiAgICBfdmFsdWU7XG4gICAgY29uc3RydWN0b3IodmFsdWUpIHtcbiAgICAgICAgdGhpcy5fdmFsdWUgPSB2YWx1ZTtcbiAgICB9XG4gICAgaXNTb21lKCkge1xuICAgICAgICByZXR1cm4gdHJ1ZTtcbiAgICB9XG4gICAgaXNOb25lKCkge1xuICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgfVxuICAgIG1hcChtYXBwZXIpIHtcbiAgICAgICAgcmV0dXJuIG5ldyBTb21lKG1hcHBlcih0aGlzLl92YWx1ZSkpO1xuICAgIH1cbiAgICBmb3JFYWNoKG1hcHBlcikge1xuICAgICAgICBtYXBwZXIodGhpcy5fdmFsdWUpO1xuICAgIH1cbiAgICBhcHBseShtYXBwZXIpIHtcbiAgICAgICAgcmV0dXJuIG1hcHBlci5tYXAoKG1hcHBlcikgPT4gbWFwcGVyKHRoaXMuX3ZhbHVlKSk7XG4gICAgfVxuICAgIGZsYXRNYXAobWFwcGVyKSB7XG4gICAgICAgIHJldHVybiBtYXBwZXIodGhpcy5fdmFsdWUpO1xuICAgIH1cbiAgICBmbGF0dGVuKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fdmFsdWU7XG4gICAgfVxuICAgIHJlZHVjZShyZWR1Y2VyLCBhY2N1bXVsYXRvcikge1xuICAgICAgICByZXR1cm4gcmVkdWNlcihhY2N1bXVsYXRvciwgdGhpcy5fdmFsdWUpO1xuICAgIH1cbiAgICBmaWx0ZXIocHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiB0ZXN0KHByZWRpY2F0ZSwgdGhpcy5fdmFsdWUpID8gdGhpcyA6IE5vbmU7XG4gICAgfVxuICAgIHJlamVjdChwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuZmlsdGVyKG5vdChwcmVkaWNhdGUpKTtcbiAgICB9XG4gICAgaW5jbHVkZXModmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIEVxdWF0YWJsZS5lcXVhbHModmFsdWUsIHRoaXMuX3ZhbHVlKTtcbiAgICB9XG4gICAgc29tZShwcmVkaWNhdGUpIHtcbiAgICAgICAgcmV0dXJuIHRlc3QocHJlZGljYXRlLCB0aGlzLl92YWx1ZSk7XG4gICAgfVxuICAgIG5vbmUocHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiB0ZXN0KG5vdChwcmVkaWNhdGUpLCB0aGlzLl92YWx1ZSk7XG4gICAgfVxuICAgIGV2ZXJ5KHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gdGVzdChwcmVkaWNhdGUsIHRoaXMuX3ZhbHVlKTtcbiAgICB9XG4gICAgYW5kKG9wdGlvbikge1xuICAgICAgICByZXR1cm4gb3B0aW9uO1xuICAgIH1cbiAgICBhbmRUaGVuKG9wdGlvbikge1xuICAgICAgICByZXR1cm4gb3B0aW9uKHRoaXMuX3ZhbHVlKTtcbiAgICB9XG4gICAgb3IoKSB7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBvckVsc2UoKSB7XG4gICAgICAgIHJldHVybiB0aGlzO1xuICAgIH1cbiAgICBnZXQoKSB7XG4gICAgICAgIHJldHVybiB0aGlzLl92YWx1ZTtcbiAgICB9XG4gICAgLyoqXG4gICAgICogQGludGVybmFsXG4gICAgICovXG4gICAgZ2V0VW5zYWZlKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fdmFsdWU7XG4gICAgfVxuICAgIGdldE9yKCkge1xuICAgICAgICByZXR1cm4gdGhpcy5fdmFsdWU7XG4gICAgfVxuICAgIGdldE9yRWxzZSgpIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuX3ZhbHVlO1xuICAgIH1cbiAgICB0ZWUoY2FsbGJhY2spIHtcbiAgICAgICAgY2FsbGJhY2sodGhpcy5fdmFsdWUpO1xuICAgICAgICByZXR1cm4gdGhpcztcbiAgICB9XG4gICAgY29tcGFyZShvcHRpb24pIHtcbiAgICAgICAgcmV0dXJuIHRoaXMuY29tcGFyZVdpdGgob3B0aW9uLCBjb21wYXJlQ29tcGFyYWJsZSk7XG4gICAgfVxuICAgIGNvbXBhcmVXaXRoKG9wdGlvbiwgY29tcGFyZXIpIHtcbiAgICAgICAgcmV0dXJuIG9wdGlvbi5pc1NvbWUoKVxuICAgICAgICAgICAgPyBjb21wYXJlcih0aGlzLl92YWx1ZSwgb3B0aW9uLl92YWx1ZSlcbiAgICAgICAgICAgIDogQ29tcGFyaXNvbi5HcmVhdGVyO1xuICAgIH1cbiAgICBlcXVhbHModmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgU29tZSAmJiBFcXVhdGFibGUuZXF1YWxzKHZhbHVlLl92YWx1ZSwgdGhpcy5fdmFsdWUpO1xuICAgIH1cbiAgICBoYXNoKGhhc2gpIHtcbiAgICAgICAgaGFzaC53cml0ZUJvb2xlYW4odHJ1ZSkud3JpdGVVbmtub3duKHRoaXMuX3ZhbHVlKTtcbiAgICB9XG4gICAgKltTeW1ib2wuaXRlcmF0b3JdKCkge1xuICAgICAgICB5aWVsZCB0aGlzLl92YWx1ZTtcbiAgICB9XG4gICAgdG9BcnJheSgpIHtcbiAgICAgICAgcmV0dXJuIFt0aGlzLl92YWx1ZV07XG4gICAgfVxuICAgIHRvSlNPTihvcHRpb25zKSB7XG4gICAgICAgIHJldHVybiB7XG4gICAgICAgICAgICB0eXBlOiBcInNvbWVcIixcbiAgICAgICAgICAgIHZhbHVlOiBTZXJpYWxpemFibGUudG9KU09OKHRoaXMuX3ZhbHVlLCBvcHRpb25zKSxcbiAgICAgICAgfTtcbiAgICB9XG4gICAgdG9TdHJpbmcoKSB7XG4gICAgICAgIHJldHVybiBgU29tZSB7ICR7dGhpcy5fdmFsdWV9IH1gO1xuICAgIH1cbn1cbi8qKlxuICogQHB1YmxpY1xuICovXG4oZnVuY3Rpb24gKFNvbWUpIHtcbiAgICBmdW5jdGlvbiBpc1NvbWUodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlIGluc3RhbmNlb2YgU29tZTtcbiAgICB9XG4gICAgU29tZS5pc1NvbWUgPSBpc1NvbWU7XG59KShTb21lIHx8IChTb21lID0ge30pKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXNvbWUuanMubWFwIiwiZXhwb3J0ICogZnJvbSBcIi4vcHJlZGljYXRlLmpzXCI7XG4vLyMgc291cmNlTWFwcGluZ1VSTD1pbmRleC5qcy5tYXAiLCJpbXBvcnQgeyBFcXVhdGFibGUgfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtZXF1YXRhYmxlXCI7XG4vKipcbiAqIEBwdWJsaWNcbiAqL1xuZXhwb3J0IHZhciBQcmVkaWNhdGU7XG4oZnVuY3Rpb24gKFByZWRpY2F0ZSkge1xuICAgIGZ1bmN0aW9uIHRlc3QocHJlZGljYXRlLCB2YWx1ZSwgLi4uYXJncykge1xuICAgICAgICByZXR1cm4gcHJlZGljYXRlKHZhbHVlLCAuLi5hcmdzKTtcbiAgICB9XG4gICAgUHJlZGljYXRlLnRlc3QgPSB0ZXN0O1xuICAgIGZ1bmN0aW9uIGZvbGQocHJlZGljYXRlLCBpZlRydWUsIGlmRmFsc2UsIHZhbHVlLCAuLi5hcmdzKSB7XG4gICAgICAgIHJldHVybiBwcmVkaWNhdGUodmFsdWUsIC4uLmFyZ3MpID8gaWZUcnVlKHZhbHVlKSA6IGlmRmFsc2UodmFsdWUpO1xuICAgIH1cbiAgICBQcmVkaWNhdGUuZm9sZCA9IGZvbGQ7XG4gICAgZnVuY3Rpb24gbm90KHByZWRpY2F0ZSkge1xuICAgICAgICByZXR1cm4gKHZhbHVlLCAuLi5hcmdzKSA9PiAhcHJlZGljYXRlKHZhbHVlLCAuLi5hcmdzKTtcbiAgICB9XG4gICAgUHJlZGljYXRlLm5vdCA9IG5vdDtcbiAgICBmdW5jdGlvbiBhbmQoLi4ucHJlZGljYXRlcykge1xuICAgICAgICByZXR1cm4gKHZhbHVlLCAuLi5hcmdzKSA9PiB7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IHByZWRpY2F0ZXMubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICAgICAgaWYgKCFwcmVkaWNhdGVzW2ldKHZhbHVlLCAuLi5hcmdzKSkge1xuICAgICAgICAgICAgICAgICAgICByZXR1cm4gZmFsc2U7XG4gICAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgfVxuICAgICAgICAgICAgcmV0dXJuIHRydWU7XG4gICAgICAgIH07XG4gICAgfVxuICAgIFByZWRpY2F0ZS5hbmQgPSBhbmQ7XG4gICAgZnVuY3Rpb24gb3IoLi4ucHJlZGljYXRlcykge1xuICAgICAgICByZXR1cm4gKHZhbHVlLCAuLi5hcmdzKSA9PiB7XG4gICAgICAgICAgICBmb3IgKGxldCBpID0gMCwgbiA9IHByZWRpY2F0ZXMubGVuZ3RoOyBpIDwgbjsgaSsrKSB7XG4gICAgICAgICAgICAgICAgaWYgKHByZWRpY2F0ZXNbaV0odmFsdWUsIC4uLmFyZ3MpKSB7XG4gICAgICAgICAgICAgICAgICAgIHJldHVybiB0cnVlO1xuICAgICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIHJldHVybiBmYWxzZTtcbiAgICAgICAgfTtcbiAgICB9XG4gICAgUHJlZGljYXRlLm9yID0gb3I7XG4gICAgZnVuY3Rpb24geG9yKC4uLnByZWRpY2F0ZXMpIHtcbiAgICAgICAgcmV0dXJuIGFuZChvciguLi5wcmVkaWNhdGVzKSwgbm90KGFuZCguLi5wcmVkaWNhdGVzKSkpO1xuICAgIH1cbiAgICBQcmVkaWNhdGUueG9yID0geG9yO1xuICAgIGZ1bmN0aW9uIG5vciguLi5wcmVkaWNhdGVzKSB7XG4gICAgICAgIHJldHVybiBub3Qob3IoLi4ucHJlZGljYXRlcykpO1xuICAgIH1cbiAgICBQcmVkaWNhdGUubm9yID0gbm9yO1xuICAgIGZ1bmN0aW9uIG5hbmQoLi4ucHJlZGljYXRlcykge1xuICAgICAgICByZXR1cm4gbm90KGFuZCguLi5wcmVkaWNhdGVzKSk7XG4gICAgfVxuICAgIFByZWRpY2F0ZS5uYW5kID0gbmFuZDtcbiAgICBmdW5jdGlvbiBlcXVhbHMoLi4udmFsdWVzKSB7XG4gICAgICAgIHJldHVybiAob3RoZXIpID0+IHZhbHVlcy5zb21lKCh2YWx1ZSkgPT4gRXF1YXRhYmxlLmVxdWFscyhvdGhlciwgdmFsdWUpKTtcbiAgICB9XG4gICAgUHJlZGljYXRlLmVxdWFscyA9IGVxdWFscztcbiAgICBmdW5jdGlvbiBwcm9wZXJ0eShwcm9wZXJ0eSwgcHJlZGljYXRlKSB7XG4gICAgICAgIHJldHVybiAodmFsdWUsIC4uLmFyZ3MpID0+IHByZWRpY2F0ZSh2YWx1ZVtwcm9wZXJ0eV0sIC4uLmFyZ3MpO1xuICAgIH1cbiAgICBQcmVkaWNhdGUucHJvcGVydHkgPSBwcm9wZXJ0eTtcbiAgICBmdW5jdGlvbiB0ZWUocHJlZGljYXRlLCBjYWxsYmFjaykge1xuICAgICAgICByZXR1cm4gKHZhbHVlLCAuLi5hcmdzKSA9PiB7XG4gICAgICAgICAgICBjb25zdCByZXN1bHQgPSBwcmVkaWNhdGUodmFsdWUsIC4uLmFyZ3MpO1xuICAgICAgICAgICAgY2FsbGJhY2sodmFsdWUsIHJlc3VsdCwgLi4uYXJncyk7XG4gICAgICAgICAgICByZXR1cm4gcmVzdWx0O1xuICAgICAgICB9O1xuICAgIH1cbiAgICBQcmVkaWNhdGUudGVlID0gdGVlO1xufSkoUHJlZGljYXRlIHx8IChQcmVkaWNhdGUgPSB7fSkpO1xuLy8jIHNvdXJjZU1hcHBpbmdVUkw9cHJlZGljYXRlLmpzLm1hcCIsImV4cG9ydCAqIGZyb20gXCIuL3JlZmluZW1lbnQuanNcIjtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPWluZGV4LmpzLm1hcCIsImltcG9ydCB7IFByZWRpY2F0ZSB9IGZyb20gXCJAc2l0ZWltcHJvdmUvYWxmYS1wcmVkaWNhdGVcIjtcbi8qKlxuICogQHB1YmxpY1xuICovXG5leHBvcnQgdmFyIFJlZmluZW1lbnQ7XG4oZnVuY3Rpb24gKFJlZmluZW1lbnQpIHtcbiAgICBSZWZpbmVtZW50LnRlc3QgPSBQcmVkaWNhdGUudGVzdDtcbiAgICBSZWZpbmVtZW50LmZvbGQgPSBQcmVkaWNhdGUuZm9sZDtcbiAgICBSZWZpbmVtZW50Lm5vdCA9IFByZWRpY2F0ZS5ub3Q7XG4gICAgUmVmaW5lbWVudC5hbmQgPSBQcmVkaWNhdGUuYW5kO1xuICAgIFJlZmluZW1lbnQub3IgPSBQcmVkaWNhdGUub3I7XG4gICAgUmVmaW5lbWVudC54b3IgPSBQcmVkaWNhdGUueG9yO1xuICAgIFJlZmluZW1lbnQubm9yID0gUHJlZGljYXRlLm5vcjtcbiAgICBSZWZpbmVtZW50Lm5hbmQgPSBQcmVkaWNhdGUubmFuZDtcbiAgICBSZWZpbmVtZW50LmVxdWFscyA9IFByZWRpY2F0ZS5lcXVhbHM7XG4gICAgZnVuY3Rpb24gaXNTdHJpbmcodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHR5cGVvZiB2YWx1ZSA9PT0gXCJzdHJpbmdcIjtcbiAgICB9XG4gICAgUmVmaW5lbWVudC5pc1N0cmluZyA9IGlzU3RyaW5nO1xuICAgIGZ1bmN0aW9uIGlzTnVtYmVyKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwibnVtYmVyXCI7XG4gICAgfVxuICAgIFJlZmluZW1lbnQuaXNOdW1iZXIgPSBpc051bWJlcjtcbiAgICBmdW5jdGlvbiBpc0JpZ0ludCh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSBcImJpZ2ludFwiO1xuICAgIH1cbiAgICBSZWZpbmVtZW50LmlzQmlnSW50ID0gaXNCaWdJbnQ7XG4gICAgZnVuY3Rpb24gaXNCb29sZWFuKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwiYm9vbGVhblwiO1xuICAgIH1cbiAgICBSZWZpbmVtZW50LmlzQm9vbGVhbiA9IGlzQm9vbGVhbjtcbiAgICBmdW5jdGlvbiBpc051bGwodmFsdWUpIHtcbiAgICAgICAgcmV0dXJuIHZhbHVlID09PSBudWxsO1xuICAgIH1cbiAgICBSZWZpbmVtZW50LmlzTnVsbCA9IGlzTnVsbDtcbiAgICBmdW5jdGlvbiBpc1VuZGVmaW5lZCh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdmFsdWUgPT09IHVuZGVmaW5lZDtcbiAgICB9XG4gICAgUmVmaW5lbWVudC5pc1VuZGVmaW5lZCA9IGlzVW5kZWZpbmVkO1xuICAgIGZ1bmN0aW9uIGlzU3ltYm9sKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwic3ltYm9sXCI7XG4gICAgfVxuICAgIFJlZmluZW1lbnQuaXNTeW1ib2wgPSBpc1N5bWJvbDtcbiAgICBmdW5jdGlvbiBpc0Z1bmN0aW9uKHZhbHVlKSB7XG4gICAgICAgIHJldHVybiB0eXBlb2YgdmFsdWUgPT09IFwiZnVuY3Rpb25cIjtcbiAgICB9XG4gICAgUmVmaW5lbWVudC5pc0Z1bmN0aW9uID0gaXNGdW5jdGlvbjtcbiAgICBmdW5jdGlvbiBpc09iamVjdCh2YWx1ZSkge1xuICAgICAgICByZXR1cm4gdHlwZW9mIHZhbHVlID09PSBcIm9iamVjdFwiICYmIHZhbHVlICE9PSBudWxsO1xuICAgIH1cbiAgICBSZWZpbmVtZW50LmlzT2JqZWN0ID0gaXNPYmplY3Q7XG4gICAgUmVmaW5lbWVudC5pc1ByaW1pdGl2ZSA9IFJlZmluZW1lbnQub3IoaXNTdHJpbmcsIFJlZmluZW1lbnQub3IoaXNOdW1iZXIsIFJlZmluZW1lbnQub3IoaXNCaWdJbnQsIFJlZmluZW1lbnQub3IoaXNCb29sZWFuLCBSZWZpbmVtZW50Lm9yKGlzTnVsbCwgUmVmaW5lbWVudC5vcihpc1VuZGVmaW5lZCwgaXNTeW1ib2wpKSkpKSk7XG59KShSZWZpbmVtZW50IHx8IChSZWZpbmVtZW50ID0ge30pKTtcbi8vIyBzb3VyY2VNYXBwaW5nVVJMPXJlZmluZW1lbnQuanMubWFwIiwiLy8gVGhlIG1vZHVsZSBjYWNoZVxudmFyIF9fd2VicGFja19tb2R1bGVfY2FjaGVfXyA9IHt9O1xuXG4vLyBUaGUgcmVxdWlyZSBmdW5jdGlvblxuZnVuY3Rpb24gX193ZWJwYWNrX3JlcXVpcmVfXyhtb2R1bGVJZCkge1xuXHQvLyBDaGVjayBpZiBtb2R1bGUgaXMgaW4gY2FjaGVcblx0dmFyIGNhY2hlZE1vZHVsZSA9IF9fd2VicGFja19tb2R1bGVfY2FjaGVfX1ttb2R1bGVJZF07XG5cdGlmIChjYWNoZWRNb2R1bGUgIT09IHVuZGVmaW5lZCkge1xuXHRcdHJldHVybiBjYWNoZWRNb2R1bGUuZXhwb3J0cztcblx0fVxuXHQvLyBDcmVhdGUgYSBuZXcgbW9kdWxlIChhbmQgcHV0IGl0IGludG8gdGhlIGNhY2hlKVxuXHR2YXIgbW9kdWxlID0gX193ZWJwYWNrX21vZHVsZV9jYWNoZV9fW21vZHVsZUlkXSA9IHtcblx0XHQvLyBubyBtb2R1bGUuaWQgbmVlZGVkXG5cdFx0Ly8gbm8gbW9kdWxlLmxvYWRlZCBuZWVkZWRcblx0XHRleHBvcnRzOiB7fVxuXHR9O1xuXG5cdC8vIEV4ZWN1dGUgdGhlIG1vZHVsZSBmdW5jdGlvblxuXHRfX3dlYnBhY2tfbW9kdWxlc19fW21vZHVsZUlkXS5jYWxsKG1vZHVsZS5leHBvcnRzLCBtb2R1bGUsIG1vZHVsZS5leHBvcnRzLCBfX3dlYnBhY2tfcmVxdWlyZV9fKTtcblxuXHQvLyBSZXR1cm4gdGhlIGV4cG9ydHMgb2YgdGhlIG1vZHVsZVxuXHRyZXR1cm4gbW9kdWxlLmV4cG9ydHM7XG59XG5cbiIsIi8vIGdldERlZmF1bHRFeHBvcnQgZnVuY3Rpb24gZm9yIGNvbXBhdGliaWxpdHkgd2l0aCBub24taGFybW9ueSBtb2R1bGVzXG5fX3dlYnBhY2tfcmVxdWlyZV9fLm4gPSAobW9kdWxlKSA9PiB7XG5cdHZhciBnZXR0ZXIgPSBtb2R1bGUgJiYgbW9kdWxlLl9fZXNNb2R1bGUgP1xuXHRcdCgpID0+IChtb2R1bGVbJ2RlZmF1bHQnXSkgOlxuXHRcdCgpID0+IChtb2R1bGUpO1xuXHRfX3dlYnBhY2tfcmVxdWlyZV9fLmQoZ2V0dGVyLCB7IGE6IGdldHRlciB9KTtcblx0cmV0dXJuIGdldHRlcjtcbn07IiwiLy8gZGVmaW5lIGdldHRlciBmdW5jdGlvbnMgZm9yIGhhcm1vbnkgZXhwb3J0c1xuX193ZWJwYWNrX3JlcXVpcmVfXy5kID0gKGV4cG9ydHMsIGRlZmluaXRpb24pID0+IHtcblx0Zm9yKHZhciBrZXkgaW4gZGVmaW5pdGlvbikge1xuXHRcdGlmKF9fd2VicGFja19yZXF1aXJlX18ubyhkZWZpbml0aW9uLCBrZXkpICYmICFfX3dlYnBhY2tfcmVxdWlyZV9fLm8oZXhwb3J0cywga2V5KSkge1xuXHRcdFx0T2JqZWN0LmRlZmluZVByb3BlcnR5KGV4cG9ydHMsIGtleSwgeyBlbnVtZXJhYmxlOiB0cnVlLCBnZXQ6IGRlZmluaXRpb25ba2V5XSB9KTtcblx0XHR9XG5cdH1cbn07IiwiX193ZWJwYWNrX3JlcXVpcmVfXy5vID0gKG9iaiwgcHJvcCkgPT4gKE9iamVjdC5wcm90b3R5cGUuaGFzT3duUHJvcGVydHkuY2FsbChvYmosIHByb3ApKSIsIi8vIGRlZmluZSBfX2VzTW9kdWxlIG9uIGV4cG9ydHNcbl9fd2VicGFja19yZXF1aXJlX18uciA9IChleHBvcnRzKSA9PiB7XG5cdGlmKHR5cGVvZiBTeW1ib2wgIT09ICd1bmRlZmluZWQnICYmIFN5bWJvbC50b1N0cmluZ1RhZykge1xuXHRcdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCBTeW1ib2wudG9TdHJpbmdUYWcsIHsgdmFsdWU6ICdNb2R1bGUnIH0pO1xuXHR9XG5cdE9iamVjdC5kZWZpbmVQcm9wZXJ0eShleHBvcnRzLCAnX19lc01vZHVsZScsIHsgdmFsdWU6IHRydWUgfSk7XG59OyIsIi8qKlxuICogVGhpcyBpcyB0aGUgbWFpbiBlbnRyeSBwb2ludCB0byB3aGF0IHdlIHJlZmVyIHRvIGFzIHRoZSBBUEkgb2YgdGhlIGV4dGVuc2lvbi5cbiAqIFRoZSBBUEkgaGFuZGxlcyBtb3N0IGludGVyYWN0aW9ucyB3aXRoIEFsZmEsIHRoZSBicm93c2VyLCBhbmQgdGhlIHBhZ2UgYmVpbmdcbiAqIHRlc3RlZCBhbmQgZXhwb3NlcyBhbiBpbnRlcmZhY2UgZm9yIHRoZSBhcHBsaWNhdGlvbiBjb2RlIHRvIGNhbGwgdGhyb3VnaFxuICogbWVzc2FnaW5nLlxuICpcbiAqIFRoZSBBUEkgaXMgcnVuIGFzIGEgcG9zc2libHkgbm9uLXBlcnNpc3RlbnQgYmFja2dyb3VuZCBzY3JpcHQgKG9yIHNlcnZpY2VcbiAqIHdvcmtlciwgZGVwZW5kaW5nIG9uIGJyb3dzZXJzKSBpbiB0aGUgYnJvd3Nlci5cbiAqIEl0IG11c3QgdGhlcmVmb3JlIG5vdCBkZXBlbmQgb24gYW55IGdsb2JhbCBzdGF0ZSBhcyBzdWNoIHN0YXRlIHdpbGwgYmUgbG9zdFxuICogd2hlbiB0aGUgYmFja2dyb3VuZCBzY3JpcHQgaXMgdW5sb2FkZWQuXG4gKlxuICogTm90YWJseSwgdGhpcyBmb3JjZXMgdGhlIHBvcHVwIHRvIGNvbm5lY3QgZGlyZWN0bHkgdG8gdGhlIGRldnRvb2xzIGluc3RhbmNlXG4gKiBvZiB0aGUgaW5zcGVjdGVkIHBhZ2U7IGFuZCB0aGlzIGZvcmNlcyB0aGUgcG9wdXAgbWFwIHRvIGJlIHN0b3JlZCBpbiBsb2NhbFxuICogc3RvcmFnZS5cbiAqL1xuXG5pbXBvcnQgeyBNYXAgfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtbWFwXCI7XG5pbXBvcnQgeyBOb25lLCBPcHRpb24gfSBmcm9tIFwiQHNpdGVpbXByb3ZlL2FsZmEtb3B0aW9uXCI7XG5pbXBvcnQgYnJvd3NlciBmcm9tIFwid2ViZXh0ZW5zaW9uLXBvbHlmaWxsXCI7XG5cbi8qKlxuICogU3RvcmFnZSBrZXlzXG4gKi9cbmNvbnN0IFBPUFVQX0tFWSA9IFwicG9wdXBzTWFwXCI7XG5cbi8qKlxuICogTWFwIGZyb20gdGFiSWQgdG8gb3BlbiBwb3B1cC5cbiAqXG4gKiBAcmVtYXJrc1xuICogRXZlcnkgbGlzdGVuZXIgd2lsbCByZWxvYWQgdGhlIHBvcHVwcyBtYXAsIHRvIG1ha2Ugc3VyZSBpdCBpcyB1cC10by1kYXRlLlxuICogTGlzdGVuZXJzIHRoYXQgdXBkYXRlIGl0IGFsc28gc2F2ZSBpdC5cbiAqIFdoZW4gY2xpY2tpbmcgdGhlIGV4dGVuc2lvbiBidXR0b24sIHdlIGFsc28gdGFrZSB0aW1lIHRvIGNsZWFuIGl0LCBpbiBjYXNlXG4gKiBhbnl0aGluZyBiYWQgaGFwcGVuZWQgYXQgc29tZSBwb2ludC5cbiAqL1xuXG5sZXQgbXlQb3B1cHMgPSBNYXAuZW1wdHkoKTtcbmFzeW5jIGZ1bmN0aW9uIGxvYWRQb3B1cHNNYXAoKSB7XG4gIGNvbnN0IHBvcHVwcyA9IGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5nZXQoUE9QVVBfS0VZKTtcbiAgbXlQb3B1cHMgPSBNYXAuZnJvbShwb3B1cHM/LltQT1BVUF9LRVldID8/IFtdKTtcbn1cbmFzeW5jIGZ1bmN0aW9uIHNhdmVQb3B1cHNNYXAoKSB7XG4gIGF3YWl0IGJyb3dzZXIuc3RvcmFnZS5sb2NhbC5zZXQoe1xuICAgIFtQT1BVUF9LRVldOiBteVBvcHVwcy50b0FycmF5KClcbiAgfSk7XG59XG5hc3luYyBmdW5jdGlvbiB3aW5kb3dFeGlzdHMod2luZG93SWQpIHtcbiAgaWYgKHdpbmRvd0lkID09PSB1bmRlZmluZWQpIHtcbiAgICByZXR1cm4gZmFsc2U7XG4gIH1cbiAgdHJ5IHtcbiAgICBhd2FpdCBicm93c2VyLndpbmRvd3MuZ2V0KHdpbmRvd0lkKTtcbiAgICByZXR1cm4gdHJ1ZTtcbiAgfSBjYXRjaCAoZSkge1xuICAgIC8vIFdlIGFzc3VtZSBlcnJvcnMgbW9zdGx5IG9jY3VyIGR1ZSB0byBub24tZXhpc3RlbnQgd2luZG93LlxuICAgIHJldHVybiBmYWxzZTtcbiAgfVxufVxuXG4vKipcbiAqIFJlbW92ZSBlbnRyaWVzIHdpdGggbm8gY29ycmVzcG9uZGluZyBvcGVuZWQgd2luZG93XG4gKlxuICogQHJlbWFya3NcbiAqIFRoaXMgc2hvdWxkIG5vdCBoYXBwZW4gc2luY2UgdGhlIHNlcnZpY2Ugd29ya2VyIHNob3VsZCByZXN0YXJ0IGFuZCBjbGVhblxuICogdGhlIG1hcCBvbiB3aW5kb3cgcmVtb3ZlZC4gVGhpcyBpcyBob3dldmVyIG5vdCBleHBlbnNpdmUgYmVjYXVzZSB3ZSBhc3N1bWVcbiAqIHRoZSBtYXAgd2lsbCBiZSBzbWFsbDsgYW5kIHRoaXMgcHJldmVudHMgYSBwb3NzaWJsZSB2ZWN0b3Igb2YgbWVtb3J5IGxlYWtcbiAqIHNpbmNlIHRoaXMgaXMgcGVyc2lzdGVudCBzdG9yYWdlIGFuZCB3ZSBoYXZlIHJlcXVlc3RlZCB1bmxpbWl0ZWQgc3RvcmFnZVxuICogcGVybWlzc2lvbi5cbiAqL1xuYXN5bmMgZnVuY3Rpb24gY2xlYW5Qb3B1cHNNYXAoKSB7XG4gIGxldCBleGlzdGluZyA9IE1hcC5lbXB0eSgpO1xuICBmb3IgKGNvbnN0IFt0YWJJZCwgcG9wdXBdIG9mIG15UG9wdXBzKSB7XG4gICAgaWYgKGF3YWl0IHdpbmRvd0V4aXN0cyhwb3B1cC53aW5kb3dJZCkpIHtcbiAgICAgIGV4aXN0aW5nID0gZXhpc3Rpbmcuc2V0KHRhYklkLCBwb3B1cCk7XG4gICAgfVxuICB9XG4gIG15UG9wdXBzID0gZXhpc3Rpbmc7XG59XG5cbi8qKlxuICogQ2xlYW51cCBwb3B1cC1tYXAgd2hlbiBhIHBvcHVwIHdpbmRvdyBpcyBjbG9zZWQuXG4gKlxuICogQHJlbWFya3NcbiAqIFRoaXMgaXMgdHJpZ2dlcmVkIGJ5IHRoZSBvdGhlciBsaXN0ZW5lcnMgY2xvc2luZyBwb3B1cCB3aW5kb3dzLlxuICovXG5icm93c2VyLndpbmRvd3Mub25SZW1vdmVkLmFkZExpc3RlbmVyKGFzeW5jIHdpbmRvd0lkID0+IHtcbiAgYXdhaXQgbG9hZFBvcHVwc01hcCgpO1xuICBsZXQga2V5ID0gTm9uZTtcbiAgbXlQb3B1cHMuZmluZCgocG9wdXAsIHRhYklkKSA9PiB7XG4gICAgaWYgKHBvcHVwLndpbmRvd0lkID09PSB3aW5kb3dJZCkge1xuICAgICAga2V5ID0gT3B0aW9uLm9mKHRhYklkKTtcbiAgICAgIHJldHVybiB0cnVlO1xuICAgIH1cbiAgICByZXR1cm4gZmFsc2U7XG4gIH0pO1xuICBrZXkuZm9yRWFjaChrZXkgPT4gbXlQb3B1cHMgPSBteVBvcHVwcy5kZWxldGUoa2V5KSk7XG4gIGF3YWl0IHNhdmVQb3B1cHNNYXAoKTtcbn0pO1xuXG4vKipcbiAqIENsb3NlIHBvcHVwIGlmIHVzZXIgbmF2aWdhdGUgdG8gYW5vdGhlciBwYWdlLlxuICovXG5icm93c2VyLnRhYnMub25VcGRhdGVkLmFkZExpc3RlbmVyKGFzeW5jIHRhYklkID0+IHtcbiAgYXdhaXQgbG9hZFBvcHVwc01hcCgpO1xuICBjb25zdCBjdXJyZW50UG9wdXAgPSBteVBvcHVwcy5nZXQodGFiSWQpLmdldE9yKHVuZGVmaW5lZCk7XG4gIGlmIChjdXJyZW50UG9wdXA/LndpbmRvd0lkKSB7XG4gICAgLy8gQ2xvc2UgdGhlIHBvcHVwIGlmIHRoZSB1cmwgY2hhbmdlc1xuICAgIGNvbnN0IHRhYiA9IGF3YWl0IGJyb3dzZXIudGFicy5nZXQodGFiSWQpO1xuICAgIGlmIChjdXJyZW50UG9wdXA/LnVybCAhPT0gdGFiLnVybCAmJiBuYXZpZ2F0b3IudXNlckFnZW50LmluZGV4T2YoXCJGaXJlZm94XCIpID09PSAtMSkge1xuICAgICAgYXdhaXQgYnJvd3Nlci53aW5kb3dzLnJlbW92ZShjdXJyZW50UG9wdXAud2luZG93SWQpO1xuICAgIH1cbiAgfVxufSk7XG5cbi8qKlxuICogQ2xvc2UgcG9wdXAgaWYgdGhlIGF1ZGl0ZWQgdGFiIGlzIGNsb3NlZC5cbiAqL1xuYnJvd3Nlci50YWJzLm9uUmVtb3ZlZC5hZGRMaXN0ZW5lcihhc3luYyB0YWJJZCA9PiB7XG4gIGF3YWl0IGxvYWRQb3B1cHNNYXAoKTtcbiAgY29uc3QgY3VycmVudFBvcHVwID0gbXlQb3B1cHMuZ2V0KHRhYklkKS5nZXRPcih1bmRlZmluZWQpO1xuICBpZiAoY3VycmVudFBvcHVwPy53aW5kb3dJZCkge1xuICAgIC8vIENsb3NlIHRoZSBwb3B1cCBpZiB0aGUgdGFiIGlzIGNsb3NlZFxuICAgIGF3YWl0IGJyb3dzZXIud2luZG93cy5yZW1vdmUoY3VycmVudFBvcHVwLndpbmRvd0lkKTtcbiAgfVxufSk7XG5cbi8qKlxuICogT3BlbiBwb3B1cCB3aGVuIGljb24gaXMgY2xpY2tlZC5cbiAqIElmIHRoZSBwb3B1cCBpcyBvcGVuLCBjbG9zZSBpdC5cbiAqL1xuYnJvd3Nlci5hY3Rpb24ub25DbGlja2VkLmFkZExpc3RlbmVyKGFzeW5jIHRhYiA9PiB7XG4gIC8vIEJhaWwgb3V0IGltbWVkaWF0ZWx5IGlmIHdlIGNhbm5vdCBnZXQgYSB0YWJJZFxuICBpZiAoIXRhYi5pZCkge1xuICAgIHJldHVybjtcbiAgfVxuICBhd2FpdCBsb2FkUG9wdXBzTWFwKCk7XG4gIGF3YWl0IGNsZWFuUG9wdXBzTWFwKCk7XG5cbiAgLy8gSWYgdGhlIGN1cnJlbnQgdGFiIGFscmVhZHkgaGFzIGFuIGV4dGVuc2lvbiBwb3B1cCwgY2xvc2UgdGhlIHBvcHVwLlxuICBjb25zdCBjdXJyZW50UG9wdXAgPSBteVBvcHVwcy5nZXQodGFiLmlkKS5nZXRPcih1bmRlZmluZWQpO1xuICBpZiAoY3VycmVudFBvcHVwPy53aW5kb3dJZCkge1xuICAgIGF3YWl0IGJyb3dzZXIud2luZG93cy5yZW1vdmUoY3VycmVudFBvcHVwLndpbmRvd0lkKTtcbiAgICByZXR1cm47XG4gIH1cblxuICAvLyBPdGhlcndpc2UsIG9wZW4gYSBuZXcgcG9wdXAuXG4gIGNvbnN0IHBvcHVwVXJsID0gbmV3IFVSTChicm93c2VyLnJ1bnRpbWUuZ2V0VVJMKFwiYXBwLmh0bWxcIikpO1xuXG4gIC8qKlxuICAgKiBQYXNzIGFsb25nIHRoZSB0YWIgSUQgYXMgYSBxdWVyeSBwYXJhbWV0ZXIuIFRoZSBhcHBsaWNhdGlvbiBjb2RlIHVzZXMgdGhpc1xuICAgKiB3aGVuIG1ha2luZyBBUEkgY2FsbHMuXG4gICAqL1xuICBwb3B1cFVybC5zZWFyY2hQYXJhbXMuc2V0KFwidGFiSWRcIiwgdGFiLmlkPy50b1N0cmluZygxMCkgfHwgXCJcIik7XG4gIGNvbnN0IHBvcHVwID0gYXdhaXQgYnJvd3Nlci53aW5kb3dzLmNyZWF0ZSh7XG4gICAgdXJsOiBwb3B1cFVybC50b1N0cmluZygpLFxuICAgIHR5cGU6IFwicGFuZWxcIixcbiAgICBoZWlnaHQ6IDYwMCxcbiAgICB3aWR0aDogODAwXG4gIH0pO1xuICBteVBvcHVwcyA9IG15UG9wdXBzLnNldCh0YWIuaWQsIHtcbiAgICB3aW5kb3dJZDogcG9wdXAuaWQsXG4gICAgdXJsOiB0YWIudXJsXG4gIH0pO1xuICBhd2FpdCBzYXZlUG9wdXBzTWFwKCk7XG59KTsiXSwibmFtZXMiOltdLCJzb3VyY2VSb290IjoiIn0=