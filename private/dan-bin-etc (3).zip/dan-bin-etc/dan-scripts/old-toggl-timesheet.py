#!/usr/bin/env python2

import sys, csv, itertools, collections, math, time, os, subprocess, re, datetime, argparse

'''














This is from my MDI days.  
It's main value seems to be rounding off to 30-minute blocks - something I don't do any more.
And it seems to be based around toggl "projects" - something I don't use any more.  (I use tags). 
- Dan Tripp, sep 2023. 



























'''

# Known bug:
# (It's unclear if this is a bug or a feature.) 
# If you use the '--include-non-billable-entries' option, sometimes you might see /less/ time claimed for a project 
# than when you didn't use that option.  i.e. you might see a billable time block appearing in the normal output and not 
# appearing in the '--include-non-billable-entries' output.  Or appearing for less time in the latter.  
# This might surprise you, because one might think that the 
# '--include-non-billable-entries' option wouldn't affect this _billable_ entry.  
# The cause: there is a non-billable entry then a billable entry in the same 30-min block.  
# And they have different projects.  The first non-billable entry will appear somewhere in else in the output 
# with '--include-non-billable-entries'.  It will appear somewhere you're not looking.  It's presence 
# made the second (billable) entry get removed, under our rules that are meant to prevent us from double billing 
# for the same real-world minute.  

# Reasons why this program implements the "--output-csv-*" options, instead of doing this in Toggl or Excel:
# - The toggl website doesn't allow selecting more than one year when showing charts  
# - I couldn't figure out how to import Toggl output directly into Excel.  In particular, how to group by month, and how to get Excel to recognize a time duration in HH:MM:SS format. 

if os.sep != '/':
	sys.exit('This script is meant to be run under Cygwin, with Cygwin python.')

MINIMUM_NUM_MINUTES = 1.0

NON_BILLABLE_TAG = 'Non-billable'
KNOWN_TAGS = set([NON_BILLABLE_TAG])
IMPLICIT_TAGS_CLIENT_TO_TAG_LIST = {
	'Education': [NON_BILLABLE_TAG], 
	'Admin': [NON_BILLABLE_TAG], 
}

def get_input_filenames(input_file_args_):
	if len(input_file_args_) == 0:
		filenames = [f for f in os.listdir('.') if (f.startswith('Toggl_time_entries_') or f.startswith('Toggl_Track_detailed_report_') \
				or f.startswith('Toggl_Track_summary_report_')) and f.endswith('.csv')]
		if not filenames:
			raise Exception('Found no candidate CSV files in current directory.')
		elif len(filenames) == 1:
			r = filenames[0]
		else:
			r = sorted(filenames, key=lambda f: os.path.getmtime(f), reverse=True)[0]
			if r.startswith('Toggl_Track_summary_report_'):
				raise Exception('Found file "%s".  This is the wrong type of file.  It\'s a summary report.  Use a detailed report instead.' \
						% r)
		print 'Using "%s" as input file (modified %s ago).' % (r, get_file_mtime_ago_str(r))
		return [r]
	else:
		return input_file_args_

def discover_user_name():
	global user_name
	user_name_filename = os.path.join('~/.%s' % os.path.basename(sys.argv[0]).split('.')[0], 'user_name')
	user_name_filename = os.path.expanduser(user_name_filename)
	if os.path.exists(user_name_filename):
		with open(user_name_filename) as fin:
			user_name =	fin.read().strip()
	else:
		print 'Enter your name:'
		user_name = raw_input('> ')
		os.makedirs(os.path.dirname(user_name_filename))
		with open(user_name_filename, 'w') as fout:
			print >> fout, user_name

def get_file_mtime_ago_str(f_):
	secs = time.time() - os.path.getmtime(f_)
	if secs < 120:
		r = '%d seconds' % int(secs)
	elif secs < 120*60:
		r = '%d minutes' % int(secs/60.0)
	elif secs < 48*60*60:
		r = '%d hours' % int(secs/(60.0*60))
	else:
		r = '%d days' % int(secs/(24*60.0*60))
	return r

name_of_this_program = os.path.basename(sys.argv[0])

argparser = argparse.ArgumentParser(formatter_class=argparse.RawDescriptionHelpFormatter, 
description='''\
This program takes a CSV file (which is a timesheet) from toggl.com as input, 
and produces output according to one of the following two output modes: 

1) An easy-to-read text file with time entries grouped by project.  This file is 
typically used to submit monthly timesheets for billing purposes.  This is the 
default output mode.

2) A .CSV file containing monthly tallies of hours, suitable for importing into 
a spreadsheet program and making a graphical chart from.  This output mode is 
typically used to see long-term trends.  This is actually two modes: use 
"--output-csv-montly" or "--output-csv-yearly" to choose between them.
''', epilog='''\
Examples: 

To output an easy-to-read text file, using as input the most recent .csv file in 
the current directory which looks like an output file from Toggl:

	{0}

To output an easy-to-read text file, using input1.csv and input2.csv as input:

	{0} input1.csv input2.csv

To output a monthly CSV file, suitable for importing into a spreadsheet 
program, from input1.csv:

	{0} --output-csv-monthly input1.csv

'''.format(name_of_this_program))

argparser.add_argument('--help-setup', action='store_true', 
	help='Print a detailed help message regarding setup.')
argparser.add_argument('--hours-per-day', type=int, default=0, help='Print number of days for each project, using this '\
	+'number of hours per day.  If you omit this argument, the number of days won\'t be printed.')
argparser.add_argument('--8', action='store_true', default=False, 
	help='Use an 8-hour day.')
argparser.add_argument('--tolerate-blank-project', action='store_true', default=False, 
	help='Tolerate blank project fields (AKA Project, in Toggl) in the input.  \
By default blank project fields are considered a fatal error.')
argparser.add_argument('--include-details', action='store_true', default=False, 
	help='Normally this program removes everything in a description after "details>".  This option suppresses that behaviour.')
argparser.add_argument('--include-non-billable-entries', action='store_true', default=False, 
	help='Don\'t ignore entries in the input that are marked non-billable.')
argparser.add_argument('--output-csv-monthly', action='store_true', default=False, 
	help='Output a .CSV file containing monthly tallies of hours, suitable for \
importing into a spreadsheet program and making a graphical chart from.')
argparser.add_argument('--output-csv-yearly', action='store_true', default=False, 
	help='Similar to "--output-csv-monthly", but tallies yearly instead of monthly.')
argparser.add_argument('--round-up', action='store_true', default=False, 
	help='Round each time entry up to the nearest multiple of 30 minutes.')
argparser.add_argument('input_file', nargs='*', help='.csv file(s) from toggl to use as input.')
args = argparser.parse_args()

if args.output_csv_monthly and args.output_csv_yearly:
	raise Exception('Error in arguments.  Can\'t output both a monthly and a yearly CSV file.')

help_setup_msg='''\
Setting up toggl to use with this program:  
- Create a free account on toggl.com.
- Click on the "Timer" tab (or rather: link on the left of 
https://toggl.com/app/timer)
- Set up a "Project/task" (with the "+" button_) in toggl for each project.  
- Press the green "Play" button, then press stop.
- Enter some text in the description field AKA the "What are you working on?" 
field.  This should describe what you did for the project.
- If you leave the Project/Task field or the Description field blank, this 
program will fail.
- Advanced usage: if you want this program to ignore a timesheet entry, 
you can tag it as "non-billable" in toggl.  To do that: 
  - Click on "Tags" on the left 
  - Add a new tag called "Non-billable" (without quotes) 
  - Click on Timer on the left and find the entry you made above 
  - When you hover the mouse over your entry, you will see a tag icon appear.  
  Click it and select the "Non-billable" tag.  Then click anywhere else to 
  make the tag popup disappear.
- Best practice: once you create a toggl "project" and log time 
under it, be careful if you ever delete or rename that project.  It is safest 
to avoid deleting / renaming.  This is because after the delete/rename, toggl 
will output a CSV with your old logged time lines having a blank project.  
This script will fail when it sees those lines. 
If you must rename a project from X to Y then one way to deal 
with this is to 1) create a new project with name Y, 2) go back through all 
of your logged time and reassign each entry under X to Y, and 3) then delete 
the project X.
If you must delete a project, consider renaming it to "Client X (archive)" 
instead.

Instructions for getting an appropriate CSV file out of Toggl (the kind of 
file which will serve as input to this program):
- Go to https://toggl.com/app/timer
- Click on "Reports" on the left
- Click on "Detailed" at the top.
- In about the third row of GUI controls from the top, you will see a button 
that lets you select a time range.  It might say "This Week" or something 
similar, by default.  Click it and select "Last Month", or whatever time 
range you want.
- Near the top-right there will be a typical-looking "download" icon.  Click 
it, then choose "Download CSV".
'''

if args.help_setup:
	print help_setup_msg 
	sys.exit(0)

input_filenames = get_input_filenames(args.input_file)

discover_user_name()

def parse_date(s_):
	return time.strptime(s_, '%Y-%m-%d')

# Ignores time zone.  This doesn't matter because this program only uses 
# /differences/ between the "seconds since the epoch" values returned by this 
# function.
def epoch_seconds_from_datetime(datetime_):
	# Thanks to https://stackoverflow.com/a/11743262 
	return (datetime_ - datetime.datetime(1970,1,1)).total_seconds()

def fdiv(x_, y_):
	return int(math.floor(x_/y_))

def round_down(x_, step_, ref_=0):
	assert type(x_) in (int, long, float)
	x = x_ - ref_
	if type(x) in (int, long):
		r = (long(x)/step_)*step_
		if type(x) is int:
			r = int(r)
	else:
		r = fdiv(x, step_)*step_
	r += ref_
	return r

def round_up(x_, step_, ref_=0):
	r = round_down(x_, step_, ref_)
	if isinstance(x_, float):
		return r if abs(r - x_) < 0.00001 else r+step_
	else:
		return r if r == x_ else r+step_

def round_up_to_nearest_30_minutes(end_time_epoch_seconds_to_round_up_, reference_start_epoch_seconds_time_):
	return round_up(end_time_epoch_seconds_to_round_up_, 60*30, reference_start_epoch_seconds_time_)

def uniq(seq_):
	first_elem = True
	prev_val = None
	r = []
	for e in seq_:
		if first_elem or (e != prev_val):
			r.append(e)
		prev_val = e
		first_elem = False
	return r

def get_tags_set_from_csv_str(str_):
	tags = set(e.strip() for e in row[12].split(','))
	tags.discard('')
	for tag in tags:
		if tag not in KNOWN_TAGS:
			raise Exception('Tag "%s" is unknown to this program.  We know the tags %s.' % (tag, KNOWN_TAGS))
	return tags

time_entries = []
all_dates = set()

file_contains_data = False

for input_filename in input_filenames:
	with open(input_filename) as fin:
		reader = csv.reader(fin)
		for linenum, row in enumerate(reader):
			try:
				if len(row) == 0:
					continue
				if row[1:6] == 'Email,Client,Project,Task,Description'.split(','):
					# header row.  skipping field 0 b/c it contains byte order mark.  (lazy.) 
					continue
				linenum += 2
				if len(row) < 13:
					raise Exception("Not enough rows in input file line %d.  Sometimes this happens because the input file is "\
							"a regular report from Toggl - not a 'Detailed Report'." % (linenum))
				file_contains_data = True
				project = row[3]
				desc = row[5]
				start_date = row[7]
				start_time = row[8]
				end_date = row[9]
				end_time = row[10]
				start_datetime = datetime.datetime.strptime('%s %s' % (start_date, start_time), '%Y-%m-%d %H:%M:%S')
				end_datetime = datetime.datetime.strptime('%s %s' % (end_date, end_time), '%Y-%m-%d %H:%M:%S')
				start_epoch_seconds = epoch_seconds_from_datetime(start_datetime)
				end_epoch_seconds = epoch_seconds_from_datetime(end_datetime)
				tags = get_tags_set_from_csv_str(row[12])
				if project in IMPLICIT_TAGS_CLIENT_TO_TAG_LIST:
					tags = tags.union(IMPLICIT_TAGS_CLIENT_TO_TAG_LIST[project])
				non_billable = NON_BILLABLE_TAG in tags
				if non_billable and not args.include_non_billable_entries:
					print 'Omitting non-billable entry: %s start time %s: %s / %s' % (start_date, start_time, project, desc)
				else:
					if not desc:
						raise Exception('Description field is blank.  (Date %s, start time %s)' \
								% (start_date, start_time))
					if start_epoch_seconds >= end_epoch_seconds:
						raise Exception('Not enough seconds.  (Date %s, start time %s, %s / %s)' \
								% (start_date, start_time, project, desc))
					if not args.include_details:
						desc = desc.split('details>', 1)[0].lstrip()
					time_entries.append({'project': project, 'descriptions': [desc], 'start_date': start_date, 
							'start_time': start_time, 'start_epoch_seconds': start_epoch_seconds, 
							'end_epoch_seconds': end_epoch_seconds, 'tags': tags})
					all_dates.add(parse_date(start_date))
			except:
				print >> sys.stderr, 'Failed on line %d' % linenum
				raise

def get_num_minutes_from_time_entry(time_entry_):
	seconds = time_entry_['end_epoch_seconds'] - time_entry_['start_epoch_seconds']
	assert seconds > 0
	r = seconds/60
	return r

def round_up_num_minutes(n_):
	return int(math.ceil(n_ / 30.0) * 30)

def get_hours_from_minutes(m_):
	return m_/60.0

def get_months_str(all_dates_):
	month_numstr_to_englishstr = {}
	for d in all_dates_:
		numstr = time.strftime('%Y-%m', d)
		englishstr = time.strftime('%B %Y', d)
		month_numstr_to_englishstr[numstr] = englishstr
	english_months = [month_numstr_to_englishstr[k] for k in sorted(month_numstr_to_englishstr.keys())]
	assert len(english_months) > 0
	if len(english_months) == 1:
		r = english_months[0]
	else:
		r = '%s through %s' % (english_months[0], english_months[-1])
	return r

def get_output_filename(input_filenames_, months_str_, output_csv_monthly_, output_csv_yearly_):
	if output_csv_monthly_:
		filename_template = 'Timesheet monthly tallies for %s - %s%%s.csv' % (user_name, months_str_)
	elif output_csv_yearly_:
		filename_template = 'Timesheet yearly tallies for %s - %s%%s.csv' % (user_name, months_str_)
	else:
		filename_template = 'Timesheet for %s - %s%%s.txt' % (user_name, months_str_)
	for unique_part in [''] + [' (%d)' % i for i in xrange(1, 99999)]:
		filename = filename_template % unique_part
		r = os.path.abspath(os.path.join(os.path.dirname(input_filenames_[0]), filename))
		if not os.path.exists(r):
			return r
	else:
		raise Exception()

def is_num_minutes_above_minimum(mins_):
	return mins_ >= MINIMUM_NUM_MINUTES

def get_windows_output_filename(f_):
	try:
		return subprocess.Popen(['cygpath', '-wa', f_], stdout=subprocess.PIPE).communicate()[0].strip()
	except:
		return None

def set_clipboard(s_):
	subprocess.Popen(["clip.exe"], stdin=subprocess.PIPE).communicate(s_)

if not file_contains_data:
	print 'File contains no data.'
	sys.exit(0)
elif len(all_dates) == 0:
	print 'File contains data, but we omitted all of it.'
	sys.exit(0)

months_str = get_months_str(all_dates)

output_filename = get_output_filename(input_filenames, months_str, args.output_csv_monthly, args.output_csv_yearly)
windows_output_filename = get_windows_output_filename(output_filename)

# The input is probably already sorted.  Here we sort it anyway.
time_entries.sort(key=lambda time_entry: time_entry['start_epoch_seconds'])

# Here we implement some of our rules for rounding up to 30-minute blocks of 
# time.  This is the complicated part where we take care not to count the 
# same minute twice.  (This assumes that some of these projects will correspond 
# to clients, and some of these time entries for clients will be billable - so 
# if we count the same minute twice, someone might notice.)  
# Example: if entry 1 is from 12:10 to 12:12 and entry 2 is 
# from 12:20 to 12:22, without this code, we would round entry 1 up to 30 
# minutes and entry 2 up to 30 minutes, treating them separately.  So we would 
# bill twice for the minutes from 12:20 to 12:40.  This code looks at entry 2, 
# sees that it starts before the rounded-up entry 1 ends (at 12:10 + 30 minutes 
# = 12:40) and coalesces entry 2 into entry 1, resulting in one entry from 
# 12:10 to 12:22, which we later round up to 30 minutes.
# That's if entry 1 and 2 are for the same project.  If they're for different 
# projects, then we move the start time of entry 2 ahead so that it doesn't 
# overlap with the rounded-up end time of entry 1.  So the project of entry 2 
# might get a partial rebate, or a full rebate if the real end time of entry 2 
# is before the rounded-up end time of entry 1.

i = 0
while i < len(time_entries)-1:
	ent1 = time_entries[i]; ent2 = time_entries[i+1]
	try:
		assert ent1['start_epoch_seconds'] < ent2['start_epoch_seconds']
		assert ent1['end_epoch_seconds'] <= ent2['start_epoch_seconds']
		if args.round_up:
			rounded_up_ent1_end_epoch_seconds = \
					round_up_to_nearest_30_minutes(ent1['end_epoch_seconds'], ent1['start_epoch_seconds'])
		else:
			rounded_up_ent1_end_epoch_seconds = ent1['end_epoch_seconds']
		if ent2['start_epoch_seconds'] < rounded_up_ent1_end_epoch_seconds:
			if ent2['project'] == ent1['project'] and ent2['tags'] == ent1['tags']:
				print 'Coalescing entry due to overlap with previous 30-minute block: %s start time %s: %s / %s' \
					% (ent2['start_date'], ent2['start_time'], ent2['project'], ent2['descriptions'][0])
				ent1['end_epoch_seconds'] = ent2['end_epoch_seconds']
				ent1['descriptions'] += ent2['descriptions']
				del time_entries[i+1]
				i -= 1
			else:
				if ent2['end_epoch_seconds'] >= rounded_up_ent1_end_epoch_seconds:
					print 'Moving start time ahead due to overlap with previous 30-minute block: %s start time %s: %s / %s' \
						% (ent2['start_date'], ent2['start_time'], ent2['project'], ent2['descriptions'][0])
					ent2['start_epoch_seconds'] = rounded_up_ent1_end_epoch_seconds
				else:
					print 'Omitting entry due to overlap with previous 30-minute block: %s start time %s: %s / %s' \
						% (ent2['start_date'], ent2['start_time'], ent2['project'], ent2['descriptions'][0])
					del time_entries[i+1]
					i -= 1
		i += 1
	except:
		print >> sys.stderr, 'Exception while processing these two entries:'
		print >> sys.stderr, ent1
		print >> sys.stderr, ent2
		raise

i = 0
while i < len(time_entries):
	time_entry = time_entries[i]
	num_minutes = get_num_minutes_from_time_entry(time_entry)
	if not is_num_minutes_above_minimum(num_minutes):
		print 'Omitting entry because it is below the minimum time: %s start time %s: %s / %s' % \
				(time_entry['start_date'], time_entry['start_time'], time_entry['project'], time_entry['descriptions'])
		del time_entries[i]
		i -= 1
	else:
		num_minutes = get_num_minutes_from_time_entry(time_entry)
		if args.round_up:
			rounded_num_minutes = round_up_num_minutes(num_minutes)
		else:
			rounded_num_minutes = num_minutes
		time_entry['num_hours'] = get_hours_from_minutes(rounded_num_minutes)
	i+=1

if args.output_csv_monthly or args.output_csv_yearly:
	assert not (args.output_csv_monthly and args.output_csv_yearly)
	date_str_end_idx = 7 if args.output_csv_monthly else 4
	date_str_to_num_hours = collections.defaultdict(int)
	for time_entry in time_entries:
		date_str = time_entry['start_date'][:date_str_end_idx]
		date_str_to_num_hours[date_str] += time_entry['num_hours']
	with open(output_filename, 'wt') as fout:
		for date_str in sorted(date_str_to_num_hours.keys()):
			num_hours = date_str_to_num_hours[date_str]
			print >> fout, '%s,%s' % (date_str, num_hours)
else:
	project_to_time_entries = collections.defaultdict(list)
	for time_entry in time_entries:
		project_to_time_entries[time_entry['project']].append(time_entry)

	with open(output_filename, 'wt') as fout:
		print >> fout
		print >> fout, 'Timesheet for %s - %s' % (user_name, months_str)
		print >> fout
		print >> fout

		project_to_hours_total = {}
		tag_to_hours = {tag: 0 for tag in KNOWN_TAGS}
		for project in sorted(project_to_time_entries.keys()):
			time_entries = project_to_time_entries[project]
			print >> fout
			print >> fout,  '- Project: "%s" -' % (project)
			print >> fout
			print >> fout,  'Date          Hours     Description'
			print >> fout,  '----          -----     -----------'
			hours_total = 0
			for time_entry in time_entries:
				descriptions = ', '.join(uniq(time_entry['descriptions']))
				tags = time_entry['tags']
				tags_to_print = tags.copy()
				tags_str = '[%s]' % ', '.join(sorted(tags_to_print)) if tags_to_print else ''
				print >> fout,  '%s     %2.2f     %s  %s' % (time_entry['start_date'], time_entry['num_hours'], descriptions, tags_str)
				hours_total += time_entry['num_hours']
				for tag in tags:
					tag_to_hours[tag] += time_entry['num_hours']
			project_to_hours_total[project] = hours_total
			print >> fout,  '              -----'
			print >> fout,  '             = %.2f hours for project "%s"' % (hours_total, project)
			if args.hours_per_day != 0:
				days_total = hours_total / args.hours_per_day
				print >> fout,  '             = %.2f days (where 1 day = %.2f hours)' % (days_total, args.hours_per_day)
			print >> fout
			print >> fout

		hours_total_all_projects = sum(project_to_hours_total.values())
		projects = project_to_hours_total.keys()
		projects_sorted_by_hours = sorted(projects, key=lambda project: project_to_hours_total[project], reverse=True)
		print >> fout
		print >> fout
		print >> fout, '- Statistics by project -'
		print >> fout
		print >> fout
		project_max_str_len = max(len(project) for project in projects)
		for project in projects_sorted_by_hours:
			hours = project_to_hours_total[project]
			print >> fout, ('"%-'+str(project_max_str_len+1)+'s": %7.2f') % (project, hours)
		print >> fout, 'Total hours for all projects: %.2f' % hours_total_all_projects
		print >> fout
		print >> fout

		if args.include_non_billable_entries:
			print >> fout
			print >> fout
			print >> fout, '- Statistics by tag -'
			print >> fout
			for tag in sorted(tag_to_hours.keys()):
				hours = tag_to_hours[tag]
				print >> fout, '%s: %.2f hours.' % (tag, hours)
			
		print >> fout
		print >> fout

print 'Wrote output timesheet to "%s"' % (output_filename)
if windows_output_filename:
	print '(AKA "%s")' % (windows_output_filename)

filename_for_clipboard = windows_output_filename or output_filename
print 'Copying the filename "%s" to the clipboard.' % filename_for_clipboard
set_clipboard(filename_for_clipboard)


