#!/usr/bin/env python3

# Appropriated from https://stackoverflow.com/a/16310739 

import os
import sys

num_chars = int(sys.argv[1])

chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ+/'
tbl = bytes.maketrans(bytearray(range(256)),
                      bytearray([ord(chars[b % len(chars)]) for b in range(256)]))
sys.stdout.buffer.write(os.urandom(num_chars).translate(tbl))

