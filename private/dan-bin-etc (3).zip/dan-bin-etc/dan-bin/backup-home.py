#!/usr/bin/env python2
import sys, os, os.path, tarfile
if len(sys.argv) not in (2, 3) or (sys.argv[1] not in ('small', 'large')) or (len(sys.argv) == 3 and sys.argv[2] != 'dryrun'):
	print >> sys.stderr, 'Usage:', os.path.basename(sys.argv[0]), 'small|large [dryrun]'
	sys.exit(1)
small_backup = (sys.argv[1] == 'small')
dryrun = (len(sys.argv) == 3)
root_dir = os.path.expanduser('~')
files_to_backup = []
for dirpath, dirnames, filenames in os.walk(root_dir):
	if 'DT_DONTBACKUP' in filenames:
		del dirnames[:]
	elif small_backup and ('DT_BACKUPLEVEL2' in filenames): 
		del dirnames[:]
	else:
		for file in filenames:
			files_to_backup.append(os.path.join(dirpath, file))
if dryrun:
	totalbytes = 0
	for file in files_to_backup:
		totalbytes += os.stat(file).st_size
	print 'Total (uncompressed): %i bytes in %i files.' % (totalbytes, len(files_to_backup))
else:
	tarrfile = tarfile.open('/tmp/work-home-dir-backup-%s.tar.gz' % ('small' if small_backup else 'large'), 'w:gz')
	for file in files_to_backup:
		tarrfile.add(file)
	tarrfile.close()

