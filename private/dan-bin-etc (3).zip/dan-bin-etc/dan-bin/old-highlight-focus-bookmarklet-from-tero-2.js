javascript: var FocusIndicatorBookmarklet;
! function(e) {
    let o;
    ! function(e) {
        e.Diff = "d", e.ClearDiff = "c", e.Autolog = "a", e.LogFormat = "f", e.LogFocused = "l", e.Indicator = "i", e.Style = "s", e.Help = "h", e.Mode = "q", e.Modifier = "ctrlKey"
    }(o || (o = {}));
    const t = [
            ["outline-style", "solid"],
            ["outline-width", "2px"],
            ["z-index", "100"]
        ],
        n = [
            ["outline-offset", "2px"],
            ["outline-color", "black"],
            ["box-shadow", "0 0 0 2px white"]
        ],
        s = [
            ["outline-offset", "-2px"],
            ["outline-color", "white"],
            ["box-shadow", "inset 0 0 0 4px black"]
        ];
    ! function() {
        const e = new Set(["id", "role", "tabindex"]);
        let l = (a = t, {
            createFocusCSSSelector: function(e, o) {
                return `.${o}:focus\n { ${(e=[...a,...e]).map((e=>`${e[0]}: ${e[1]};`)).join("\n")} }`
            }
        });
        var a;
        let c = function() {
                function e(e) {
                    if (e[o.Modifier] && e.key === o.Mode) return n = !n, void r.printStatus("Form mode: ", n);
                    if (n) return;
                    const t = e.target;
                    switch (e.key) {
                        case o.Help:
                            console.log("Hot keys:\n---------"), console.log("Active when the document has focus."), console.log(`${o.Style}: Toggle between available focus indicator styles.`), console.log(`${o.Indicator}: Toggle focus indicator style on/off.`), console.log(`${o.LogFormat}: Toggle auto-logging format.`), console.log(`${o.Autolog}: Toggle auto-logging on/off.`), console.log(`${o.LogFocused}: Log the focused element's attributes as a list.`), console.log(`${o.Diff}: Save an element's diff snapshot. Reports the diff status if available.`), console.log(`${o.ClearDiff}: Clear all diff statuses.`), console.log(`CTRL + ${o.Mode}: Toggle form mode on/off.`);
                            break;
                        case o.LogFocused:
                            r.logAttributes(t);
                            break;
                        case o.Autolog:
                            r.toggleAutologStatus();
                            break;
                        case o.LogFormat:
                            r.toggleLogFormat();
                            break;
                        case o.Style:
                            c.toggleStyleName();
                            break;
                        case o.Indicator:
                            c.toggleIndicatorStyleOnOff();
                            break;
                        case o.ClearDiff:
                            i.clearDiffSnapshots();
                            break;
                        case o.Diff:
                            r.logDiff(t)
                    }
                }

                function t(e) {
                    const o = e.target;
                    i.setFocusStyle(o), r.autologElement(o)
                }
                let n = !1,
                    s = [],
                    a = 0;
                return {
                    addEventListeners: function() {
                        document.body.addEventListener("focus", t, !0), document.body.addEventListener("keydown", e, !0)
                    },
                    createFocusStyles: function(e, o) {
                        return e.map(((e, t) => {
                            let n = o.concat("-", (t + 1).toString());
                            return s.push(n),
                                function(e, o) {
                                    let t = document.createElement("style");
                                    return t.setAttribute("type", "text/css"), t.innerHTML = l.createFocusCSSSelector(e, o), t
                                }(e, n)
                        }))
                    },
                    insertStyleInDocument: function(e) {
                        let o = document.getElementsByTagName("head")[0];
                        return o ? !!e.every((e => o.appendChild(e))) || (console.log("Error: Cannot insert a style element into the <head> tag."), !1) : (console.log("Error: The page is missing a <head> tag --\x3e Not a web page?"), !1)
                    },
                    getActiveStyleName: function() {
                        return a >= 0 ? s[a] : void 0
                    },
                    getInactiveStyleNames: function() {
                        return a >= 0 ? s.filter(((e, o) => o !== a)) : s
                    },
                    toggleStyleName: function() {
                            a = a + 1 < s.length ? a + 1 : 0, r.printStatus("Focus style: ", `#${a+1}%60)},toggleIndicatorStyleOnOff:function(){a=a>=0?-1:0,r.printStatus("Focus style: ",a>=0)}}}(),i=function(){function e(e){const o=c.getActiveStyleName();e.classList.remove(o)}function o(o){let t=new Map,n=o.cloneNode();return e(n),[...n.attributes].forEach((e=>t.set(e.nodeName,e.value))),t}function t(e,t){t||(t=o(e)),n.set(e,t)}let n=new Map;return{setFocusStyle:function(e){const o=c.getActiveStyleName();c.getInactiveStyleNames().forEach((o=>e.classList.remove(o))),o&&e.classList.add(o)},unsetFocusStyle:e,getDiff:function(e,s=!1){const l=o(e),a=n.has(e)?new Map(n.get(e)):new Map;let c=new Set,i=new Set,r=new Map;return l.forEach(((e,o)=>{let t=a.get(o);void 0===t?c.add(o):t!==e&&r.set(o,[t,e]),a.delete(o)})),a.forEach(((e,o)=>i.add(o))),s&&t(e,l),{added:c,removed:i,updated:r}},hasDiffSnapshot:function(e){return n.has(e)},saveDiffSnapshot:t,clearDiffSnapshots:function(){n=new Map,console.log("Diff data cleared.")}}}(),r=function(e){const o=function(){const e=new Map;return e.set("object",(e=>console.log(e))),e.set("standard",(e=>Object.values(e).forEach((e=>console.log(e))))),function(o,t){e.get(t)(o)}}();function t(e,o){const t="boolean"==typeof o?o?"ON":"OFF":o;console.log(%60${e}${t}%60)}let n=!0,s="standard";return{printStatus:t,autologElement:function(t){if(!n)return;let l=[];e.forEach((e=>{t.hasAttribute(e)&&l.push(%60${e}: ${t.getAttribute(e)}%60)}));const a=Object.assign({element:t},l.length&&{attributes:l.join(", ")});o(a,s)},logAttributes:function(e){let t=e.cloneNode();i.unsetFocusStyle(t);let n=[...t.attributes],s=n.length;if(0===s)return void console.log("No attributes.");const l={attributes:function(e){let o="";for(const{nodeName:t,nodeValue:n}of e)o=o.concat(%60• ${t}: %60),o=o.concat(n?%60${n}%60:"(no value)","\n");return o}(function(){const e=n.splice(n.findIndex((e=>"id"===e.nodeName)),1),o=n.splice(n.findIndex((e=>"class"===e.nodeName)),1);return n.sort(((e,o)=>e.nodeName<o.nodeName?-1:1)),e.length&&n.unshift(e[0]),o.length&&n.push(o[0]),n}())};console.log(%60\n${e.nodeName} / ${s}:%60),o(l,"standard")},toggleAutologStatus:function(){n=!n,t("Auto log: ",n)},toggleLogFormat:function(){s="standard"===s?"object":"standard",t("Log format: ",s)},logDiff:function(e){if(!i.hasDiffSnapshot(e))return i.saveDiffSnapshot(e),void console.log("\nDiff set.\n");let{added:o,removed:t,updated:n}=i.getDiff(e,!0);const s=o.size+t.size+n.size;console.log("\nDiff:\n-----\n"),0!==s?(o.size>0&&(console.log("Added"),o.forEach((e=>console.log(%60• ${e}%60)))),t.size>0&&(console.log("Removed"),t.forEach((e=>console.log(%60• ${e}%60)))),n.size>0&&(console.log("Updated"),n.forEach(((e,o)=>{console.log(%60• ${o}: ${e[0]} -> ${e[1]}%60)}))),console.log("-----"),console.log(%60${s} change${s>1?"s":""}.%60)):console.log("No changes.")}}}(e);!function(){const e=[n,s],o=c.createFocusStyles(e,"bookmarklet-focusstyle");console.log("Keyboard Testing Bookmarklet\n(v2023.05.15)"),console.log("Active focus style: ",o[0]),c.insertStyleInDocument(o)?(c.addEventListeners(),console.log("Bookmarklet running."),console.log("For help, press 'h'.")):console.log("Start-up aborted.")}()}()}(FocusIndicatorBookmarklet||(FocusIndicatorBookmarklet={}));