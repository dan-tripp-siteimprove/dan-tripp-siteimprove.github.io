#!/usr/bin/env python2

import sys, collections, argparse, re

argparser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
argparser.add_argument('-d', '--input-delim', type=str, default=',', help='Delimiter to use while reading input.  '\
	'Can be multiple characters.  This program doesn\'t do any escaping of the delimiter when it reads the input file.')
argparser.add_argument('-f', '--field', required=True, type=str, help='Field to print.  Can be an integer (column index) '\
	'or a string (column name).')
argparser.add_argument('--filter', type=str, help='Filter lines based on this argument, which takes '\
	'the form FIELD=VALUE.  FIELD can be an integer (column index) or a string (column name).  VALUE is a '\
	'regular expression.')
argparser.add_argument('filename', nargs='?', default='stdin', help='Filename to use as input.')
args = argparser.parse_args()

def get_field_idx_from_header(field_idx_, header_line_fields_):
	if isinstance(field_idx_, int):
		r = field_idx_
	elif isinstance(field_idx_, str):
		if field_idx_ in header_line_fields_:
			r = header_line_fields_.index(field_idx_)
		else:
			raise Exception('Column "%s" not found on line 0.  There were %d field(s).  They were: %s.' % \
					(field_idx_, len(header_line_fields_), header_line_fields_))
	else:
		assert False
	return r

def get_field_idx_from_arg(arg_):
	try:
		r = int(arg_)
	except ValueError:
		r = arg_
	return r

print_field_idx = get_field_idx_from_arg(args.field)

if args.filter:
	filter_field_idx, filter_field_value_regex = args.filter.split('=', 1)
	filter_field_idx = get_field_idx_from_arg(filter_field_idx)

with sys.stdin if args.filename == 'stdin' else open(args.filename) as in_stream:
	for line_idx, line in enumerate(in_stream):
		line = line.decode('utf-8-sig') # strip BOM if present 
		if not line.strip(): continue
		line_fields = line.rstrip('\r\n').split(args.input_delim)
		if line_idx == 0:
			print_field_idx = get_field_idx_from_header(print_field_idx, line_fields)
			if args.filter:
				filter_field_idx = get_field_idx_from_header(filter_field_idx, line_fields)
		else:
			print_cur_line = False
			if args.filter:
				cur_line_filter_field_val = line_fields[filter_field_idx]
				print_cur_line = re.match(filter_field_value_regex, cur_line_filter_field_val)
			else:
				print_cur_line = True
			if print_cur_line:
				print line_fields[print_field_idx]

'''
to do:

'''

