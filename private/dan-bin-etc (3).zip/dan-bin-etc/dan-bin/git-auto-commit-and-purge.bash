#!/usr/bin/env bash

set -uo pipefail
IFS=$'\n\t'  # Inspired by http://redsymbol.net/articles/unofficial-bash-strict-mode/.  Meant as a safety net.  You should still quote variable expansions.
function err_trap_func () {
	exit_status="$?"
  echo "Exiting with status \"$exit_status\" due to command \"$BASH_COMMAND\" (call stack: line(s) $LINENO ${BASH_LINENO[*]} in $0)"
	exit "$exit_status"
}
trap err_trap_func ERR

function exit_trap_func () {
	true
}
trap exit_trap_func EXIT

set -o errtrace

#cd "$(dirname "$0")"
#set -o xtrace

#numArgsMin=2
#numArgsMax=2
#if [[ ( "$#" -le "$numArgsMin"-1 ) || ( "$#" -ge "$numArgsMax"+1 ) || ( "$#" == 1 && "$1" == "--help" ) ]] ; then
#	nameOfThisProgram="$(basename "$0")"
#	cat << EOF
#Usage example(s): 
#$nameOfThisProgram ARG1 ARG2
#EOF
#	exit 1
#fi

git add --all
git commit -m 'automatic commit' || true
cutoff_date="$(date -d "30 days ago" '+%Y-%m-%d')"
FILTER_BRANCH_SQUELCH_WARNING=1 git filter-branch --force --commit-filter '
  if [ "$(git show -s --format=%ct $GIT_COMMIT)" -lt "$(date -d "'"$cutoff_date"'" +%s)" ];
  then
    skip_commit "$@";
  else
    git commit-tree "$@";
  fi
' HEAD


