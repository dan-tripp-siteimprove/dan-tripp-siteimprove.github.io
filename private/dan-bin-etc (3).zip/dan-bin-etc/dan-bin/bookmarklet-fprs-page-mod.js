javascript:
var bookmarkletVars_4741e8c0_88a7_4bd9_a658_25b52851254a;
(async function (bookmarkletVars) {

	let g_targetDate = {year: 2023, month: 10, day: 19};

	/*
	Good test account (many fprs): https://my2.siteimprove.com/Auth/Direct?personId=47207321&accountId=6247&back=%2FSettings%2FSites%2Fv2%3Flang%3Den-US  
	*/
	
	let g_accountIdToNote = {
		"6001104": "If fpr is on a 'login' page or site: part of this account (a certain 'login' page or site) has it's crawling broken, and it's in the CSEs court to fix it, according to https://help.siteimprove.com/a/tickets/2197744 ", 
		"48630": "If fpr is on a captcha: support asked customer to fix whitelist to get around captchas and they haven't responded.  https://help.siteimprove.com/a/tickets/2029712 ", 
		"8343": "don't check again until processing fprs for oct 30.", 
		"6004868": "probably approve everything, w/ classiication ID 59f36177, b/c of https://help.siteimprove.com/a/tickets/1701368", 
		"6247": "2023-10-26: PRs slow to load 30 sec - 2 min (gave up).  very annoying.  solution: PRs seemed to work faster on franky w/ proxyus0aws.  live pages ~~ seemed to work ok both on franky w/ that proxy, and from my local machine.", 
		"77642": "if the page report shows up blank (i.e. visually blank and mostly empty of HTML, then reject the fpr and leave this rejection comment:\n\n\nThis is happening because the Siteimprove crawler is getting errors while crawling your site.  Please contact Support for assistance (through https://help.siteimprove.com/support/tickets/new or other means) and mention https://help.siteimprove.com/a/tickets/2325961 .\n\n", 
		"6109247": "big hassle w/ loading page reports on 2023-10-12.  best bet: use franky to load fprs page, page reports, and live page.", 
		"10885": "page report loaded on franky only, 2023-10-12", 
		"6119418": "1) sites gold-room-nyc.tambo.site and gvl-meetings.tambo.site are pending deletion.\n2) on 2023-10-17 a pr loaded on franky (did not load on local machine)", 
		"10353": "ticket opened 2023-10-17    https://help.siteimprove.com/a/tickets/2349881", 
		"1310736": "sites mylacprd.wpengine.com and mylacprd.wpenginepowered.com are soft-deleted", 
		"6013613": "ticket opened early sept: https://help.siteimprove.com/a/tickets/2216971", 
		"6120827": "queued in my notes 'https://siteimprove.freshdesk.com/a/tickets/2326211   live pages don't look like prs   2023-10-24  #queue >= 10-30'", 
		"67733058": "ticket opened 2023-10-27", 
		"1302885": "ticket 2023-10-27 re: facebook URLs", 
		"8808": "ticket 2023-10-31", 
		"6031830": "login to live page is strange.  if you get error msg 'We are sorry, but an error occurred during the processing of your request.' then go to https://os.lsac.org/ first, /then/ the live page.", 
	};

	let response = await fetch('https://cdn.jsdelivr.net/npm/@js-joda/core@5.6.0');
	if(response.ok) {
		eval(await response.text());
	} else {
		throw new Error("Failed to fetch joda time from CDN: " + response.status);
	}

	if(bookmarkletVars.ourListenersAndTheirElemsAndEventTypes === undefined) {
		bookmarkletVars.ourListenersAndTheirElemsAndEventTypes = [];
	}

	if(bookmarkletVars.observer) {
		bookmarkletVars.observer.disconnect();
		bookmarkletVars.observer = undefined;
	}

	let noteForAccount = g_accountIdToNote[getAccountId()];
	if(noteForAccount) {
		alert(noteForAccount);
	}

	function removeStyleAttribsAddedByUs() {
		document.querySelectorAll('*[data-fprs-page-mod-bookmarklet-added-style-attrib-to-elem]')
			.forEach((e) => { e.removeAttribute('style'); });
	}
	
	function markElemAsHavingStyleAttribAddedByUs(elem_) {
		elem_.setAttribute('data-fprs-page-mod-bookmarklet-added-style-attrib-to-elem', '');
	}
	
	let COLORS = [
		"#0000FF",
		"#009900",
		"#00DDDD",
		"#AA0000",
		"#FF00FF",
		"#BBBBBB",
		"#777777",
		"#9999FF",
		"#55FFFF",
		"#FF5555",
		"#FF55FF",
		"#FFFF55",
	];

	function getCheckboxFromCustomerPageUrlSpan(span_) {
		let rowRootElem = span_.parentElement.parentElement.parentElement.parentElement.parentElement;
		if(rowRootElem.nodeName.toLowerCase() !== 'tr') throw new Error();
		let possibleCheckboxes = rowRootElem.querySelectorAll('input[type="checkbox"]');
		if(possibleCheckboxes.length != 1) throw new Error();
		let checkbox = possibleCheckboxes[0];
		return checkbox;
	}

	function getTbodyOfTable() {
		let tbodyOfTableAll = document.querySelectorAll('[role="tabpanel"] table tbody');
		/* ^^ handles all 3 tabs: "needs review", "approved", and "rejected". */
		if(tbodyOfTableAll.length !== 1) return undefined;
		let r = tbodyOfTableAll[0];
		return r;
	}

	function getAccountId() {
		let r = document.querySelector('html head meta[name="accountId"]').getAttribute('value');
		return r;
	}

	function getSupportToolSiteConfigUrlFromPageReportUrl(accountId_, pageReportUrl_) {
		let qaSiteId = pageReportUrl_.match(/\/Inspector\/(\d+)\//)[1];
		let isUsNotEuDatacenter = {'my2.us.siteimprove.com': true, 'my2.siteimprove.com': false}[window.location.hostname];
		/* ^^ why window.location.hostname ?  why not pageReportUrl_?  sloppy code, probably. */
		let supportToolDomain = isUsNotEuDatacenter ? 'ussupporttool.siteimprove.com' : 'supporttool.siteimprove.com';
		let r = `https://${supportToolDomain}/QA/Configuration.aspx?accountid=${accountId_}&qasiteid=${qaSiteId}`;
		return r;
	}

	function getSupportToolSiteCrawlHistoryUrlFromPageReportUrl(accountId_, pageReportUrl_) {
		let qaSiteId = pageReportUrl_.match(/\/Inspector\/(\d+)\//)[1];
		let isUsNotEuDatacenter = {'my2.us.siteimprove.com': true, 'my2.siteimprove.com': false}[window.location.hostname];
		let supportToolDomain = isUsNotEuDatacenter ? 'ussupporttool.siteimprove.com' : 'supporttool.siteimprove.com';
		let r = `https://supporttool.siteimprove.com/QA/Crawl/History/Default.aspx?accountid=${accountId_}&qasiteid=${qaSiteId}`;
		return r;
	}

	function createLinkElem(url_, visibleText_) {
		let r = document.createElement('a');
		r.setAttribute('href', url_);
		r.setAttribute('target', '_blank');
		r.setAttribute('style', 'font-size: 2em');
		r.textContent = visibleText_;
		return r;
	}

	function addSiteColumnSupportToolLinks() {
		let tbodyOfTable = getTbodyOfTable();
		let siteColRootSpanElems = tbodyOfTable.querySelectorAll('tr > td:nth-of-type(3) > div > div > span');
		for(let siteColRootSpanElem of siteColRootSpanElems) {
			let siteColRootSpanElemFirstSpanChild = siteColRootSpanElem.querySelector('span:nth-of-type(1)');
			let customerPageUrlAnchorElem = siteColRootSpanElem.parentNode.parentNode.parentNode.parentNode
				.querySelector('th:nth-of-type(1) > div > div > span > span > a');
			let pageReportUrl = customerPageUrlAnchorElem.href;

			function hidePopupMenu() {
				popupMenuDiv.style.display = 'none';
			}

			let popupClickTargetElem = siteColRootSpanElem.parentElement.parentElement.parentElement;
			/* ^^ making this (the td elem) the click target instead of the div is so that we can 
			handle it when this cell has no inner text i.e. it's visually empty.  that happens when the 
			site has been deleted and/or soft-deleted.  IDK the difference. */
			popupClickTargetElem.setAttribute('style', 
				'background-color: #f0f0f0; cursor: pointer; border-radius: 12px;');
			markElemAsHavingStyleAttribAddedByUs(popupClickTargetElem);

			let popupMenuDiv = document.createElement('div');
			markElemAsAddedByUs(popupMenuDiv);
			popupMenuDiv.setAttribute('style', 
				'position: fixed; border: 1px solid black; background-color: white; z-index: 1;');
			hidePopupMenu();

			let link1Elem = createLinkElem(
				getSupportToolSiteConfigUrlFromPageReportUrl(getAccountId(), pageReportUrl), 
				'Support tool - site config');
			popupMenuDiv.appendChild(link1Elem);

			popupMenuDiv.appendChild(document.createElement('br'));
			popupMenuDiv.appendChild(document.createElement('br'));
			
			let link2Elem = createLinkElem(
				getSupportToolSiteCrawlHistoryUrlFromPageReportUrl(getAccountId(), pageReportUrl), 
				'Support tool - site crawl history');
			popupMenuDiv.appendChild(link2Elem);

			popupClickTargetElem.parentElement.appendChild(popupMenuDiv);

			let listener = function(event) {
				event.stopPropagation();
				popupMenuDiv.style.left = `${event.clientX}px`;
				popupMenuDiv.style.top = `${event.clientY}px`;
				popupMenuDiv.style.display = 'block';
			};
			popupClickTargetElem.addEventListener("click", listener);
			bookmarkletVars.ourListenersAndTheirElemsAndEventTypes.push(
				[listener, popupClickTargetElem, 'click']);

			/* I don't feel obliged to remove these event listeners because there is no chance 
			that they'll be called after we remove the listener which makes these 
			links appear.  I hope that not removing these event listeners doesn't cause a 
			memory leak or similar. */
			link1Elem.addEventListener("click", hidePopupMenu);
			link2Elem.addEventListener("click", hidePopupMenu);

		}
	}

	function removeElementsAddedByUs() {
		document.querySelectorAll('[data-fprs-page-mod-bookmarklet-added-new-elem]')
			.forEach((e) => { e.parentNode.removeChild(e); });
	}

	function getAllCustomerPageUrlSpanElems() {
		let r = getTbodyOfTable().querySelectorAll('th span.title-url_url_3EOcD');
		return r;
	}

	function markElemAsAddedByUs(elem_) {
		elem_.setAttribute('data-fprs-page-mod-bookmarklet-added-new-elem', '');
	}

	function makeCheckboxesLargeAndAddBulkActionButtons() {
		for(let customerPageUrlSpanElem of getAllCustomerPageUrlSpanElems()) {
			let checkbox = getCheckboxFromCustomerPageUrlSpan(customerPageUrlSpanElem);
			let checkboxesAncestorToFill = checkbox.parentElement.parentElement;
			checkboxesAncestorToFill.style.position = 'relative';
			checkboxesAncestorToFill.setAttribute(
				'data-fprs-page-mod-bookmarklet-added-style-attrib-to-elem', '');
			checkbox.setAttribute("style", 
				"width: 100%; height: 85%; margin: 0; position: absolute; top: 0; left: 0;");
			checkbox.setAttribute(
				'data-fprs-page-mod-bookmarklet-added-style-attrib-to-elem', '');
			let bulkApproveButtonForThisRow = document.createElement("button");
			bulkApproveButtonForThisRow.setAttribute('data-fprs-page-mod-bookmarklet-added-new-elem', '');
			bulkApproveButtonForThisRow.innerText = 'A';
			bulkApproveButtonForThisRow.setAttribute("style", 
				"width: 50%; height: 15%; margin: 0; position: absolute; top: 85%; left: 0;");
			let bulkApproveButtonForAllRows = document.querySelector('div.bulk-actions_bulk-bar_wGCpL > button:nth-child(2)');
			bulkApproveButtonForThisRow.addEventListener("click", () => {bulkApproveButtonForAllRows.click()});
			checkboxesAncestorToFill.append(bulkApproveButtonForThisRow);

			let bulkRejectButtonForThisRow = document.createElement("button");
			bulkRejectButtonForThisRow.setAttribute('data-fprs-page-mod-bookmarklet-added-new-elem', '');
			bulkRejectButtonForThisRow.innerText = 'R';
			bulkRejectButtonForThisRow.setAttribute("style", 
				"width: 50%; height: 15%; margin: 0; position: absolute; top: 85%; left: 50%;");
			let bulkRejectButtonForAllRows = document.querySelector('div.bulk-actions_bulk-bar_wGCpL > button:nth-child(3)');
			bulkRejectButtonForThisRow.addEventListener("click", () => {bulkRejectButtonForAllRows.click()});
			checkboxesAncestorToFill.append(bulkRejectButtonForThisRow);

		}
	}

	function addCustomerPageUrlColorCoding() {
		let customerPageUrlToColor = {};
		let customerPageUrlsThatHaveBrokenRuns = new Set();
		let allCustomerPageUrlSpanElems = getAllCustomerPageUrlSpanElems();
		let prevCustomerPageUrl = null;
		for(let customerPageUrlSpanElem of allCustomerPageUrlSpanElems) {
			let customerPageUrl = customerPageUrlSpanElem.innerText;

			if(prevCustomerPageUrl !== null && customerPageUrl !== prevCustomerPageUrl && customerPageUrl in customerPageUrlToColor) {
				customerPageUrlsThatHaveBrokenRuns.add(customerPageUrl);
			}
			prevCustomerPageUrl = customerPageUrl;

			if(!(customerPageUrl in customerPageUrlToColor)) {
				let nextColor = COLORS[Object.keys(customerPageUrlToColor).length % COLORS.length];
				customerPageUrlToColor[customerPageUrl] = nextColor;
			}
		}
		let domParser = new DOMParser();
		for(let customerPageUrlSpanElem of allCustomerPageUrlSpanElems) {
			let customerPageUrl = customerPageUrlSpanElem.innerText;
			let color = customerPageUrlToColor[customerPageUrl];
			let elemToAddBackgroundColorTo = 
				customerPageUrlSpanElem.parentElement.parentElement.parentElement.parentElement;
			if(customerPageUrlsThatHaveBrokenRuns.has(customerPageUrl)) {
				elemToAddBackgroundColorTo.style.background = 
					`repeating-linear-gradient(45deg, transparent, transparent 10px, ${color} 10px, ${color} 20px)`;
			} else {
				elemToAddBackgroundColorTo.style.backgroundColor = color;
			}
			/*elemToAddBackgroundColorTo.style.textShadow = 
				'0.2em 0 0 white, -0.2em 0 0 white, 0 0.2em 0 white, 0 -0.2em 0 white';*/
			elemToAddBackgroundColorTo.style.textShadow = '0px 0px 5px #000';
			elemToAddBackgroundColorTo.setAttribute(
				'data-fprs-page-mod-bookmarklet-added-style-attrib-to-elem', '');
		}
	}

	function addVeryObviousFocusIndicator() {
		const __focusStyleClassName = "fprsInjectedFocusIndicator";
		const getFocusSelector = (mode) => {
			const selector = ".".concat(__focusStyleClassName, ":focus");
			const outlineColor = "".concat(mode === "light" ? "#ffffff" : mode === "dark" ? "#000000" : "revert", " !important;");
			const body = "outline-style: solid !important; outline-width: 3px !important; ".concat("outline-color: ", outlineColor);
			return "".concat(selector, "{", body, "}");
		};
		const addFocusStyle = (element) => {
			element.classList.add(__focusStyleClassName);
		};
		const ourEventListenerToAddFocusStyle = (event) => {
			addFocusStyle(event.target);
		};
		const addFocusStyleAndListener = ({colorMode}) => {
			let focusStyle = document.createElement("style");
			focusStyle.setAttribute("type", "text/css");
			focusStyle.innerHTML = getFocusSelector(colorMode);
			document.querySelector("head").appendChild(focusStyle);
			addFocusStyle(document.activeElement);
			document.body.addEventListener("focus", ourEventListenerToAddFocusStyle, true);
		};
		addFocusStyleAndListener({colorMode: "auto"});
	}

	function getAllDateColumnTdElems() {
		let r = getTbodyOfTable().querySelectorAll('tr > td:nth-of-type(5)');
		return r;
	}

	function addDateColumnColorCoding() {
		if(!g_targetDate) return;
		let locale = document.documentElement.getAttribute('data-locale');
		if(!locale) throw new Error();
		let isThereMoreThanOnePageOfFprs = !!document.querySelector('div[data-component="pagination"] button[aria-label="Next"]');
		let localeToDateFormat = {
			'da-DK': 'dd-MM-yyyy', /* eg. 05-09-2023 https://my2.siteimprove.com/Auth/Direct?personId=126687093&accountId=50&back=%2FSupportTools%2FA11YSupport%2FDecisionSupport%3Flang%3Dda-DK */
			'de-AT': 'dd.MM.yy', /* eg. 12.09.23, 04.10.23  https://my2.siteimprove.com/Auth/Direct?personId=552509745&accountId=6033142&back=%2FSupportTools%2FA11YSupport%2FDecisionSupport%3Flang%3Den-US */ 
			'de-CH': 'dd.MM.yy', /* eg. 28.09.23, 02.12.22  https://my2.siteimprove.com/Auth/Direct?personId=583082225&accountId=6036438&back=%2FSupportTools%2FA11YSupport%2FDecisionSupport%3Flang%3Den-US */
			'de-DE': 'dd.MM.yy', /* eg. 27.09.22 or 08.12.22 https://my2.siteimprove.com/Auth/Direct?personId=149994145&accountId=24542&back=%2FSupportTools%2FA11YSupport%2FDecisionSupport%3Flang%3Dde-DE */
			'en-AU': 'd/M/yy', /* eg. 31/8/23, 8/8/22 - https://my2.siteimprove.com/Auth/Direct?personId=175342849&accountId=82990&back=%2FSupportTools%2FA11YSupport%2FDecisionSupport%3Flang%3Den-GB  */
			'en-CA': 'yyyy-MM-dd', 
			'en-GB': 'dd/MM/yyyy', /* eg. "08/09/2023" -  https://my2.siteimprove.com/Auth/Direct?personId=47212020&accountId=8803&back=%2FSupportTools%2FA11YSupport%2FDecisionSupport%3Flang%3Den-GB*/
			'en-IE': 'dd/MM/yyyy', /* eg. 05/07/2022 or 22/06/2022 https://my2.siteimprove.com/Auth/Direct?accountId=5009233&back=%2FSupportTools%2FA11YSupport%2FDecisionSupport */
			'en-NZ': 'd/MM/yy', /* d or dd is unclear.  eg. 21/09/23 https://my2.siteimprove.com/Auth/Direct?personId=1057622587&accountId=6280755&back=%2FSupportTools%2FA11YSupport%2FDecisionSupport%3Flang%3Den-GB */
			'en-US': 'M/d/yy', /* eg. 9/7/23, 9/21/23 - https://my2.us.siteimprove.com/Auth/Direct?personId=984774533&accountId=6290449&back=%2FSupportTools%2FA11YSupport%2FDecisionSupport%3Flang%3Den-US  */
			'es-ES': 'd/M/yy', /* eg. 1/9/23 https://my2.siteimprove.com/Auth/Direct?personId=735683955&accountId=6097427&back=%2FSupportTools%2FA11YSupport%2FDecisionSupport%3Flang%3Den-US */
			'fi-FI': 'd.M.yyyy', /* eg. 13.9.2023 - https://my2.siteimprove.com/Auth/Direct?personId=681201032&accountId=6049239&back=%2FSupportTools%2FA11YSupport%2FDecisionSupport%3Flang%3Den-GB */
			'it-IT': 'dd/MM/yy', /* eg. "31/08/23" - https://my2.siteimprove.com/Auth/Direct?personId=741857441&accountId=6114173&back=%2FSupportTools%2FA11YSupport%2FDecisionSupport%3Flang%3Den-US */
			'ja-JP': 'yyyy/MM/dd' , /* eg. 2023/08/03  https://my2.siteimprove.com/Auth/Direct?personId=1374993545&accountId=6287304&back=%2FSupportTools%2FA11YSupport%2FDecisionSupport%3Flang%3Den-US */
			'nb-NO': 'dd.MM.yyyy', /* eg. 09.02.2023, 23.08.2023  https://my2.siteimprove.com/Auth/Direct?personId=746257710&accountId=6122885&back=%2FSupportTools%2FA11YSupport%2FDecisionSupport%3Flang%3Den-GB */
			'nl-BE': 'd/MM/yyyy', /* eg. 3/10/2023, 25/09/2023 https://my2.siteimprove.com/Auth/Direct?personId=744795036&accountId=6120827&back=%2FSupportTools%2FA11YSupport%2FDecisionSupport%3Flang%3Den-US */ 
			'nl-NL':  'dd-MM-yyyy', /* eg. "04-09-2023" - https://my2.siteimprove.com/Auth/Direct?personId=257718760&accountId=6005070&back=%2FSupportTools%2FA11YSupport%2FDecisionSupport%3Flang%3Den-US */
			'sv-SE': 'yyyy-MM-dd', /* eg. 2023-09-14 - https://my2.siteimprove.com/Auth/Direct?personId=47210236&accountId=7845&back=%2FSupportTools%2FA11YSupport%2FDecisionSupport%3Flang%3Den-US */
		};
		let dateFormatter = JSJoda.DateTimeFormatter.ofPattern(localeToDateFormat[locale]);
		let targetDate = JSJoda.LocalDate.of(g_targetDate.year, g_targetDate.month, g_targetDate.day);
		let ignorableBacklogCutoffDate = JSJoda.LocalDate.of(2022, 12, 31);
		for(let dateColTdElem of getAllDateColumnTdElems()) {
			let curRowDateStr = dateColTdElem.innerText;
			let curRowDate = JSJoda.LocalDate.parse(curRowDateStr, dateFormatter);
			let color;
			if(curRowDate.isAfter(targetDate)) {
				color = '#00f';
			} else if(curRowDate.isEqual(targetDate) || curRowDate.isAfter(ignorableBacklogCutoffDate)) {
				color = '#faa';
			} else {
				color = '#ccc';
			}
			if(isThereMoreThanOnePageOfFprs) {
				dateColTdElem.style.background = 
					`repeating-linear-gradient(45deg, transparent, transparent 10px, ${color} 10px, ${color} 20px)`;
			} else {
				dateColTdElem.style.backgroundColor = color;
			}
			dateColTdElem.setAttribute('data-fprs-page-mod-bookmarklet-added-style-attrib-to-elem', '');
		}
	}

	function hideBottomBarProfilerResults() {
		document.querySelectorAll('.profiler-results').forEach((e) => { 
			e.setAttribute('style', 'display: none');
			e.setAttribute('data-fprs-page-mod-bookmarklet-added-style-attrib-to-elem', '');
		});
	}

	function hideHelpCenterButton() {
		getXPathElements('/html/body/button').forEach((e) => {
			e.setAttribute('style', e.getAttribute('style') + '; visibility: hidden');
		}); 
	}

	function getXPathElements(xpathExpression_) {
		let result = [];
		let xpathResult = document.evaluate(xpathExpression_, document, null, XPathResult.ORDERED_NODE_ITERATOR_TYPE, null);
		let node = xpathResult.iterateNext();
		while (node) {
			result.push(node);
			node = xpathResult.iterateNext();
		}
		return result;
	}

	function isTheMainTablePresent() {
		return !!getTbodyOfTable();
	}

	function removeListenersAddedByUs() {
		for(let e of bookmarkletVars.ourListenersAndTheirElemsAndEventTypes) {
			let listener = e[0], elem = e[1], eventType = e[2];
			elem.removeEventListener(eventType, listener);
		}
		bookmarkletVars.ourListenersAndTheirElemsAndEventTypes = [];
	}

	function refreshAllOfOurMods() {
		if(!isTheMainTablePresent()) return;

		removeStyleAttribsAddedByUs();
		removeElementsAddedByUs();
		/* We don't make any attempt to undo hideHelpCenterButton() */
		removeListenersAddedByUs();

		addDateColumnColorCoding();
		addCustomerPageUrlColorCoding();
		addSiteColumnSupportToolLinks();
		addVeryObviousFocusIndicator();
		makeCheckboxesLargeAndAddBulkActionButtons();
		hideBottomBarProfilerResults();
		hideHelpCenterButton();
	}

	refreshAllOfOurMods();

	let observerTargetNode = document.querySelector('[role="tabpanel"]').parentElement;

	let observerOptions = {
		childList: true,
		attributes: false, /* it's important that this is false b/c when it was true it caused 
			a problem.  on a page w/ 200 false positive rows if I clicked the checkbox for 
			the ~ 200th row, our callback would get called many times (tens or hundreds) 
			over 10-20 seconds sometimes.  this noticeably slowed down the browser.  
			didn't seem to happen as much when I clicked the checkbox for say the 1-10th row 
			from the top.  just the rows near the bottom. */
		subtree: true, 
		characterData: true, /* This is important for us b/c w/o it we don't get notified 
			when the user does a sort by a column.  This was a bug once.  The MDN article on 
			MutationObserver doesn't (circa 2023-10-25) mention characterData.  Odd. */
	};

	let callback = function(mutationsList_, observer_) {
		if(mutationsList_.length == 0) return;
		observer_.disconnect();
		refreshAllOfOurMods();
		observer_.observe(observerTargetNode, observerOptions);
	};

	bookmarkletVars.observer = new MutationObserver(callback);
	bookmarkletVars.observer.observe(observerTargetNode, observerOptions);


})(bookmarkletVars_4741e8c0_88a7_4bd9_a658_25b52851254a || (bookmarkletVars_4741e8c0_88a7_4bd9_a658_25b52851254a = {}));
