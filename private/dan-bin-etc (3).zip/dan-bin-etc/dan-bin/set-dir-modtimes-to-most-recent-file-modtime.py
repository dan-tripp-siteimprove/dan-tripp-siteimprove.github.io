#!/usr/bin/env python2

import os

# Thanks to https://stackoverflow.com/a/13505966 
def get_path_splits(s):
	rest, tail = os.path.split(s)
	if rest == '':
		return tail,
	return get_path_splits(rest) + (tail,)

for dirpath, dirnames, filenames in os.walk('.', topdown=False):
	if '.hg' in get_path_splits(dirpath):
		continue
	children = [os.path.join(dirpath, x) for x in dirnames + filenames]
	if not children:
		continue
	max_mtime_of_children = max(os.path.getmtime(x) for x in children)
	new_access_time = new_mod_time = max_mtime_of_children
	os.utime(dirpath, (new_access_time, new_mod_time))

