javascript:
var bookmarkletVars_9803b87c_cf28_49be_8e1a_14d6d7ba077d;
(function (bookmarkletVars) {

	/* test page example:  https://www.dshs.texas.gov/health-professions-resource-center-hprc/health-professions/county-supply-distribution-tables-0/advanced-practice-registered-nurses-1 */
	let selector = 'body.node--type-child-page main.main-content div.block-system-main-block article.node--type-child-page div.child-page-main-content p';
	let afterClassProps = 'font-size: 1rem !important; line-height: 1.5 !important; ';

	/* example: to remove all h1 elements which have an empty innerText.   
	(we don't really remove them.  we add "display: none" to them.)   
	eg. https://www.kcl.ac.uk/study/undergraduate/how-to-apply/mitigating-circumstances-and-the-admissions-process
	let selector = 'h1:empty';
	let afterClassProps = 'display: none !important';
	*/
	
	function createSignElem() {
		let signElemStyle = 'position: fixed; z-index: 2147483646; font-size: 8vh; text-shadow: 0.5vh 0 0 white, -0.5vh 0 0 white, 0 0.5vh 0 white, 0 -0.5vh 0 white; ';
		let r = document.createElement('div');
		r.setAttribute('style', signElemStyle);
		document.body.appendChild(r);
		return r;
	}

	let topLeft = createSignElem();
	topLeft.style.top = "0";
	topLeft.style.left = "0";

	let topRight = createSignElem();
	topRight.style.top = "0";
	topRight.style.right = "0";
	
	let bottomLeft = createSignElem();
	bottomLeft.style.bottom = "0";
	bottomLeft.style.left = "0";
	
	let bottomRight = createSignElem();
	bottomRight.style.bottom = "0";
	bottomRight.style.right = "0";
	
	let signElems = [topLeft, topRight, bottomLeft, bottomRight];
	
	let style = document.createElement('style');
	style.innerHTML = `
		${selector}.danTrippAfterClass {
			${afterClassProps} 
		}
	`;

	document.head.appendChild(style);

	let isAfterVersionNotBeforeVersion = false;
	setInterval(() => {
			isAfterVersionNotBeforeVersion = !isAfterVersionNotBeforeVersion;
			signElems.forEach((signElem) => {
				signElem.textContent = isAfterVersionNotBeforeVersion ? 'after' : 'before';
			});
			
			let targetElems = document.querySelectorAll(selector);

			if(isAfterVersionNotBeforeVersion) {
				targetElems.forEach((targetElem) => {
					targetElem.classList.add('danTrippAfterClass');
				});
			} else {
				targetElems.forEach((targetElem) => {
					targetElem.classList.remove('danTrippAfterClass');
				});
			}
	}, 500);


})(bookmarkletVars_9803b87c_cf28_49be_8e1a_14d6d7ba077d || (bookmarkletVars_9803b87c_cf28_49be_8e1a_14d6d7ba077d = {}));
