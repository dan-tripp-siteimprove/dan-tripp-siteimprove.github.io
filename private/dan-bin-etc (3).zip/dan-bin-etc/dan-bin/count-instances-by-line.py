#!/usr/bin/env python2

import sys, re, os, subprocess

infile = (file(sys.argv[1]) if len(sys.argv) >= 1 else sys.stdin)

linetext_to_count = {}

for line in (x.rstrip() for x in infile):
	linetext_to_count[line] = linetext_to_count.get(line, 0) + 1

counts_and_linetexts = []
for linetext, count in linetext_to_count.iteritems():
	counts_and_linetexts.append((count, linetext))

counts_and_linetexts.sort(key=lambda x: x[0], reverse=True)

for count, linetext in counts_and_linetexts:
	print '%4d' % (count), linetext 


	
