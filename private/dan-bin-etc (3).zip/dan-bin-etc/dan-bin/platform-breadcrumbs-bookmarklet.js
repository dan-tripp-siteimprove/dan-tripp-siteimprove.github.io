javascript:
var bookmarkletVars_0eed7a59_cf6e_4254_aa0a_798a6332b6f1;
(async function (bookmarkletVars) {

	function getAccountIdWhenWeAreOnAPlatformPageReport() {
		let r;
		for (let script of document.querySelectorAll('script')) {
			let scriptContent = script.textContent || script.innerText;
			let match = scriptContent.match(/sz.*push.*customerid.*?(\d+)/);
			if (match) {
				r = match[1];
				break;
			}
		}
		if(!r) {
			throw new Error();
		}
		return r;
	}


	function getAccountIdWhenWeAreOnPlatformPageThatIsNotAPageReport() {
		let r = document.querySelector('html head meta[name="accountId"]')?.getAttribute('value');
		return r;
	}

	/* To my surprise, this part of the page content in this case contains a global site ID.  
	not a QA site ID.  even though it's the QA site ID that is used in most platform URLs. */
	function getGlobalSiteIdWhenWeAreOnPlatformPageThatIsNotAPageReport() {
		let r = document.querySelector('html head meta[name="siteId"]')?.getAttribute('value');
		return r;
	}

	function getQaSiteIdWhenWeAreOnPlatformPageThatIsNotAPageReport() {
		let r;
		for(let e of document.querySelectorAll('a[href^="/QualityAssurance/"]')) {
			let match = e.href.match(/\/QualityAssurance\/(\d+)\//);
			if(match) {
				r = match[1];
				break;
			}
		}
		return r;
	}

	function getSupportToolSiteConfigUrl(accountId_, qaSiteId_, currentUrl_) {
		let hostname = (new URL(currentUrl_)).hostname;
		let isUsNotEuDatacenter = {'my2.us.siteimprove.com': true, 'my2.siteimprove.com': false}
			[hostname];
		let supportToolDomain = isUsNotEuDatacenter 
			? 'ussupporttool.siteimprove.com' : 'supporttool.siteimprove.com';
		let r = `https://${supportToolDomain}/QA/Configuration.aspx?accountid=${accountId_}`+
			`&qasiteid=${qaSiteId_}`;
		return r;
	}


	function getSupportToolSiteCrawlHistoryUrl(accountId_, qaSiteId_, currentUrl_) {
		let hostname = (new URL(currentUrl_)).hostname;
		let isUsNotEuDatacenter = {'my2.us.siteimprove.com': true, 'my2.siteimprove.com': false}
			[hostname];
		let supportToolDomain = isUsNotEuDatacenter 
			? 'ussupporttool.siteimprove.com' : 'supporttool.siteimprove.com';
		let r = `https://supporttool.siteimprove.com/QA/Crawl/History/Default.aspx?`+
			`accountid=${accountId_}&qasiteid=${qaSiteId_}`;
		return r;
	}


	function areWeOnAPlatformPageReport() {
		let r = (new URL(window.location.href)).pathname.startsWith('/Inspector/');
		return r;
	}

	function getSiteIdWhenWeAreOnAPlatformPageReport(pageReportUrl_) {
		let r = pageReportUrl_.match(/\/Inspector\/(\d+)\//)[1];
		return r;
	}

	function go() {
		createAndShowOurPopup();
	}

	function makeOpenInNewTabSvgElem() {
		let r = `<svg width="1.5em" version="1.1" xmlns="http://www.w3.org/2000/svg" 
				xmlns:xlink="http://www.w3.org/1999/xlink" viewBox="0 0 24 24"> 
			<g fill="#3C485E"> 
				<path d="M2.3,3.5C1,3.5,0,4.5,0,5.8v15.9C0,23,1,24,2.3,24h15.9c1.3,0,2.3-1,2.3-2.3v-6.8l-2.3-2.3v9.1H2.3V5.8h9.1 L9.1,3.5H2.3z"/> 
				<polygon points="16,0 19.1,3 10.5,11.6 12.4,13.5 21,4.9 24,8 24,0 "/> 
			</g> 
		</svg>`;
		r = (new DOMParser()).parseFromString(r, 'image/svg+xml');
		r = r.documentElement;
		return r;
	}

	function createAndShowOurPopup() {
		let divElem = document.createElement('div');
		document.body.appendChild(divElem);
		let linkNameToUrl = {};
		linkNameToUrl['platform > false positive reports'] = '/SupportTools/A11YSupport/DecisionSupport';
		linkNameToUrl['platform > settings > sites'] = '/Settings/Sites/v2';
		if(areWeOnAPlatformPageReport()) {
			let currentUrl = window.location.href;
			let accountId = getAccountIdWhenWeAreOnAPlatformPageReport();
			let qaSiteId = getSiteIdWhenWeAreOnAPlatformPageReport(currentUrl);
			linkNameToUrl['supporttool > site X > site config'] = 
				getSupportToolSiteConfigUrl(accountId, qaSiteId, currentUrl);
			linkNameToUrl['supporttool > site X > crawl history'] = 
				getSupportToolSiteCrawlHistoryUrl(accountId, qaSiteId, currentUrl);
		} else {
			let accountId = getAccountIdWhenWeAreOnPlatformPageThatIsNotAPageReport();
			let qaSiteId = getQaSiteIdWhenWeAreOnPlatformPageThatIsNotAPageReport();
			if(accountId && qaSiteId) {
				let currentUrl = window.location.href;
				linkNameToUrl['supporttool > site X > site config'] = 
					getSupportToolSiteConfigUrl(accountId, qaSiteId, currentUrl);
				linkNameToUrl['supporttool > site X > crawl history'] = 
					getSupportToolSiteCrawlHistoryUrl(accountId, qaSiteId, currentUrl);				
			} else {
				linkNameToUrl['supporttool > site X > site config'] = '';
				linkNameToUrl['supporttool > site X > crawl history'] = '';			

			}
		}
		divElem.style = `position: fixed; top: 0;  left: 50%; 
			transform: translateX(-50%);    background: #fff; border: 2px solid black ; 
			padding: 10px; z-index: 999999;`;
		for(let [linkName, url] of Object.entries(linkNameToUrl)) {
			let mainLinkElem = document.createElement('a');
			divElem.appendChild(mainLinkElem);
			mainLinkElem.innerText = linkName;
			if(url) {
				mainLinkElem.href = url;
			}

			divElem.appendChild(document.createTextNode(' '));

			let newTabLinkElem = document.createElement('a');
			divElem.appendChild(newTabLinkElem);
			newTabLinkElem.target = '_blank';
			newTabLinkElem.appendChild(makeOpenInNewTabSvgElem());
			if(url) {
				newTabLinkElem.href = url;
			}

			divElem.appendChild(document.createElement('br'));
		}

		function deleteOurPopup() {
			divElem.parentElement.removeChild(divElem);
		}
		for(let e of divElem.querySelectorAll('a')) {
			e.addEventListener("click", deleteOurPopup);
		}
	}

	/* Doing it this way makes it so that this code can run either:
	- as a bookmarklet (in which case this code will probably be run well after page load is finished)
	or:
	- as a tampermonkey script via "@require" (in which case this code will definitely be run well 
	before page load is finished.) */
	if(document.readyState == "complete") {
		go();
	} else {
		document.addEventListener("readystatechange", (event__) => {
			if(document.readyState === "complete") {
				go();
			}
		});
	}

	
/* ^^ run this:  uuidgen.exe  | sed 's/-/_/g' | clip */
})(bookmarkletVars_0eed7a59_cf6e_4254_aa0a_798a6332b6f1 || (bookmarkletVars_0eed7a59_cf6e_4254_aa0a_798a6332b6f1 = {}));
