#!/usr/bin/env python3

import datetime, pytz, csv, collections, os

if __name__ == '__main__':

	inputFilePath = os.path.expanduser('~/notes/fp_count_per_rule_2023-03-15______from_martin.csv')

	ruleIdToNumFprs = {}

	with open(inputFilePath, newline='', encoding='utf-8') as fin:
		csvreader = csv.DictReader(fin, delimiter=';')
		for iRow, row in enumerate(csvreader):
			ruleId = row['ruleId']
			numFprs = int(row['approved']) + int(row['rejected']) + int(row['waiting'])
			ruleIdToNumFprs[ruleId] = numFprs
			
	percentTally = 0
	totalNumFprsForAllRules = sum(ruleIdToNumFprs.values())
	ruleIdToNumFprsSortedItems = sorted(ruleIdToNumFprs.items(), key=lambda item: item[1], reverse=True)
	for ruleId, numFprs in ruleIdToNumFprsSortedItems:
		percentage = 100*numFprs/totalNumFprsForAllRules
		alfaRuleUrl = f'https://alfa.siteimprove.com/rules/{ruleId}'
		print('%s: %s/%s false positives (= %d%%).  %s' % (ruleId, numFprs, totalNumFprsForAllRules, percentage, alfaRuleUrl))
		percentTally += percentage
	print(percentTally)
		
