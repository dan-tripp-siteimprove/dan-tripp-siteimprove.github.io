#!/usr/bin/env python3

import sys, re, statistics

calc_standard_deviation = True

infiles = [sys.stdin] if len(sys.argv) == 1 else [file(arg) for arg in sys.argv[1:]]
for infile in infiles:
	if calc_standard_deviation:
		all_vals = []
	tally = 0.0
	min_val = None; max_val = None
	num_lines_total = 0
	num_lines_used = 0
	for line in infile:
		mo = re.search(r'(?<!-)\b(\d+(\.\d+)?)\b(?!-)', line)
		if mo:
			cur_val = float(mo.group(1))
			tally += cur_val
			min_val = min(min_val, cur_val) if min_val is not None else cur_val
			max_val = max(max_val, cur_val) if max_val is not None else cur_val
			num_lines_used += 1
			if calc_standard_deviation:
				all_vals.append(cur_val)
		num_lines_total += 1
	num_lines_ignored = num_lines_total - num_lines_used
	#print('File: %s' % infile.name)
	#print('\t%d lines (%d used, %d ignored)' % (num_lines_total, num_lines_used, num_lines_ignored))
	print('%.02f' % tally)
	if False: # num_lines_used > 0:
		print('\tMin: %.4f' % min_val)
		print('\tMax: %.4f' % max_val)
		print('\tAverage: %.4f' % (tally/num_lines_used))
		print('\tStd dev: %.4f' % statistics.stdev(all_vals))

