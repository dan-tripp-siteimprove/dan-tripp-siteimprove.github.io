javascript: var OurBookmarkletFunction;
/* 
- a good name for this bookmarklet in the browser: focus bookmarklet - set 'element of interest' to temp1.  (run this second.) 
*/
(function(OurBookmarkletFunction) {
    (function() {
				focus_bookmarklet_element_of_interest = temp1;
    })();
})(OurBookmarkletFunction || (OurBookmarkletFunction = {}));
