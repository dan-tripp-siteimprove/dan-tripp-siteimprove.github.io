#!/usr/bin/env python3

import sys, os, re, subprocess, urllib.parse 

MIN_ARGS=0; MAX_ARGS=0
if (len(sys.argv) < MIN_ARGS+1) or (len(sys.argv) == 2 and sys.argv[1] == "--help") or (len(sys.argv) > MAX_ARGS+1):
	nameOfThisProgram = os.path.basename(sys.argv[0])
	print(f"""Usage example(s): 
{nameOfThisProgram} ___arg1___ ___arg2___
""")
	sys.exit(1)


input_data = sys.stdin.read()

encoded_data = urllib.parse.quote(input_data)

print(encoded_data)

