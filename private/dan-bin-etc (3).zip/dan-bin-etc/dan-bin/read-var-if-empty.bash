if [ "$#" != 2 ] ; then 
	echo 'Need two arguments.'
else
	var_name="$1"
	default_value="$2"

	eval orig_value='$'$var_name

	if [ "$orig_value" == "" ] ; then 
		if echo $- | grep i >/dev/null  ; then 
		# ^^ tests if shell is interactive 
			echo 'Enter a non-default value for '"$var_name"' if desired, then press ENTER.  You have 3 seconds...'
			read -t 3 new_value
			if [ "$new_value" != "" ] ; then
				echo 'New value: "'"$new_value"'"'
				eval $var_name="$new_value"
			else
				echo 'No value entered.  Using default "'"$default_value"'".'
				eval $var_name="$default_value"
			fi
			sleep 0.5
		else
			eval $var_name="$default_value"
		fi
	fi
fi

