# Meant to be run w/ windows python (not cygwin python).

import sys, datetime, subprocess, re, os, traceback, time
import pyperclip, tzlocal, html5lib, xml.dom

# This is necessary b/c at least when I checked on 2023-09-20 windows python 
# datetime.datetime.now() was returning a naive datetime object that seemed to be in 
# UTC i.e. it was five hours ahead of me i.e. at 9:20 pm it was at 2:20 am the next day.  
# I don't know why.  cygwin python at the same time returning the right thing i.e. 9:20 pm.
def get_datetime_now():
	return datetime.datetime.now(tzlocal.get_localzone())

def get_todays_date():
	return get_datetime_now().date()

def get_current_date_and_time_to_the_minute():
	return get_datetime_now().strftime('%Y-%m-%d %H:%M')

def get_clipboard_contents():
	r = pyperclip.paste()
	r = re.sub('\r', '', r)
	return r
	
def set_clipboard_contents(str_):
	pyperclip.copy(str_)
	
def old_get_clipboard_contents_dont_use():
	pass
	# don't use thi sb/c running powershell causes a powershell console window to appear for a fraction of a second 
	# and that is enough to switch focus away from whatever window my focus is in, 
	# and break functionality if eg. I'm in windows explorer and I'm in the middle of renaming a file.  
	#r = subprocess.check_output(['Powershell', '-command', 'Add-Type', '-AssemblyName', 
			#'System.Windows.Forms;[System.Windows.Forms.Clipboard]::GetText()'])


def get_clipboard_contents_and_escape_for_false_positive_review_comment():

	r = get_clipboard_contents()

	for forbidden_string in ['___', '<<<', '>>>', 'botched', 'gotcha', 'guidance', '[', ']', 'snippet', 'canned', 
				'overrideFocus', # from /home/dtr/dan-bin/focus-bookmarklet-load.js 
				'cust ', 'customer', 
				]:
		if forbidden_string in r:
			raise Exception('"%s" is in the string.' % forbidden_string)

	# "Escape" HTML tags (eg. replace <a> with < a >) so that they'll be accepted 
	# by the platform.  i.e. avoid the "Changing approval state failed" error. 
	r = re.sub(r'<(?! )', '< ', r)
	r = re.sub(r'(?<! )>', ' >', r)

	return r

def get_clipboard_contents_with_whitespace_normalized():
	r = get_clipboard_contents()
	r = re.sub(r'\u001a', '', r) # \u001a is the unicode 'sub' code point.   I don't know what it means or why it's (
		# (sometimes) there.   It appears when eg. the clipboard contains an arrow character, like this: →  
	r = r.strip()
	r = re.sub(r'[ ]{3,}', '  ', r)
	r = re.sub(r'[\r\n]+', ' ', r)
	return r

def get_clipboard_contents_as_plain_text():
	r = get_clipboard_contents()
	return r

def edit_clipboard_contents_pretty_printed_html():
	orig_clipboard_contents = get_clipboard_contents()

	document = html5lib.parse(orig_clipboard_contents, treebuilder="dom")
	new_clipboard_contents = document.toprettyxml()

	set_clipboard_contents(new_clipboard_contents)
	return ''

if __name__ == '__main__':
	outputTempFilePath = sys.argv[-1]
	try:
		assert len(sys.argv) == 3
		functionName = sys.argv[1]
		output = str(globals()[functionName]())

		# Here we convert tabs to spaces. 
		# If we don't convert tabs to spaces then ahk will send a real TAB which 
		# usually in my situations will switch keyboard focus to the next widget 
		# (rather than type a TAB character).  I don't want that. 
		output = re.sub('\t', '    ', output)

		# Escape as per autohotkey rules. Source: https://www.autohotkey.com/docs/v1/misc/EscapeChar.htm 
		if '{' in output: # tdr revert 
			pass #raise Exception("Contains '{'.  This program can't handle this, for no good reason.")
			# This program silently drops "{" if it reaches the code below.  I don't know why.  
			# It seems to turn "{" into "{{}" fine, and "{{}" is the right way to escape "{" according to 
			# autohotkey docs. 
		for char in '{}^!+#':
			replaceWith = '{'+char+'}'
			output = re.sub(re.escape(char), replaceWith, output)

	except:
		output = traceback.format_exc()

	os.makedirs(os.path.dirname(outputTempFilePath), exist_ok=True)
	with open(outputTempFilePath, 'w', encoding='utf-8', newline='\n') as fout:
		fout.write(output)


