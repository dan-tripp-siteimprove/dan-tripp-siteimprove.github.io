#!/usr/bin/env python3

import sys, os, re, subprocess

MIN_ARGS=0; MAX_ARGS=0
if (len(sys.argv) < MIN_ARGS+1) or (len(sys.argv) == 2 and sys.argv[1] == "--help") or (len(sys.argv) > MAX_ARGS+1):
	nameOfThisProgram = os.path.basename(sys.argv[0])
	print(f"""Usage example(s): 
{nameOfThisProgram} ___arg1___ ___arg2___
""")
	sys.exit(1)

from datetime import date, timedelta

def day_of_week(d):
    days = ["Mon", "","","","","",  "Sun"]
    return days[d.weekday()]

start_date = date(2023, 10, 9)  # Monday, Oct 9, 2023
end_date = date(2024, 1, 1)  # January 1, 2024

current_date = start_date
label = "Dan"

while current_date <= end_date:
    start_dow = day_of_week(current_date)
    end_dow = day_of_week(current_date + timedelta(days=6))
    
    print(f"Date in the \"Created\" column: {start_dow} {current_date} to {end_dow} {current_date + timedelta(days=6)} - {label}")

    current_date += timedelta(days=7)
    label = "Bayley" if label == "Dan" else "Dan"

