#!/usr/bin/env python3

import sys, os, subprocess, shutil, tempfile, time, datetime
from string import Formatter
from datetime import timedelta


if len(sys.argv) != 1:
	raise Exception()

name_of_this_program = os.path.basename(sys.argv[0])

MAX_DESIRED_JPG_SIZE_IN_BYTES = 300_000

# Thanks to https://stackoverflow.com/a/42320260 
def strfdelta(tdelta, fmt='{D:02}d {H:02}h {M:02}m {S:02}s', inputtype='timedelta'):
    """Convert a datetime.timedelta object or a regular number to a custom-
    formatted string, just like the stftime() method does for datetime.datetime
    objects.

    The fmt argument allows custom formatting to be specified.  Fields can 
    include seconds, minutes, hours, days, and weeks.  Each field is optional.

    Some examples:
        '{D:02}d {H:02}h {M:02}m {S:02}s' --> '05d 08h 04m 02s' (default)
        '{W}w {D}d {H}:{M:02}:{S:02}'     --> '4w 5d 8:04:02'
        '{D:2}d {H:2}:{M:02}:{S:02}'      --> ' 5d  8:04:02'
        '{H}h {S}s'                       --> '72h 800s'

    The inputtype argument allows tdelta to be a regular number instead of the  
    default, which is a datetime.timedelta object.  Valid inputtype strings: 
        's', 'seconds', 
        'm', 'minutes', 
        'h', 'hours', 
        'd', 'days', 
        'w', 'weeks'
    """

    # Convert tdelta to integer seconds.
    if inputtype == 'timedelta':
        remainder = int(tdelta.total_seconds())
    elif inputtype in ['s', 'seconds']:
        remainder = int(tdelta)
    elif inputtype in ['m', 'minutes']:
        remainder = int(tdelta)*60
    elif inputtype in ['h', 'hours']:
        remainder = int(tdelta)*3600
    elif inputtype in ['d', 'days']:
        remainder = int(tdelta)*86400
    elif inputtype in ['w', 'weeks']:
        remainder = int(tdelta)*604800

    f = Formatter()
    desired_fields = [field_tuple[1] for field_tuple in f.parse(fmt)]
    possible_fields = ('W', 'D', 'H', 'M', 'S')
    constants = {'W': 604800, 'D': 86400, 'H': 3600, 'M': 60, 'S': 1}
    values = {}
    for field in possible_fields:
        if field in desired_fields and field in constants:
            values[field], remainder = divmod(remainder, constants[field])
    return f.format(fmt, **values)

def we_want_to_shrink_file(dir_entry_):
	return dir_entry_.is_file() \
			and (dir_entry_.name.endswith('.jpg') or dir_entry_.name.endswith('.jpeg')) \
			and (dir_entry_.stat().st_size > MAX_DESIRED_JPG_SIZE_IN_BYTES)

print('Will shrink these files:')
file_paths_to_shrink = []
with os.scandir() as it:
	cur_time_in_epoch_seconds = time.time()
	for e in it:
		if we_want_to_shrink_file(e):
			file_mod_time_in_epoch_seconds = e.stat().st_mtime
			file_age_in_seconds = cur_time_in_epoch_seconds - file_mod_time_in_epoch_seconds
			file_age_str = strfdelta(datetime.timedelta(seconds=file_age_in_seconds))
			print('modified %s ago: %s' % (file_age_str, e.path))
			file_paths_to_shrink.append(e.path)

if len(file_paths_to_shrink) == 0:
	print('None.')
	sys.exit(0)

print('Sleeping...')
time.sleep(5)

for input_file_path in file_paths_to_shrink:
	print('Shrinking %s...' % input_file_path)
	output_tmp_file_prefix = '%s.tmp.' % name_of_this_program
	with tempfile.NamedTemporaryFile(prefix=output_tmp_file_prefix, dir='.', delete=False) as tmp_file_obj:
		output_tmp_file_path = tmp_file_obj.name
	try:
		for percent in range(90, 10-1, -5):
			subprocess.check_call(['magick', 'convert', input_file_path, '-resize', str(percent)+'%', output_tmp_file_path])
			if os.stat(output_tmp_file_path).st_size < MAX_DESIRED_JPG_SIZE_IN_BYTES:
				shutil.move(output_tmp_file_path, input_file_path)
				print('Shrunk %s to %s%%.' % (input_file_path, percent))
				break
	finally:
		if os.path.exists(output_tmp_file_path):
			os.remove(output_tmp_file_path)


