#!/usr/bin/env python3

import sys, base64

encoded_val = sys.argv[1]
username, password = base64.b64decode(encoded_val).decode('utf-8').split(':', 1)
print(username)
print(password)


