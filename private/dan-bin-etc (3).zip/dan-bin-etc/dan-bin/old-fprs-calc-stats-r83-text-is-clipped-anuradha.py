#!/usr/bin/env python3

import datetime, pytz, csv, collections, os
import sqlite3

'''

- handle us datacenter when creating direct link URLs.

'''

def get_direct_link(account_id_):
	r = f'https://my2.siteimprove.com/Auth/Direct?accountId={account_id_}&back=%2FSupportTools%2FA11YSupport%2FDecisionSupport'
	return r
	
def parseFpDecisionDateTimeStr(str_):
	# Parse the string into a naive datetime object (no timezone information)
	naive_datetime = datetime.datetime.strptime(str_, "%Y-%m-%d %H:%M:%S")
	
	# Assume the string is in a timezone that is 6 hours ahead of Toronto i.e. 2 hours ahead of UTC
	# This probably has many bugs around daylight savings time.  Or maybe even all of winter.  
	# I wrote it in June.  
	utc_offset = datetime.timedelta(hours=2)
	timezone_ahead_of_utc = pytz.FixedOffset(utc_offset.total_seconds() // 60)
	aware_datetime = timezone_ahead_of_utc.localize(naive_datetime)
	
	# Convert to your local timezone
	local_timezone = pytz.timezone('America/New_York')  
	local_datetime = aware_datetime.astimezone(local_timezone)
	
	return local_datetime
	

if __name__ == '__main__':

	input_fp_decisions_filename = os.path.expanduser('~/tmp/reviewed_fp_decisions_2023_06_21.csv')
    
	with open(input_fp_decisions_filename) as fin:
		for line in fin:
			if 'insert_ts;updated_ts;rule_id;approved_yn;account_id;site_id' in line: continue
			insertedTimestamp, updatedTimesamp, ruleId, approvedYesNo, accountId, _ = line.strip().split(';')
			assert approvedYesNo in ('Y', 'N')
			if not (ruleId == 'sia-r83' and approvedYesNo == 'Y'): continue
			directLink = get_direct_link(accountId)
			print('acct:', accountId, insertedTimestamp[:10], directLink)
			continue
			ruleIdToDecisionTally[rule_id] += 1
			accountIdToDecisionTally[account_id] += 1
			#print(insert_ts, updated_ts, rule_id, approved_yn, account_id)
			fpDecisionDateTime = parseFpDecisionDateTimeStr(updated_ts)
			event = Event.createFpDecision(fpDecisionDateTime, rule_id, account_id)
			events.append(event)




