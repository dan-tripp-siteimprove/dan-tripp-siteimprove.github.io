#!/usr/bin/env python3

import sys, re, statistics

def is_a_number(x_):
	try:
		float(x_)
		return True
	except ValueError:
		return False

cmdline_args = sys.argv[1:]
if len(cmdline_args) > 0 and all(is_a_number(x) for x in cmdline_args):
	all_nums = [float(x) for x in cmdline_args]
else:
	if len(cmdline_args) == 0:
		print('Reading from stdin.')
		infiles = [sys.stdin]
	else:
		print('Reading from files on cmdline.')
		infiles = [open(arg) for arg in cmdline_args]
	try:
		all_nums = []
		for infile in infiles:
			for line in infile:
				line = re.sub(r'\+', ' ', line)
				line = re.sub(r'\s+', ' ', line)
				cur_nums = [float(x) for x in line.split(' ') if x]
				all_nums += cur_nums
	finally:
		for infile in infiles:
			infile.close()

print(f'{len(all_nums)} numbers.\naverage: {statistics.mean(all_nums):.10g}\ntally: {sum(all_nums):.10g}\nstd dev: {statistics.stdev(all_nums):.10g}')


