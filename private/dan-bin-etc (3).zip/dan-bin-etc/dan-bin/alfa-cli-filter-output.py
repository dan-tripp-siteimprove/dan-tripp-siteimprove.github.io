#!/usr/bin/env python3

import sys, json, copy

input_filepath = sys.argv[1]
alfa_ruleid = sys.argv[2]

with open(input_filepath) as file_obj_in:
	input_file_contents = json.load(file_obj_in)

output_contents = copy.deepcopy(input_file_contents)

def predicate_keep_graph_elem_earl_format(graph_elem_, desired_alfa_ruleid_):
	try:
		#print(graph_elem_["test"]["@id"]) # tdr 
		return graph_elem_["test"]["@id"].endswith('/'+desired_alfa_ruleid_)
	except KeyError as e:
		return True

def predicate_keep_graph_elem_json_format(graph_elem_, desired_alfa_ruleid_):
	try:
		#print(graph_elem_["rule"]["uri"]) # tdr 
		return graph_elem_["rule"]["uri"].endswith('/'+desired_alfa_ruleid_)
	except KeyError as e:
		return True

FILTER_BY_ALFA_RULE = True
if FILTER_BY_ALFA_RULE:
	isEarlNotJsonFormat = "@graph" in input_file_contents
	if isEarlNotJsonFormat:
		output_contents["@graph"] = [e for e in output_contents["@graph"] if predicate_keep_graph_elem_earl_format(e, alfa_ruleid)]
	else:
		output_contents["outcomes"] = [e for e in output_contents["outcomes"] if predicate_keep_graph_elem_json_format(e, alfa_ruleid)]

json.dump(output_contents, sys.stdout, indent='\t')


