#!/usr/bin/env bash

set -uo pipefail
function err_trap_func () {
  echo "Exiting with status $? due to command \"$BASH_COMMAND\" (call stack: line(s) $LINENO ${BASH_LINENO[*]} in $0)"
	exit
}
trap err_trap_func ERR
function exit_trap_func () {
	true
}
trap exit_trap_func EXIT
set -o errtrace

cat << EOF
Example:
accountId=66356303; siteId=4623060379; curl --verbose -u "\$accountId": --basic  'https://api.siteimprove.com/v2/sites/'"\$siteId"'/quality_assurance/overview/groups?page_size=1000' | json-print-prefix-keys   | vl
EOF

