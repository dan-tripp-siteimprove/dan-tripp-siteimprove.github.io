#!/usr/bin/env python2

import sys, os, subprocess, time

for dirpath, dirnames, filenames in os.walk('.'):
	if os.path.basename(dirpath) == '.hg':
		del dirnames[:]
		continue
	for f in [os.path.join(dirpath, x) for x in filenames]:
		print '%s...' % f
		last_rev_date = subprocess.check_output(['hg', 'log', '-T', '{date|isodate}', '-l', '1', f]).strip()
		if not last_rev_date:
			continue
		subprocess.check_call(['touch', '--date', last_rev_date, f])

		

