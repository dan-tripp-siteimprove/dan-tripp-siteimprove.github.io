#!/usr/bin/env bash

set -uo pipefail
function err_trap_func () {
  echo "Exiting with status $? due to command \"$BASH_COMMAND\" (call stack: line(s) $LINENO ${BASH_LINENO[*]} in $0)"
	exit
}
trap err_trap_func ERR
function exit_trap_func () {
	true
}
trap exit_trap_func EXIT
set -o errtrace

cat << EOF 
Example:
curl -X POST 'http://a11y-nemo-ui-aws.prod-eu.stmprv.io/api/Validation/76025/881984/71671459993/123?includeCssSelector=true' -H  "accept: */*" -H  "Content-Type: application/json-patch+json" -d "{'answers': []}" --verbose

- IDs in URL are: acctId/siteId/pageId/personId 
	- acctId: get it from bottom bar 
	- siteId: get it from URL of page report, non-direct link eg. the 1150354 in https://my2.siteimprove.com/Inspector/1150354/A11Y/Page?pageId=40465089033&...
		- this is a different siteId than the siteIds returned by the API.  
			- this is my rough understanding of what works as of 2022-11-09 - email thread w/ Martin Vyrostko 
			- there are two different kinds of siteId.  "I think the terminology is "global site id" and "QA site id" (not even sure which one is which..." - martin 
		- pageId: get it from URL of page report, non-direct link
	- personId doesn't matter


EOF
