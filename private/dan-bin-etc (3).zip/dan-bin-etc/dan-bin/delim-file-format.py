#!/usr/bin/env python2

import sys, collections, argparse

argparser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter)
argparser.add_argument('-d', '--input-delim', type=str, default=',', help='Delimiter to use while reading input.  '\
	'Can be multiple characters.  This program doesn\'t do any escaping of the delimiter when it reads the input file.')
argparser.add_argument('-o', '--output-delim', type=str, default=' ', help='Delimiter to use while writing output.  '\
	'Can be multiple characters.')
argparser.add_argument('-b', '--buffer-lines', type=int, default=20, help='Number of lines to buffer.  '\
	'A higher number will effectively look ahead more and give you better formatting.')
argparser.add_argument('filename', nargs='?', default='stdin', help='Filename to use as input.')
args = argparser.parse_args()

with sys.stdin if args.filename == 'stdin' else open(args.filename) as in_stream:

	col_idx_to_max_len = collections.defaultdict(lambda: 0)
	buffered_line_fields = []

	def print_line_fields(line_fields_, col_idx_to_max_len_):
		padded_fields = []
		for col_idx, line_field in enumerate(line_fields_):
			col_width = col_idx_to_max_len_[col_idx]
			padded_fields.append(('%-'+str(col_width)+'s') % line_field)
		print args.output_delim.join(padded_fields)

	for line in in_stream:
		line = line.decode('utf-8-sig') # strip BOM if present 
		cur_line_fields = line.rstrip('\r\n').split(args.input_delim)
		for col_idx, field in enumerate(cur_line_fields):
			col_idx_to_max_len[col_idx] = max(col_idx_to_max_len[col_idx], len(field))
		buffered_line_fields.append(cur_line_fields)
		if len(buffered_line_fields) > args.buffer_lines:
			line_fields_to_print = buffered_line_fields.pop(0)
			print_line_fields(line_fields_to_print, col_idx_to_max_len)

	while len(buffered_line_fields) > 0:
		line_fields_to_print = buffered_line_fields.pop(0)
		print_line_fields(line_fields_to_print, col_idx_to_max_len)


'''
to do:

'''

