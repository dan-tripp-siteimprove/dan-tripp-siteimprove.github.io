#!/usr/bin/env python2
import datetime, time, os
print str(datetime.datetime.now())
s = datetime.datetime.now().second
if s > 0:
	time.sleep(60-s)
while datetime.datetime.now().second > 10:
	time.sleep(0.25)
print str(datetime.datetime.now())
