#!/usr/bin/env bash

set -uo pipefail
function err_trap_func () {
  echo "Exiting with status $? due to command \"$BASH_COMMAND\" (call stack: line(s) $LINENO ${BASH_LINENO[*]} in $0)"
	exit
}
trap err_trap_func ERR
function exit_trap_func () {
	true
}
trap exit_trap_func EXIT
set -o errtrace

: '

Dont repeat the --outcome flag - possible bug observed 10-13.

'

if [[ "$#" == 1 && "$1" == "--help" ]] ; then
	echo '

** Formats **

--format json 
	- Has "kind" (i.e. reason for failure)
	- Does not have xpaths 
		- except for the "related" element xpaths.  they'"'"'re in expectations.*error.*errors.  

--format earl 
	- Does not have "kind" (i.e. reason for failure)
	- Does have xpaths 
		- does not have the "related" element xpaths.  

If you want both "kind" and xpaths: look in the platform, alfaResults API response.   It''s hit and miss.  Some rules have xpaths eg. target and related.  Some have neither (eg. r17 it seems.)

** Example(s) **

ruleid=sia-r62; page_to_test="file:///C:/cygwin64/home/dtr/notes/alfa-vs-axe/act-be4d0c-links-not-distinguishable-act-test-case-1.html" ;  alfa_cli_output_path=/tmp/alfa-cli-output-"$(dt)"-"$(echo "$page_to_test" | sed 's/[\/:]/_/g')".txt; cd /tmp && alfa-cli.bash audit --format json --timeout 45000 --output "$(cygpath -wa "$alfa_cli_output_path")"  "$page_to_test" && alfa-cli-filter-output.py "$alfa_cli_output_path" "$ruleid" | sponge "$alfa_cli_output_path" && vh

p='passed-example-1'; ruleid=sia-r62; page_to_test=~/notes/alfa-vs-axe/act-be4d0c-links-not-distinguishable-act-$p.html; echo "$page_to_test"; page_to_test="$(cygpath -wa "$page_to_test")" ; echo "$page_to_test"; alfa_cli_output_path=/tmp/alfa-cli-output-"$(dt)"-"$(echo "$page_to_test" | sed s/[\\/:]/_/g  )".txt; alfa-cli.bash audit --format earl --timeout 45000 --output "$(cygpath -wa "$alfa_cli_output_path")"  "$page_to_test" && alfa-cli-filter-output.py "$alfa_cli_output_path" "$ruleid" | sponge "$alfa_cli_output_path"
'
	exit 0
fi

# This is old.  Probably not usable after apr 2023.  Maybe useful if downgrading alfa to something before ~ mar 2023.  
#cd ~/alfa-mainline
#yarn alfa "$@"

# This is my fork which contains my PR that makes "yarn alfa" work - 2023-04-24 
#cd ~/alfa-integrations-dan-tripp-fork
#yarn alfa "$@"

# This is the mainline which does NOT contain my PR that makes "yarn alfa" work - 2023-04-24 
# cd ~/alfa-integrations
# node packages/alfa-cli/bin/alfa.js "$@"

cd ~/alfa-integrations
yarn alfa "$@"

