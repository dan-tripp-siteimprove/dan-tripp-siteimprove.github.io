#!/usr/bin/env bash

set -uo pipefail
function err_trap_func () {
	exit_status="$?"
  echo "Exiting with status \"$exit_status\" due to command \"$BASH_COMMAND\" (call stack: line(s) $LINENO ${BASH_LINENO[*]} in $0)"
	exit "$exit_status"
}
trap err_trap_func ERR

function exit_trap_func () {
	true
}
trap exit_trap_func EXIT
set -o errtrace # Same as -E 

echo "Are you sure you want to use this script?  Are you in the alfa repo or alfa-integrations repo?  and which fork thereof?  and should you run 'yarn install' first? see alfa notes." 
exit 1

cd "$(git rev-parse --show-toplevel)"
yarn build
# ^^ if that fails, maybe run "yarn install" then run this script again.  see alfa readme: "building" section. 


