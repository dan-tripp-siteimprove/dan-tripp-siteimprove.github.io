javascript:
var bookmarkletVars_55ea52b9_9a0b_4022_b667_578839079080;
(function (bookmarkletVars) {
	let accountId;
	for (let script of document.querySelectorAll('script')) {
		let scriptContent = script.textContent || script.innerText;
		let match = scriptContent.match(/sz.*push.*customerid.*?(\d+)/);
		if (match) {
			accountId = match[1];
			break;
		}
	}
	let newUrl;
	if(accountId) {
		newUrl = `${window.location.protocol}//${window.location.hostname}/Auth/Direct?accountId=${accountId}&back=%2FSettings%2FSites%2Fv2%3Flang%3Den-US`;
	}
	if(!newUrl) {
		alert("Failed");
	} else {
		window.location.href = newUrl;
	}
})(bookmarkletVars_55ea52b9_9a0b_4022_b667_578839079080 || (bookmarkletVars_55ea52b9_9a0b_4022_b667_578839079080 = {}));
