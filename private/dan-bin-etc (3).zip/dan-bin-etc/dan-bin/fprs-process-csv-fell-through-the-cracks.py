#!/usr/bin/env python3

import sys, os, sqlite3, subprocess, datetime

'''

I once saw some datacenter confusion in CSV files:   
	sep 2023 
	acct appeared in both csv files 
	no sign of datacenter move in salesforce or freshdesk 
	I noticed this b/c the directlink that I created when I was going through the eu datacenter csv file failed. 
	this doesn't work: open-direct-link.py   eu 6290804
	this works: open-direct-link.py   us 6290804 
	[8] LAPTOP-E3GC2JVK  $ dg 6290804
	./waiting_fp_decision_most_recent_date_sorted_2023-sep.csv:6290804;2023-05-30 19:11:50
	./waiting_fp_decision_most_recent_date_sorted_2023-sep_us.csv:6290804;2023-05-30 19:11:50

	
'''

def get_direct_link(account_id_, datacenter_):
	assert datacenter_ in ('us', 'eu')
	datacenter_domain_prefix = 'my2' if datacenter_ == 'eu' else 'my2.us'
	r = f'https://{datacenter_domain_prefix}.siteimprove.com/Auth/Direct?accountId={account_id_}&back=%2FSupportTools%2FA11YSupport%2FDecisionSupport'
	return r

		
if __name__ == '__main__':

	'''
	print('guidance: process the fprs w/ 2023-01-01 <= date <= today-ideal_time_lag')
	print('guidance: if no false positive reports show up in platform, that\'s ok, as per email from martin, ~ 2023-05-25.')
	print()
	print('guidance: *********')
	print('guidance: *********')
	print('guidance: *********')
	print('guidance: ********* in toggl, use the tags fprs and __fprs_fell_through_the_cracks')
	print('guidance: *********')
	print('guidance: *********')
	print('guidance: *********')
	print()
	'''

	inputFilePathEU = os.path.expanduser('~/tmp/waiting_fp_decision_most_recent_date_sorted_2023-sep.csv')
	inputFilePathUS = os.path.expanduser('~/tmp/waiting_fp_decision_most_recent_date_sorted_2023-sep_us.csv')
	printTextNotHtml = False
	if not printTextNotHtml:
		print('''<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>fprs - fell through the cracks</title>
	<style>

p { 
	line-height: 1.5; 
}

*:focus {
	outline-style: solid !important; 
	outline-width: 3px !important; 
	outline-color: revert !important;
}

	</style>
</head>
<body>
<main>
''')
	for inputFilePath in [inputFilePathEU, inputFilePathUS]:
		datacenter = {inputFilePathEU:'eu', inputFilePathUS:'us'}[inputFilePath]
		with open(inputFilePath) as fin:
			for line in fin:
				account_id, date_time = line.strip().split(';', 2)
				date_time = datetime.datetime.strptime(date_time, '%Y-%m-%d %H:%M:%S')
				if date_time.year < 2023: continue
				if printTextNotHtml:
					print(date_time, get_direct_link(account_id, datacenter))
					print()
				else:
					print(f'{date_time} <a target="_blank" href="{get_direct_link(account_id, datacenter)}">{account_id}</a><br>')

	if not printTextNotHtml:
		print('''</main>
</body>
</html>
''')
		
