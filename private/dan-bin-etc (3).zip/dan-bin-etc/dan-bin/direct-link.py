#!/usr/bin/env python3

import sys, os

def get_direct_link(account_id_, datacenter_):
	assert datacenter_ in ('us', 'eu')
	datacenter_domain_prefix = 'my2' if datacenter_ == 'eu' else 'my2.us'
	r = f'https://{datacenter_domain_prefix}.siteimprove.com/Auth/Direct?accountId={account_id_}&back=%2FSupportTools%2FA11YSupport%2FDecisionSupport'
	return r

		
if __name__ == '__main__':

	if (len(sys.argv) == 1) or (len(sys.argv) == 2 and sys.argv[1] == '--help') or (len(sys.argv) >= 4):
		nameOfThisProgram = os.path.basename(sys.argv[0])
		print(f'''Usage example(s): 
	{nameOfThisProgram} eu 6021787 
	''')
		sys.exit(1)

	datacenter = sys.argv[1]
	accountId = sys.argv[2]

	print(get_direct_link(accountId, datacenter))
