javascript:var OurBookmarklet; (function (OurBookmarklet) {

	function clickElem(elem_) {
		let event = new MouseEvent('click', {
			bubbles: true,
			cancelable: true,
			view: window
		});

		elem_.dispatchEvent(event);
	}

	function simulateSpaceKey(element) {
			var spaceKeyEvent = new KeyboardEvent('keydown', {
					key: ' ',
					code: 'Space',
					charCode: 32,
					keyCode: 32,
					which: 32,
					bubbles: true,
					cancelable: true
			});

			element.dispatchEvent(spaceKeyEvent);
	}

	let activeElement = document.activeElement;
	if(!activeElement) {
		console.log("no activeelement");
	} else {
		if(!(activeElement.nodeName.toLowerCase() === 'input' && activeElement.type === 'checkbox')) {
			console.log("activeelement is not the kind of checkbox that we're looking for");
		} else {
			let curRowOfTable = activeElement.parentElement.parentElement.parentElement;
			if(curRowOfTable.nodeName.toLowerCase() !== 'tr') throw new Error();
			let custPageUrlOfCurRow = curRowOfTable.querySelector('th span.title-url_url_3EOcD').innerText;
			/* console.log(`url is ${custPageUrlOfCurRow}`); */
			let tbodyOfTable = curRowOfTable.parentElement;
			if(tbodyOfTable.nodeName.toLowerCase() !== 'tbody') throw new Error();
			let allCustPageUrlsSpanElems = tbodyOfTable.querySelectorAll('th span.title-url_url_3EOcD');
			for(let otherRowCustPageUrlSpanElem of allCustPageUrlsSpanElems) {
				let otherRowCustPageUrl = otherRowCustPageUrlSpanElem.innerText;
				/* console.log(`url is ${custPageUrl}`); */
				let otherRow = otherRowCustPageUrlSpanElem.parentElement.parentElement.parentElement.parentElement.parentElement;
				if(otherRow.nodeName.toLowerCase() !== 'tr') throw new Error();
				let otherRowCheckbox = otherRow.querySelector('input[type="checkbox"]');
				if(otherRowCheckbox.nodeName.toLowerCase() !== 'input') throw new Error();
				if(otherRowCheckbox.type.toLowerCase() !== 'checkbox') throw new Error();
				if(otherRowCustPageUrl === custPageUrlOfCurRow) {
					/* console.log(`yes`, otherRowCustPageUrl); */
					if(!otherRowCheckbox.checked) {
						/*otherRowCheckbox.setAttribute('checked', '');*/
						otherRowCheckbox.checked = true;
						otherRowCheckbox.setAttribute('aria-checked', 'true');
					}
				} else { 
					/* console.log(`no`, otherRowCustPageUrl); */
					if(otherRowCheckbox.checked) {
						/*otherRowCheckbox.removeAttribute('checked');*/
						otherRowCheckbox.checked = false;
						otherRowCheckbox.setAttribute('aria-checked', 'false');
					}
				}
			}
		}
	}
})(OurBookmarklet || (OurBookmarklet = {}));
