#!/usr/bin/env python3

import sys, datetime, re, os, os.path
import pytz

if (len(sys.argv) == 1) or (len(sys.argv) == 2 and sys.argv[1] == '--help') or (len(sys.argv) != 6):
	nameOfThisProgram = os.path.basename(sys.argv[0])
	print(f'''Usage: 
{nameOfThisProgram} year month day hour minute 
''')
	sys.exit(1)

year, month, day, hour, minute = (int(x) for x in sys.argv[1:])

naive_datetime = datetime.datetime(year, month, day, hour, minute, 0)
toronto_tz = pytz.timezone('America/Toronto')
toronto_datetime = toronto_tz.localize(naive_datetime)

minneapolis_tz = pytz.timezone('America/Chicago')
seattle_tz = pytz.timezone('America/Los_Angeles')
copenhagen_tz = pytz.timezone('Europe/Copenhagen')

minneapolis_datetime = toronto_datetime.astimezone(minneapolis_tz)
seattle_datetime = toronto_datetime.astimezone(seattle_tz)
copenhagen_datetime = toronto_datetime.astimezone(copenhagen_tz)

if toronto_datetime.hour < 9:
	raise Exception(f'hour is {toronto_datetime.hour}.  this program assumes that you don\'t really want to meet that early in the morning.  Reminder: the hour parameter is in 24-hour time.')

all_datetimes = [toronto_datetime, minneapolis_datetime, seattle_datetime, copenhagen_datetime]
if len(set([dt.date() for dt in all_datetimes])) != 1:
	raise Exception("This program doesn't handle eg. an 11 PM meeting time as per Toronto time (which would happen the next day in Copenhagen).")

def get_12_hour_timestr(dt_):
	r = dt_.strftime('%I:%M %p')
	r = r.lstrip('0')
	# startswith('00') will never happen, because that would be '12:00' not '00:00'.
	return r

def get_day_of_month_str(dt_):
	r = dt_.strftime('%d')
	r = r.lstrip('0')
	return r

datestr = toronto_datetime.strftime('%A, %B ') + get_day_of_month_str(toronto_datetime)
toronto_timestr = get_12_hour_timestr(toronto_datetime)
minneapolis_timestr = get_12_hour_timestr(minneapolis_datetime)
seattle_timestr = get_12_hour_timestr(seattle_datetime)
copenhagen_timestr = copenhagen_datetime.strftime('%H:%M')

s = f'''"Dan's Accessibility Hour" for this week:
Date: {datestr}
Time: {minneapolis_timestr} Minneapolis time (= {toronto_timestr} Toronto time = {seattle_timestr} Seattle time = {copenhagen_timestr} Copenhagen time)
Here's the teams meeting link.  _________ 
If you would like me to send you the meeting invite, email me: dtr@siteimprove.com 
'''
print(s)
