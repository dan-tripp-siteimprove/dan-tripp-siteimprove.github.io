#!/usr/bin/env python2

# TODO: don't pass newlines to stringfunc.  that would make this program useful for methods like isalnum()
# TODO: examine stringfunc's arg types and cast our args to them.

import sys

stringfunc = str.__dict__[sys.argv[1]]
args = tuple(sys.argv[2:])

for line in sys.stdin.readlines():
	print str(stringfunc(line, *args)), 
