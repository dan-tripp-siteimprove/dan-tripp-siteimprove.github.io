#!/usr/bin/env python3

import sys

input_xpath = sys.argv[1]

def massage_xpath_part(e_):
	if not e_ or e_.endswith(']'):
		return e_
	else:
		return '%s[1]' % e_

xpath_parts = input_xpath.split('/')
xpath_parts = [massage_xpath_part(e) for e in xpath_parts]
output_xpath = '/'.join(xpath_parts)
print(output_xpath)

