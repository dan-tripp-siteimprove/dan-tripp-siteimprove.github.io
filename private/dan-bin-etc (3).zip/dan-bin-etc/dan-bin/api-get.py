#!/usr/bin/env python3

import sys, os, os.path

if (len(sys.argv) == 1) or (len(sys.argv) == 2 and sys.argv[1] == '--help'):
	nameOfThisProgram = os.path.basename(sys.argv[0])
	print(f'''Usage examples: 
{nameOfThisProgram} 6021787 "https://api.eu.siteimprove.com/v2/sites/1351747164/seov2/issues/mobile_speed/details"
{nameOfThisProgram} 6021787 eu "/sites/1351747164/seov2/issues/mobile_speed/details"
{nameOfThisProgram} 6021787 eu "/sites/1351747164/seov2/issues/mobile_speed/details" --include --verbose
''')
	sys.exit(1)

if (len(sys.argv) == 3) or (len(sys.argv) > 3 and  sys.argv[2] not in ['eu', 'us']):
	accountId = sys.argv[1]; url = sys.argv[2]; extraArgsForCurl = sys.argv[3:]
	assert(url.startswith('http'))
elif len(sys.argv) >= 4:
	accountId = sys.argv[1]; datacenter = sys.argv[2]; partialUrl = sys.argv[3]; extraArgsForCurl = sys.argv[4:]
	assert(datacenter in ['eu', 'us'])
	assert(partialUrl.startswith('/'))
	urlPrefix = {'eu': 'https://api.eu.siteimprove.com/v2', 'us': 'https://api.us.siteimprove.com/v2'}[datacenter]
	url = urlPrefix + partialUrl
else:
	raise Exception()

print(f'url: {url}', file=sys.stderr)
curlArgs = ['--no-progress-meter', '--header', 'X-Siteimprove-Api-Caller: Testing - dtr@siteimprove.com', '-u', accountId+':', '--basic', url] + extraArgsForCurl
os.execvp('curl', ['curl'] + curlArgs)

