#!/usr/bin/env python3

import sys, subprocess

if len(sys.argv) != 3:
	raise Exception('This program needs two argument: 1) a file path, 2) a percentage')

file_path = sys.argv[1]
percent = int(sys.argv[2])

subprocess.check_call(['magick', 'convert', file_path, '-resize', str(percent)+'%', file_path])


