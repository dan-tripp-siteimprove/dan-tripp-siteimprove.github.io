#!/usr/bin/env python2
import sys
for line in sys.stdin.readlines():
	print line.lower(), 
