javascript: 
/* 

An alternative to this bookmarklet is to use chrome devtools to create a "live expression" on document.activeElement (https://developer.chrome.com/docs/devtools/accessibility/focus/)
comparing that to this bookmarklet:
	- this bookmarklet logs the time.
	- this bookmarklet has the 'target element' feature.
	- this bookmarklet logs all of the element's attributes.
	- both can be right-clicked and then you can go "Reveal in Elements panel".  this is not obvious w/ a live expression, but it's there.
	- this bookmarklet works in firefox too.

- a good name for this bookmarklet in the browser: focus bookmarklet - load and set 'element of interest' to null.  (run this first.) 
- this bookmarklet is used with focus-bookmarklet-set-element-of-interest.js 

a newer / post-fork version of this might exist in tero's demo pages.   that version might have more "commands" like "diff" and different focus styles.

to do: feature: get tero's different focus styles (underline vs. border?) and cycle through them on a 500 ms timer. 

bug: loading bookmarklet mult times (w/o page load in between) will result in duplicate console.log calls. 

feature: log currently-focused element on bookmarklet load.  (not just on focus change later.) 


*/
var OurBookmarkletFunction;
(function(OurBookmarkletFunction) {
    (function() {
				focus_bookmarklet_element_of_interest = null;

				/* If you change this then also change /home/dtr/dan-bin/ahk_functions.py */
        const __focusStyleClassName = "overrideFocus";

        const getFocusSelector = (mode) => {
            const selector = ".".concat(__focusStyleClassName, ":focus");
            const outlineColor = "".concat(mode === "light" ? "#ffffff" : mode === "dark" ? "#000000" : "revert", " !important;");
            const body = "outline-style: solid !important; outline-width: 3px !important; ".concat("outline-color: ", outlineColor);
            return "".concat(selector, "{", body, "}");
        };
        const addFocusStyle = (element) => {
						let log = false;
						if(focus_bookmarklet_element_of_interest !== null) {
							if(focus_bookmarklet_element_of_interest === element) {
								log = true;
							}
						} else {
							log = true;
						}
						if(log) {
							let date = new Date();
							let dateWithMilliseconds = date.toLocaleString('en-US', 
								{ hour12: false, hour: '2-digit', minute: '2-digit', second: '2-digit' }) + '.' + ("000" + date.getMilliseconds()).slice(-3); 
							console.log(dateWithMilliseconds, element);
						}
            element.classList.add(__focusStyleClassName);
        };
        const makeFocusTargetVisible = (event) => {
            addFocusStyle(event.target);
        };
        const runBookmarklet = ({
            colorMode
        }) => {
            let focusStyle = document.createElement("style");
            focusStyle.setAttribute("type", "text/css");
            focusStyle.innerHTML = getFocusSelector(colorMode);
            document.querySelector("head").appendChild(focusStyle);
            console.log("-- Bookmarklet activated --");
						addFocusStyle(document.activeElement);
            document.body.addEventListener("focus", makeFocusTargetVisible, true);
        };
        runBookmarklet({
            colorMode: "auto"
        });
    })();
})(OurBookmarkletFunction || (OurBookmarkletFunction = {}));
