#!/usr/bin/env python2

import sys, re, os, subprocess

# return list of (path, isdir, linkedtopath) pairs. 
# linkedtopath will only be non-None if it's a symlink 
# sorted by file modification time, descending. 
def list_files(searchterms_):
	r = []
	files = os.listdir('.')
	for file in files:
		if all(searchterm.lower() in file.lower() for searchterm in searchterms_):
			linkedto = (os.readlink(file) if os.path.islink(file) else None)
			r.append((file, os.path.isdir(file), linkedto))
	r.sort(key=lambda x: getmtime(x[0]), reverse=True)
	return r

def getmtime(path_):
	if os.path.exists(path_):
		return os.path.getmtime(path_)
	elif os.path.islink(path_):
		return os.lstat(path_).st_mtime
	else:
		raise Exception('"%s" does not exist, and is not a symbolic link.' % path_)

def get_arg_files(isdir_, numargs_, argv_):
	idxes = argv_[-numargs_:]
	if len(idxes) == numargs_ and all(idx.isdigit() for idx in idxes):
		idxes = [int(idx) for idx in idxes]
		searchterms = argv_[1:-numargs_]
	else:
		idxes = range(numargs_)
		searchterms = argv_[1:]

	all_matching_files = [x[0] for x in list_files(searchterms) if x[1] == isdir_]
	for idx in idxes:
		if not (0 <= idx < len(all_matching_files)):
			raise Exception('We found %d matching filenames.  Index %d is invalid in this list.' \
					% (len(all_matching_files), idx))
	r = [all_matching_files[idx] for idx in idxes]
	r = r[::-1]
	return r

def run_program(progname_, numargs_, argv_, print_file_paths_=False):
	if len(sys.argv) == 2 and argv_[1] == '--help':
		idx_msg = ('idx' if numargs_ == 1 else ' '.join('idx%d' % i for i in range(numargs_)))
		sys.exit('Usage: %s [SEARCHTERMS...] [%s]' % (os.path.basename(argv_[0]), idx_msg))
	else:
		files = get_arg_files(False, numargs_, argv_)
		if print_file_paths_:
			if len(files) == 1:
				print 'Using file "%s"' % files[0]
			else:
				print 'Using files:'
				for f in files:
					print '"%s"' % f
		subprocess.check_call([progname_] + files)

if __name__ == '__main__':

	#print get_recent_file(argv_[1:], 0, False)
	for f in list_files(['t', '.txt']):
		print f[0]

