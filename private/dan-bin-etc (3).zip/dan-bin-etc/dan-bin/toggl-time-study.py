#!/usr/bin/env python3

import sys, datetime, pytz, csv, collections, os, re

'''

to do: 

distinguish between ~ "unknown" (== time entry DNE == "unaccounted for?") and "uncategorized" (time entry exists but has no useful category.) 

make the time I spent on the "target size bookmarklet" stand out somehow. 

'''




def parseDate(str_):
	return datetime.datetime.strptime(str_, "%Y-%m-%d").date()

def getDayOfWeekStr(date_):
	assert(isinstance(date_, datetime.date))
	return date_.strftime('%a')

def getProjectLongName(projectShortName_):
	r = {
		'fprs': 'False Positive Reviews', 
		'act_cg': 'ACT Rules Community Group', 
		'uta_reporting': 'UTA (University of Texas, Arlington) - API reporting app', 
		}.get(projectShortName_, projectShortName_)
	r = re.sub('_', ' ', r)
	return r

if __name__ == '__main__':

	useThisHardCodedFilePath = sys.argv[1] == 'yes'
	if not useThisHardCodedFilePath: raise Exception()
	inputTogglTimesheetFilePath = "/tmp/Toggl_time_entries_2023-10-01_to_2023-10-31(2).csv"

	dateToNumHoursWorked = {}
	with open(os.path.expanduser('~/notes/timesheet-hours-worked-per-day.txt')) as fin:
		csvreader = csv.reader(fin)
		for iRow, row in enumerate(csvreader):
			dateStr, numHoursWorkedStr = row[:2]
			date = parseDate(dateStr)
			numHoursWorkedStr = numHoursWorkedStr.strip()
			if numHoursWorkedStr:
				try:
					numHoursWorkedThisRow = float(numHoursWorkedStr)
				except ValueError as e:
					hours, minutes = (int(x) for x in numHoursWorkedStr.split(':', 1))
					numHoursWorkedThisRow = hours + float(minutes)/60
				dateToNumHoursWorked[date] = numHoursWorkedThisRow

	projectToNumHours = collections.defaultdict(lambda: 0)
	
	details_lines = []
    
	togglDatesCovered = set()
	with open(inputTogglTimesheetFilePath, newline='', encoding='utf-8-sig') as fin:
		csvreader = csv.DictReader(fin)
		for iRow, row in enumerate(csvreader):
			try:
				date = parseDate(row['Start date'])
				togglDatesCovered.add(date)
				numHours = float(row['Duration'])
				description = row['Description']
				tags = set(re.split(', *', row['Tags']))
				if len(tags) == 0 or '' in tags: raise Exception()

				# Fudge the tags:  
				for tag in ['coding', 'other']:
					if tag in tags: 
						tags.remove(tag)
				tags = set([x for x in tags if not x.startswith('__')])
				tags = set(['thought_leadership' if x == 'accessu' else x for x in tags])
				if tags == set(['fprs', 'consulting']): tags = set(['fprs'])
				if len(tags) == 0: tags = set(['unknown'])

				if len(tags) != 1: raise Exception(tags)
				project = list(tags)[0] # here a 'tag' becomes a 'project' 
				projectToNumHours[project] += numHours

				details_lines.append(f'{date}: {numHours:.1f} hours: '+\
					f'{getProjectLongName(project)}: {description if description else "(no description)"}')
			except:
				print('Error while processing row:', row)
				raise	

	anyErrorsForTogglDateCoverage = False
	for togglDateCovered in sorted(togglDatesCovered):
		if togglDateCovered not in dateToNumHoursWorked:
			print(f'error: date "{togglDateCovered}" is in toggl timesheet and not in "hours worked per day" file.')
			anyErrorsForTogglDateCoverage = True
	if anyErrorsForTogglDateCoverage: raise Exception()
	numHoursWorkedSumOverAllTogglDays = sum(dateToNumHoursWorked[date] for date in togglDatesCovered)

	startDate = min(togglDatesCovered); endDate = max(togglDatesCovered)
	numWorkingDays = len(togglDatesCovered)
	numHoursNotAccountedFor = numHoursWorkedSumOverAllTogglDays - sum(projectToNumHours.values())
	projectToNumHours['unknown'] += numHoursNotAccountedFor

	for date in [startDate + datetime.timedelta(days=i) for i in range((endDate - startDate).days + 1)]:
		if date not in dateToNumHoursWorked: continue
		if date not in togglDatesCovered:
			raise Exception(f'"{date} is non-blank in "hours worked per day" file and has no toggle entries.')

	print('SUMMARY:')
	print()
	print(f'Start date: {getDayOfWeekStr(startDate)} {startDate}.  End date: {getDayOfWeekStr(endDate)} {endDate}.')
	print(f'Hours worked: {numHoursWorkedSumOverAllTogglDays:.1f}.  Days worked: {numWorkingDays:.1f}.' + 
		f'  Hours/day = {numHoursWorkedSumOverAllTogglDays:.1f}/{numWorkingDays:.1f} = {numHoursWorkedSumOverAllTogglDays/numWorkingDays:.2f}.')
	print()

	numHoursTallyForAllProjects = 0
	projectToNumHours = {k: v for k, v in sorted(projectToNumHours.items(), 
		key=lambda item: item[1], reverse=True)}
	hoursPercentTally = 0
	for project, numHours in projectToNumHours.items():
		project = getProjectLongName(project)
		hoursPercent = numHours*100/numHoursWorkedSumOverAllTogglDays
		hoursPercentTally += hoursPercent
		print(f'{project}: {numHours:.1f} hours, {hoursPercent:.0f}%')
		numHoursTallyForAllProjects += numHours
	assert numHoursTallyForAllProjects == numHoursWorkedSumOverAllTogglDays, \
		'%s %s' % (numHoursTallyForAllProjects, numHoursWorkedSumOverAllTogglDays)
	assert int(hoursPercentTally) == 100, hoursPercentTally
	print()
	print()
	print()

	print('DETAILS:')
	print()
	for l in details_lines:
		print(l)
