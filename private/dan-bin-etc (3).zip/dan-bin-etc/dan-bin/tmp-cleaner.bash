#!/bin/bash

cd /tmp
f -type f -atime +60 -print0 | x0 rm
f -type d -empty -print0 | x0 rmdir

