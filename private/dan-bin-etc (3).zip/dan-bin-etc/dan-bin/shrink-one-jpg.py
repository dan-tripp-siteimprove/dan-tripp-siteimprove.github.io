#!/usr/bin/env python3

import sys, os, subprocess, shutil, tempfile, time, datetime
from string import Formatter
from datetime import timedelta

MAX_DESIRED_JPG_SIZE_IN_BYTES = 300_000

if len(sys.argv) != 2:
	raise Exception()

name_of_this_program = os.path.basename(sys.argv[0])
input_file_path = sys.argv[1]

print('Shrinking %s...' % input_file_path)
output_tmp_file_prefix = '%s.tmp.' % name_of_this_program
with tempfile.NamedTemporaryFile(prefix=output_tmp_file_prefix, dir='.', delete=False) as tmp_file_obj:
	output_tmp_file_path = tmp_file_obj.name
try:
	for percent in range(90, 10-1, -5):
		subprocess.check_call(['magick', 'convert', input_file_path, '-resize', str(percent)+'%', output_tmp_file_path])
		if os.stat(output_tmp_file_path).st_size < MAX_DESIRED_JPG_SIZE_IN_BYTES:
			shutil.move(output_tmp_file_path, input_file_path)
			print('Shrunk %s to %s%%.' % (input_file_path, percent))
			break
finally:
	if os.path.exists(output_tmp_file_path):
		os.remove(output_tmp_file_path)


