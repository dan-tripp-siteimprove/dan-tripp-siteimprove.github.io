#!/usr/bin/env python2

import sys

if len(sys.argv) > 1:
	inputfile = file(sys.argv[1])
else:
	inputfile = sys.stdin

for c in inputfile.read():
	print '%s %s' % (c, ord(c))

