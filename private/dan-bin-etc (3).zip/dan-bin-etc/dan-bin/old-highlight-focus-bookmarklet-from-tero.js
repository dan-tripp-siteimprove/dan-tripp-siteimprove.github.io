javascript: var FocusStyleBookmarklet;
(function(FocusStyleBookmarklet) {
    (function() {
        const __focusStyleClassName = "overrideFocus";
        const __focusableTags = new Set(["A", "BUTTON", "INPUT", "TEXTAREA", "SELECT", "DETAILS"]);
        const getFocusSelector = (mode) => {
            const selector = ".".concat(__focusStyleClassName, ":focus");
            const outlineColor = "".concat(mode === "light" ? "#ffffff" : mode === "dark" ? "#000000" : "revert", " !important;");
            const body = "outline-style: solid !important; outline-width: 3px !important; ".concat("outline-color: ", outlineColor);
            return "".concat(selector, "{", body, "}");
        };
        const addFocusStyle = (element) => {
            console.log(element);
            element.classList.add(__focusStyleClassName);
        };
        const makeFocusTargetVisible = (event) => {
            addFocusStyle(event.target);
        };
        const runBookmarklet = ({
            colorMode
        }) => {
            let focusableElements = [];
            let focusStyle = document.createElement("style");
            focusStyle.setAttribute("type", "text/css");
            focusStyle.innerHTML = getFocusSelector(colorMode);
            document.querySelector("head").appendChild(focusStyle);
            console.log("-- Bookmarklet activated --");
            document.body.addEventListener("focus", makeFocusTargetVisible, true);
        };
        runBookmarklet({
            colorMode: "auto"
        });
    })();
})(FocusStyleBookmarklet || (FocusStyleBookmarklet = {}));