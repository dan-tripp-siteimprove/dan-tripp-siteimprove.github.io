javascript:
var bookmarkletVars_cc26f9f1_d320_4a87_af44_26da19ab9208;
(async function (bookmarkletVars) {

	function getAccountIdOfCurPage() {
		let r;
		for (let script of document.querySelectorAll('script')) {
			let scriptContent = script.textContent || script.innerText;
			let match = scriptContent.match(/sz.*push.*customerid.*?(\d+)/);
			if (match) {
				r = match[1];
				break;
			}
		}
		if(!r) {
			throw new Error('failed to find accountId');
		}
		return r;
	}

	function getDatacenterOfCurPage() {
		let url = window.location.href;
		if(url.includes('https://my2.siteimprove.com')) {
			return 'eu';
		} else if(url.includes('https://my2.us.siteimprove.com')) {
			return 'us';
		} else {
			throw new Error('failed to get datacenter');
		}
	}

	function getPageIdOfCurPage() {
		let r = (new URLSearchParams((new URL(window.location.href)).search)).get('pageId');
		if(!r) {
			throw new Error('failed to get page ID');
		}
		return r;
	}

	function getCustPageUrlOfCurPage() {
		let aElems = document.querySelectorAll('div.inspector-meta a');
		if(aElems.length != 1) {
			throw new Error('failed');
		}
		let aElem = aElems[0];
		let r = aElem.href;
		if(!r) throw new Error();
		return r;
	}


	function getQaSiteIdFromCurPage() {
		let url = new URL(window.location.href);
		let urlPathParts = url.pathname.split('/');
		if(!(urlPathParts[1] === "Inspector" && urlPathParts[3] === "A11Y")) throw new Error();
		let qaSiteId = urlPathParts[2];
		return qaSiteId;
	}

	let accountId = getAccountIdOfCurPage();
	let datacenter = getDatacenterOfCurPage();
	let pageId = getPageIdOfCurPage();
	let custPageUrl = getCustPageUrlOfCurPage();
	let qaSiteId = getQaSiteIdFromCurPage();

	let msgToUser = `params:     ${accountId} ${datacenter} ${pageId} ${custPageUrl} ${qaSiteId} `;
	alert(msgToUser);

})(bookmarkletVars_cc26f9f1_d320_4a87_af44_26da19ab9208 || (bookmarkletVars_cc26f9f1_d320_4a87_af44_26da19ab9208 = {}));
/* ^^ run this:  uuidgen.exe  | sed 's/-/_/g' | clip */
