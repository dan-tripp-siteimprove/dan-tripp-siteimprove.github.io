#!/usr/bin/env python3

import sys, datetime, pytz, csv, collections, os
import sqlite3

'''

caveat: can't calc any stats based on approve/reject rates yet b/c they're skewed b/c I reject 
everything that I can't see on the page report any more.




- check for approvals w/o a classification ID 

- check for rejections w/ a classification ID 

concatenate (and dedupe) all past trustable stats files 
	b/c ~ 2023-10-18 Dan asked martin V via email:
	"Do you know why there are some lines in reviewed_fp_decisions_2023_06_21.csv that aren’t in reviewed_fp_decisions_2023_jan_1_to_oct_6_eu.csv?  I thought that these decisions last forever in the database.  But some of them seem to have disappeared."
	martin responded:
	"My immediate thoughts are that the decision may have been deleted (by the user probably). Unlikely, but possible.
	Another possible explanation, yet perhaps even less likely, is that the review has been removed (using the "Undo approval", "Undo rejection" buttons).
	I don't really see any other possibility, except for a bug in a system. 🙈"
	- argument for concatenating: acct 6047745 - when I checked 2023-10-27 in the platform, I saw no rejections. that can't be true. I recognize this customer as a frequent reporter of false positives.





- calc fprs reviewed per day.

- by time: test for clock drift - toggl time window 2023-08-14 16:47 - 16:52.  I reviewed a few for acct 67733058 then ended the toggl time window a few seconds after. 

- by time: print minutes per fpr. 

- by time: handle case of 2023-08-04 18:58 where I did a ~ 3 min toggl window, and reviewed 1 fprs (acct 6003082) 

- by time: to do: handle case 2023-07-31: pidan tangent.  I handled many skip link fprs at the end of that tangent i.e. near the end of that toggl window.

- by time: to do: on toggl window end, print how much of that toggl window was filed under rule/account.

- by time: to do: handle 2023-07-20 where I spent ~ 2 hours on a chrome extension for the line-height rule.  precipitated by fprs by acct 38280, which I rejected after I had finished writing the chrome extension IIRC.    unclear how those two hours should be counted.   maybe under that acct and rule.

- by time: to do: handle 2023-07-25 , ~ 14:00 (my time zone), when I worked on the bookmarklet for ~ 1 hr (in response to an r17 fpr), then stopped and started toggl, then (probably) processed the r17 fprs for acct 6451.  I say "probably" because ATOW I haven't done it yet. 

- by time: to do: handle 2023-07-21 bookmarklet coding. 

- by time: offset 6 hours? 
	- 2023-06-06 15:39:03;2023-06-20 19:50:27;sia-r73;N;9343;1135195
		2023-06-06 15:45:51;2023-06-20 19:48:47;sia-r73;Y;9343;1135195
		2023-06-06 15:39:43;2023-06-20 19:50:26;sia-r73;N;9343;1135195
		2023-06-06 15:44:17;2023-06-20 19:50:26;sia-r73;N;9343;1135195
	- https://track.toggl.com/reports/detailed/6754835/period/thisWeek/tags/14191849 
	- "False positive reports for june 6.   finished."  13:08 - 13:59 
	- none reported by this acct on any other day june in june.  just june 6. 

- by time: offset 6 hours: strong evidence: 
	- 2023-06-16 16:09:27 2023-06-16 16:09:39 sia-r83 Y 6000394 https://my2.siteimprove.com/Auth/Direct?accountId=6000394&back=%2FSupportTools%2FA11YSupport%2FDecisionSupport
	- https://track.toggl.com/reports/detailed/6754835/period/prevWeek/projects/0/tags/14191849  says "recent backlog.  csa group." from 10:01 - 10:30.  csa group acct id is 6000394 

'''

def getAlfaRuleDocsUrlFromRuleId(alfaRuleId_):
	r = 'https://alfa.siteimprove.com/rules/%s' % alfaRuleId_
	return r

def get_direct_link(datacenter_, account_id_):
	if datacenter_ == 'eu':
		r = f'https://my2.siteimprove.com/Auth/Direct?accountId={account_id_}&back=%2FSupportTools%2FA11YSupport%2FDecisionSupport'
	elif datacenter_ == 'us':
		r = f'https://my2.us.siteimprove.com/Auth/Direct?accountId={account_id_}&back=%2FSupportTools%2FA11YSupport%2FDecisionSupport'
	else:
		raise Exception()
	return r
	
def parseFpDecisionDateTimeStr(str_):
	# Parse the string into a naive datetime object (no timezone information)
	naive_datetime = datetime.datetime.strptime(str_, "%Y-%m-%d %H:%M:%S")
	
	# Assume the string is in a timezone that is 6 hours ahead of Toronto i.e. 2 hours ahead of UTC
	# This probably has many bugs around daylight savings time.  Or maybe even all of winter.  
	# I wrote it in June.  
	utc_offset = datetime.timedelta(hours=2)
	timezone_ahead_of_utc = pytz.FixedOffset(utc_offset.total_seconds() // 60)
	aware_datetime = timezone_ahead_of_utc.localize(naive_datetime)
	
	# Convert to your local timezone
	local_timezone = pytz.timezone('America/New_York')  
	local_datetime = aware_datetime.astimezone(local_timezone)
	
	return local_datetime
	
def parseTogglTimesheetDateTimeStrs(dateStr_, timeStr_):
	dateTimeStr = f'{dateStr_} {timeStr_}'
	# Parse the string into a naive datetime object (no timezone information)
	naive_datetime = datetime.datetime.strptime(dateTimeStr, "%Y-%m-%d %H:%M:%S")
	
	# Assume the string is in Toronto time.  i.e. 4 hours behind UTC
	# This probably has many bugs around daylight savings time.  Or maybe even all of winter.  
	# I wrote it in June.  
	utc_offset = datetime.timedelta(hours=-4)
	timezone_ahead_of_utc = pytz.FixedOffset(utc_offset.total_seconds() // 60)
	aware_datetime = timezone_ahead_of_utc.localize(naive_datetime)
	
	# Convert to your local timezone
	local_timezone = pytz.timezone('America/New_York')  
	local_datetime = aware_datetime.astimezone(local_timezone)
	
	return local_datetime
	

class Event:

	@staticmethod
	def createTogglWindowStart(datetime_):
		r = Event()
		r.tipe = 'toggl-window-start'
		r.datetime = datetime_
		return r
		
	@staticmethod
	def createTogglWindowEnd(datetime_):
		r = Event()
		r.tipe = 'toggl-window-end'
		r.datetime = datetime_
		return r

	@staticmethod
	def createFpDecision(datetime_, ruleId_, accountId_):
		assert isinstance(datetime_, datetime.datetime)
		r = Event()
		r.tipe = 'fp-decision'
		r.datetime = datetime_
		r.ruleId = ruleId_
		r.accountId = accountId_
		return r
		
	def __str__(self):
		if self.tipe == 'fp-decision':
			return f'{self.datetime} {self.tipe} {self.ruleId} {self.accountId}'
		else:
			return f'{self.datetime} {self.tipe}'

if __name__ == '__main__':

	if 1:
		inputFpDecisionsFilenameEU = os.path.expanduser('~/notes/fprs-csv-files-from-martin/reviewed_fp_decisions_2023_jan_1_to_oct_6_eu.csv')
		inputFpDecisionsFilenameUS = os.path.expanduser('~/notes/fprs-csv-files-from-martin/reviewed_fp_decisions_2023_jan_1_to_oct_6_us.csv')
	else:
		inputFpDecisionsFilenameEU = os.path.expanduser('~/notes/fprs-csv-files-from-martin/reviewed_fp_decisions_2023_06_21.csv')
		inputFpDecisionsFilenameUS = os.path.expanduser('~/notes/fprs-csv-files-from-martin/reviewed_fp_decisions_2023_06_21_us_datacenter_dummy.csv')
	#input_toggl_timesheet_filename = "/tmp/Toggl_time_entries_2023-01-01_to_2023-12-31(9).csv" # jan 1 2023 - ~ june 20 2023 
	input_toggl_timesheet_filename = "/tmp/Toggl_time_entries_2023-01-01_to_2023-12-31(9)_copy0.csv" # ~ may 20 2023 - ~ june 20 2023 
    
	topN = 20
	
	events = []

	ruleIdToDecisionTally = collections.defaultdict(lambda: 0)
	accountIdToDecisionTally = collections.defaultdict(lambda: 0)
	accountIdToNumApprovals = collections.defaultdict(lambda: 0)
	accountIdToNumRejections = collections.defaultdict(lambda: 0)

	accountIdToDatacenter = {}

	accountIdsToIgnore = {
		'30156', # Siteimprove Internal Marketing 
		'6177223', # Solutions Team demo account 
	}

	# These IDs are from ~/notes/fprs-classification.txt 
	approvalClassificationIdToLongDesc = {
		"c2444ae1": "not rule-specific > recommend (in approval comment) to customer that they set up an \"exclude content\" rule",
		"530db3af": "not rule-specific > site is on non-JS crawl and I suspect that these occurrences would disappear if they switched to JS crawl",
		"59f36177": "not rule-specific > site is on JS crawl and something about the site is difficult i.e. crawler config changes won't help.  Maybe unimplemented possible crawler enhancements would help.",
		"7efa8c9e": "not rule-specific > site is on JS crawl and problem could probably be fixed by changing crawler configuration eg. timing, \"scroll down\" - support ticket pending",
		"b54f5c25": "not rule-specific > site is on JS crawl and problem could probably be fixed by changing crawler configuration eg. timing, \"scroll down\" - support ticket not pending",
		"0514e095": "rule-specific > (deprecated) is due to an alfa bug or unimplemented possible enhancement", 
		"97a6b71d": "rule-specific > is due to an alfa bug or unimplemented possible enhancement > bug: contrast rules on <select>'s <option> elements: https://siteimprove-wgs.atlassian.net/browse/CST-1378",
		"d8cd3ac9": "rule-specific > is due to an alfa bug or unimplemented possible enhancement > alfa issue for contrast rules r66 and r69: exclude decorative text (AKA symbols AKA non-text content) like | , &",
		"66bfa4e7": "rule-specific > is due to an alfa bug or unimplemented possible enhancement > :where pseudo-class not supported",
		"59af3ce2": "rule-specific > \"no contest\"",
		"6a2b3f6f": "rule-specific > is due to an alfa bug or unimplemented possible enhancement > general",
		"81ef44ea": "I can't tell whether it's rule-specific or not",
		"d82d511e": "no classification ID present",
	}
	approvalClassificationIdToShortDesc = {
		"c2444ae1": "exclude content recommend",
		"530db3af": "non-JS crawler",
		"59f36177": "crawler feature",
		"7efa8c9e": "crawler config, ticket pending",
		"b54f5c25": "crawler config, ticket not pending",
		"0514e095": "(deprecated)", 
		"97a6b71d": "alfa bug/feature > contrast on <option> bug",
		"d8cd3ac9": "alfa bug/feature > contrast on decorative text",
		"66bfa4e7": "alfa bug/feature > :where",
		"59af3ce2": "\"no contest\"",
		"6a2b3f6f": "alfa bug/feature > general",
		"81ef44ea": "mystery",
		"d82d511e": "no classification ID present",
	}
	approvalClassificationIdsForAlfaBugsAndFeatures = {"97a6b71d", "d8cd3ac9", "66bfa4e7", "6a2b3f6f"}
	assert approvalClassificationIdToLongDesc.keys() == approvalClassificationIdToShortDesc.keys()
	approvalClassificationIds = set(approvalClassificationIdToLongDesc.keys())


	approvalClassificationIdNotPresent = 'd82d511e'
	assert approvalClassificationIdNotPresent in approvalClassificationIds

	# I got this by running this: curl 'https://raw.githubusercontent.com/Siteimprove/alfa-web-extension/main/src/localization/locales/en/messages.json?token=GHSAT0AAAAAACH6EPKTCNNW6RZRQUYKRI52ZJSQQ4Q' | jq 'to_entries | map(select(.key | test("ruleR[0-9]+Title"))) | map({(.key): .value.message}) | add ' | sed -e 's/ruleR([0-9]*)Title/sia-r\1/' | clip 
	ruleIdToTitle = \
		{
		"sia-r109": "",
		"sia-r10": "Autocomplete does not work as intended ",
		"sia-r110": "Some roles are invalid",
		"sia-r11": "Link missing a text alternative",
		"sia-r12": "Button missing a text alternative",
		"sia-r13": "Inline frame missing a text alternative",
		"sia-r14": "Visible label and accessible name do not match",
		"sia-r15": "Multiple inline frames with the same text alternative",
		"sia-r16": "Required ARIA attribute is missing",
		"sia-r17": "Hidden element has focusable content",
		"sia-r18": "ARIA attribute unsupported or prohibited",
		"sia-r19": "Invalid state or property",
		"sia-r1": "Page missing a title",
		"sia-r20": "ARIA attribute does not exist",
		"sia-r21": "All roles are invalid",
		"sia-r22": "Captions have not been provided",
		"sia-r23": "A transcript has not been provided",
		"sia-r24": "A transcript hasn't been provided",
		"sia-r25": "The audio doesn't contain all information in the video",
		"sia-r26": "The video is not a media alternative for text",
		"sia-r27": "Video missing captions",
		"sia-r28": "Image button missing a text alternative",
		"sia-r29": "The audio isn't a media alternative for text",
		"sia-r2": "Image missing a text alternative",
		"sia-r30": "Audio missing a transcript",
		"sia-r31": "The video is not a media alternative for text",
		"sia-r32": "A separate audio alternative has not been provided",
		"sia-r33": "A transcript hasn't been provided",
		"sia-r34": "The video doesn't have a description track",
		"sia-r35": "Video without audio missing an accessible alternative",
		"sia-r36": "Description track is incomplete",
		"sia-r37": "Video missing an audio-description",
		"sia-r38": "Video with audio missing an accessible alternative",
		"sia-r39": "Image file name is not an appropriate text alternative",
		"sia-r3": "Element IDs are not unique ",
		"sia-r40": "Page region missing an accessible name",
		"sia-r41": "Links on the same page with the same text alternative",
		"sia-r42": "Role not inside the required context",
		"sia-r43": "Vector image missing a text alternative",
		"sia-r44": "Page orientation is locked",
		"sia-r45": "Table headers aren't referenced correctly",
		"sia-r46": "No data cells assigned to table header",
		"sia-r47": "Page zoom is restricted",
		"sia-r48": "Audio plays for longer than 3 seconds",
		"sia-r49": "Audio has no control mechanism",
		"sia-r4": "Page language has not been identified ",
		"sia-r50": "Audio plays automatically and can't be switched off",
		"sia-r53": "Headings are not structured",
		"sia-r54": "Field input error is not announced in full",
		"sia-r55": "Page sections with the same name do not serve the same purpose",
		"sia-r56": "Landmarks are not uniquely identifiable",
		"sia-r57": "Text not included in an ARIA landmark",
		"sia-r59": "Page missing headings",
		"sia-r5": "Page language not recognized ",
		"sia-r60": "Grouped form controls missing an accessible name",
		"sia-r61": "Page does not start with a level 1 heading",
		"sia-r62": "Links are not clearly identifiable",
		"sia-r63": "Object missing a text alternative",
		"sia-r64": "Empty headings",
		"sia-r65": "Keyboard focus indicator is missing",
		"sia-r66": "Color contrast does not meet enhanced requirement",
		"sia-r67": "Decorative image is exposed to assistive technologies",
		"sia-r68": "Container element is empty",
		"sia-r69": "Color contrast does not meet minimum requirement",
		"sia-r70": "HTML element is deprecated or obsolete",
		"sia-r71": "Uneven spacing in text",
		"sia-r72": "Text in all caps",
		"sia-r73": "Line height is below minimum value",
		"sia-r74": "Font size is fixed",
		"sia-r75": "Font size is too small",
		"sia-r76": "Table header cell is missing a header role",
		"sia-r77": "Table cell missing context",
		"sia-r78": "Content missing after heading",
		"sia-r79": "Improper use of preformatted text element",
		"sia-r7": "Content language not recognized ",
		"sia-r80": "Line height is fixed",
		"sia-r81": "Links in the same context with the same text alternative",
		"sia-r82": "Form error indicators are not sufficient",
		"sia-r83": "Text is clipped when resized",
		"sia-r84": "Scrollable element is not keyboard accessible",
		"sia-r85": "Overuse of italics",
		"sia-r86": "Presentational element is exposed to assistive technologies",
		"sia-r87": "Skip to main content link is missing",
		"sia-r88": "",
		"sia-r89": "",
		"sia-r8": "Form field missing a label ",
		"sia-r90": "Role with implied hidden content has keyboard focus",
		"sia-r91": "Letter spacing does not meet minimum requirement",
		"sia-r92": "Word spacing does not meet minimum requirement",
		"sia-r93": "Line height does not meet minimum requirement",
		"sia-r94": "Menu item missing a text alternative",
		"sia-r95": "Interactive content excluded from keyboard navigation",
		"sia-r96": "Page refreshes or redirects without warning",
		"sia-r9": "Page refreshes or redirects without warning (within 20 hours)"
		}

	approvalClassificationIdsStartDate = datetime.date(year=2023, month=9, day=1)
	numApprovalsAfterStartDateWithoutClassificationId = 0
	approvalClassificationIdToAccountIdToTally = collections.defaultdict(lambda: collections.defaultdict(lambda: 0))
	ruleIdToNumApprovalsRelatedToAlfaBugsAndFeatures = collections.defaultdict(lambda: 0)

	for inputFpDecisionsFilename in [inputFpDecisionsFilenameEU, inputFpDecisionsFilenameUS]:
		datacenter = {inputFpDecisionsFilenameEU:'eu', inputFpDecisionsFilenameUS:'us'}[inputFpDecisionsFilename]
		with open(inputFpDecisionsFilename) as fin:
			csvreader = csv.DictReader(fin, delimiter=';')
			for iRow, row in enumerate(csvreader):
				insertedTimestamp = row['insert_ts']; updatedTimestamp = row['updated_ts']; ruleId = row['rule_id']
				approved = row['approved_yn']; accountId = row['account_id']
				siteId = row['site_id']; reviewerNote = row.get('support_note', '')
				approved = {'Y':True, 'N':False}[approved]
				if accountId in accountIdsToIgnore: continue
				updatedDateTime = parseFpDecisionDateTimeStr(updatedTimestamp)
				if 0: print(reviewerNote)
				if not approved and any(x in reviewerNote for x in approvalClassificationIds):
					print('WARN: rejection w/ approval classification ID:')
					#print('full info:', row)
					print(f'{ruleIdToTitle[ruleId]}, reported {insertedTimestamp}, updated {updatedTimestamp}')
					print(get_direct_link(datacenter, accountId))
					print()
				elif approved and (updatedDateTime.date() >= approvalClassificationIdsStartDate):
					approvalClassificationIdsPresent = {x for x in approvalClassificationIds if x in reviewerNote}
					assert approvalClassificationIdNotPresent not in approvalClassificationIdsPresent
					if len(approvalClassificationIdsPresent) == 0:
						#print('WARN: approval w/o approval classification ID:', updatedTimestamp)
						#print('full info:', row)
						#print(f'{ruleIdToTitle[ruleId]}, reported {insertedTimestamp}, updated {updatedTimestamp}')
						#print(get_direct_link(datacenter, accountId))
						#print()
						approvalClassificationId = approvalClassificationIdNotPresent
					elif len(approvalClassificationIdsPresent) == 1:
						approvalClassificationId = list(approvalClassificationIdsPresent)[0]
					else:
						raise Exception(f'mult IDs present: {reviewerNote}')
					if approvalClassificationId == '0514e095': # deprecated 
						approvalClassificationId = '6a2b3f6f'
					if approvalClassificationId in approvalClassificationIdsForAlfaBugsAndFeatures:
						ruleIdToNumApprovalsRelatedToAlfaBugsAndFeatures[ruleId] += 1
					approvalClassificationIdToAccountIdToTally[approvalClassificationId][accountId] += 1
		
				
				ruleIdToDecisionTally[ruleId] += 1
				accountIdToDecisionTally[accountId] += 1
				(accountIdToNumApprovals if approved else accountIdToNumRejections)[accountId] += 1
				event = Event.createFpDecision(updatedDateTime, ruleId, accountId)
				events.append(event)
				accountIdToDatacenter[accountId] = datacenter

	with open(input_toggl_timesheet_filename, newline='', encoding='utf-8-sig') as fin:
		csvreader = csv.DictReader(fin)
		for iRow, row in enumerate(csvreader):
			assert 'fprs' in row['Tags']
			#print(row)
			togglWindowStartDateTime = parseTogglTimesheetDateTimeStrs(row['Start date'], row['Start time'])
			events.append(Event.createTogglWindowStart(togglWindowStartDateTime))
			togglWindowEndDateTime = parseTogglTimesheetDateTimeStrs(row['End date'], row['End time'])
			events.append(Event.createTogglWindowEnd(togglWindowEndDateTime))
			#print(togglWindowStartDateTime, togglWindowEndDateTime)
			continue
		
	ruleIdToDecisionTally = dict(ruleIdToDecisionTally)
	accountIdToDecisionTally = dict(accountIdToDecisionTally)
	accountIdToNumApprovals = dict(accountIdToNumApprovals)
	accountIdToNumRejections = dict(accountIdToNumRejections)
	
	events.sort(key=lambda x: x.datetime)

	print('** BY APPROVAL CLASSIFICATION ID **')
	print()
	
	shortDescMaxLen = max(len(x) for x in approvalClassificationIdToShortDesc.values())

	# Sort by decreasing tally of inner dict values.  Thanks chatgpt. 
	approvalClassificationIdToAccountIdToTally = \
		{k: v for k, v in sorted(approvalClassificationIdToAccountIdToTally.items(), key=lambda item: sum(item[1].values()), reverse=True)}

	numApprovalsAllIdsAllAccounts = sum([item for sublist in approvalClassificationIdToAccountIdToTally.values() for item in sublist.values()])
	percentagesTally = 0.0
	for classId, accountIdToTally in approvalClassificationIdToAccountIdToTally.items():
		numApprovalsCurIdAllAccounts = sum(accountIdToTally.values())
		numer = numApprovalsCurIdAllAccounts; denom = numApprovalsAllIdsAllAccounts
		percentagesTally += numer/denom
		print(f'{classId} {approvalClassificationIdToShortDesc[classId]:<{shortDescMaxLen}}: {numer}/{denom} = {int(100*numer/denom)}%.  Over {len(accountIdToTally)} accounts.')
	assert percentagesTally == 1.0
	print()

	ruleIdToNumApprovalsRelatedToAlfaBugsAndFeatures = \
		{k: v for k, v in sorted(ruleIdToNumApprovalsRelatedToAlfaBugsAndFeatures.items(), key=lambda item: item[1], reverse=True)}
	denom = sum(ruleIdToNumApprovalsRelatedToAlfaBugsAndFeatures.values())
	for ruleId, numApprovalsRelatedToAlfaBugsAndFeatures in ruleIdToNumApprovalsRelatedToAlfaBugsAndFeatures.items():
		numer = numApprovalsRelatedToAlfaBugsAndFeatures
		print(f'{ruleId} "{ruleIdToTitle[ruleId]}": {numer}/{denom} = {int(100*numer/denom)}%')

	NUMBERS=0
	if NUMBERS:
		print('** BY NUMBERS **')
		print()


		totalDecisionsTallied = sum(ruleIdToDecisionTally.values())
		totalDecisionsTallied2 = sum(accountIdToDecisionTally.values())
		assert totalDecisionsTallied == totalDecisionsTallied2

		print(f'By ruleIds, top {topN}:')
		ruleIdToDecisionTallySortedItems = sorted(ruleIdToDecisionTally.items(), key=lambda item: item[1], reverse=True)
		for ruleId, decisionTally in ruleIdToDecisionTallySortedItems[:topN]:
			decisionTallyPercentageForThisRuleId = 100*decisionTally/totalDecisionsTallied
			print('Rule %s: %s/%s = %d%%.  (%s)' % (ruleId, decisionTally, totalDecisionsTallied, decisionTallyPercentageForThisRuleId, getAlfaRuleDocsUrlFromRuleId(ruleId)))

		print()
		print(f'accountIds top {topN}:')
		accountIdToDecisionTallySortedItems = sorted(accountIdToDecisionTally.items(), key=lambda item: item[1], reverse=True)
		for accountId, decisionTally in accountIdToDecisionTallySortedItems[:topN]:
			decisionTallyPercentageForThisAccountId = 100*decisionTally/totalDecisionsTallied
			datacenter = accountIdToDatacenter[accountId]
			print('Account %s: %s/%s = %d%% (%s)' % (accountId, decisionTally, totalDecisionsTallied, decisionTallyPercentageForThisAccountId, get_direct_link(datacenter, accountId)))

	VERBOSE = 0
	if VERBOSE:
		print()
		print()
		print('** VERBOSE **')
		print()

		verboseAccountIds = ['6451']
		for accountId in verboseAccountIds:
			approvals = accountIdToNumApprovals[accountId]
			rejections = accountIdToNumRejections[accountId]
			decisions = accountIdToDecisionTally[accountId]
			assert approvals + rejections == decisions
			print(f'account {accountIdToDecisionTally[accountId]}: '
				+f'approvals: {approvals}.  rejections: {rejections}.  decisions: {decisions}.')

	TIME=0
	if TIME:
		print('** BY TIME **')
		print()

		weAreInATogglWindow = False
		curTogglWindowStartEvent = None
		ruleIdToTimeTally = collections.defaultdict(lambda: datetime.timedelta(0))
		accountIdToTimeTally = collections.defaultdict(lambda: datetime.timedelta(0))
		timeDeltaForTallyOfAllTogglWindows = datetime.timedelta(0)
		numFpDecisionsMadeInsideATogglWindow = 0
		LOG = False
		for iCurEvent in range(len(events)):
			curEvent = events[iCurEvent]; prevEvent = events[iCurEvent-1]
			if LOG:
				#print(prevEvent)
				print(curEvent)
				#print('---')
			if curEvent.tipe == 'toggl-window-start':
				assert not weAreInATogglWindow
				weAreInATogglWindow = True
				curTogglWindowStartEvent = curEvent
			elif curEvent.tipe == 'toggl-window-end':
				assert weAreInATogglWindow
				weAreInATogglWindow = False
				timeDeltaForTallyOfAllTogglWindows += curEvent.datetime - curTogglWindowStartEvent.datetime
				curTogglWindowStartEvent = None
			if iCurEvent == 0: continue 
			if curEvent.tipe == 'fp-decision':
				if weAreInATogglWindow:
					numFpDecisionsMadeInsideATogglWindow += 1
					if LOG: print('^^ fp decision made inside of a toggl window.')
				else:
					if LOG: print('^^ fp decision made outside of a toggl window.')
			if curEvent.tipe == 'fp-decision' and weAreInATogglWindow:
				timeDeltaForHowLongTheCurEventFpDecisionTook = curEvent.datetime - prevEvent.datetime
				ruleIdToTimeTally[curEvent.ruleId] += timeDeltaForHowLongTheCurEventFpDecisionTook
				accountIdToTimeTally[curEvent.accountId] += timeDeltaForHowLongTheCurEventFpDecisionTook
				#print(timeDelta) # tdr 


		if LOG:
			for accountId in accountIdToTimeTally.keys():
				print(accountId)

		numFpDecisionsTotal = len([e for e in events if e.tipe == 'fp-decision'])
		print(f'percentage of fp decisions filed under rule/account: {100*numFpDecisionsMadeInsideATogglWindow/numFpDecisionsTotal:.0f}')
		
		print()

		totalFpDecisionTimeTracked = sum(ruleIdToTimeTally.values(), datetime.timedelta(0))
		totalFpDecisionTimeTracked2 = sum(accountIdToTimeTally.values(), datetime.timedelta(0))
		assert totalFpDecisionTimeTracked == totalFpDecisionTimeTracked2
		print(f'hours filed under rule/account: {totalFpDecisionTimeTracked.total_seconds()/3600:.1f}  toggl time: {timeDeltaForTallyOfAllTogglWindows.total_seconds()/3600:.1f}')
		print()
		
		print(f'ruleIds top {topN}:')
		ruleIdToTimeTallySortedItems = sorted(ruleIdToTimeTally.items(), key=lambda item: item[1], reverse=True)
		#percentTally = 0
		for ruleId, timeTally in ruleIdToTimeTallySortedItems[:topN]:
			timeTallyPercentage = 100*timeTally/totalFpDecisionTimeTracked
			print('%s %s %d%%' % (ruleId, timeTally, timeTallyPercentage))
			#percentTally += timeTallyPercentage
		#print(percentTally)
			
		print()
			
		print(f'accountIds top {topN}:')
		#percentTally = 0
		accountIdToTimeTallySortedItems = sorted(accountIdToTimeTally.items(), key=lambda item: item[1], reverse=True)
		for accountId, timeTally in accountIdToTimeTallySortedItems[:topN]:
			timeTallyPercentage = 100*timeTally/totalFpDecisionTimeTracked
			print('%s %s %d%%' % (accountId, timeTally, timeTallyPercentage))
			#percentTally += timeTallyPercentage
		#print(percentTally)



